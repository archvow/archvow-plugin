"""Adopting existing code: `archvow init <package> --adopt` proposes `layer_paths`.

An existing project keeps its files where they are. The proposal reads folder and file names it
recognises (core, models, crud, services, api...) and maps each to a layer by position in the
template (foundations, domain, I/O, services or jobs, entry points). It is written into the project
vow, printed, and reviewed by the architects in the merge request like any guard change. Files
with no known name stay unmapped and are listed: an architect maps them by hand or leaves them out.
"""

from __future__ import annotations

from pathlib import Path

from archvow.checks.engine import IGNORED_DIRS
from archvow.checks.layers import layer_paths, mapped_layer
from archvow.model import store
from archvow.templates import Template

# Names that say what a folder or module is for, by layer position: foundations, domain, I/O,
# services/jobs, entry points (every built-in template has these five layers, in this order).
ROLES: list[set[str]] = [
    {"core", "common", "config", "configs", "settings", "shared", "constants", "utils", "util", "helpers",
     "lib", "plugins", "hookspecs"},
    {"models", "model", "schemas", "schema", "domain", "entities", "entity", "types", "transformations",
     "transforms", "transformation", "recipes", "parsers", "parser", "logic"},
    {"crud", "repository", "repositories", "db", "database", "io", "readers", "reader", "writers",
     "writer", "storage", "clients", "client", "adapters", "migrations", "sources", "sinks", "gateways"},
    {"services", "service", "jobs", "job", "pipelines", "pipeline", "usecases", "use_cases", "workflows"},
    {"api", "routes", "routers", "router", "endpoints", "views", "cli", "commands", "main", "app",
     "entrypoints", "entrypoint", "__main__", "server"},
]


def _role(word: str) -> int | None:
    for index, names in enumerate(ROLES):
        if word.lower() in names:
            return index
    return None


def propose(root: Path, data: dict, template: Template) -> tuple[dict[str, list[str]], list[str]]:
    """({layer: [paths]}, unmapped files) for the first container's Python files that are in no layer."""
    container = data["containers"][0]
    base = root / container["path"]
    layers = list(template.layer_names)
    existing = layer_paths(data)
    proposal: dict[str, list[str]] = {}
    unmapped: list[str] = []
    for path in sorted(base.rglob("*.py")):
        rel_parts = path.relative_to(base).parts
        if any(part.startswith(".") or part in IGNORED_DIRS for part in rel_parts[:-1]):
            continue
        rel = path.relative_to(root).as_posix()
        if (rel_parts[0] in layers or mapped_layer(existing, rel) is not None
                or (len(rel_parts) == 1 and path.name == "__init__.py")):
            continue
        if any(mapped_layer([(p, layer)], rel) for layer, paths in proposal.items() for p in paths):
            continue  # its folder is proposed already
        words = [*rel_parts[:-1], path.stem]
        for depth, word in enumerate(words):
            role = _role(word)
            if role is None:
                continue
            layer = layers[min(role, len(layers) - 1)]
            folder = depth < len(words) - 1
            target = (base.joinpath(*rel_parts[:depth + 1]).relative_to(root).as_posix() + "/" if folder
                      else rel)
            proposal.setdefault(layer, []).append(target)
            break
        else:
            if path.name != "__init__.py":
                unmapped.append(rel)
    return proposal, unmapped


def write(root: Path, proposal: dict[str, list[str]], layers: list[str]) -> None:
    """Add the proposal to the project's `layer_paths` (what is mapped already stays), layers in the
    template's order."""
    data = store.load(root)
    current = data.get("layer_paths") or {}
    for layer, paths in proposal.items():
        entries = current.setdefault(layer, [])
        entries.extend(p for p in paths if p not in entries)
    order = {name: index for index, name in enumerate(layers)}
    data["layer_paths"] = dict(sorted(current.items(), key=lambda item: order.get(item[0], len(order))))
    store.save(root, data)
