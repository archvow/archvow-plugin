"""The tests that are evidence: do they check something (ARCH045), did they run and pass (ARCH046)?

A test marked ``@pytest.mark.invariant("clean_orders.INV1")``, ``decision(3)``, ``rule("R2")`` or
``example("FATTRIB-012-negative-quantity")`` is the evidence of that item. archvow reads three levels of evidence:

* declared - the mark is there (ARCH031, ARCH038 look for it);
* executed - the test ran and passed: `archvow check --test-report test-results.xml` reads pytest's
  JUnit report (ARCH046, for every marked test; the generated CI always passes the report);
* verified - what the test checks is right: a person reviewing the test. archvow does not judge it.

ARCH045 only catches a test that cannot fail: no assert, `assert True`, `assert x == x`, an empty or
`pass` body. A test checks something when it has an assert that can fail, `pytest.raises` /
`pytest.warns`, a call whose name starts with `assert` (assert_frame_equal, self.assertEqual,
assertDataFrameEqual...), `pytest.fail`, or calls a helper that does - a helper of the same test file
is read, one imported from the tests folder (conftest, helpers) is trusted.
"""

from __future__ import annotations

import ast
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path

from archvow.checks.engine import Checker
from archvow.foundation import logs
from archvow.model.spec import mode

log = logs.get("evidence")

MARKS = ("invariant", "decision", "rule", "example")
SKIP_DIRS = {"venv", "env", "build", "dist", "node_modules", "__pycache__", "site-packages"}
_CHECK_CONTEXTS = {"raises", "warns", "deprecated_call", "assertRaises", "assertWarns", "assertRaisesRegex",
                   "assertWarnsRegex", "assertLogs"}


@dataclass
class MarkedTest:
    file: str  # relative to the project, e.g. tests/p1_domain/test_clean_orders.py
    line: int
    name: str
    marks: list[str] = field(default_factory=list)  # e.g. ['invariant("clean_orders.INV1")', 'decision(3)']
    checks: bool = True
    skipped: bool = False  # marked skip / skipif / xfail, or calls pytest.skip: it never proves anything


def _mark_name(deco: ast.expr) -> str:
    target = deco.func if isinstance(deco, ast.Call) else deco
    return target.attr if isinstance(target, ast.Attribute) else getattr(target, "id", "")


def _is_mark(deco: ast.expr) -> bool:
    """A pytest mark archvow reads. `example` only as `pytest.mark.example(...)` / `mark.example(...)`:
    a bare `@example(...)` is Hypothesis's."""
    name = _mark_name(deco)
    return isinstance(deco, ast.Call) and name in MARKS and (name != "example" or isinstance(deco.func, ast.Attribute))


def _marks(node: ast.FunctionDef | ast.AsyncFunctionDef | ast.ClassDef) -> list[str]:
    return [ast.unparse(d).removeprefix("pytest.mark.").removeprefix("mark.") for d in node.decorator_list
            if _is_mark(d)]


def mark_values(test_marks: list[str], name: str, upper: bool = True) -> list[str]:
    """The values of one kind of mark, upper case: ['decision(1, 2)', 'rule("R2")'], 'decision' -> ['1', '2']."""
    values = []
    for mark in test_marks:
        if mark.startswith(f"{name}("):
            found = [v.strip().strip("'\"") for v in mark[len(name) + 1:-1].split(",") if v.strip()]
            values += [v.upper() for v in found] if upper else found
    return values


def describe(test_marks: list[str]) -> str:
    """'clean_orders.INV1, decision 3, rule R2, example FATTRIB-012-paid': what a test is the evidence of."""
    words = {"invariant": "", "decision": "decision ", "rule": "rule ", "example": "example "}
    return ", ".join(f"{words[kind]}{value}" for kind in MARKS for value in mark_values(test_marks, kind, upper=False))


def skipped(node: ast.FunctionDef | ast.AsyncFunctionDef, classes: list[ast.ClassDef] | None = None) -> bool:
    """Marked skip, skipif or xfail (on the test or its class), or calls pytest.skip / pytest.xfail."""
    decorators = [*node.decorator_list, *(d for c in classes or [] for d in c.decorator_list)]
    if any(_mark_name(d) in ("skip", "skipif", "xfail") for d in decorators):
        return True
    return any(isinstance(sub, ast.Call) and _called_name(sub) in ("skip", "xfail")
               and isinstance(sub.func, ast.Attribute) for sub in ast.walk(node))


def _same(left: ast.expr, right: ast.expr) -> bool:
    return ast.dump(left) == ast.dump(right)


def _assert_can_fail(node: ast.Assert) -> bool:
    test = node.test
    if isinstance(test, ast.Constant):
        return not bool(test.value)  # `assert False` fails; `assert True`, `assert 1` never do
    # `assert x == x` never fails
    return not (isinstance(test, ast.Compare) and len(test.ops) == 1
                and isinstance(test.ops[0], (ast.Eq, ast.Is, ast.LtE, ast.GtE))
                and _same(test.left, test.comparators[0]))


def _called_name(call: ast.Call) -> str:
    func = call.func
    return func.attr if isinstance(func, ast.Attribute) else func.id if isinstance(func, ast.Name) else ""


class _Helpers:
    """The functions of one test file, and the names it imports from the tests folder."""

    def __init__(self, tree: ast.Module) -> None:
        self.defs = {n.name: n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}
        self.trusted: set[str] = set()  # imported from the tests folder or conftest: not read, trusted
        for node in tree.body:
            if isinstance(node, ast.ImportFrom) and (
                    node.level or (node.module or "").split(".")[0] in ("tests", "conftest")):
                self.trusted.update(a.asname or a.name for a in node.names)


def checks_something(node: ast.AST, helpers: _Helpers, seen: set[str] | None = None) -> bool:
    """True when the body of `node` contains a check that can fail."""
    seen = seen if seen is not None else set()
    for sub in ast.walk(node):
        if isinstance(sub, ast.Assert) and _assert_can_fail(sub):
            return True
        if isinstance(sub, (ast.With, ast.AsyncWith)):
            for item in sub.items:
                if isinstance(item.context_expr, ast.Call) and _called_name(item.context_expr) in _CHECK_CONTEXTS:
                    return True
        if not isinstance(sub, ast.Call):
            continue
        name = _called_name(sub)
        if name.lower().startswith("assert") or name in ("fail", "raises", "warns"):
            return True
        if isinstance(sub.func, ast.Name) and name in helpers.trusted:
            return True
        if isinstance(sub.func, ast.Name) and name in helpers.defs and name not in seen:
            seen.add(name)
            if checks_something(helpers.defs[name], helpers, seen):
                return True
    return False


def _test_files(root: Path) -> list[Path]:
    base = root / "tests"
    if not base.is_dir():
        return []
    return [p for p in sorted(base.rglob("*.py"))
            if not any(part.startswith(".") or part in SKIP_DIRS for part in p.relative_to(base).parts[:-1])]


def marked_tests(root: Path) -> list[MarkedTest]:
    """Every test function that carries an invariant, decision, rule or example mark (on itself or its class).
    A test file that is not UTF-8 cannot be read: unreadable_tests() names it, so a "no marked test" message
    can say why (ARCH031, ARCH056)."""
    found: list[MarkedTest] = []
    for path in _test_files(root):
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            logs.swallowed(log, "marked_tests: UnicodeDecodeError")
            continue
        found += marked_in(text, path.relative_to(root).as_posix())
    return found


def unreadable_tests(root: Path) -> list[str]:
    """The test files whose marks cannot be read - not UTF-8, or not valid Python - each with the reason:
    "tests/p1/test_x.py is not UTF-8", "tests/p1/test_y.py has a syntax error (line 3)"."""
    out = []
    for path in _test_files(root):
        rel = path.relative_to(root).as_posix()
        try:
            ast.parse(path.read_text(encoding="utf-8"))
        except UnicodeDecodeError:
            out.append(f"{rel} is not UTF-8")
        except SyntaxError as exc:
            out.append(f"{rel} has a syntax error (line {exc.lineno or 0})")
    return out


def unreadable_hint(root: Path) -> str:
    """What a "no marked test" message adds when some test files cannot be read ("" when all can)."""
    unreadable = unreadable_tests(root)
    if not unreadable:
        return ""
    return f" ({', '.join(unreadable)}: {'its' if len(unreadable) == 1 else 'their'} marks cannot be read - fix it first)"


def marked_in(text: str, rel: str) -> list[MarkedTest]:
    """The marked tests of one test file's text (`rel`: its path in the project)."""
    try:
        tree = ast.parse(text)
    except SyntaxError:
        logs.swallowed(log, "marked_in: SyntaxError")
        return []
    helpers = _Helpers(tree)
    found: list[MarkedTest] = []
    seen: set[int] = set()
    for node in ast.walk(tree):
        if not isinstance(node, ast.ClassDef):
            continue
        class_marks = _marks(node)
        for method in node.body:
            if isinstance(method, (ast.FunctionDef, ast.AsyncFunctionDef)) and method.name.startswith("test"):
                marks = class_marks + _marks(method)
                seen.add(method.lineno)
                if marks:
                    found.append(MarkedTest(rel, method.lineno, method.name, marks,
                                            checks_something(method, helpers), skipped(method, [node])))
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.lineno not in seen and _marks(node):
            found.append(MarkedTest(rel, node.lineno, node.name, _marks(node), checks_something(node, helpers),
                                    skipped(node)))
    return found


def run_evidence(checker: Checker) -> None:
    """ARCH045 (tests that check nothing); ARCH046 with --test-report (marked tests that did not pass)."""
    strict = mode(checker.manifest) == "strict" or checker.complete
    for test in marked_tests(checker.root):
        if not test.checks:
            checker.add("ARCH045", f"{test.name} is the evidence of {', '.join(test.marks)} but checks nothing "
                        "(no assert that can fail) -> assert on what the component returns, or use "
                        "pytest.raises", test.file, test.line, escalate=strict)
    if checker.test_report is not None:
        check_report(checker, checker.test_report)


def _module_parts(test_file: str) -> list[str]:
    """tests/p1_domain/test_x.py -> ['tests', 'p1_domain', 'test_x']"""
    return test_file.removesuffix(".py").split("/")


def _belongs(classname: str, module: list[str]) -> bool:
    """Is a JUnit `classname` (tests.p1_domain.test_x, or ...test_x.TestClass) from this test file?
    pytest names it from its own root folder, so the file's path may appear after a few more folders."""
    parts = classname.split(".")
    size = len(module)
    for start in range(len(parts) - size + 1):
        if parts[start:start + size] == module:
            rest = parts[start + size:]
            return all(p[:1].isupper() for p in rest)  # what follows can only be test classes
    return False


def report_cases(report: Path) -> list[tuple[str, str, str, str]] | None:
    """The test cases of a JUnit report: (classname, file, name without its [parameters], state: passed |
    skipped | failed). None when the report cannot be read."""
    try:
        tree = ET.parse(report)
    except (ET.ParseError, OSError):
        logs.swallowed(log, "report_cases: ET.ParseError, OSError")
        return None
    cases = []
    for case in tree.iter("testcase"):
        tags = {child.tag for child in case}
        state = "failed" if tags & {"failure", "error"} else "skipped" if "skipped" in tags else "passed"
        cases.append((case.get("classname", ""), case.get("file", ""), case.get("name", "").split("[")[0], state))
    return cases


def state_of(test: MarkedTest, cases: list[tuple[str, str, str, str]]) -> str:
    """A marked test's state in the report: passed | skipped | failed | not run - matched by its file and
    its name, the worst case of a parametrized test."""
    rank = {"passed": 0, "skipped": 1, "failed": 2}
    module = _module_parts(test.file)
    states = [s for cls, file, name, s in cases if name == test.name
              and (file.replace("\\", "/").endswith(test.file) if file else _belongs(cls, module))]
    return max(states, key=rank.__getitem__) if states else "not run"


def check_report(checker: Checker, report: Path) -> None:
    """ARCH046: every marked test (of an invariant, a decision, a rule or an example) ran and passed in
    the JUnit report - matched by its file and its name, every case of a parametrized test included."""
    cases = report_cases(report)
    if cases is None:
        try:
            ET.parse(report)
        except (ET.ParseError, OSError) as exc:
            checker.add("ARCH046", f"cannot read the test report {report}: {exc}", report.as_posix())
        return
    for test in marked_tests(checker.root):
        state = state_of(test, cases)
        if state != "passed":
            checker.add("ARCH046", f"{test.name} (test of {describe(test.marks)}) {state} in {report.name} -> "
                        "run the tests with pytest --junitxml and make it pass", test.file, test.line)
