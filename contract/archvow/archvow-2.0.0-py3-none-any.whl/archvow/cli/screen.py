"""How `archvow show <component>` prints a component: its header, open items, examples, evidence and personal
data, from the view in cli/views.py.
"""

from __future__ import annotations

from archvow.briefs import ref_of
from archvow.cli.console import style as ui
from archvow.cli.output import count
from archvow.examples import SHOW_MAX_DIFFERENCES, TABLE_KINDS
from archvow.model import store
from archvow.model.spec import SEVERITIES
from archvow.privacy import columns_line
from archvow.views.component import report_name


def _print_ai_origin(item: dict, keep: str, indent: str = "        ") -> None:
    """Under an item an AI agent added: by whom and why, and the command that keeps it while no person did."""
    if not item.get("added_by"):
        return
    why = f": {item['why']}" if item.get("why") else ""
    if item.get("to_accept"):
        print(ui.warn(f"{indent}added by the AI ({item['added_by']}){why}") + ui.dim(f"  -> {keep}"))
    else:
        print(ui.dim(f"{indent}added by the AI ({item['added_by']}){why}"))


def _print_question(q: dict) -> None:
    print(f" S{q['number']:<2} {ui.mark('done' if q['status'] == 'answered' else 'open')} {q['question']}")
    for h in q.get("hazards", []):
        origin = "suggested" if h.get("suggested") else "your own"
        print(ui.dim(f"       {h['id']} {h['severity']} ({origin}): {h['description']}"))
        _print_ai_origin(h, f"archvow hazard accept {h['id']}", "         ")
        for inv in h["prevented_by"]:
            tested = "" if "tested" not in inv else " - tested" if inv["tested"] else " - not tested yet"
            print(ui.dim(f"       <- prevented by {inv['id']}: {inv['statement']}{tested}"))
        if not h["prevented_by"] and h["severity"] in ("critical", "high"):
            print(ui.dim("       <- prevented by nothing yet"))
    if "dismissed" in q:
        print(ui.dim(f"       not applicable: {q['dismissed']}"))
    suggestion = q.get("suggestion") or {}
    if suggestion.get("not_applicable"):
        print(ui.dim(f"       not applicable, says decision {suggestion['decision']['number']}: "
                     f"{suggestion['decision']['answer']}  -> archvow hazard dismiss <component> S{q['number']}"))
        return
    if suggestion.get("decision"):
        d = suggestion["decision"]
        print(ui.dim(f"       covered by decision {d['number']}: {d['answer']}  (hazard add without words: the "
                     f"hazard below, protected by decision {d['number']})"))
        if suggestion.get("hazard"):
            print(ui.dim(f"       suggested hazard: {suggestion['hazard']}"))
        return
    if suggestion.get("hazard"):
        print(ui.dim(f"       suggested hazard: {suggestion['hazard']}"))
    if suggestion.get("invariant"):
        print(ui.dim(f"       suggested invariant: {suggestion['invariant']}"))


def _open_counts(view: dict) -> tuple[int, int, int]:
    """Decisions to make, open safety questions, other open items (P/O/C, columns)."""
    others = sum(1 for q in view["questions"] if not q["answer"]) + sum(1 for c in view["columns"] if not c["class"])
    return (sum(1 for d in view["decisions"] if not d["answer"] and not d.get("proposed")),
            sum(1 for q in view["safety"] if q["status"] == "open"), others)


def print_component(view: dict) -> None:
    cid = view["component"]
    to_make, safety, others = _open_counts(view)
    kind = f", {view['kind']}" if view.get("kind") else ""
    print(ui.title(f"{cid} ({view['type']}{kind})") + f" - {view['description']}")
    owned = f" - owners: {' '.join(view['owners'])} (and the architects)" if view.get("owners") else ""
    print(ui.dim(f"status: {view['status']} - open: {count(to_make, 'decision')} to make, "
                 f"{count(safety, 'safety question')}, {count(others, 'other item')}{owned}"))
    if view.get("origin") == "ai":
        print(ui.warn(f"created by the AI ({view.get('created_by') or 'an agent'}), not accepted yet -> a person "
                      f"checks it, then archvow component accept {cid}"))
    if view.get("source"):
        print(ui.dim(f"drawn from: {view['source'].get('file', '')}"
                     + (f"#{view['source']['section']}" if view["source"].get("section") else "")))
    links = [f"uses {', '.join(view['uses'])}" if view.get("uses") else "",
             f"used by {', '.join(view['used_by'])}" if view.get("used_by") else ""]
    if any(links):
        print(ui.dim(" - ".join(x for x in links if x)))
    print()
    known = columns_line([(k["component"], k["columns"]) for k in view.get("known_columns", [])], cid)
    if known:  # the names its questions are about
        print(ui.dim(known + "\n"))
    for needed in view.get("missing", []):
        print(ui.warn(f"uses no {needed}: archvow component add {needed} <name> -d \"...\", then archvow component edit {cid} -u <name>_{needed}"))
    due = view.get("to_review") or []
    if due:  # ARCH057: recorded before the component changed
        print(ui.warn(f"To review - {'; '.join(sorted({d['why'] for d in due}))}: "
                      f"{', '.join(d['item'] for d in due)} may no longer hold."))
        print(ui.dim(f"  change one by recording it again; when every one still holds: archvow component accept {cid}\n"))
    print(ui.title("Decisions") + ui.dim(f" - {len(view['decisions']) - to_make} of {len(view['decisions'])} "
                                          f"made  -> archvow decision make {cid} <n> [\"answer\"]"))
    for d in view["decisions"]:
        review = ui.severity("warning", "  (to review)") if d.get("review") else ""
        print(f" {d['number']:>3}. {ui.mark('done' if d['answer'] else 'open')} {d['question']}{review}")
        _print_ai_origin(d, f"archvow question accept {cid} {d['number']} (or answer it)")
        if d["answer"]:
            origin = "" if not d["suggested"] else " (suggested)" if d["answer"] == d["suggested"] else " (your own)"
            origin = " (proposed by the AI, accepted)" if d.get("origin") == "ai" else origin
            if d.get("origin") == store.TYPE_ORIGIN:
                origin = f" (project answer, every {view['type']})"
            who = f"  - {d['by']}, {d['on']}" if view.get("file") and d.get("by") else ""
            print(ui.dim(f"        ->{origin} {d['answer']}{who}"))
        elif d.get("proposed"):
            print(ui.warn(f"        proposed by the AI, not reviewed: {d['proposed']}") +
                  ui.dim(f"  -> archvow decision accept {cid} {d['number']}"))
        elif d["suggested"]:
            print(ui.dim(f"        suggested: {d['suggested']}"))
        elif d.get("choices"):  # no safe default: answers to start from, none chosen for you
            print(ui.dim("        no default (it depends on this project) - to start from: "
                         + " | ".join(d["choices"])))
    if view["rules"]:
        print("\n" + ui.title("Rules") + ui.dim(f"  -> archvow rule add {cid} \"...\" | rule edit R<n> \"...\" | "
                                              "rule remove R<n>"))
        for r in view["rules"]:
            scope = "" if r["scope"] == cid else ui.dim(f"  ({r['scope']})")
            print(f"  {r['id']:>3}. {r['text']}{scope}")
            _print_ai_origin(r, f"archvow rule accept {r['id']}")
    _print_examples(view)
    if view.get("file"):
        _print_evidence(view)
    _print_personal(view)
    sets: dict[str, list] = {}
    for q in view["questions"]:
        sets.setdefault(q["title"], []).append(q)
    for title, questions in sets.items():
        done = sum(1 for q in questions if q["answer"])
        print("\n" + ui.title(title) + ui.dim(f" - {done} of {len(questions)} answered  -> archvow decision make "
                                             f"{cid} {questions[0]['set']}<n> \"...\""))
        for q in questions:
            print(f" {q['key']:<4} {ui.mark('done' if q['answer'] else 'open')} {q['question']}")
            if q["answer"]:
                print(ui.dim(f"        -> {q['answer']}"))
    if view["safety"]:
        print("\n" + ui.title("Safety") + ui.dim(f" - {len(view['safety']) - safety} of {len(view['safety'])} "
                                                f"answered  -> archvow hazard add {cid} S<n> {'|'.join(SEVERITIES)} "
                                                '["what must never happen"]'))
        for q in view["safety"]:
            _print_question(q)
    pending = [a for a in view["assumptions"] if a.get("status") != "accepted"]
    if view["assumptions"]:
        print("\n" + ui.title("Assumptions made while coding"))
        for a in view["assumptions"]:
            print(f" {a['number']:>3}. {ui.mark('done' if a.get('status') == 'accepted' else 'open')} "
                  f"[{a.get('status', 'proposed')}] {a['text']}")
        if pending:
            print(ui.dim(f"  -> a person runs archvow assumption accept {cid} <n> (or reject)"))
    tasks = view.get("tasks") or []
    if tasks:
        done = sum(1 for t in tasks if t["done"])
        print("\n" + ui.title("Tasks") + ui.dim(f" - {done} of {len(tasks)} done  -> archvow prompt {cid} "
                                               "(the next one), or --task <n>"))
        for t in tasks:
            print(f"  {t['task']:>3} {ui.mark('done' if t['done'] else 'open')} {t['summary']}")
        if len(tasks) > 3:
            print(ui.dim("  more than 3 tasks: splitting the component may be clearer (archvow component add ...)"))
    print()
    left = next((t["task"] for t in tasks if not t["done"]), None)
    if due:
        print(ui.code(f"Next: look at the items to review, then archvow component accept {cid}"))
    elif to_make or safety or others:
        print(ui.code(f"Next: archvow specify {cid}"))
    elif tasks and left is None:
        print(ui.code(f"Done: every task of {cid} is built and tested"))
    else:
        what = f"task {left} - " if left else ""
        print(ui.code(f"Next: implement {what}archvow prompt {cid} (or tell the AI: implement {cid})"))
    if view.get("run"):  # an entry point: how to try it on a laptop, or what it still needs
        print(ui.ok(view["run"]["line"]) if view["run"]["ready"] else ui.warn(view["run"]["line"]))


def _example_state(e: dict) -> str:
    """What one example's line says after its name: the test's verdict and what actual/ shows."""
    differing = [f for f in e.get("files") or [] if f["state"] in ("differs", "missing", "extra")]

    def files_text() -> str:
        parts = []
        for f in differing:
            if f["state"] == "missing":
                parts.append(f"{f['name']} missing in actual/")
            elif f["state"] == "extra":
                parts.append(f"{f['name']} only in actual/")
            else:
                unit = "row" if f["kind"] in ("table", "records") else "line"
                n = f["differences"]
                parts.append(f"{f['name']}: {n} {unit}{'' if n == 1 else 's'} differ{'s' if n == 1 else ''}")
        return "; ".join(parts)

    result = e.get("result")
    if result == "failing":
        detail = files_text() if differing else ("actual/ not written by the test" if not e.get("actual")
                                                 else "actual/ = expected/: see the test's message")
        return ui.red(f"failing - {detail}")
    if result == "no_test":
        return ui.yellow("no marked test yet")
    if result == "skipped":
        return ui.dim(f"skipped in {report_name()}")
    if result == "not_run":
        if e.get("run_on"):  # a report, but this test is not in it
            return ui.dim(f"not in the last run ({report_name()} of {e['run_on']})")
        return ui.dim(f"not run yet (make test writes {report_name()})")
    line = ui.dim(f"{e['level']}, by {e.get('by') or '?'}, {e.get('on')}")
    if differing:
        line += ui.dim(f"  - the test passes; actual/ differs in form only ({files_text()})")
    return line


def _example_differences(e: dict, indent: str) -> list[str]:
    """The rows or lines where actual/ differs from expected/, file by file, at most SHOW_MAX_DIFFERENCES per
    file (a table row written as CSV, so a comma inside a cell stays readable)."""
    import csv
    import io


    if e.get("result") == "passing":
        return []
    out = []
    for f in e.get("files") or []:
        if f["state"] not in ("differs", "missing", "extra"):
            continue
        table = f["kind"] in TABLE_KINDS

        def text(value: object, table: bool = table) -> str:
            if table and isinstance(value, list):
                buffer = io.StringIO()
                csv.writer(buffer, lineterminator="").writerow(value)
                return buffer.getvalue()
            return str(value)
        out.append(indent + ui.dim(f"  {f['name']}" + (f" ({f['note']})" if f.get("note") else "")))
        pad = indent + "    "
        header = f.get("header") or {}
        if table and header.get("expected") is not None and header.get("actual") is not None \
                and header["expected"] != header["actual"]:
            out.append(pad + ui.yellow(f"~ columns {text(header['expected'])} -> {text(header['actual'])}"))
        rows = [r for r in f.get("rows") or [] if r["op"] != "same"]
        for row in rows[:SHOW_MAX_DIFFERENCES]:
            if row["op"] == "extra":
                out.append(pad + ui.red(f"+ {text(row['actual'])}"))
            elif row["op"] == "missing":
                out.append(pad + ui.yellow(f"- {text(row['expected'])}"))
            else:
                out.append(pad + ui.yellow(f"~ {text(row['expected'])} -> {text(row['actual'])}"))
        if len(rows) > SHOW_MAX_DIFFERENCES:
            out.append(pad + ui.dim(f"and {len(rows) - SHOW_MAX_DIFFERENCES} more (archvow show "
                                    f"{e['folder'].split('/')[2]} --json)"))
    return out


def _print_examples(view: dict) -> None:
    """The business examples, grouped by the rule they show: the test's verdict (test-results.xml), what
    actual/ differs from expected/, each locked by its fingerprint. The test decides; archvow shows."""
    rows = view.get("examples") or []
    if not rows:
        return
    cid = view["component"]
    tested = sum(1 for e in rows if e["tested"])
    failing = sum(1 for e in rows if e.get("result") == "failing")
    print("\n" + ui.title("Examples") + ui.dim(f" - {tested} of {len(rows)} with a marked test"
                                               + (f", {failing} failing" if failing else "")
                                               + f"  -> archvow example add {cid} <example> | example remove "
                                               f"{cid} <example>"))
    rules = list(dict.fromkeys(e.get("rule") for e in rows))
    grouped = any(rules)
    for rule in [r for r in rules if r] + ([None] if None in rules else []):
        indent = "  "
        if grouped:
            text = (view.get("rule_texts") or {}).get(rule, "") if rule else ""
            print(f"  {ui.code(rule) if rule else ui.dim('no rule named')}" + (f"  {ui.dim(text)}" if text else ""))
            indent = "    "
        for e in (x for x in rows if x.get("rule") == rule):
            ticket = f" ({e['ticket']})" if e.get("ticket") else ""
            locked = "" if e["unchanged"] else ui.warn("  files changed since recorded (ARCH055)")
            print(f"{indent}{ui.example_mark(e.get('result', 'no_test'))} {e['name']}{ticket}  {_example_state(e)}{locked}")
            if e.get("source"):
                print(indent + ui.dim(f"  drawn from {ref_of(e['source'])}"))
            for line in _example_differences(e, indent):
                print(line)
    run = next((e["run_on"] for e in rows if e.get("run_on")), None)
    print(ui.dim(f"  folders: tests/examples/{cid}/<example>/" + (f" · last run {run} ({report_name()})" if run else "")))


def _print_evidence(view: dict) -> None:
    """With show <file>: the test that is the evidence of each decision, rule and invariant."""
    rows = view.get("evidence") or []
    if not rows:
        return
    untested = [r["item"] for r in rows if not r["tests"]]
    print("\n" + ui.title("Evidence") + ui.dim(f" - {len(rows) - len(untested)} of {len(rows)} with a marked test"))
    for r in rows:
        if r["tests"]:
            print(f"  {r['item']:<22} " + ui.dim(", ".join(r["tests"])))
    if untested:
        print(ui.dim(f"  no marked test yet: {', '.join(untested)}"))


def _print_personal(view: dict) -> None:
    """Columns of a schema/model (classified or not), and the personal columns a component handles."""
    cid = view["component"]
    if view["declares_columns"]:
        unclassified = [c for c in view["columns"] if not c["class"]]
        print("\n" + ui.title("Columns") + ui.dim(f" - {len(view['columns']) - len(unclassified)} of "
                                                 f"{len(view['columns'])} classified  -> archvow column set {cid} "
                                                 "<name,...> personal|special|none"))
        for c in view["columns"]:
            where = "" if c["in_code"] or view["status"] == "planned" else ui.dim("  (not in the code)")
            print(f"  {ui.mark('done' if c['class'] else 'open')} {c['name']:<24} {c['class'] or 'not classified'}{where}")
        if not view["columns"]:
            print(ui.dim("  none yet: classified from the code once it exists, or ahead with archvow column set"))
    personal = view["personal"]
    if personal.get("handles") and not view["declares_columns"]:
        listed = ", ".join(f"{n} ({k})" for n, k in personal["handles"].items())
        print("\n" + ui.title("Personal data") + f" - handles {listed}")
        if personal.get("writes"):
            print(ui.dim(f"  writes: {', '.join(personal['writes'])}"
                         + (f"; pseudonymised before: {', '.join(personal['pseudonymised'])}"
                            if personal.get("pseudonymised") else "")))
        if personal.get("removed"):
            print(ui.dim(f"  removed before the write: {', '.join(personal['removed'])}"))
