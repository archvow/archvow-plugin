"""What the item commands share (hazards, invariants, rules, questions): finding an item, removing it,
who recorded it.
"""

from __future__ import annotations

import argparse
import re
from pathlib import Path

from archvow import agent
from archvow.cli.output import after_change, confirm, print_result, project_root
from archvow.foundation import logs
from archvow.foundation.errors import SpecError
from archvow.foundation.text import a_or_an
from archvow.model import store
from archvow.model.spec import rule_scope
from archvow.spec.hazards import orphans_of, remove_hazard
from archvow.spec.invariants import check_invariant_removable, remove_invariant
from archvow.spec.items import ITEM_ID, find_item
from archvow.spec.rules import remove_rule

log = logs.get("cli")


ITEM_TEXT = {"hazard": lambda h: f"{h['id']} ({h['severity']}, {h.get('component') or 'system'}): "
                                 f"{h.get('description')}",
             "invariant": lambda i: f"{i['id']} ({i.get('component') or 'system'}): {i.get('statement')}"
                                    + (f" - prevents {', '.join(i['mitigates'])}" if i.get("mitigates") else ""),
             "rule": lambda r: f"{r['id']} ({rule_scope(r)}): {r.get('text')}"}


def remove_item(args: argparse.Namespace, expected: str) -> int:
    """archvow hazard|invariant|rule remove <id>: says what goes, asks, removes."""
    root = project_root(args)
    data = store.load(root)
    given = [args.id, *([args.more] if getattr(args, "more", None) else [])]
    wanted = store.normalise_item_id(given)
    if not ITEM_ID.match(wanted) or not item_exists(data, wanted):
        raise SpecError(no_such_item(data, expected, " ".join(given), wanted))
    kind, item = find_item(data, wanted)
    if kind != expected:
        raise SpecError(f"{item['id']} is {a_or_an(kind)}: archvow {kind} remove {item['id']}")
    if kind == "invariant":
        check_invariant_removable(data, item)  # refused before asking anything
    what = ITEM_TEXT[kind](item)
    orphans = orphans_of(data, item["id"]) if kind == "hazard" else []
    confirm(args, f"remove {kind} {what}" + "".join(f"\n  and {ITEM_TEXT['invariant'](i)} (it protects only this hazard)"
                                                    for i in orphans))
    removed = {"hazard": remove_hazard, "invariant": remove_invariant,
               "rule": remove_rule}[kind](root, item["id"])
    text = f"Removed {what}"
    if kind == "hazard" and removed.get("unlinked"):
        text += (f"\n  {', '.join(removed['unlinked'])} no longer "
                 f"{'points' if len(removed['unlinked']) == 1 else 'point'} to it")
    if kind == "hazard" and removed.get("removed_invariants"):
        text += f"\n  removed with it: {', '.join(removed['removed_invariants'])} (it protected only this hazard)"
    after_change(args, root)
    print_result(args, removed, text, success=True)
    return 0


POOLS = {"hazard": "hazards", "invariant": "invariants", "rule": "project_rules"}


def item_exists(data: dict, wanted: str) -> bool:
    try:
        find_item(data, wanted)
        return True
    except SpecError:
        logs.swallowed(log, "_item_exists: SpecError")
        return False


def no_such_item(data: dict, expected: str, given: str, wanted: str) -> str:
    """What was received, what it may have meant, and the ids that exist: `hazard remove clean_sales.clean_sales.H1`
    (a component written twice) says `did you mean clean_sales.H1?` and lists the component's hazards."""
    example = {"hazard": "clean_orders H1", "invariant": "clean_orders INV1", "rule": "R1"}[expected]
    parts = [p for p in re.split(r"[.\s]+", given.strip()) if p]
    deduped = [p for i, p in enumerate(parts) if i == 0 or p != parts[i - 1]]
    guess = store.normalise_item_id(deduped) if deduped else ""
    ids = [str(i.get("id")) for i in data.get(POOLS[expected]) or [] if i.get("id")]
    component = guess.split(".")[0] if "." in guess else (deduped[0] if expected != "rule" and deduped else "")
    near = [i for i in ids if i.startswith(component + ".")] if component and expected != "rule" else ids
    text = (f"'{given}' is not {a_or_an(expected)} of this project" if ITEM_ID.match(wanted)
            else f"'{given}' is not {a_or_an(expected)} id (write it as archvow show prints it: {example})")
    if guess != wanted and guess in ids:
        short = guess.replace(".", " ") if expected != "rule" else guess
        text += f" - did you mean {guess}? archvow {expected} remove {short}"
    if near:
        where = f" of {component}" if component and expected != "rule" and near is not ids else ""
        text += f". The {expected}s{where}: {', '.join(near)}"
    elif ids:
        text += f". The {expected}s of this project: {', '.join(ids)}"
    else:
        text += f". This project has no {expected} yet"
    return text


def ai_author(root: Path) -> str | None:
    """The AI agent running this command (what it adds is its own until a person keeps it), or None."""
    return agent.author(root, store.load(root))


def kept_by_a_person(entry: dict, keep: str) -> str:
    """The line telling that an item is the AI's until a person keeps it."""
    if not entry.get("added_by"):
        return ""
    return f"\nAdded by the AI ({entry['added_by']}): a person keeps it - {keep}"


TESTED_BY = {"example_test": 'a test marked @pytest.mark.invariant("{id}")',
             "property_test": 'a Hypothesis @given test marked @pytest.mark.invariant("{id}")',
             "runtime": "a guard in the component's file marked  # archvow: enforces[{id}]"}


def tested_by(invariant: dict) -> str:
    if invariant.get("from_decision") and invariant.get("verify") in ("example_test", "property_test"):
        kind = "a test" if invariant["verify"] == "example_test" else "a Hypothesis @given test"
        return f"\n  tested by: {kind} marked @pytest.mark.decision({invariant['from_decision']}) (the decision's own test)"
    how = TESTED_BY.get(invariant.get("verify"))
    return f"\n  tested by: {how.format(id=invariant['id'])}" if how else ""


def edited_item(args: argparse.Namespace, expected: str) -> dict:
    """The hazard or invariant `edit` names (the same ways remove takes it)."""
    data = store.load(project_root(args))
    given = [args.id, *([args.more] if getattr(args, "more", None) and re.fullmatch(r"(?i)(H|INV)\d+", args.more) else [])]
    wanted = store.normalise_item_id(given)
    if not ITEM_ID.match(wanted) or not item_exists(data, wanted):
        raise SpecError(no_such_item(data, expected, " ".join(given), wanted).replace(f"{expected} remove",
                                                                                         f"{expected} edit"))
    kind, item = find_item(data, wanted)
    if kind != expected:
        raise SpecError(f"{item['id']} is {a_or_an(kind)}: archvow {kind} edit {item['id']}")
    if getattr(args, "more", None) and len(given) == 1:  # `hazard edit clean_orders.H1 "words"`
        args.words = args.more if args.words is None else args.words
    return item
