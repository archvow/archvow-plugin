"""The argparse toolkit of archvow's commands: the parser with examples and details, the help texts,
and Builder, which each commands module uses to declare its commands.
"""

from __future__ import annotations

import argparse
import re
import textwrap
from pathlib import Path

from archvow.branches import ticket_example, ticket_pattern
from archvow.foundation import logs
from archvow.foundation.errors import SpecError
from archvow.model import store
from archvow.spec.answers import DEFAULT_TEMPLATE
from archvow.templates import (
    Template,
    TemplateError,
    load_template,
    template_name,
)

log = logs.get("cli")


SEVERITY_HELP = """\
severities - how bad it would be:
  critical  data lost, or wrong results that cannot be undone (needs a property test or stronger)
  high      wrong results reach users (needs an invariant with a test)
  medium    a delay or a re-run, no wrong data
  low       noticed and fixed without harm"""


DEFAULT_TEMPLATE = DEFAULT_TEMPLATE


FLOW = """\
how to build a project (every command prints what it changed;
`archvow <command> --help` lists all its options, with examples). What the spec stores is
written `archvow <noun> <verb>`: component, question, decision, rule, assumption, hazard,
invariant, column, dependency, feature - `archvow <noun> --help` lists its verbs:

  1. create the project
       archvow init <package> -t pyspark-pipeline -d "<what it does>" \\
           -a architects=@<user or group> -a ai_tools=<assistant,...>
  2. declare what must exist: a feature (what the product does), then its components one at a time
       archvow feature add <feature> -d "<what the product does in it>"
       archvow component add <type> <name> -d "<what it must do>" -f <feature> -s <ticket> -u <component,...>
       (types: archvow catalog; settings, logging and the app that plugs the features in are in `shared`)
       or ask the AI assistant to "draft the spec of <feature>" (/archvow-draft-spec): it proposes these
       commands, you read and run them
  3. make the decisions: what each component does, so that nothing is left to chance
       archvow show <component>                  everything about it, on one screen
       archvow specify <component>               answers what is open, one question at a time
       archvow decision make <component> <number> "<answer>"
       archvow rule add <component>[,...] "<a rule in your own words>"   (or --type <type>, --all)
       archvow column set <schema> <column,...> personal|special|none   (personal data: every column classified)
       archvow decision make <component> P1 "<answer>"   (P: personal data, O: operations - when asked)
  4. decide what must never happen (archvow specify asks it too)
       archvow hazard add <component> S<number> <severity> "<what must never happen>"
       archvow invariant add <component> "<what always holds>" --prevents H1
  5. commit the spec
       git add .archvow && git commit -m "<ticket>: specify ..."
  6. write the code in this order - yourself, or tell the AI assistant "implement <component>"
       archvow next
  7. review what the AI assumed, run pytest, commit (the Git hook runs ruff and check), release
       archvow assumption accept <component> <number>        (or: archvow assumption reject ...)
       archvow check --complete
       archvow changes --from <last release> --markdown   (what the release contains)
     optional: a second, approved AI reviews the change and only reports (-a reviewers=<tool>):
       tell it "review the last change", or let the CI run archvow review --base develop
"""


class Formatter(argparse.RawDescriptionHelpFormatter):
    """The same help on every Python version, so the command reference never depends on it:
    `-t TEMPLATE, --template TEMPLATE` (Python 3.13 writes `-t, --template TEMPLATE`), and the
    column of the help text measured as Python 3.12 does (3.13 counts the sub-command indent)."""

    def add_argument(self, action: argparse.Action) -> None:
        if action.help is not argparse.SUPPRESS:
            invocations = [self._format_action_invocation(action)]
            invocations += [self._format_action_invocation(sub) for sub in self._iter_indented_subactions(action)]
            length = max(map(len, invocations)) + self._current_indent
            self._action_max_length = max(self._action_max_length, length)
            self._add_item(self._format_action, [action])

    def _format_action_invocation(self, action: argparse.Action) -> str:
        if not action.option_strings or action.nargs == 0:
            return super()._format_action_invocation(action)
        value = self._format_args(action, self._get_default_metavar_for_optional(action))
        return ", ".join(f"{option} {value}" for option in action.option_strings)


class Parser(argparse.ArgumentParser):
    """argparse parser whose help ends with template-dependent details and examples.

    The details (init answers, component types, guide words) are read from the template only
    when the help is shown, so ordinary commands never pay for it.
    """

    def __init__(self, *args, examples: str = "", details=None, **kwargs) -> None:
        kwargs.setdefault("formatter_class", Formatter)
        super().__init__(*args, **kwargs)
        self.examples = examples
        self.details = details
        self.chosen_template: str | None = None

    def format_help(self) -> str:
        text = super().format_help()
        if self.details is not None:
            try:
                extra = self.details(self)
            except (TemplateError, store.ManifestError, SpecError, OSError) as exc:
                logs.swallowed(log, "format_help: TemplateError, store.ManifestError, SpecError, OSError")
                extra = f"(template details unavailable: {exc})"
            text += "\n" + extra.rstrip() + "\n"
        examples = self.examples
        command = self.prog.removeprefix("archvow").strip()
        try:  # a template may give concrete examples for its own component types
            examples = (help_template(self).data.get("help_examples") or {}).get(command) or examples
        except (TemplateError, store.ManifestError, SpecError, OSError):
            logs.swallowed(log, "format_help: TemplateError, store.ManifestError, SpecError, OSError")
            pass
        if examples:
            text += "\nexamples:\n" + textwrap.indent(textwrap.dedent(examples).strip("\n"), "  ") + "\n"
        return project_tickets(text)


class TemplateAction(argparse.Action):
    """Store -t, and remember it so that `init -t NAME --help` describes that template."""

    def __call__(self, parser, namespace, values, option_string=None) -> None:
        parser.chosen_template = values
        setattr(namespace, self.dest, values)


def project_tickets(text: str) -> str:
    """Inside a project, the examples' tickets (US-001) are written as the project writes them."""
    try:
        pattern = ticket_pattern(store.load(store.find_root(Path.cwd())))
    except store.ManifestError:
        logs.swallowed(log, "_project_tickets: store.ManifestError")
        return text
    return re.sub(r"\bUS-(\d+)\b", lambda m: ticket_example(pattern, int(m.group(1))), text)


def help_template(parser: Parser) -> Template:
    """The template the help is about: -t, else the current project's, else the default."""
    try:
        root: Path | None = store.find_root(Path.cwd())
    except store.ManifestError:
        logs.swallowed(log, "_help_template: store.ManifestError")
        root = None
    name = parser.chosen_template
    if name is None and root is not None:
        name = template_name(store.load(root)["containers"][0])[0]
    return load_template(name or DEFAULT_TEMPLATE, root)


def wrap_help(text: str, indent: int) -> str:
    return textwrap.fill(" ".join(str(text).split()), width=100, initial_indent=" " * indent,
                         subsequent_indent=" " * indent)


def answers_help(template: Template) -> str:
    """Every init answer of a template: required or default, allowed values, meaning."""
    lines = []
    questions = template.summary()["questions"]
    for q in sorted(questions, key=lambda q: not q["required"]):  # required first, then template order
        if q["required"]:
            state = "required"
        else:
            state = f"default: {q.get('default') or '(empty)'}"
            for other, values in (q.get("default_from") or {}).items():  # the default follows an earlier answer
                state = "default: " + ", ".join(f"{v} with {other}={k}" for k, v in values.items()) + \
                        f", else {q.get('default') or '(empty)'}"
        if q.get("choices"):
            joined = ", ".join(str(c) for c in q["choices"])
            state += f";  {'comma-separated, from' if q['multiple'] else 'one of'}: {joined}"
        elif q.get("suggestions"):  # any agent's name; those archvow has a profile for
            state += ";  comma-separated agent names, any (a profile for: " + ", ".join(map(str, q["suggestions"])) + ")"
        lines.append(f"  {q['id']:<16} " + wrap_help(state, 19).lstrip())
        lines.append(wrap_help(q.get("prompt", ""), 19))
        if q.get("pattern_hint"):
            lines.append(wrap_help(f"format: {q['pattern_hint']}", 19))
    return "\n".join(lines)


def init_details(parser: Parser) -> str:
    template = help_template(parser)
    return (f"answers of template {template.ref} (-a KEY=VALUE, repeatable; another template:\n"
            "archvow init -t NAME --help, or archvow catalog):\n" + answers_help(template))


def types_details(parser: Parser) -> str:
    template = help_template(parser)
    lines = [f"component types of template {template.ref} (TYPE NAME gives the component id):"]
    for key, ct in template.component_types.items():
        if not ct.get("addable", True):
            continue
        cid = str(ct.get("module", "{name}")).replace("{name}", "<name>")
        lines.append(f"  {key:<15} {cid:<15} {ct.get('description', '')}")
        hint = ct.get("name_hint")
        notes = [f"name: {hint}"] if hint else []
        if ct.get("signature_overridable"):
            symbol = (ct.get("symbols") or [{}])[0]
            notes.append(f"signature {symbol.get('signature', '')} (--signature changes it)")
        if template.kinds(key):
            notes.append(f"kinds (-k): {', '.join(template.kinds(key))} (default {template.kinds(key)[0]})")
        if notes:
            lines.append(wrap_help("; ".join(notes), 34))
    return "\n".join(lines)


def guide_words_details(parser: Parser) -> str:
    template = help_template(parser)
    lines = ["safety questions: use the number archvow show <component> shows (S2, or 2); the guide word works too.",
             f"guide words of template {template.ref}:"]
    for word, question in (template.data.get("guide_words") or {}).items():
        lines.append(f"  {word:<10} " + wrap_help(question, 13).lstrip())
    return "\n".join(lines) + "\n\n" + SEVERITY_HELP


VERIFY_HELP = """\
tested by - every invariant is checked by a test that carries its number:
  @pytest.mark.invariant("clean_orders.INV1")   on a test (a Hypothesis @given test for a critical hazard)
archvow check fails while a coded component's invariant has no such test. Experts can ask for
another kind of check (a guard in the code, a model, a proof): see the Rules documentation.
"""


# what `archvow --help` says first
DESCRIPTION = """archvow - architecture specifications for AI-written code, and the guards that enforce them.

archvow never writes source code. It writes the spec (what must exist, what must never
happen, which decisions are made) and verifies that the code follows it.
"""

COMPONENT_HELP = "component id, as `archvow next` or `archvow show` shows it"


class Builder:
    """How a commands module declares its commands: `b.command(...)` for a command, `b.noun(...)` for a thing
    stored in the spec with its verbs (component add, hazard remove...)."""

    def __init__(self, sub: argparse._SubParsersAction) -> None:
        self.sub = sub

    def command(self, name: str, func, help_text: str, json_flag: bool = False, *, examples: str = "",
                details=None, parent=None, usage: str | None = None) -> Parser:
        parent = self.sub if parent is None else parent
        p = parent.add_parser(name, help=help_text, description=help_text[:1].upper() + help_text[1:] + ".",
                              examples=examples, details=details, **({"usage": usage} if usage else {}))
        p.set_defaults(func=func)
        if json_flag:
            p.add_argument("--json", action="store_true", help="machine-readable output (IDE plugin, scripts)")
        return p

    def noun(self, name: str, help_text: str, verbs: str, examples: str = "") -> argparse._SubParsersAction:
        """A thing stored in the spec: `archvow <noun> <verb>` (component add, hazard remove...)."""
        group = self.command(name, None, help_text, examples=examples)
        return group.add_subparsers(dest=f"{name}_command", required=True, metavar=verbs,
                                    help=f"archvow {name} {verbs} --help: options and examples")
