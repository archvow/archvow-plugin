"""What every command prints and how: the result (--json or text), the "to change it" lines, the
warnings after a change of the spec, the project root of a command.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from archvow import __contract__
from archvow.branches import ticket_example
from archvow.briefs import BriefError, source
from archvow.checks.engine import Report
from archvow.checks.run import run_check
from archvow.cli.console import style as ui
from archvow.foundation.config import settings
from archvow.foundation.errors import SpecError
from archvow.foundation.git import git_or_none
from archvow.model import store
from archvow.views import project_doc
from archvow.views.component_doc import render_prompt
from archvow.views.guidance import attach


def project_root(args: argparse.Namespace) -> Path:
    return store.find_root(Path(args.root) if args.root else Path.cwd())


def as_json(payload: object, **options: object) -> str:
    """archvow's --json output: an object starts with the contract version tools rely on (wiki 13)."""
    if isinstance(payload, dict):
        payload = {"contract": __contract__, **payload}
    return json.dumps(payload, indent=2, **options)


def print_result(args: argparse.Namespace, payload: object, text: str, success: bool = False) -> None:
    if getattr(args, "json", False):
        print(as_json(payload))
    elif success:
        first, _, rest = text.partition("\n")
        print(ui.ok(first) + ("\n" + rest if rest else ""))
    else:
        print(text)


def after_change(args: argparse.Namespace, root: Path) -> None:
    """After a spec change: CODEOWNERS follows the components' owners, and a change on a protected branch is said
    now. Nothing else is generated: the docs are written on request (`archvow doc`), never committed."""
    project_doc.write_owners(root)
    protected_branch_warning(root)


def protected_branch_warning(root: Path) -> None:
    """A spec change on main or develop cannot be committed there (gitflow): say so now, not at the commit.
    The first commit of a repository is made on main."""
    protected = settings().protected_branches
    branch = current_branch(root) if protected else ""
    if branch in protected and (git_or_none(root, "rev-parse", "-q", "--verify", "HEAD") or "").strip():
        ticket = ticket_example((store.load(root).get("init_answers") or {}).get("ticket_pattern"), 1)
        print(ui.warn(f"You are on {branch}: this spec change cannot be committed here (gitflow). Take it to a "
                      f"branch now: git switch -c feature/{ticket}-<short-name> develop"), file=sys.stderr)


def current_branch(root: Path) -> str:
    return (git_or_none(root, "symbolic-ref", "--short", "-q", "HEAD") or "").strip()


def to_change(command: str) -> str:
    """The line under a confirmation: the command that changes what was just recorded."""
    return "\n" + ui.dim(f"  to change it: {command}")


def source_of(root: Path, args: argparse.Namespace) -> dict | None:
    """--from briefs/x.md#section: where an item comes from (file, section, hash of its text)."""
    if not getattr(args, "source", None):
        return None
    try:
        return source(root, args.source)
    except BriefError as exc:
        raise SpecError(f"--from: {exc}") from exc




def warnings_of(entry: dict) -> str:
    """The doubts archvow has about what was just recorded (written anyway): one amber line each."""
    return "".join("\n" + ui.warn(w) for w in entry.get("warnings") or [])


def confirm(args: argparse.Namespace, what: str) -> None:
    """Every removal says exactly what goes; a person confirms it (or passes --yes in a script)."""
    if args.yes:
        return
    if not (sys.stdin.isatty() and sys.stdout.isatty()):
        raise SpecError(f"{what}: no terminal to confirm it - add --yes")
    if input(f"{what}? [y/N] ").strip().lower() not in ("y", "yes", "o", "oui"):
        raise SpecError("nothing removed")


def count(number: int, noun: str) -> str:
    """'1 decision', '3 decisions', '0 other items'."""
    return f"{number} {noun}" + ("" if number == 1 else "s")


def checked(args: argparse.Namespace, root: Path, *more, **options) -> Report:
    """`run_check`, each finding with its guide (what to do, in the project's language): what every command that
    shows findings uses. `args.grammar`: the parser's commands, set by cli/parser.py."""
    if store.is_project(root):
        shared: dict = {}  # read once for every component's task
        options.setdefault("task_text", lambda cid: render_prompt(root, cid, include_status=False, shared=shared))
    report = run_check(root, *more, **options)
    attach(report, str(store.load(root).get("language") or "en") if store.is_project(root) else "en", args.grammar())
    return report
