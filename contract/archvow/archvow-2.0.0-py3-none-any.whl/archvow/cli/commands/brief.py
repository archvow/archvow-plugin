"""`archvow brief show|accept`: the documents the spec is drawn from.
"""

from __future__ import annotations

import argparse
from pathlib import Path

from archvow import briefs
from archvow.briefs import BriefError, accept
from archvow.cli.args import Builder
from archvow.cli.console import style as ui
from archvow.cli.output import after_change, as_json, print_result, project_root
from archvow.foundation.errors import SpecError
from archvow.model import store


def brief_status(root: Path, data: dict) -> dict:
    """Every brief file of the briefs folders, its sections and what is drawn from each: `items` (empty: nothing
    yet - to draft), `changed` (the text changed since the items were drawn: ARCH039, to review)."""
    changed = briefs.changed(root, data)
    files = []
    for file, sections in sorted(briefs.coverage(root, data).items()):
        rows = []
        for section, items in sections.items():
            ref = f"{file}#{section}" if section else file
            moved = changed.get(ref) or (changed.get(file) if not section else None)
            rows.append({"section": section, "items": items, "changed": bool(moved),
                         **({"reason": moved["reason"]} if moved and moved["reason"] != "changed" else {})})
        files.append({"file": file, "sections": rows})
    return {"folders": briefs.folders(data), "files": files,
            "to_draft": sum(1 for f in files for r in f["sections"] if not r["items"]),
            "changed": sum(1 for f in files for r in f["sections"] if r["changed"])}


def cmd_brief_show(args: argparse.Namespace) -> int:
    """archvow brief show: the briefs, section by section - what the spec draws from each."""
    root = project_root(args)
    status = brief_status(root, store.load(root))
    if args.json:
        print(as_json(status))
        return 0
    print(ui.title("Briefs") + ui.dim(f" - folders: {', '.join(f + '/' for f in status['folders']) or 'none'}"))
    if not status["files"]:
        print(ui.dim("  no .md or .txt file in them yet"))
    for f in status["files"]:
        used = sum(1 for r in f["sections"] if r["items"])
        print(f"\n {f['file']}" + ui.dim(f"  ({used} of {len(f['sections'])} sections used)"))
        for r in f["sections"]:
            name = f"#{r['section']}" if r["section"] else "(the whole file)"
            if r["changed"]:
                print(ui.warn(f"   ! {name} changed - {', '.join(r['items'])}")
                      + ui.dim(f"  -> review them, then archvow brief accept {f['file']}"
                               + (f"#{r['section']}" if r["section"] else "")))
            elif r["items"]:
                print(f"   {ui.mark('done')} {name}" + ui.dim(f" - {', '.join(r['items'])}"))
            else:
                print(f"   {ui.mark('open')} {name}" + ui.dim(" - not used yet"))
    return 0


def cmd_brief_accept(args: argparse.Namespace) -> int:
    """archvow brief accept <file>[#section]: the brief changed, the items drawn from it were reviewed."""
    root = project_root(args)
    try:
        stamped = accept(root, args.brief)
    except BriefError as exc:
        raise SpecError(str(exc)) from exc
    after_change(args, root)
    print_result(args, {"brief": args.brief, "items": stamped},
           f"Recorded the current text of {args.brief} for {', '.join(stamped)}", success=True)
    return 0


def declare_brief(b: Builder) -> None:
    """`archvow brief`: its parser."""
    bsub = b.noun("brief", "the documents the spec is drawn from (briefs/): see what each section gives, record a "
                  "reviewed change", "show|accept", examples="""
        archvow brief show                              # each section: what is drawn from it, not used yet, changed
        archvow component add reader sales -d "..." --from briefs/sales.md#input-files
        archvow check                                   # ARCH039 when that section changes
        archvow brief accept briefs/sales.md#input-files     # reviewed: record its new text
        """)
    p = b.command("show", cmd_brief_show, "every brief, section by section: what the spec draws from it, the sections "
                  "not used yet, the ones changed since", True, parent=bsub, examples="""
        archvow brief show
        archvow brief show --json     # for an IDE plugin
        """)
    p = b.command("accept", cmd_brief_accept, "the brief changed and what was drawn from it is reviewed: record its "
                  "new text (a person, never the AI)", True, parent=bsub, examples="""
        archvow brief accept briefs/sales.md#input-files     # one section
        archvow brief accept briefs/sales.md                 # every item drawn from the file
        """)
    p.add_argument("brief", metavar="BRIEF", help="briefs/<file>.md, or briefs/<file>.md#<section>")
