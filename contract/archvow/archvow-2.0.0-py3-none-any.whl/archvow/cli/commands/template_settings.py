"""The settings of a new template (`pack template`): from the options, or asked in a terminal.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from archvow.cli.console import style as ui
from archvow.cli.console.ask import ask, ask_company_defaults, setup_line_editing
from archvow.foundation.errors import SpecError
from archvow.spec.answers import check_answer
from archvow.templates import TemplateError, check_layer_names, load_template


def _split_list(text: str | None) -> list[str]:
    return [item.strip() for item in (text or "").replace(" ", ",").split(",") if item.strip()]


def template_settings(args: argparse.Namespace, root: Path | None, folder: Path) -> dict:
    """What `pack template` writes as settings: from the options, or asked in a terminal."""
    try:
        base = load_template(args.extends, root, extra=(folder,))
    except TemplateError as exc:
        raise SpecError(str(exc)) from exc
    given = args.description or args.answer or args.allowed_paths or args.verbatim_folders or args.layer
    if not given and not args.no_input and sys.stdin.isatty() and sys.stdout.isatty():
        setup_line_editing()
        print(ui.dim("Enter skips a question."))
        args.description = ask(f"  description [Custom variant of {args.extends}.]: ").strip() or None
        print(ui.dim(f"\nThe company's defaults for the init answers of {args.extends}, one at a time: Enter "
                     "keeps the base's default; a project can still change any of them (-a)."))
        args.answer = [f"{key}={value}" for key, value in ask_company_defaults(base).items()]
        print()
        args.allowed_paths = ask("  allowed_paths - top folders of Python files that are not "
                                    "components (e.g. devops,tools): ")
        args.verbatim_folders = ask("  verbatim_folders - folders of files/ copied as they are, .j2 "
                                       "included (e.g. templates): ")
        layers = " ".join(layer["name"] for layer in base.layers)
        args.layer = ask(f"  layer folders - Enter keeps {layers}; to rename, LAYER=FOLDER separated by "
                            "spaces (e.g. p1_domain=domain): ").split()
    questions = {q["id"]: q for q in base.data.get("questions", [])}
    defaults = {}
    for item in args.answer or []:
        key, sep, value = item.partition("=")
        if not sep:
            raise SpecError(f"-a {item}: write KEY=VALUE (e.g. -a ci=jenkins)")
        if key not in questions:
            raise SpecError(f"-a {key}: {args.extends} has no such init answer "
                            f"(archvow catalog lists them: {', '.join(questions)})")
        defaults[key] = check_answer(base, questions[key], value)
    allowed = [entry.strip("/") for entry in _split_list(args.allowed_paths)]
    deep = [entry for entry in allowed if "/" in entry]
    if deep:
        raise SpecError(f"allowed_paths: {', '.join(deep)} - only top folders (archvow looks at the "
                        "first folder of a file's path: devops covers devops/deploy/run.py)")
    verbatim = [entry.strip("/") for entry in _split_list(args.verbatim_folders)]
    layer_names = {}
    for item in args.layer or []:
        old, sep, new = item.partition("=")
        if not sep:
            raise SpecError(f"--layer {item}: write LAYER=FOLDER (e.g. --layer p1_domain=domain)")
        layer_names[old.strip()] = new.strip()
    try:
        check_layer_names(args.name, [layer["name"] for layer in base.layers], layer_names)
    except TemplateError as exc:
        raise SpecError(str(exc).replace("layer_names:", "--layer:")) from exc
    return {"description": args.description, "defaults": defaults, "allowed_paths": allowed,
            "verbatim_folders": verbatim, "layer_names": layer_names}
