"""`archvow invariant add|edit|remove`: what must always hold.
"""

from __future__ import annotations

import argparse

from archvow.cli.args import VERIFY_HELP, Builder
from archvow.cli.items import (
    ITEM_TEXT,
    ai_author,
    edited_item,
    kept_by_a_person,
    remove_item,
    tested_by,
)
from archvow.cli.output import after_change, print_result, project_root, to_change, warnings_of
from archvow.foundation.errors import SpecError
from archvow.spec.invariants import add_invariant, edit_invariant


def cmd_invariant_remove(args: argparse.Namespace) -> int:
    return remove_item(args, "invariant")


def cmd_invariant_add(args: argparse.Namespace) -> int:
    root = project_root(args)
    component = None if args.component == "system" else args.component
    prevents = [m.strip() for m in (args.prevents or "").split(",") if m.strip()]
    if not args.statement and args.from_decision is None:
        raise SpecError("the statement is required: say what always holds, in quotes - or --from-decision N when "
                        "decision N of the component already protects the hazard")
    if args.statement and args.from_decision is not None:
        raise SpecError("--from-decision N takes no words: the invariant says what decision N answers")
    entry = add_invariant(root, args.statement, verify=args.verify, mitigates=prevents,
                                component=component, evidence=args.evidence, rule=args.rule,
                                from_decision=args.from_decision, added_by=ai_author(root), why=args.why)
    after_change(args, root)
    text = (f"Recorded {entry['id']}, prevents {', '.join(entry['mitigates'])}: {entry['statement']}"
            + tested_by(entry) + kept_by_a_person(entry, f"archvow hazard accept {', '.join(entry['mitigates'])}")
            + to_change(f"archvow invariant edit {entry['id']} \"...\"") + warnings_of(entry))
    print_result(args, entry, text, success=True)
    return 0


def cmd_invariant_edit(args: argparse.Namespace) -> int:
    root = project_root(args)
    item = edited_item(args, "invariant")
    entry = edit_invariant(root, item["id"], args.words, args.verify)
    after_change(args, root)
    print_result(args, entry, f"Changed {ITEM_TEXT['invariant'](entry)}" + tested_by(entry), success=True)
    return 0


def declare_invariant(b: Builder) -> None:
    """`archvow invariant`: its parser."""
    p = b.command("invariant", None, "what must always hold, so a hazard cannot happen", examples="""
        archvow invariant add <component> "<what always holds>"
        archvow invariant remove <component> INV1
        """)
    isub = p.add_subparsers(dest="invariant_command", required=True, metavar="add|edit|remove",
                            help="archvow invariant add|edit|remove --help: options and examples")
    ip = b.command("add", cmd_invariant_add, "add an invariant guarding one or more hazards", True, parent=isub,
                   details=lambda _parser: VERIFY_HELP, examples="""
        archvow invariant add <component> "<what always holds>"        # its hazard, the usual proof
        archvow invariant add <component> "<what always holds>" --prevents H2
        archvow invariant add <component> "<what always holds>" --prevents orders_reader.H1   # another component's
        archvow invariant add <component> --from-decision 1 --prevents H1   # decision 1 protects it
        """)
    ip.add_argument("component", help="component id, or 'system'")
    ip.add_argument("statement", nargs="?", help="the property, in plain words; it must be checkable")
    ip.add_argument("--from-decision", type=int, metavar="N", help="decision N of the component protects the hazard: "
                    "the invariant says what it answers (and follows it), and its test marked decision(N) proves it")
    ip.add_argument("--prevents", metavar="IDS", help="the hazard(s) it prevents: H1 (this component's), orders_reader.H1 (another's) (default: the "
                    "component's one hazard that no invariant prevents yet)")
    ip.add_argument("--verify", metavar="METHOD",
                    choices=["static", "example_test", "property_test", "runtime", "model_check", "proof"],
                    help=argparse.SUPPRESS)  # experts: runtime, static, model_check, proof (docs: Rules)
    ip.add_argument("--why", metavar="REASON",
                    help="why it is added, in a few words - shown to the person who keeps it")
    ip.add_argument("--evidence", metavar="FILE", help=argparse.SUPPRESS)
    ip.add_argument("--rule", help=argparse.SUPPRESS)
    ip = b.command("edit", cmd_invariant_edit, "change an invariant's words; its id, hazards and test marker stay", True,
                   parent=isub, examples='archvow invariant edit <component> INV1 "<new words>"')
    ip.add_argument("id", metavar="WHAT", help="the component (then INV<n>), or the id <component>.INV1")
    ip.add_argument("more", nargs="?", metavar="INV<n>", help="with a component: its invariant INV<n>")
    ip.add_argument("words", nargs="?", help="what always holds, in new words")
    ip.add_argument("--verify", metavar="METHOD", choices=["static", "example_test", "property_test", "runtime",
                    "model_check", "proof"], help=argparse.SUPPRESS)
    ip = b.command("remove", cmd_invariant_remove, "remove an invariant (never the last guard of a critical or high "
                   "hazard; asks first)", True, parent=isub, examples="archvow invariant remove <component> INV1")
    ip.add_argument("id", metavar="WHAT", help="the component, then INV<n> (or the id <component>.INV1)")
    ip.add_argument("more", nargs="?", metavar="INV<n>", help="the invariant's number in that component, e.g. INV1")
    ip.add_argument("--yes", action="store_true", help="do not ask for confirmation (scripts)")
