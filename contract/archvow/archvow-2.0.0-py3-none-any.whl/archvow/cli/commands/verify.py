"""`archvow check|review|freeze|audit|diff|changes`: verify the code and the spec.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from archvow import freeze
from archvow.cli.args import Builder
from archvow.cli.console import style as ui
from archvow.cli.output import as_json, checked, print_result, project_root
from archvow.foundation.errors import GitError, SpecError
from archvow.review import ReviewError, run
from archvow.views.audit import render_audit, run_audit
from archvow.views.changes import changes_report, render_changes, to_json
from archvow.views.specdiff import render, spec_diff


def cmd_changes(args: argparse.Namespace) -> int:
    root = project_root(args)
    try:
        rows = changes_report(root, args.start, args.end)
    except GitError as exc:
        raise SpecError(str(exc)) from exc
    print(to_json(rows) if args.json else render_changes(rows, args.start, args.end, args.markdown), end="")
    return 0


def cmd_freeze(args: argparse.Namespace) -> int:
    root = project_root(args)
    count = freeze.write(root, checked(args, root, raw=True))
    print_result(args, {"frozen": count, "file": freeze.FROZEN_REL},
           f"Froze {count} existing violation(s) in {freeze.FROZEN_REL}. Commit it: from now on "
           "only new violations fail. Fix frozen ones over time and run `archvow freeze` again.", success=True)
    return 0


def cmd_audit(args: argparse.Namespace) -> int:
    rows = run_audit(project_root(args))
    print_result(args, rows, render_audit(rows))
    return 1 if args.strict and any(r["flags"] for r in rows) else 0


def cmd_diff(args: argparse.Namespace) -> int:
    root = project_root(args)
    try:
        changes = spec_diff(root, args.base)
    except GitError as exc:
        raise SpecError(f"cannot compare with '{args.base}': {exc}") from exc
    if args.json:
        print(as_json(changes))
    else:
        print(render(changes, markdown=args.markdown), end="")
    return 0


def _say_what_to_do(guide: dict) -> str:
    """The finding's guide on one line: what to do, and who when it is not whoever writes the code."""
    fr = guide.get("language") == "fr"
    who = guide.get("who", "")
    named = "" if who.startswith(("Whoever writes", "Celui qui écrit")) else f" - {who.split(':')[0].rstrip('.')}"
    return ("que faire : " if fr else "what to do: ") + guide["fix"] + named


def cmd_check(args: argparse.Namespace) -> int:
    root = project_root(args)
    if args.file and not args.stdin and not Path(args.file).is_file():
        raise SpecError(f"--file {args.file}: no such file (for an unsaved buffer, add --stdin)")
    content = sys.stdin.read() if args.stdin else None
    report = checked(args, root, Path(args.file) if args.file else None, content,
                       base=args.base, accept_weakening=args.accept_weakening, complete=args.complete,
                       test_report=Path(args.test_report) if args.test_report else None)
    if args.json:
        print(as_json(report.to_dict()))
    else:
        quiet = [] if args.all else [v for v in report.violations if v.code in ("ARCH035", "ARCH038")]
        explained: set[tuple[str, str]] = set()
        for v in report.violations:
            if v in quiet:
                continue
            where = f"{v.file}:{v.line}:{v.col}:" if v.line else f"{v.file}:"
            print(f"{ui.dim(where)} {ui.severity(v.severity, f'{v.code} [{v.severity}]')} {v.message}")
            if v.guide and (v.code, v.guide["fix"]) not in explained:  # what to do, once per rule and advice
                explained.add((v.code, v.guide["fix"]))
                print(ui.dim(f"  {_say_what_to_do(v.guide)}"))
        for c in report.changes:
            print(f"architecture change: {c['change']} {c['id']}" + (f" ({c['type']})" if c.get("type") else ""))
            if c["change"] == "contract_changed":
                print(ui.dim("  review the components that use it: " + (", ".join(c["users"]) or "none")
                             + " (their code and their tests may need to follow)"))
            if c["change"] == "example_changed":
                print(ui.dim(f"  example {c['example']}: new files accepted by {c.get('by') or '?'} - the reviewers "
                             "compare them with the ticket"))
        counts: dict[str, int] = {}
        for comp in report.components:
            counts[comp.status] = counts.get(comp.status, 0) + 1
        open_safety = [v for v in quiet if v.code == "ARCH035"]
        if open_safety:
            done, total = report.safety.get("answered", 0), report.safety.get("total", 0)
            print(ui.warn(f"Safety: {done} of {total} questions answered ({len(open_safety)} open, ARCH035): "
                          "`archvow show <component>` lists them, `archvow check --all` shows each one."))
        unmarked = [v for v in quiet if v.code == "ARCH038"]
        if unmarked:
            print(ui.warn(f"Tests: {len(unmarked)} coded component(s) with decisions or rules no test is marked "
                          "with (ARCH038): `archvow check --all` lists them."))
        if report.frozen:
            print(ui.dim(f"{len(report.frozen)} frozen violation(s) ignored ({freeze.FROZEN_REL})."))
        if report.stale_frozen:
            print(ui.warn(f"{len(report.stale_frozen)} frozen violation(s) are fixed: run `archvow freeze` "
                          "to shrink the list."))
        order = ["planned", "implemented", "tested", "verified", "drift"]
        by_rule = report.counts()
        if len(by_rule) > 1:
            print("\n" + ui.dim("By rule: " + "  ".join(f"{code} {n}" for code, n in by_rule.items())))
        progress = ", ".join(f"{counts[k]} {k}" for k in order if k in counts) or "no components"
        summary = (f"{len(report.errors)} error(s), {len(report.violations) - len(report.errors)} "
                   f"warning(s). Components: {progress}.")
        print()
        print(ui.ok(summary) if not report.errors else ui.error(summary))
    return 1 if report.errors else 0


def cmd_ai_review(args: argparse.Namespace) -> int:
    root = project_root(args)
    try:
        outcome = run(root, args.base, acknowledged=args.acknowledged,
                      echo=(lambda _text: None) if args.json else (lambda text: print(ui.dim(text))))
    except ReviewError as exc:
        raise SpecError(str(exc)) from exc
    failed = outcome["status"] in ("high", "failed")
    if args.json:
        print(as_json(outcome))
        return 1 if failed else 0
    for finding in outcome["findings"]:
        line = f"{finding['severity']:<6} {finding['text']}"
        print(ui.severity("error", line) if finding["severity"] == "HIGH" else
              ui.severity("warning", line) if finding["severity"] == "MEDIUM" else line)
    if outcome["findings"]:
        print()
    message = outcome["message"]
    if failed:
        print(ui.error(message))
    elif outcome["status"] in ("passed", "nothing"):
        print(ui.ok(message))
    else:
        print(ui.warn(message))
    return 1 if failed else 0


def declare_check(b: Builder) -> None:
    """`archvow check`: its parser."""
    p = b.command("check", cmd_check, "verify the code against the spec (exit 1 on errors)", True, examples="""
        archvow check                             # before every commit (the Git hook runs it)
        archvow check --base origin/main          # merge request: no guard weakened
        archvow check --complete                  # release gate: everything planned is built
        """)
    p.add_argument("--file", help="only report violations for this file (an IDE, or an AI checking the file it writes)")
    p.add_argument("--stdin", action="store_true", help="read --file content from stdin (unsaved buffer)")
    p.add_argument("--base", metavar="REF", help="git ref to compare guards with, e.g. origin/main")
    p.add_argument("--accept-weakening", action="store_true",
                   help="report ARCH020 as a warning (pass only after architect approval)")
    p.add_argument("--complete", action="store_true",
                   help="also fail on planned components not built yet (release gate)")
    p.add_argument("--all", action="store_true",
                   help="list every warning one by one (by default the open safety questions, ARCH035, and "
                        "the tests not marked with their decision or rule, ARCH038, are counted on one line)")
    p.add_argument("--test-report", metavar="JUNIT_XML",
                   help="pytest's JUnit report (pytest --junitxml=...): every invariant's test must have run and "
                        "passed (DORA004)")


def declare_review(b: Builder) -> None:
    """`archvow review`: its parser."""
    p = b.command("review", cmd_ai_review, "have an approved AI reviewer review the change, without a person "
                  "(CI; it never changes code)", True, examples="""
        archvow review --base origin/main                      # merge request: report in reviews/last-change.md
        archvow review --base origin/main --acknowledged       # a person has read the HIGH findings
        """)
    p.add_argument("--base", required=True, metavar="REF",
                   help="the branch the merge request targets, e.g. origin/main: the components changed since "
                        "then are reviewed")
    p.add_argument("--acknowledged", action="store_true",
                   help="a person has read the report: HIGH findings no longer fail (CI passes it when the "
                        "merge request has the label review-acknowledged)")


def declare_freeze(b: Builder) -> None:
    """`archvow freeze`: its parser."""
    b.command("freeze", cmd_freeze, "accept today's violations; only new ones fail from now on", True,
              examples="archvow freeze      # adopting archvow on existing code; commit the result")


def declare_audit(b: Builder) -> None:
    """`archvow audit`: its parser."""
    p = b.command("audit", cmd_audit, "who recorded each decision, hazard and invariant, cross-checked with Git",
                  True, examples="archvow audit\narchvow audit --strict      # in CI")
    p.add_argument("--strict", action="store_true", help="exit 1 if any record is flagged")


def declare_changes(b: Builder) -> None:
    """`archvow changes`: its parser."""
    p = b.command("changes", cmd_changes, "what a release contains, merge by merge: ticket, spec, components, "
                  "tests, who merged and approved", True, examples="""
        archvow changes --from v1.2.0 --to v1.3.0 --markdown > CHANGES.md
        archvow changes --from v1.2.0                    # up to HEAD
        """)
    p.add_argument("--from", dest="start", required=True, metavar="REF", help="the previous release (a tag or a commit)")
    p.add_argument("--to", dest="end", default="HEAD", metavar="REF", help="the release (default: HEAD)")
    p.add_argument("--markdown", action="store_true", help="Markdown output")


def declare_diff(b: Builder) -> None:
    """`archvow diff`: its parser."""
    p = b.command("diff", cmd_diff, "spec changes since a branch, in plain words (merge-request report)", True,
                  examples="archvow diff --base origin/main --markdown")
    p.add_argument("--base", required=True, metavar="REF", help="git ref, e.g. origin/main")
    p.add_argument("--markdown", action="store_true", help="Markdown output for merge-request reports")
