"""`archvow column set`: personal data in columns.
"""

from __future__ import annotations

import argparse

from archvow.cli.args import Builder
from archvow.cli.output import after_change, print_result, project_root, to_change
from archvow.packs.regimes import TAGS
from archvow.privacy import classify


def cmd_column_set(args: argparse.Namespace) -> int:
    """archvow column set <component> <names> personal|special|none, or --removes / --pseudonymises."""
    root = project_root(args)
    result = classify(root, args.component, args.names.split(","), args.kind, removes=args.removes,
                      pseudonymises=args.pseudonymises, tags=[t for v in args.tag or [] for t in v.split(",")])
    after_change(args, root)
    if "columns" in result:
        tags = result.get("tags") or {}
        text = "\n".join(f"{args.component}.{n}: {k}" + (f" ({', '.join(tags[n])})" if n in tags else "")
                         for n, k in result["columns"].items()) + to_change(
            f"archvow column set {args.component} {','.join(result['columns'])} personal|special|none [--tag ...]")
    else:
        key = "removes" if args.removes else "pseudonymises"
        text = f"{args.component} {key} {', '.join(result[key])} before the data is written"
    print_result(args, result, text, success=True)
    return 0


def declare_column(b: Builder) -> None:
    """`archvow column`: its parser."""
    # ---- personal data and third parties
    ksub = b.noun("column", "personal data: classify columns, or say a component removes or pseudonymises them",
                  "set", examples='archvow column set <schema> <column,...> personal|special|none')
    p = b.command("set", cmd_column_set, "classify columns: personal, special (sensitive) or none, with tags", True,
                  parent=ksub, examples="""
        archvow column set <schema> customer_email,phone personal
        archvow column set <schema> diagnosis special --tag health     # health, religion, biometrics... (sensitive)
        archvow column set <schema> card_number personal --tag financial   # GLBA: nonpublic personal information
        archvow column set <schema> order_id,amount none
        archvow column set <transformation> phone --removes        # dropped before the data is written
        archvow column set <transformation> customer_email --pseudonymises
        """)
    p.add_argument("component", help="a schema or model component (classes); any component for --removes / "
                   "--pseudonymises")
    p.add_argument("names", help="column names, separated by commas")
    p.add_argument("kind", nargs="?", choices=["personal", "special", "none"], help="personal | special | none")
    p.add_argument("--tag", action="append", metavar="TAG", help=f"what a privacy regime covers: {', '.join(TAGS)} "
                   "(repeat it, or commas; none removes them)")
    flow = p.add_mutually_exclusive_group()
    flow.add_argument("--removes", action="store_true", help="this component drops these columns")
    flow.add_argument("--pseudonymises", action="store_true", help="this component pseudonymises or encrypts them")
