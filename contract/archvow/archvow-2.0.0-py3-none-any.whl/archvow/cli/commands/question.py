"""`archvow question add|accept|remove`: open questions.
"""

from __future__ import annotations

import argparse

from archvow import proposals as ai
from archvow.cli.args import COMPONENT_HELP, Builder
from archvow.cli.items import ai_author, kept_by_a_person
from archvow.cli.output import (
    after_change,
    confirm,
    print_result,
    project_root,
    source_of,
    to_change,
)
from archvow.model import store
from archvow.model.spec import find_component
from archvow.spec.acceptance import accept_question
from archvow.spec.questions import ask, remove_question


def cmd_question_remove(args: argparse.Namespace) -> int:
    """archvow question remove <component> <n>: a question a person added, with its answer if any."""
    root = project_root(args)
    _, comp = find_component(store.load(root), args.component)
    decisions = comp.get("decisions", []) or []
    question = decisions[args.number - 1]["question"] if 1 <= args.number <= len(decisions) else "?"
    confirm(args, f"remove question {args.number} of {args.component}: {question}")
    removed = remove_question(root, args.component, args.number)
    ai.renumber(root, args.component, args.number)
    after_change(args, root)
    print_result(args, removed, f"Removed question {args.number} of {args.component}: {removed['question']}",
           success=True)
    return 0


def cmd_question_add(args: argparse.Namespace) -> int:
    root = project_root(args)
    entry = ask(root, args.component, args.question, source=source_of(root, args),
                      added_by=ai_author(root), why=args.why)
    number = len(find_component(store.load(root), args.component)[1]["decisions"])
    after_change(args, root)
    print_result(args, entry, f"Open question {number} recorded for {args.component}: {entry['question']}\n"
                        f"A person answers it: archvow decision make {args.component} {number} \"...\""
           + kept_by_a_person(entry, f"answers it, or archvow question accept {args.component} {number} "
                                      "(answered later)")
           + to_change(f"archvow question remove {args.component} {number}, then question add again"),
           success=True)
    return 0


def cmd_question_accept(args: argparse.Namespace) -> int:
    root = project_root(args)
    entry = accept_question(root, args.component, args.number)
    after_change(args, root)
    print_result(args, entry, f"Kept question {args.number} of {args.component} (asked by {entry['added_by']}): "
                        f"{entry['question']}\nIt stays open until a person answers it: archvow decision make "
                        f"{args.component} {args.number} \"...\"", success=True)
    return 0


def declare_question(b: Builder) -> None:
    """`archvow question`: its parser."""
    qsub = b.noun("question", "an open question: it blocks the component until a person answers it", "add|accept|remove",
                  examples="""
        archvow question add <component> "<the question>"
        archvow decision make <component> <n> "<the answer>"     # a person answers it
        archvow question accept <component> <n>                 # a person keeps the AI's question, to answer later
        archvow question remove <component> <n>
        """)
    p = b.command("add", cmd_question_add, "record an open question (blocks implementation until answered)", True,
                  parent=qsub, examples='archvow question add <component> "<the question>"')
    p.add_argument("component", help=COMPONENT_HELP)
    p.add_argument("question", help="the question; a person answers it with archvow decision make")
    p.add_argument("--from", dest="source", metavar="BRIEF",
                   help="the brief it is drawn from: briefs/<file>.md, or briefs/<file>.md#<section> (a heading); "
                        "archvow check warns when that text changes (ARCH039)")
    p.add_argument("--why", metavar="REASON",
                   help="why it is added, in a few words (what in the spec or the brief leaves it open) - "
                        "shown to the person who keeps it")
    p = b.command("accept", cmd_question_accept, "keep a question the AI asked, to answer it later (a person, never "
                  "the AI; answering it keeps it too)", True, parent=qsub,
                  examples="archvow question accept <component> 4      # its number, as archvow show prints it")
    p.add_argument("component", help=COMPONENT_HELP)
    p.add_argument("number", type=int, help="the question's number, as archvow show prints it")
    p = b.command("remove", cmd_question_remove, "remove a question a person added, with its answer (asks first; "
                  "the template's questions stay)", True, parent=qsub,
                  examples="archvow question remove <component> 4      # its number, as archvow show prints it")
    p.add_argument("component", help=COMPONENT_HELP)
    p.add_argument("number", type=int, help="the question's number, as archvow show prints it")
    p.add_argument("--yes", action="store_true", help="do not ask for confirmation (scripts)")
