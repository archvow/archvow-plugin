"""`archvow example add|remove`: business examples.
"""

from __future__ import annotations

import argparse

from archvow import examples
from archvow.briefs import ref_of
from archvow.cli.args import COMPONENT_HELP, Builder
from archvow.cli.console import style as ui
from archvow.cli.output import (
    after_change,
    confirm,
    print_result,
    project_root,
    source_of,
    to_change,
)


def cmd_example_add(args: argparse.Namespace) -> int:
    """archvow example add <component> <example> [-s <ticket>]: record (or accept again) a business example."""
    root = project_root(args)
    entry = examples.add(root, args.component, args.name, args.spec, source_of(root, args))
    after_change(args, root)
    verb = "Accepted the new files of" if entry["replaced"] else "Recorded"
    test = f'@pytest.mark.example("{entry["name"]}")' + (" and @pytest.mark.integration"
                                                          if entry["level"] == "integration" else "")
    shows = f", rule {entry['rule']}" if entry.get("rule") else ""
    drawn = ""
    if entry.get("source"):
        drawn = f", drawn from {ref_of(entry['source'])}"
    print_result(args, entry, f"{verb} example {entry['name']} of {args.component} ({entry['folder']}/, "
                        f"fingerprint {entry['fingerprint']}{shows}{drawn})\n"
                        + ui.dim(f"  its test reads input/, writes what the component gives to {examples.ACTUAL}/, "
                                 f"compares with expected/, and is marked {test}")
           + to_change(f"replace its files, then archvow example add {args.component} {entry['name']} again"),
           success=True)
    return 0


def cmd_example_remove(args: argparse.Namespace) -> int:
    root = project_root(args)
    confirm(args, f"remove example {args.name} of {args.component} from the spec (its files stay)")
    entry = examples.remove(root, args.component, args.name)
    after_change(args, root)
    print_result(args, entry, f"Removed example {entry['name']} of {args.component} from the spec; its files stay in "
                        f"{entry['folder']}/ (delete them, or add the example again)", success=True)
    return 0


def declare_example(b: Builder) -> None:
    """`archvow example`: its parser."""
    esub = b.noun("example", "a business example: this input gives this result, locked by its fingerprint",
                  "add|remove", examples="""
        archvow example add <component> <example> -s <ticket>   # its files: tests/examples/<component>/<example>/
        archvow example remove <component> <example>
        """)
    p = b.command("add", cmd_example_add, "record an example whose files are in tests/examples/<component>/<example>/ "
                  "(input/ and expected/); run again after its files change", True, parent=esub, examples="""
        archvow example add clean_orders FATTRIB-012-negative-quantity -s FATTRIB-012
        #   tests/examples/clean_orders/FATTRIB-012-negative-quantity/input/orders.csv
        #   tests/examples/clean_orders/FATTRIB-012-negative-quantity/expected/orders.csv
        #   tests/examples/clean_orders/FATTRIB-012-negative-quantity/scenario.feature  (optional; Rule: clean_orders.INV1)
        archvow example add clean_orders FATTRIB-012-negative-quantity --from briefs/orders.md#cleaning
        """)
    p.add_argument("component", help=COMPONENT_HELP)
    p.add_argument("name", metavar="example", help="its folder name: letters, digits, - and _, often the ticket first")
    p.add_argument("-s", "--spec", metavar="TICKET", help="the ticket it comes from (e.g. the Jira story)")
    p.add_argument("--from", dest="source", metavar="BRIEF",
                   help="the brief it is drawn from: briefs/<file>.md, or briefs/<file>.md#<section> (a heading); "
                        "a link only (a person copies the rows into the files); archvow check warns when that "
                        "text changes (ARCH039)")
    p = b.command("remove", cmd_example_remove, "remove an example from the spec (its files stay; asks first)", True,
                  parent=esub, examples="archvow example remove clean_orders FATTRIB-012-negative-quantity")
    p.add_argument("component", help=COMPONENT_HELP)
    p.add_argument("name", metavar="example", help="the example, as archvow show <component> lists it")
    p.add_argument("--yes", action="store_true", help="do not ask for confirmation (scripts)")
