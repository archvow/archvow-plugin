"""One module per noun of archvow's commands (component, question, decision, rule, assumption, brief, hazard,
invariant, column, dependency, example) or per group (project, show, next, specify, verify). Each declares its
commands with `declare_<command>(b)` (called by cli/parser.py, in the order of `archvow --help`) and holds their
handlers, `cmd_<command>(args)`: they return the exit code.
"""
