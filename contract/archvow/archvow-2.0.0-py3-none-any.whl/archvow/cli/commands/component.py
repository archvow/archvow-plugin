"""`archvow component add|edit|accept|move|remove`: what must exist.
"""

from __future__ import annotations

import argparse

from archvow import agent, toreview
from archvow import proposals as ai
from archvow.cli.args import COMPONENT_HELP, Builder, types_details
from archvow.cli.console import style as ui
from archvow.cli.output import (
    after_change,
    confirm,
    count,
    print_result,
    project_root,
    source_of,
    to_change,
    warnings_of,
)
from archvow.foundation.errors import SpecError
from archvow.foundation.text import a_or_an
from archvow.model import store
from archvow.model.spec import find_component
from archvow.spec.components import add_component, edit_component, remove_component
from archvow.spec.features import move_component
from archvow.spec.items import ITEM_ID, find_item


def cmd_component_add(args: argparse.Namespace) -> int:
    root = project_root(args)
    uses = [u.strip() for u in (args.uses or "").split(",") if u.strip()]
    found = agent.detect(root, agent.tool_data(root, store.load(root)))  # an AI agent (modes guided, free)
    entry = add_component(root, args.type, args.name, args.description, spec=args.spec,
                                uses=uses, signature=args.signature, container_id=args.container,
                                group=args.group, routes=args.route, source=source_of(root, args), kind=args.kind,
                                file=args.file, created_by=found.tool if found else None, feature=args.feature)
    after_change(args, root)
    kind = f" ({entry['kind']})" if entry.get("kind") else ""
    text = (f"Specified {entry['type']}{kind} '{entry['id']}' ({store.source_path(store.container(store.load(root), args.container), entry)}).\n"
            f"Its vow: {store.where(entry)} (feature {entry['feature']})\n"
            f"Next: archvow specify {entry['id']}  (everything about it: archvow show {entry['id']})"
            + (f"\nCreated by the AI ({entry['created_by']}): a person accepts it - archvow component accept "
               f"{entry['id']}" if entry.get("origin") == "ai" else "")
            + warnings_of(entry) + to_change(f"archvow component edit {entry['id']} -d \"...\""))
    print_result(args, entry, text, success=True)
    return 0


def cmd_component_edit(args: argparse.Namespace) -> int:
    root = project_root(args)
    uses = None if args.uses is None else [u.strip() for u in args.uses.split(",") if u.strip()]
    owners = None if args.owners is None else args.owners.replace(",", " ").split()
    if all(v is None for v in (args.description, args.spec, uses, args.signature, args.group, args.route,
                               args.source, owners)):
        raise SpecError("nothing to change: pass -d, -s, -u, -g, --route, --signature, --owners and/or --from")
    before = find_component(store.load(root), args.component)
    comp = edit_component(root, args.component, description=args.description, spec=args.spec,
                                uses=uses, signature=args.signature, group=args.group, routes=args.route,
                                source=source_of(root, args), owners=owners)
    if before[1]["module"] != comp["module"] and not args.json:  # moved to another group: move the files too
        old_file = store.source_path(before[0], before[1])
        new_file = store.source_path(before[0], comp)
        print(ui.warn(f"Move the files too: git mv {old_file} {new_file}; git mv {store.test_path(before[1])} "
                      f"{store.test_path(comp)} (and fix the imports that name the old module)"))
    after_change(args, root)
    print_result(args, comp, f"Updated the spec of '{comp['id']}'. Commit .archvow/ with the code that follows it."
           + to_change(f"archvow component edit {comp['id']} -d \"...\""), success=True)
    if comp["to_review"] and not args.json:  # recorded before the change: nothing deleted, a person looks again
        cid = comp["id"]
        print(ui.warn(f"To review: {', '.join(comp['to_review'])} - recorded before this change, each may no "
                      "longer hold (ARCH057; nothing was deleted)."))
        print(ui.dim(f"  look at them: archvow show {cid}; change one by recording it again; when every one "
                     f"still holds: archvow component accept {cid}"))
    return 0


def cmd_component_accept(args: argparse.Namespace) -> int:
    """archvow component accept <component>: what was recorded before its change still holds (ARCH057)."""
    root = project_root(args)
    labels = toreview.accept(root, args.component)
    after_change(args, root)
    created = [label for label in labels if label.startswith("the component (created by")]
    others = [label for label in labels if label not in created]
    text = " ".join(([f"'{args.component}' {created[0][len('the component '):]} is the team's now, accepted by you today."] if created else [])
                    + ([(f"Looked at again after the change of '{args.component}': {', '.join(others)} - each still "
                         "holds, signed again by you today.")] if others else []))
    print_result(args, {"component": args.component, "accepted": labels}, text + " Commit .archvow/.", success=True)
    return 0


def cmd_component_remove(args: argparse.Namespace) -> int:
    """archvow component remove <component>: with its decisions, hazards and invariants."""
    root = project_root(args)
    target = args.component
    if ITEM_ID.match(target):
        kind, item = find_item(store.load(root), target)
        raise SpecError(f"{target} is {a_or_an(kind)}: archvow {kind} remove {item['id']}")
    data = store.load(root)
    _, comp = find_component(data, target)
    hazards = [h["id"] for h in store.hazards(data) if h.get("component") == target]
    invariants = [i["id"] for i in data.get("invariants", []) or [] if i.get("component") == target]
    confirm(args, f"remove the component {target}, its {count(len(comp.get('decisions') or []), 'decision')}, "
                   f"{count(len(hazards), 'hazard')} and {count(len(invariants), 'invariant')}")
    removed = remove_component(root, target)
    ai.drop_component(root, target)
    extra = ""
    if removed["hazards"] or removed["invariants"]:
        extra = f" Also removed hazards {removed['hazards']} and invariants {removed['invariants']}."
    text = (f"Removed '{removed['component']}' from the spec.{extra} Delete its file and test too: "
            "`archvow check` reports them until you do.")
    after_change(args, root)
    print_result(args, removed, text, success=True)
    return 0


def cmd_component_move(args: argparse.Namespace) -> int:
    """archvow component move <component> <feature>: its vow moves to that feature; nothing else changes."""
    root = project_root(args)
    moved = move_component(root, args.component, args.feature)
    after_change(args, root)
    print_result(args, moved, f"Moved '{moved['id']}' from {moved['was']} to {moved['feature']}: {moved['file']}."
                 + to_change(f"archvow component move {moved['id']} {moved['was']}"), success=True)
    return 0


def declare_component(b: Builder) -> None:
    """`archvow component`: its parser."""
    csub = b.noun("component", "what must exist: add, change, move or remove a component of the spec",
                  "add|edit|accept|move|remove", examples="""
        archvow component add <type> <name> -d "<what it must do>" --feature <feature> -s <ticket> -u <component>
        archvow component edit <component> -d "<the new description>"
        archvow component accept <component>     # what was recorded before that change still holds
        archvow component move <component> <feature>
        archvow component remove <component>
        """)
    _declare_add(b, csub)

    p = b.command("edit", cmd_component_edit, "change a component's description, ticket, dependencies or signature",
                  True, parent=csub, examples="""
        archvow component edit <component> -d "<the new description>"
        archvow component edit <component> -u <component>,<component>      # the complete new list
        archvow component edit <component> -g orders                       # move it into the folder orders/
        archvow component edit <component> --owners @acme/payments         # its team approves its vow
        archvow component edit <component> --owners ""                      # back to the architects
        """)
    p.add_argument("component", help=COMPONENT_HELP)
    p.add_argument("-d", "--description", metavar="TEXT",
                   help="the new description (what gets implemented); what was recorded before is then to review "
                        "(archvow component accept)")
    p.add_argument("-s", "--spec", metavar="TICKET", help="the new ticket or user story")
    p.add_argument("-u", "--uses", metavar="IDS", help="the complete new list, comma-separated ('' for none)")
    p.add_argument("--signature", help="only for types with an overridable signature")
    p.add_argument("-g", "--group", metavar="GROUP",
                   help="move it to another folder inside its layer ('' for none); then git mv its files")
    p.add_argument("-r", "--route", action="append", metavar="ROUTE",
                   help='for a router: the complete new list of routes, one -r each')
    p.add_argument("--owners", metavar="WHO",
                   help="who approves changes to its vow besides the architects: @user, @group (several with "
                        "spaces or commas; '' for the architects only). Written in CODEOWNERS; a weakened guard "
                        "still needs the architects (ARCH020)")
    p.add_argument("--from", dest="source", metavar="BRIEF",
                   help="the brief it is drawn from: briefs/<file>.md, or briefs/<file>.md#<section> (a heading); "
                        "archvow check warns when that text changes (ARCH039)")
    p = b.command("accept", cmd_component_accept, "after a change of its description, signature or routes: a person "
                  "looked at what was recorded before and each item still holds (signs them again)", True, parent=csub,
                  examples="""
        archvow show <component>               # the items to review, and why
        archvow decision make <component> <n> "<the new answer>"   # one no longer holds: record it again
        archvow component accept <component>   # every one still holds
        """)
    p.add_argument("component", help=COMPONENT_HELP)
    p = b.command("move", cmd_component_move, "move a component to another feature (its vow moves; its id, uses "
                  "and tests stay)", True, parent=csub, examples="""
        archvow component move <component> <feature>
        """)
    p.add_argument("component", help=COMPONENT_HELP)
    p.add_argument("feature", help="the feature it goes to (archvow show lists them)")
    p = b.command("remove", cmd_component_remove, "remove a component with its decisions, hazards and invariants "
                  "(asks first)", True, parent=csub, examples="""
        archvow component remove <component>      # then delete its file and test: archvow check lists them
        """)
    p.add_argument("component", help=COMPONENT_HELP)
    p.add_argument("--yes", action="store_true", help="do not ask for confirmation (scripts)")


def _declare_add(b: Builder, csub) -> None:
    """`archvow component add`: its options."""
    p = b.command("add", cmd_component_add, "specify a component (writes the spec, never code)", True, parent=csub,
                  details=types_details, examples="""
        archvow component add <type> <name> -d "<what it must do>" -s <ticket>
        archvow component add <type> <name> -d "<what it must do>" -u <component>,<component>  # it uses them
        archvow component add <type> <name> -d "<what it must do>" -g <group>     # in the folder <layer>/<group>/
        archvow component add <type> <name> -d "<what it must do>" -k <kind>      # a reader of a table, a database...
        archvow component add <type> <name> -d "<what it does>" --file src/<package>/crud.py  # existing code
        """)
    p.add_argument("type", help="component type (listed below)")
    p.add_argument("name", help="short snake_case name; the type turns it into the component id (below)")
    p.add_argument("-d", "--description", required=True, metavar="TEXT",
                   help="what the component must do - the instruction the AI assistant or developer "
                        "implements, with the details that matter (change it with archvow component edit)")
    p.add_argument("-f", "--feature", metavar="FEATURE",
                   help="the feature it belongs to (archvow feature add); default: the project's one feature - "
                        "the first component makes it, named after the project; `shared`: what every feature uses")
    p.add_argument("-s", "--spec", metavar="TICKET", help="ticket or user story it implements, e.g. US-001")
    p.add_argument("-u", "--uses", metavar="IDS",
                   help="comma-separated ids of the components it uses")
    p.add_argument("-k", "--kind", metavar="KIND",
                   help="for the types that have kinds (listed below): what it reads or writes, e.g. a reader "
                        "of files (the default), a table, a database (jdbc), a connector or custom code; "
                        "fixed once added (remove and add again to change it)")
    p.add_argument("--signature", help="replace the public function's signature (only for the types that "
                                       "allow it, listed below; e.g. a second input)")
    p.add_argument("--container", help="container id, when the project has several (default: the first)")
    p.add_argument("-g", "--group", metavar="GROUP",
                   help="a folder inside the layer, to organise many components, e.g. orders: "
                        "<layer>/orders/<file>.py and tests/<layer>/orders/test_<id>.py")
    p.add_argument("-r", "--route", action="append", metavar="ROUTE",
                   help='for a router: one route, "<function>: <METHOD> <path>" (repeatable), '
                        'e.g. "get_order: GET /orders/{order_id}"')
    p.add_argument("--from", dest="source", metavar="BRIEF",
                   help="the brief it is drawn from: briefs/<file>.md, or briefs/<file>.md#<section> (a heading); "
                        "archvow check warns when that text changes (ARCH039)")
    p.add_argument("--file", metavar="PATH",
                   help="adopt an existing module where it is (path from the project root): its layer comes "
                        "from `layer_paths`, its symbols are the public functions, classes, constants and "
                        "routes the file has today")
