"""`archvow decision make|propose|accept|add`: answers to a component's questions.
"""

from __future__ import annotations

import argparse
from pathlib import Path

from archvow import proposals as ai
from archvow import questions
from archvow.cli.args import COMPONENT_HELP, Builder
from archvow.cli.output import after_change, print_result, project_root, source_of, to_change
from archvow.foundation.errors import SpecError
from archvow.model import store
from archvow.model.spec import find_component
from archvow.proposals import ProposalError, propose
from archvow.spec.decisions import (
    accept_proposal,
    decide,
    decide_for_type,
    suggested_answer,
    unset_for_type,
)


def cmd_decision_make(args: argparse.Namespace) -> int:
    """archvow decision make <component> <n>[,<n>...] ["answer"]: answer questions by number (or P1, O2...)."""
    root = project_root(args)
    if args.type or args.unset:
        return _decision_for_type(args, root)
    if args.question is None:
        raise SpecError(f"give the question's number: archvow decision make {args.component} <number> [\"...\"] "
                        f"(archvow show {args.component} lists them)")
    numbers = args.question.replace(" ", "").split(",")
    if not all(n.isdigit() or questions.is_key(n) for n in numbers):
        raise SpecError(f"'{args.question}' is not a question number (archvow show {args.component} lists them); "
                        f"a new question with its answer: archvow decision add {args.component} \"<question>\" "
                        "\"<answer>\"")
    if all(questions.is_key(n) for n in numbers):  # P1, O2, C1: personal data, operations, company
        if args.answer is None:
            raise SpecError(f"give the answer: archvow decision make {args.component} {args.question} \"...\"")
        answered = [questions.answer(root, args.component, n, args.answer) for n in numbers]
        after_change(args, root)
        text = "\n".join(f"Decision made ({q['key']}): {q['question']}\n  -> {q['answer']}"
                         + to_change(f"archvow decision make {args.component} {q['key']} \"...\"") for q in answered)
        print_result(args, answered[0] if len(answered) == 1 else answered, text, success=True)
        return 0
    if args.answer is None:  # no text: the template's suggestion, question by question
        data = store.load(root)
        decisions = []
        for n in numbers:
            suggested = suggested_answer(root, data, args.component, int(n)) if n.isdigit() else None
            if suggested is None:
                raise SpecError(f"question {n} of {args.component} has no suggested answer: give yours "
                                f"(archvow decision make {args.component} {n} \"...\")")
            decisions.append(decide(root, args.component, int(n), suggested))
    else:  # one answer, or the same answer to several questions
        decisions = [decide(root, args.component, int(n), args.answer) for n in numbers]
    for n in numbers:  # a person's answer replaces what the AI proposed
        ai.take(root, args.component, int(n))
    after_change(args, root)
    origin = "suggested" if args.answer is None else "your own"
    text = "\n".join(f"Decision made ({origin}): {d['question']}\n  -> {d['answer']}"
                     + to_change(f"archvow decision make {args.component} {n} \"...\"")
                     for n, d in zip(numbers, decisions, strict=False))
    print_result(args, decisions[0] if len(decisions) == 1 else decisions, text, success=True)
    return 0


def _decision_for_type(args: argparse.Namespace, root: Path) -> int:
    """archvow decision make --type <type> <n> ["answer"] | --unset: one answer for every component of a type.
    The positionals shift: what argparse read as the component is the number, as the number the answer."""
    if not args.type:
        raise SpecError("--unset goes with --type: archvow decision make --type <type> <number> --unset")
    number, answer = args.component, args.question
    if args.answer is not None or not str(number).isdigit():
        raise SpecError(f"archvow decision make --type {args.type} <number> [\"<answer>\"] - one question at a time, "
                        "by its number in archvow show of a component of that type")
    if args.unset:
        if answer is not None:
            raise SpecError("--unset takes no answer")
        done = unset_for_type(root, args.type, int(number))
        after_change(args, root)
        text = (f"Question {number} of every {args.type} is no longer answered for the whole type: "
                f"{done['question']}\n  each one answers it on its own: "
                + (", ".join(done["components"]) or "no component of that type yet")
                + to_change(f"archvow decision make --type {args.type} {number} \"...\""))
        print_result(args, done, text, success=True)
        return 0
    entry = decide_for_type(root, args.type, int(number), answer)
    after_change(args, root)
    origin = "suggested" if answer is None else "your own"
    lines = [f"Decision made for every {args.type} ({origin}): {entry['question']}", f"  -> {entry['answer']}",
             "  takes it: " + (", ".join(entry["components"]) or "no component of that type yet")
             + f" - and every {args.type} added later"]
    if entry["own"]:
        lines.append("  keeps its own answer: " + ", ".join(entry["own"]))
    text = "\n".join(lines) + to_change(f"archvow decision make --type {args.type} {number} \"...\" (or --unset)")
    print_result(args, entry, text, success=True)
    return 0


def cmd_decision_propose(args: argparse.Namespace) -> int:
    """archvow decision propose <c> <n> "answer": the AI's answer, for a person to review (mode guided/free)."""
    root = project_root(args)
    if not args.question.isdigit():
        raise SpecError("decision propose answers a question by its number (archvow show lists them)")
    try:
        entry = propose(root, args.component, int(args.question), args.answer)
    except ProposalError as exc:
        raise SpecError(str(exc)) from exc
    after_change(args, root)
    print_result(args, entry, f"Proposed (by the AI, not reviewed yet): {entry['question']}\n  -> {entry['answer']}\n"
                        f"A person reviews it: archvow decision accept {args.component} {args.question}"
                        + to_change(f"archvow decision make {args.component} {args.question} \"...\""), success=True)
    return 0


def cmd_decision_accept(args: argparse.Namespace) -> int:
    """archvow decision accept <c> <n>: a person accepts what the AI proposed; it joins the component's vow."""
    root = project_root(args)
    try:
        decision = accept_proposal(root, args.component, args.number)
    except ProposalError as exc:
        raise SpecError(str(exc)) from exc
    after_change(args, root)
    print_result(args, decision, f"Decision made (proposed by the AI, accepted): {decision['question']}\n"
                           f"  -> {decision['answer']}"
                           + to_change(f"archvow decision make {args.component} {args.number} \"...\""), success=True)
    return 0


def cmd_decision_add(args: argparse.Namespace) -> int:
    """archvow decision add <component> "question" "answer": a question the template does not ask, decided."""
    root = project_root(args)
    numbers = args.question.replace(" ", "").split(",")
    if all(n.isdigit() or questions.is_key(n) for n in numbers):
        raise SpecError(f"question {args.question} exists: archvow decision make {args.component} {args.question} "
                        "\"<answer>\"")
    decision = decide(root, args.component, args.question, args.answer, source=source_of(root, args))
    number = len(find_component(store.load(root), args.component)[1]["decisions"])
    after_change(args, root)
    print_result(args, decision, f"Decision made (your own): {decision['question']}\n  -> {decision['answer']}"
           + to_change(f"archvow decision make {args.component} {number} \"...\""), success=True)
    return 0


def declare_decision(b: Builder) -> None:
    """`archvow decision`: its parser."""
    dsub = b.noun("decision", "what a component does: answer its questions, so nothing is left to chance",
                  "make|add|propose|accept",
                  examples="""
        archvow decision make <component> <n> "<the answer>"
        archvow decision add <component> "<a new question>" "<its answer>"
        """)
    p = b.command("make", cmd_decision_make, "answer questions by number (archvow show lists them)", True,
                  parent=dsub, examples="""
        archvow decision make <component> 1 "<the answer>"
        archvow decision make <component> 1                      # the suggested answer (archvow show shows it)
        archvow decision make <component> 3,4 "<the same answer to questions 3 and 4>"
        archvow decision make <component> P1 "<purpose of the processing>"     # P: personal data, O: operations
        archvow decision make --type writer 3 "<one answer for every writer>"   # today's and later ones
        archvow decision make --type writer 3 --unset                          # each writer answers again
        """)
    p.add_argument("component", help=COMPONENT_HELP + " (with --type: the question's number)")
    p.add_argument("question", metavar="number", nargs="?",
                   help="the question's number in archvow show: 1, 3,4, P1 or O2 (with --type: the answer)")
    p.add_argument("answer", nargs="?", help="the decision, in plain words; it becomes a test "
                   "(none: the template's suggested answer, when it gives one)")
    p.add_argument("--type", metavar="TYPE",
                   help="answer the question once for every component of this type, today's and later ones "
                        "(an architect's decision; a component's own answer still wins)")
    p.add_argument("--unset", action="store_true",
                   help="with --type: no longer answer it for the whole type (each component answers it again)")
    p = b.command("propose", cmd_decision_propose, "the AI's answer to an open question, for a person to review "
                  "(mode guided or free)", True, parent=dsub, examples="""
        archvow decision propose <component> 6 "<the answer the AI chose>"     # then it goes on
        archvow decision accept <component> 6                                  # a person reviews it
        """)
    p.add_argument("component", help=COMPONENT_HELP)
    p.add_argument("question", metavar="number", help="the question's number in archvow show")
    p.add_argument("answer", help="the answer the AI chose, in plain words")
    p = b.command("accept", cmd_decision_accept, "accept what the AI proposed: it becomes a decision (a person, "
                  "never the AI)", True, parent=dsub, examples="archvow decision accept <component> 6")
    p.add_argument("component", help=COMPONENT_HELP)
    p.add_argument("number", type=int, help="the question's number in archvow show")
    p = b.command("add", cmd_decision_add, "add a question the template does not ask, with its answer", True,
                  parent=dsub, examples='archvow decision add <component> "<a new question>" "<its answer>"')
    p.add_argument("component", help=COMPONENT_HELP)
    p.add_argument("question", help="the new question")
    p.add_argument("answer", help="the decision, in plain words; it becomes a test")
    p.add_argument("--from", dest="source", metavar="BRIEF",
                   help="the brief it is drawn from: briefs/<file>.md, or briefs/<file>.md#<section> (a heading); "
                        "archvow check warns when that text changes (ARCH039)")
