"""`archvow feature add|rename|remove`: what the product does, each feature a folder of the spec.
"""

from __future__ import annotations

import argparse

from archvow import agent
from archvow.cli.args import Builder
from archvow.cli.output import after_change, print_result, project_root, to_change
from archvow.model import store
from archvow.spec.features import add_feature, remove_feature, rename_feature


def cmd_feature_add(args: argparse.Namespace) -> int:
    root = project_root(args)
    found = agent.detect(root, agent.tool_data(root, store.load(root)))  # an AI agent (modes guided, free)
    entry = add_feature(root, args.name, args.description, args.brief, created_by=found.tool if found else None)
    after_change(args, root)
    print_result(args, entry, f"Added the feature '{entry['name']}': .archvow/features/{entry['name']}/\n"
                 f"Next: archvow component add <type> <name> -d \"...\" --feature {entry['name']}"
                 + to_change(f"archvow feature rename {entry['name']} <name>"), success=True)
    return 0


def cmd_feature_rename(args: argparse.Namespace) -> int:
    root = project_root(args)
    renamed = rename_feature(root, args.feature, args.name)
    after_change(args, root)
    print_result(args, renamed, f"Renamed the feature '{renamed['was']}' to '{renamed['name']}' "
                 f"({len(renamed['components'])} component(s) moved with it).", success=True)
    return 0


def cmd_feature_remove(args: argparse.Namespace) -> int:
    root = project_root(args)
    removed = remove_feature(root, args.feature)
    after_change(args, root)
    print_result(args, removed, f"Removed the feature '{removed['name']}'.", success=True)
    return 0


def declare_feature(b: Builder) -> None:
    """`archvow feature`: its parser."""
    fsub = b.noun("feature", "what the product does: add, rename or remove a feature (a folder of the spec "
                  "holding its components)", "add|rename|remove", examples="""
        archvow feature add orders -d "A customer creates orders and reads their own" --brief briefs/orders.md
        archvow feature rename orders ordering
        archvow feature remove orders          # refused while it has components
        """)
    p = b.command("add", cmd_feature_add, "add a feature: .archvow/features/<name>/", True, parent=fsub,
                  examples="""
        archvow feature add orders -d "A customer creates orders and reads their own"
        archvow feature add orders -d "..." --brief briefs/orders.md
        """)
    p.add_argument("name", help="lower case, digits and _: it names the folder (orders, invoices) - what the product "
                                "does, not a ticket")
    p.add_argument("-d", "--description", required=True, metavar="TEXT", help="what the product does in it")
    p.add_argument("--brief", metavar="FILE", help="the brief people wrote for it (briefs/orders.md)")
    p = b.command("rename", cmd_feature_rename, "rename a feature (its folder moves with its components)", True,
                  parent=fsub, examples="archvow feature rename orders ordering")
    p.add_argument("feature", help="the feature (archvow show lists them)")
    p.add_argument("name", help="its new name")
    p = b.command("remove", cmd_feature_remove, "remove a feature with no component left", True, parent=fsub,
                  examples="archvow feature remove orders")
    p.add_argument("feature", help="the feature (archvow show lists them)")
