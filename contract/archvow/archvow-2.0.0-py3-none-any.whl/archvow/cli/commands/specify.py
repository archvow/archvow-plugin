"""`archvow specify`: answer what is still open, one question at a time, in a terminal.
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

from archvow import proposals as ai
from archvow.cli.args import Builder
from archvow.cli.console import style as ui
from archvow.cli.console.ask import ask, setup_line_editing
from archvow.cli.output import after_change, project_root
from archvow.foundation.errors import SpecError
from archvow.foundation.i18n import tr
from archvow.model import store
from archvow.model.spec import find_component
from archvow.privacy import classify, columns_line, known_columns
from archvow.questions import answer as answer_question
from archvow.spec.decisions import accept_proposal, decide
from archvow.spec.hazards import add_hazard, dismiss_question
from archvow.spec.invariants import add_invariant
from archvow.templates import templates_of
from archvow.views.component import open_items
from archvow.views.component_doc import situation


def cmd_specify(args: argparse.Namespace) -> int:
    root = project_root(args)
    if not (sys.stdin.isatty() and sys.stdout.isatty()):
        target = args.component or "<component>"
        raise SpecError(f"specify asks questions in a terminal; to see what is open: archvow show {target}")
    data = store.load(root)
    say = _speaker(data)
    items = open_items(root, args.component)
    if not items:
        print(ui.ok(say("Nothing left to specify.") + ("" if args.component else say(" Next: archvow next"))))
        return 0
    setup_line_editing()  # arrows, Home/End, Up for earlier answers, Tab for the suggestion
    print(ui.dim(say("{count} item(s) to specify", count=len(items)))
          + " (" + _keys(say, *EDIT_KEYS, ("s", "skip"), ("q", "quit")) + ")")
    steps = {"decision": _specify_decision, "question": _specify_decision, "column": _specify_column,
             "safety": _specify_safety}
    components = {c["id"]: c for container in data["containers"] for c in container.get("components", [])}
    shown = None
    try:
        for number, item in enumerate(items, 1):
            if item["component"] != shown:  # the component, once, before its items
                shown = item["component"]
                comp = components.get(shown) or {}
                kind = f", {comp['kind']}" if comp.get("kind") else ""
                print("\n" + ui.title(f"{shown} ({comp.get('type', '?')}{kind})")
                      + ui.dim(f" - {comp.get('description', '')}"))
                known = _known_columns_line(root, data, shown)
                if known:
                    print(ui.dim(known))
            print("\n" + ui.dim(f"  {number}/{len(items)}"), end=" ")
            if not steps[item["kind"]](root, item, say):
                break
    except (KeyboardInterrupt, EOFError):  # Ctrl+C or Ctrl+D: stop like q, what was answered stays
        print("\n" + ui.error(say("stopped - the answers given before are saved (what is still open: "
                                         "archvow show {target})", target=args.component or "<component>")))
        return 130
    finally:
        after_change(args, root)  # the views follow every answer recorded, even when stopped
    return 0


def _known_columns_line(root: Path, data: dict, cid: str) -> str:
    container, comp = find_component(data, cid)
    found = known_columns(root, container, comp, templates_of(root, data).get(container["id"]))
    return columns_line(found, cid)


def _speaker(data: dict):
    """What `specify` says, in the project's language (commands and keywords stay as they are)."""
    language = data.get("language") or "en"
    return lambda message, /, **values: tr(language, message, **values)


def _keys(say, *pairs: tuple[str, str]) -> str:
    """'Enter: suggestion - Tab: edit - q: quit': each key in colour, its words in the language."""
    return " - ".join(f"{ui.code(say(key))}{say(': ')}{say(words)}" for key, words in pairs)


EDIT_KEYS = (("Enter", "suggestion"), ("Tab", "edit"))  # with a suggestion: Enter takes it, Tab puts it in the line


def _prompt(say, label: str, suggestion: str | None = None, keys: str = "") -> str:
    """'  what must never happen (hazard)? [the suggestion] (keys): ' - the suggestion greyed."""
    shown = " " + ui.hint(f"[{suggestion}]") if suggestion else ""
    return f"  {label}{shown}" + (f" ({keys})" if keys else "") + say(": ")


def _specify_decision(root: Path, item: dict, say) -> bool:
    """A decision to make (1, 2...) or a P/O/C question (P1, O2...): one answer."""
    label = (say("vow question {key}", key=item["key"]) if item.get("key")
             else say("spec decision {n}", n=item["number"]))
    print(ui.label(label, "question" if item.get("key") else "decision"))
    print(ui.question(item["question"], indent=2))
    suggested = item.get("suggested")
    choices = [] if suggested else list(item.get("choices") or [])
    for number, choice in enumerate(choices, 1):  # no default: answers to start from, by their number
        print(ui.dim(f"   {number}. {choice}"))
    if item.get("proposed"):  # the review of what the AI chose: Enter accepts it
        suggested = item["proposed"]
        print(ui.warn("  " + say("proposed by the AI: {answer}", answer=suggested)))
    keys = (_keys(say, *EDIT_KEYS, ("s", "skip"), ("q", "quit")) if suggested
            else _keys(say, ("Enter", "skip"), ("q", "quit")))
    answer = ask(_prompt(say, say("answer"), None if item.get("proposed") else suggested, keys), suggested).strip()
    if answer.lower() == "q":
        return False
    if suggested and not answer:
        answer = suggested
    elif answer.lower() == "s" and suggested:
        answer = ""
    elif answer.isdigit() and 1 <= int(answer) <= len(choices):
        answer = choices[int(answer) - 1]
    elif re.match(r"^\d+\s*[-:,]\s*\S", answer) and choices and 1 <= int(re.match(r"\d+", answer).group()) <= len(choices):
        number = int(re.match(r"\d+", answer).group())  # "2 - from the --run-date argument": a choice, completed
        answer = choices[number - 1] + " - " + re.sub(r"^\d+\s*[-:,]\s*", "", answer)
    if answer:
        try:
            if item.get("key"):
                answer_question(root, item["component"], item["key"], answer)
            elif item.get("proposed") and answer == item["proposed"]:
                accept_proposal(root, item["component"], item["number"])
            else:
                decide(root, item["component"], item["number"], answer)
                ai.take(root, item["component"], item["number"])
            which = item.get("key") or item["number"]
            origin = say(" (suggested)") if answer == suggested else say(" (your own)") if suggested else ""
            print(ui.ok(say("decision made") + origin + say(": ") + answer)
                  + _say_change(say, f"archvow decision make {item['component']} {which} \"...\""))
        except SpecError as error:
            print(ui.warn(str(error)))
    return True


def _say_change(say, command: str) -> str:
    return "\n" + ui.dim("  " + say("to change it: {command}", command=command))


def _specify_column(root: Path, item: dict, say) -> bool:
    print(ui.label(say("column {name}", name=item["column"]), "question"))
    print(ui.question(say("personal, special (health, religion, biometrics... sensitive) or none?"), indent=2))
    while True:
        choice = ask("  (" + _keys(say, ("p", "personal"), ("s", "special"), ("n", "none"), ("Enter", "skip"),
                                      ("q", "quit")) + ")" + say(": ")).strip().lower()
        if choice in ("", "q", "p", "s", "n"):
            break
    if choice == "q":
        return False
    if choice:
        kind = {"p": "personal", "s": "special", "n": "none"}[choice]
        classify(root, item["component"], [item["column"]], kind)
        print(ui.ok(f"{item['column']}: {kind}")
              + _say_change(say, f"archvow column set {item['component']} {item['column']} personal|special|none"))
    return True


def _specify_safety(root: Path, item: dict, say) -> bool:
    """One vow question: what must never happen (the hazard), then what is always true so it cannot
    happen (the invariant). Each suggestion appears once, greyed, in the prompt that answers it; the
    hazard is recorded high (it needs an invariant, a plain test of it is enough); `archvow hazard
    add` sets another severity."""
    print(ui.label(say("vow question S{n}", n=item["number"]), "question"))
    print(ui.question(situation(item["question"]), indent=2))
    suggestion = item.get("suggestion") or {}
    if suggestion.get("decision"):
        d = suggestion["decision"]
        print(ui.dim("  " + say("already made in decision {number}: {answer}", number=d["number"], answer=d["answer"])))
    text = ""
    if suggestion.get("not_applicable"):  # the decision says there is nothing to protect: Enter says so
        keys = _keys(say, ("Enter", "not applicable"), ("s", "skip"), ("q", "quit"))
        text = ask(_prompt(say, say("what must never happen (hazard)?"), suggestion["not_applicable"], keys)).strip()
        if text.lower() == "q":
            return False
        if text.lower() == "s":
            return True
        if not text or text == suggestion["not_applicable"]:
            try:
                dismiss_question(root, item["component"], str(item["number"]), suggestion["not_applicable"])
                print(ui.ok(say("not applicable: {reason}", reason=suggestion["not_applicable"]))
                      + _say_change(say, f"archvow hazard remove {item['component']} S{item['number']}"))
            except SpecError as error:
                print(ui.warn(str(error)))
            return True
        suggestion = {}  # a hazard written anyway: archvow warns that it contradicts the decision
    hazard = suggestion.get("hazard") or None
    keys = _keys(say, *(EDIT_KEYS if hazard else ()), ("n", "not applicable"), ("s", "skip"), ("q", "quit"))
    while not text:
        text = ask(_prompt(say, say("what must never happen (hazard)?"), hazard, keys), hazard).strip()
        if text.lower() in ("q", "s", "n"):
            break
        text = text or hazard or ""
    if text.lower() == "q":
        return False
    if text.lower() == "s":
        return True
    try:
        if text.lower() == "n":
            reason = ""
            while not reason:
                reason = ask(_prompt(say, say("why it cannot happen here"))).strip()
            dismiss_question(root, item["component"], str(item["number"]), reason)
            print(ui.ok(say("not applicable: {reason}", reason=reason))
                  + _say_change(say, f"archvow hazard remove {item['component']} S{item['number']}"))
            return True
        proposal = suggestion.get("invariant") or None
        keys = _keys(say, *(EDIT_KEYS if proposal else ()), ("s", "skip"), ("q", "quit"))
        statement = ask(_prompt(say, say("how is it prevented (invariant)?"), proposal, keys), proposal).strip()
        if statement.lower() == "q":
            return False
        statement = None if statement.lower() == "s" else (statement or proposal)
        entry = add_hazard(root, text, guide_word=str(item["number"]), severity="high",
                                 component=item["component"])
        linked = suggestion.get("decision") if statement and statement == proposal else None
        invariant = (add_invariant(root, None, mitigates=[entry["id"]], component=item["component"],
                                         from_decision=linked["number"]) if linked
                     else add_invariant(root, statement, mitigates=[entry["id"]], component=item["component"])
                     if statement else None)
        print(ui.ok(say("{id} recorded: {text}", id=entry["id"], text=entry["description"])))
        for warning in entry.get("warnings") or []:
            print(ui.warn("  ! " + warning))
        if invariant:
            print(ui.dim("  " + say("prevented by {id}: {statement}", id=invariant["id"], statement=invariant["statement"])))
            for warning in invariant.get("warnings") or []:
                print(ui.warn("  ! " + warning))
        else:
            print(ui.warn("  " + say("It needs an invariant: {command}",
                                     command=f"archvow invariant add {item['component']} \"...\" --prevents {entry['id']}")))
        print(_say_change(say, f"archvow hazard edit {entry['id']} \"...\"").lstrip("\n"))
    except SpecError as error:
        print(ui.warn(str(error)))
    return True


def declare_specify(b: Builder) -> None:
    """`archvow specify`: its parser."""
    p = b.command("specify", cmd_specify, "answer what is still open, one question at a time (in a terminal)",
                  examples="""
        archvow specify                         # every component: decisions to make, then safety
        archvow specify <component>             # one component (in a terminal; to read: archvow show)
        """)
    p.add_argument("component", nargs="?", help="only this component (default: all)")
