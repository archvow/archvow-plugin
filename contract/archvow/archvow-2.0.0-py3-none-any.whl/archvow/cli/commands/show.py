"""`archvow show`: a component, a feature, a file, an item or a search, on one screen.
"""

from __future__ import annotations

import argparse
from pathlib import Path

from archvow.cli.args import Builder
from archvow.cli.console import style as ui
from archvow.cli.output import as_json, checked, project_root
from archvow.cli.screen import print_component
from archvow.foundation.errors import SpecError
from archvow.model import features as feats
from archvow.model import store
from archvow.model.spec import find_component, rule_scope
from archvow.spec.items import ITEM_ID
from archvow.views import locate
from archvow.views.component import component_view, item_view
from archvow.views.feature_doc import feature_view
from archvow.views.search import NOTES, SHOW_MAX, search


def cmd_show(args: argparse.Namespace) -> int:
    root = project_root(args)
    data = store.load(root)
    if args.json and not args.component:
        print(as_json(data))
        return 0
    if not args.component:
        print("archvow show <component> shows one component (archvow show <component> H1: one of its hazards)\n"
              + ui.dim("The whole project, in build order: archvow next - on one page: archvow doc"))
        return 0
    if locate.is_path(args.component, root):
        return _show_file(args, root, data)
    wanted = store.normalise_item_id([args.component, *([args.item] if args.item else [])])
    if args.item and not ITEM_ID.match(wanted):
        raise SpecError(f"usage: archvow show {args.component} H1 (or INV1): one of its hazards or invariants")
    report = checked(args, root)
    if ITEM_ID.match(wanted):
        item = item_view(root, data, wanted, report)
        if args.json:
            print(as_json(item))
        else:
            _print_item(item)
        return 0
    known = {c["id"] for ct in data.get("containers", []) for c in ct.get("components", [])}
    if args.component not in known and not args.item and args.component in {f["name"] for f in feats.features(data)}:
        feature = feature_view(root, data, args.component, report)
        print(as_json(feature) if args.json else _feature_text(feature))
        return 0
    if args.component not in known and not args.item:  # any other name: where it is, what is wrong with it

        found = search(root, data, args.component, report)
        if args.json:
            print(as_json(found, ensure_ascii=False))
            return 0 if found["total"] else 2
        if not found["total"]:  # nowhere: the close names, and how to declare a component of that name
            close = "; ".join(f"{c['name']} ({c['what']})" for c in found["close"])
            try:
                find_component(data, args.component)
            except SpecError as exc:
                raise SpecError(f"'{args.component}' is not a component, a file or an item, and is nowhere in the "
                                f"project." + (f" Close names: {close}." if close else "") + f" {exc}") from None
        print_search(found)
        return 0
    view = component_view(root, data, args.component, report)
    if args.json:
        print(as_json(view))
        return 0
    print_component(view)
    return 0


def _feature_text(feature: dict) -> str:
    """A feature on one screen: what it does, its components in build order, the features it uses and used by."""
    lines = [ui.title(f"Feature {feature['feature']}") + f"  {len(feature['components'])} component(s)"]
    if feature["description"]:
        lines.append(feature["description"])
    if feature.get("brief"):
        lines.append(ui.dim(f"brief: {feature['brief']}"))
    for c in feature["components"]:
        lines.append(f"  {c['id']:<28} {c['type']:<12} {c['layer']:<14} {c['status']}")
    lines.append(ui.dim("uses: " + (", ".join(feature["uses"]) or "-") + "   used by: "
                        + (", ".join(feature["used_by"]) or "-")))
    lines.append(ui.dim(f"  its doc: archvow doc {feature['feature']} - its AI prompt: archvow prompt --feature "
                        f"{feature['feature']}"))
    return "\n".join(lines)


def _show_file(args: argparse.Namespace, root: Path, data: dict) -> int:
    """`archvow show <file>[:<line>]`: the component that owns a file, read from the defect's side."""
    if args.item:
        raise SpecError(f"usage: archvow show {args.component} (a file, or file:line) - no second word")
    rel, line = locate.resolve(root, args.component)
    cid, role = locate.owner(root, data, rel)
    if cid is None:
        message = locate.not_in_a_component(rel, data)
        if args.json:
            print(as_json({"file": rel, "line": line, "component": None, "hint": message}))
        else:
            print(ui.warn(message))
        return 0
    view = {"file": rel, "role": role, **({"line": line} if line else {}),
            **component_view(root, data, cid, checked(args, root))}
    if line:
        symbol = locate.enclosing(root / rel, line)
        if symbol:
            symbol["called_by"] = locate.callers(root, symbol["name"]) if role == "code" else []
        view["symbol"] = symbol
    if args.json:
        print(as_json(view))
        return 0
    _print_file_header(view)
    print_component(view)
    return 0


def _print_file_header(view: dict) -> None:
    where = f"{view['file']}:{view['line']}" if view.get("line") else view["file"]
    role = "the test file of" if view["role"] == "test" else "code of"
    print(ui.code(where) + f" - {role} {view['component']}")
    symbol = view.get("symbol")
    if symbol:
        what = f"{symbol['kind']} {symbol['name']}" + ("" if symbol["public"] else " (a helper)")
        print(ui.dim(f"  inside {what}, line {symbol['line']}"))
        if view["role"] == "code":
            callers = symbol["called_by"]
            print(ui.dim(f"  tests calling {symbol['name']} by name: {', '.join(callers)}" if callers else
                         f"  no test calls {symbol['name']} by name (found by name only: through another "
                         "function it is not seen)"))
    elif view.get("line"):
        print(ui.dim("  outside any function or class (module level)"))
    print()


def _print_item(view: dict) -> None:
    who = ui.dim(f"recorded by {view.get('by', '?')} on {str(view.get('on', '?'))[:10]}")
    if view["kind"] == "hazard":
        print(ui.title(f"{view['id']} {view['severity']}") + f" ({view.get('component') or 'system'}, "
              f"{view.get('guide_word')}): {view.get('description')}")
        for inv in view["prevented_by"]:
            print(ui.dim(f"  <- prevented by {inv['id']}: {inv['statement']}"
                         + (" - tested" if inv["tested"] else " - not tested yet")))
        if not view["prevented_by"]:
            print(ui.dim("  <- prevented by nothing yet"))
    elif view["kind"] == "invariant":
        print(ui.title(view["id"]) + f" ({view.get('component') or 'system'}): {view.get('statement')}")
        for h in view["prevents"]:
            print(ui.dim(f"  prevents {h['id']} ({h['severity']}): {h['description']}"))
        print(ui.dim(f"  tested: {'yes' if view['tested'] else 'not yet'} ({view.get('verify', '?')})"))
    else:
        print(ui.title(view["id"]) + f" ({rule_scope(view)}): {view.get('text')}")
        print(ui.dim(f"  applies to: {', '.join(view['applies_to']) or 'no component yet'}"))
    print("  " + who)














def declare_show(b: Builder) -> None:
    """`archvow show`: its parser."""
    # ---- reading and answering
    p = b.command("show", cmd_show, "everything about a component on one screen (the whole project: archvow next)",
                  True, examples="""
        archvow show <component>                # decisions, rules, safety, assumptions, next step
        archvow show <component> H1             # one of its hazards (H1) or invariants (INV1), with its links
        archvow show src/<package>/<layer>/<file>.py:42   # a file (and a line): its component, who uses it,
                                                # the tests behind each decision - where a bug points
        archvow show R1                         # one of the project's rules
        archvow show normalize_amount           # any other name (a function, a column, a ticket, an example):
                                                # where it is - spec, code, tests, briefs - and the problems naming it
        archvow show --json                     # the whole spec, as JSON (IDE use)
        """)
    p.add_argument("component", nargs="?", help="one component, a rule R1, a file (file.py or file.py:<line>), "
                   "or any other name to find in the project")
    p.add_argument("item", nargs="?", metavar="H<n>|INV<n>", help="one of its hazards or invariants")


def print_search(result: dict) -> None:
    """The search as the terminal shows it: the groups in order, at most SHOW_MAX lines each."""
    name = result["name"]
    what = f" ({result['summary']})" if result["summary"] else ""
    print(ui.title(name) + ui.dim(f" - found in {result['total']} place{'' if result['total'] == 1 else 's'}{what}"))
    for group in result["groups"]:
        note = NOTES.get(group["group"])
        print("\n" + ui.title(group["title"]) + (ui.dim(f"  ({note})") if note else ""))
        shown = group["hits"][:SHOW_MAX]

        def part_of(hit: dict) -> str:
            return hit["part"] + (f" ({hit['what']})" if hit.get("what") else "") + (
                f" [{hit['marks']}]" if hit.get("marks") else "")
        width = min(max(len(h["component"] or "-") for h in shown), 24)
        size = min(max(len(part_of(h)) for h in shown), 36)
        for hit in shown:
            where = f"{hit['file']}:{hit['line']}" if hit["line"] else hit["file"]
            if group["group"] == "problems":
                code = ui.red(hit["part"]) if hit.get("severity") == "error" else ui.yellow(hit["part"])
                print(f"  {code}  {hit['text']}  " + ui.dim(where))
                continue
            text = hit["text"] if len(hit["text"]) <= 60 else hit["text"][:59] + "…"
            print(f"  {(hit['component'] or '-'):<{width}}  {part_of(hit):<{size}}  {text:<60}  " + ui.dim(where))
        if len(group["hits"]) > SHOW_MAX:
            print(ui.dim(f"  and {len(group['hits']) - SHOW_MAX} more (archvow show {name} --json)"))
