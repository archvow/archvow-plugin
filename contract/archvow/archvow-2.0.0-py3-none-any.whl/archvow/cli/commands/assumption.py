"""`archvow assumption add|accept|reject`: what the implementer assumed.
"""

from __future__ import annotations

import argparse

from archvow.cli.args import COMPONENT_HELP, Builder
from archvow.cli.output import after_change, print_result, project_root, to_change
from archvow.spec.questions import assume, review_assumption


def cmd_assumption_add(args: argparse.Namespace) -> int:
    root = project_root(args)
    entry = assume(root, args.component, args.text)
    after_change(args, root)
    print_result(args, entry, f"Assumption recorded as proposed; CI blocks {args.component} until a person "
           f"accepts it (archvow assumption accept {args.component} <n>, or reject).", success=True)
    return 0


def cmd_assumption_review(args: argparse.Namespace, status: str) -> int:
    root = project_root(args)
    entry = review_assumption(root, args.component, args.number, status)
    after_change(args, root)
    other = "reject" if status == "accepted" else "accept"
    print_result(args, entry, f"Assumption {status}: {entry['text']}"
           + to_change(f"archvow assumption {other} {args.component} {args.number}"), success=True)
    return 0


def declare_assumption(b: Builder) -> None:
    """`archvow assumption`: its parser."""
    asub = b.noun("assumption", "what the implementer assumed: recorded, then accepted or rejected by a person",
                  "add|accept|reject", examples="""
        archvow assumption add <component> "<what was assumed>"
        archvow show <component>                           # lists the assumptions
        archvow assumption accept <component> 1            # a person, never the AI (or: reject)
        """)
    p = b.command("add", cmd_assumption_add, "record an implementer assumption (blocks until accepted)", True,
                  parent=asub, examples='archvow assumption add <component> "<what was assumed>"')
    p.add_argument("component", help=COMPONENT_HELP)
    p.add_argument("text", help="what the implementer assumed")
    for name, status in (("accept", "accepted"), ("reject", "rejected")):
        p = b.command(name, lambda a, s=status: cmd_assumption_review(a, s),
                      f"{name} assumption number N (a person, never the AI)", True, parent=asub,
                      examples=f"archvow show <component>      # lists the assumptions\n"
                               f"archvow assumption {name} <component> 1")
        p.add_argument("component", help=COMPONENT_HELP)
        p.add_argument("number", type=int, help="assumption number, as archvow show shows it")
