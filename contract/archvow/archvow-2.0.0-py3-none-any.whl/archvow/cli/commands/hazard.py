"""`archvow hazard add|dismiss|edit|accept|remove`: what must never happen.
"""

from __future__ import annotations

import argparse
import re
from pathlib import Path

from archvow.cli.args import Builder, guide_words_details
from archvow.cli.console import style as ui
from archvow.cli.items import (
    ITEM_TEXT,
    ai_author,
    edited_item,
    kept_by_a_person,
    remove_item,
    tested_by,
)
from archvow.cli.output import (
    after_change,
    confirm,
    print_result,
    project_root,
    to_change,
    warnings_of,
)
from archvow.foundation.errors import SpecError
from archvow.model import store
from archvow.model.spec import find_component
from archvow.spec.acceptance import accept_hazard
from archvow.spec.hazards import (
    add_hazard,
    dismiss_question,
    edit_hazard,
    reopen_safety_question,
    safety_questions,
    suggestion_for,
)
from archvow.spec.invariants import add_invariant
from archvow.templates import (
    load_template,
    template_name,
)


def cmd_hazard_remove(args: argparse.Namespace) -> int:
    """archvow hazard remove <component> H1 | <component> S<n> (undo a "not applicable")."""
    if args.question is None or re.fullmatch(r"(?i)(H|INV)\d+", args.question):
        args.more = args.question
        return remove_item(args, "hazard")
    if not re.fullmatch(r"[Ss]\d+", args.question):
        raise SpecError(f"usage: archvow hazard remove {args.id} S<n> (a safety question marked not applicable)")
    root = project_root(args)
    component, which = args.id, args.question.upper()
    entry = next((d for d in store.load(root).get("dismissed") or [] if d.get("component") == component), None)
    confirm(args, f"reopen safety question {which} of {component}"
                   + (f" (not applicable: \"{entry.get('rationale')}\")" if entry else ""))
    removed = reopen_safety_question(root, component, which)
    after_change(args, root)
    print_result(args, removed, f"Safety question {which} of {component} is open again: archvow show {component}",
           success=True)
    return 0


def cmd_hazard_accept(args: argparse.Namespace) -> int:
    root = project_root(args)
    target = edited_item(args, "hazard")
    entry = accept_hazard(root, target["id"])
    after_change(args, root)
    guards = f", with {', '.join(entry['invariants'])}" if entry["invariants"] else ""
    print_result(args, entry, f"Kept {entry['id']}{guards}: {entry['description']}", success=True)
    return 0


def _record_hazard(root: Path, component: str | None, question: str, severity: str,
                   description: str | None, added_by: str | None = None,
                   why: str | None = None) -> tuple[dict, dict | None, dict]:
    """A hazard; without a description, the suggested one and, for a critical or high hazard,
    the suggested invariant that prevents it. Returns the suggestion too."""
    _, suggestion = suggestion_for(root, component, question)
    if description is None and suggestion.get("not_applicable"):
        decision = suggestion["decision"]
        raise SpecError(f"decision {decision['number']} says \"{decision['answer']}\": there is nothing to protect - "
                        f"answer not applicable: archvow hazard dismiss {component} {question} (the reason: "
                        f"\"{suggestion['not_applicable']}\"). To declare a hazard anyway, write it: archvow hazard add "
                        f"{component} {question} {severity} \"...\"")
    entry = add_hazard(root, description, guide_word=question, severity=severity, component=component,
                             added_by=added_by, why=why)
    invariant = None
    if description is None and severity in ("critical", "high"):
        if suggestion.get("decision"):  # the decision protects it: a link to it, not a copy of its words
            invariant = add_invariant(root, None, mitigates=[entry["id"]], component=component,
                                            from_decision=suggestion["decision"]["number"], added_by=added_by)
        elif suggestion.get("invariant"):
            invariant = add_invariant(root, suggestion["invariant"], mitigates=[entry["id"]], component=component,
                                            added_by=added_by)
    return entry, invariant, suggestion


def _hazard_text(entry: dict, invariant: dict | None, target: str, suggestion: dict) -> str:
    origin = "the suggested hazard" if entry["description"] == suggestion.get("hazard") else "your own text"
    text = f"Recorded {entry['id']} ({entry['severity']}) - {origin}: {entry['description']}"
    if invariant and invariant.get("from_decision"):
        text += f"\n  prevented by {invariant['id']}: {invariant['statement']}" + tested_by(invariant)
    elif invariant:
        mine = "" if invariant["statement"] == suggestion.get("invariant") else " (your own)"
        text += f"\n  prevented by {invariant['id']}{mine}: {invariant['statement']}" + tested_by(invariant)
    elif entry["severity"] in ("critical", "high"):
        text += (f"\nA {entry['severity']} hazard needs an invariant (what is always true, so it cannot happen): "
                 f"archvow invariant add {target} \"...\" --prevents {entry['id']}")
        if suggestion.get("invariant"):
            text += "\n" + ui.dim(f"  the suggested one: \"{suggestion['invariant']}\"")
    return text + warnings_of(entry) + to_change(f"archvow hazard edit {entry['id']} \"...\" [--severity ...]")


def cmd_hazard_add(args: argparse.Namespace) -> int:
    root = project_root(args)
    component = None if args.component == "system" else args.component
    entry, invariant, suggestion = _record_hazard(root, component, args.guide_word, args.severity, args.description,
                                                  added_by=ai_author(root), why=args.why)
    after_change(args, root)
    payload = {**entry, "invariant": invariant} if invariant else entry
    print_result(args, payload, _hazard_text(entry, invariant, args.component, suggestion)
           + kept_by_a_person(entry, f"archvow hazard accept {entry['id']}"), success=True)
    return 0


def cmd_hazard_dismiss(args: argparse.Namespace) -> int:
    root = project_root(args)
    component = None if args.component == "system" else args.component
    questions = [q.strip() for q in args.guide_word.split(",") if q.strip()]
    entries = [dismiss_question(root, component, q, args.rationale) for q in questions]
    after_change(args, root)
    text = "\n".join(f"Not applicable ({e['guide_word']}): {e['rationale']}" + warnings_of(e)
                     + (to_change(f"archvow hazard remove {component} S{_safety_number(root, component, e)}")
                        if component else "") for e in entries)
    print_result(args, entries[0] if len(entries) == 1 else entries, text, success=True)
    return 0


def _safety_number(root: Path, component: str, entry: dict) -> int:
    """The number `archvow show` gives a safety question (S2), from its guide word."""
    container, comp = find_component(store.load(root), component)
    words = safety_questions(load_template(template_name(container)[0], root), comp)
    return words.index(entry["guide_word"]) + 1


def cmd_hazard_edit(args: argparse.Namespace) -> int:
    root = project_root(args)
    item = edited_item(args, "hazard")
    entry = edit_hazard(root, item["id"], args.words, args.severity)
    after_change(args, root)
    text = f"Changed {ITEM_TEXT['hazard'](entry)} ({' and '.join(entry['changed'])})"
    if entry.get("to_review"):
        text += (f"\n  to review: {', '.join(entry['to_review'])} - check that it still prevents it, then "
                 f"archvow component accept {entry.get('component') or 'system'}")
    text += warnings_of(entry)
    print_result(args, entry, text, success=True)
    return 0


def declare_hazard(b: Builder) -> None:
    """`archvow hazard`: its parser."""
    # ---- safety analysis
    hsub = b.noun("hazard", "what must never happen: record, dismiss, change, keep or remove a hazard",
                  "add|dismiss|edit|accept|remove",
                  examples="""
        archvow show <component>              # the numbered safety questions S1, S2...
        archvow hazard add <component> <number> <severity> "<what must never happen>"
        archvow hazard dismiss <component> <number> "<why it cannot happen here>"
        archvow hazard edit <component> H1 "<new words>" --severity critical
        archvow hazard accept <component> H1      # a person keeps a hazard the AI added
        archvow hazard remove <component> H1
        """)
    hp = b.command("add", cmd_hazard_add, "record what must never happen", True, parent=hsub,
                   details=guide_words_details, examples="""
        archvow hazard add <component> S2 high "<what must never happen>"
        archvow hazard add system <number> critical "<what must never happen to the whole system>"
        """)
    hp.add_argument("component", help="component id, or 'system' for the whole system")
    hp.add_argument("guide_word", metavar="number", help="the safety question's number in archvow show, S2 or 2 "
                    "(or its guide word, listed below)")
    hp.add_argument("severity", choices=["critical", "high", "medium", "low"],
                    help="critical | high | medium | low")
    hp.add_argument("description", nargs="?", help="what must never happen, in plain words (default: the "
                    "suggestion archvow show shows; for critical or high, its invariant is added too - the decision "
                    "that covers the question, when one does)")
    hp.add_argument("--why", metavar="REASON",
                   help="why it is added, in a few words (what in the spec or the brief leaves it open) - "
                        "shown to the person who keeps it")
    hp = b.command("dismiss", cmd_hazard_dismiss, "record that a guide word does not apply, and why", True,
                   parent=hsub, details=guide_words_details,
                   examples='archvow hazard dismiss <component> S3 "<why it cannot happen here>"')
    hp.add_argument("component", help="component id, or 'system'")
    hp.add_argument("guide_word", metavar="number", help="the safety question's number in archvow show, S2 or 2 "
                    "(or its guide word, listed below); several: S2,S4")
    hp.add_argument("rationale", nargs="?", help="why it cannot happen here (default: the decision that says there is "
                    "nothing to protect, e.g. \"decision 2: none\")")
    hp = b.command("edit", cmd_hazard_edit, "change a hazard's words or severity; its id, invariants and tests stay", True,
                   parent=hsub, examples="""
        archvow hazard edit <component> H1 "<new words>"
        archvow hazard edit <component> H1 --severity critical      # its invariants are marked to review
        """)
    hp.add_argument("id", metavar="WHAT", help="the component (then H<n>), or the hazard's id <component>.H1")
    hp.add_argument("more", nargs="?", metavar="H<n>", help="with a component: its hazard H<n>")
    hp.add_argument("words", nargs="?", help="what must never happen, in new words")
    hp.add_argument("--severity", choices=["critical", "high", "medium", "low"], help="critical | high | medium | low")
    hp = b.command("accept", cmd_hazard_accept, "keep a hazard the AI added, with the invariants it added to prevent "
                   "it (a person, never the AI)", True, parent=hsub, examples="""
        archvow hazard accept <component> H1
        archvow hazard accept <component>.H1
        """)
    hp.add_argument("id", metavar="WHAT", help="the component (then H<n>), or the hazard's id <component>.H1")
    hp.add_argument("more", nargs="?", metavar="H<n>", help="with a component: its hazard H<n>")
    hp = b.command("remove", cmd_hazard_remove, "remove a hazard, or undo a \"not applicable\" (asks first)", True,
                   parent=hsub, examples="""
        archvow hazard remove <component> H1        # the invariants that protect only it go with it
        archvow hazard remove <component> S2        # undo a "not applicable": safety question S2 is open again
        """)
    hp.add_argument("id", metavar="WHAT", help="the component (then H<n> or S<n>), or the hazard's id <component>.H1")
    hp.add_argument("question", nargs="?", metavar="H<n>|S<n>",
                    help="with a component: its hazard H<n>, or the safety question S<n> marked not applicable")
    hp.add_argument("--yes", action="store_true", help="do not ask for confirmation (scripts)")
