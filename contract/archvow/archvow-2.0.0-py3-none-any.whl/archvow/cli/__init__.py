"""archvow's console (layer 4): everything a person or a tool types and reads.

  main.py      the bootstrap: streams, completion, logs, the agent gate, dispatch, the one error handler
  parser.py    assembles the parser from commands/*; args.py is its toolkit (Parser, Builder, help texts)
  output.py    how results are printed (--json or text), the "to change it" lines, warnings after a change
  commands/    one module per noun (component, decision, hazard...) or group (project, show, next, verify):
               each declares its commands (declare_<command>) and their handlers (cmd_<command>)
  items.py     what the item commands share; views.py what show, next and specify read about a component
  console/     the terminal: style (colours, symbols, logo), ask (line editing, questions), completion (Tab)

May import every other archvow package; nothing imports it but archvow/__main__.py and the `archvow` script.
"""
