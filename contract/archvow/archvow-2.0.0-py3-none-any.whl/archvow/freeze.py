"""Freeze existing violations so archvow can be adopted on existing code.

`archvow freeze` records today's violations in .archvow/frozen.json (committed,
protected by CODEOWNERS). From then on `archvow check` ignores exactly those - and only
those: anything new fails as usual. Violations that disappear are reported, so the file can
only shrink over time (`archvow freeze` again after fixing). Growing it in a branch is a
guard change (ARCH020 with `--base`).

A violation is identified by rule, file and message - not by line number, so editing other
lines of the file does not unfreeze it.
"""

from __future__ import annotations

import json
from collections import Counter
from pathlib import Path

from archvow.checks.engine import Report, Violation
from archvow.foundation.files import write_text
from archvow.foundation.paths import FROZEN_REL

NEVER_FROZEN = {"ARCH020", "ARCH021"}  # base-branch comparisons are about the change itself


def fingerprint(v: Violation | dict) -> tuple[str, str, str]:
    if isinstance(v, dict):
        return (v["code"], v["file"], v["message"])
    return (v.code, v.file, v.message)


def load(root: Path) -> Counter:
    path = root / FROZEN_REL
    if not path.is_file():
        return Counter()
    data = json.loads(path.read_text(encoding="utf-8"))
    return Counter(fingerprint(item) for item in data.get("frozen", []))


def write(root: Path, report: Report) -> int:
    # only errors: warnings never fail the build, freezing them would just hide reminders
    items = sorted(fingerprint(v) for v in report.violations
                   if v.severity == "error" and v.code not in NEVER_FROZEN)
    payload = {
        "about": "Violations that existed when archvow was adopted. Only fixes may remove "
                 "entries; adding entries needs architect approval. Regenerate: archvow freeze",
        "frozen": [{"code": c, "file": f, "message": m} for c, f, m in items],
    }
    path = root / FROZEN_REL
    path.parent.mkdir(parents=True, exist_ok=True)
    write_text(path, json.dumps(payload, indent=2) + "\n")
    return len(items)


def apply(root: Path, report: Report) -> None:
    """Remove frozen violations from the report; record what was frozen and what is stale."""
    remaining = load(root)
    if not remaining:
        return
    kept = []
    for violation in report.violations:
        key = fingerprint(violation)
        if violation.severity == "error" and violation.code not in NEVER_FROZEN and remaining[key] > 0:
            remaining[key] -= 1
            report.frozen.append({"code": key[0], "file": key[1], "message": key[2]})
        else:
            kept.append(violation)
    report.violations = kept
    report.stale_frozen = [{"code": c, "file": f, "message": m}
                           for (c, f, m), n in sorted(remaining.items()) for _ in range(n)]
