"""A company's own rules, declared as data in its pack (`rules/<FAMILY>.yaml`, packs/rules.py), no Python needed.

The kinds: forbid_import, forbid_call, forbid_pattern, forbid_file, only_in, require_keyword (matched here, on the
Python files of the containers) and require_question (asked as C1, C2... of those component types, questions.py).
The family of a rule is the letters of its code (ACME): its view is .archvow/rules/ACME.md.
`catches()` runs one rule on one example: `archvow pack rule` and `pack check` prove each rule catches its bad
example and passes its good one.
"""

from __future__ import annotations

import ast
import fnmatch
import re
from pathlib import Path

from archvow.checks.catalogue import custom_rules
from archvow.checks.engine import IGNORED_DIRS, Checker
from archvow.foundation import logs
from archvow.imports import Names

log = logs.get("custom")


def run_custom(checker: Checker) -> None:
    templates = list(checker.templates.values())
    rules = custom_rules(templates)
    if not rules:
        return
    files = _component_files(checker)
    for code, rule in rules.items():
        if rule["kind"] == "require_question":
            continue  # asked as a C question, checked with the other question sets
        if rule["kind"] == "forbid_file":
            for pattern in rule["targets"]:
                for path in sorted(checker.root.glob(pattern)):
                    rel = path.relative_to(checker.root)
                    if path.is_file() and not any(p.startswith(".") or p in IGNORED_DIRS for p in rel.parts[:-1]):
                        checker.add(code, _message(rule, rel.as_posix()), rel.as_posix())
            continue
        for rel, layer, ctype, source in files:
            for line, found in matches(rule, source, _inside(rule, layer, ctype)):
                checker.add(code, _message(rule, found), rel, line)


def _message(rule: dict, found: str) -> str:
    fix = f" -> {rule['fix']}" if rule.get("fix") else ""
    return f"{rule['title']}: {found}{fix}"


def _inside(rule: dict, layer: str, ctype: str) -> bool:
    """Whether a file is where the rule looks (no in_types / in_layers: everywhere)."""
    if not rule["types"] and not rule["layers"]:
        return True
    return ctype in rule["types"] or layer in rule["layers"]


def _component_files(checker: Checker) -> list[tuple[str, str, str, str]]:
    """(path, layer, component type, source) of every Python file of the containers."""
    found = []
    for container in checker.manifest.get("containers", []):
        base = checker.root / container["path"]
        if not base.is_dir():
            continue
        types = {str(c.get("module", "")): str(c.get("type", "")) for c in container.get("components", [])}
        package = str(container.get("package", ""))
        for path in sorted(base.rglob("*.py")):
            rel = path.relative_to(base)
            if any(p.startswith(".") or p in IGNORED_DIRS for p in rel.parts[:-1]):
                continue
            layer = rel.parts[0] if len(rel.parts) > 1 else ""
            module = ".".join([package, *rel.with_suffix("").parts])
            found.append((path.relative_to(checker.root).as_posix(), layer, types.get(module, ""),
                          path.read_text(encoding="utf-8", errors="replace")))
    return found


def matches(rule: dict, source: str, inside: bool = True) -> list[tuple[int, str]]:
    """Where a rule finds something in one file: (line, what). `inside`: the file is where the rule looks."""
    kind, targets = rule["kind"], rule["targets"]
    if kind == "forbid_pattern":
        if not inside:
            return []
        pattern = re.compile(targets[0])
        return [(n, line.strip()) for n, line in enumerate(source.splitlines(), 1) if pattern.search(line)]
    if kind == "require_keyword":
        if not inside or re.search(targets[0], source, re.MULTILINE):
            return []
        return [(0, f"no {targets[0]}")]
    try:
        tree = ast.parse(source)
    except SyntaxError:
        logs.swallowed(log, "matches: SyntaxError")
        return []
    if kind == "only_in" and inside:
        return []  # where the import is allowed
    if kind in ("forbid_import", "forbid_call") and not inside:
        return []
    out = []
    names = Names(tree)
    for node in ast.walk(tree):
        if kind in ("forbid_import", "only_in") and isinstance(node, (ast.Import, ast.ImportFrom)):
            modules = [a.name for a in node.names] if isinstance(node, ast.Import) else [node.module or ""]
            for module in modules:
                if any(module == p or module.startswith(p + ".") for p in targets):
                    out.append((node.lineno, f"import {module}"))
        elif kind == "forbid_call" and isinstance(node, ast.Call):
            called = ast.unparse(node.func)
            full = names.full_name(node.func)  # an alias is resolved: `nap` -> time.sleep
            short = node.func.attr if isinstance(node.func, ast.Attribute) else called
            candidates = {called, f"*.{short}"} | ({full, f"*.{full.rsplit('.', 1)[-1]}"} if full else set())
            for pattern in targets:
                if any(fnmatch.fnmatch(c, pattern) or c == pattern for c in candidates):
                    out.append((node.lineno, f"{called}()" + (f" ({full})" if full and full != called else "")))
                    break
    return out


def catches(rule: dict, example: str) -> bool:
    """Whether the rule finds something in an example: Python source, or a file path for forbid_file (the example
    is read as a file of the types and layers the rule looks in)."""
    if rule["kind"] == "forbid_file":
        return any(fnmatch.fnmatch(example, pattern) or Path(example).match(pattern) for pattern in rule["targets"])
    if rule["kind"] == "only_in":
        return bool(matches(rule, example, inside=False))  # an import outside where it is allowed
    return bool(matches(rule, example, inside=True))
