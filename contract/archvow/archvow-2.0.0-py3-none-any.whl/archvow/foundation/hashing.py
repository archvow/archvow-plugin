"""The short digests archvow stores in vows: 12 hexadecimal characters of a sha256. They are written in
committed files (template questions, briefs, business examples), so the way each is computed never
changes: a different value would look like a changed question or a changed brief."""

from __future__ import annotations

import hashlib
import os
from collections.abc import Iterable
from pathlib import Path

from archvow.foundation import logs

log = logs.get("hashing")
LENGTH = 12


def short_digest(text: str) -> str:
    """The digest of a text, as stored for template questions (vow `template_question`)."""
    return hashlib.sha256(str(text).encode("utf-8")).hexdigest()[:LENGTH]


def text_digest(text: str) -> str:
    """The digest of a text blind to trailing spaces and to blank lines at the ends (a brief's section)."""
    normal = "\n".join(line.rstrip() for line in text.strip().splitlines())
    return short_digest(normal)


def parts_digest(parts: Iterable[tuple[str, bytes]]) -> str:
    """The digest of named contents in order: each name and content followed by a NUL byte, Windows line
    endings read as LF (a business example: its input/, expected/ and scenario.feature files)."""
    digest = hashlib.sha256()
    for name, content in parts:
        digest.update(name.encode("utf-8") + b"\0")
        digest.update(content.replace(b"\r\n", b"\n") + b"\0")
    return digest.hexdigest()[:LENGTH]


def tree_state(root: Path, skip: Iterable[str] = ()) -> str:
    """A digest of what a folder holds now - each file's path, size and modification time, `.git` and the folders
    named in `skip` left out: equal digests mean nothing was added, removed, saved or touched (`archvow workspace
    --since`). Never stored: it only tells a tool that its last answer still holds."""
    skipped = {".git", *skip}
    digest = hashlib.sha256()
    for folder, dirs, files in os.walk(root):
        dirs[:] = sorted(d for d in dirs if d not in skipped)
        for name in sorted(files):
            path = Path(folder) / name
            try:
                info = path.stat()
            except OSError:
                logs.swallowed(log, "tree_state: OSError")
                continue  # removed while walking: the next call sees it gone
            digest.update(f"{path.relative_to(root).as_posix()}\0{info.st_size}\0{info.st_mtime_ns}\0".encode())
    return digest.hexdigest()[:LENGTH]
