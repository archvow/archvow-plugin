"""The one way archvow runs git: `git(root, ...)` returns the output or raises GitError, `git_or_none`
returns None instead (no Git, not a repository, a reference that does not exist). Every call is logged at
debug level with its duration (archvow -vv)."""

from __future__ import annotations

import shutil
import subprocess
import time
from pathlib import Path

from archvow.foundation import logs
from archvow.foundation.errors import GitError

log = logs.get("git")


def _run(root: Path, args: tuple[str, ...], stdin: str | None, timeout: float | None) -> subprocess.CompletedProcess[str]:
    start = time.perf_counter()
    try:
        done = subprocess.run(["git", "-C", str(root), *args], capture_output=True, text=True, input=stdin,
                              check=False, encoding="utf-8", errors="replace", timeout=timeout)
    except (OSError, subprocess.SubprocessError) as exc:
        log.debug("git %s: %s", " ".join(args[:2]), type(exc).__name__)
        raise
    ms = round((time.perf_counter() - start) * 1000)
    log.debug("git %s: exit %d (%d ms)", " ".join(args[:2]), done.returncode, ms, extra={"duration_ms": ms})
    return done


def git(root: Path, *args: str, stdin: str | None = None, timeout: float | None = None) -> str:
    """git's output; GitError with git's own message when it fails or is not installed."""
    try:
        done = _run(root, args, stdin, timeout)
    except FileNotFoundError as exc:
        raise GitError("git is not installed") from exc
    except (OSError, subprocess.SubprocessError) as exc:
        raise GitError(f"git {' '.join(args)} failed ({type(exc).__name__})") from exc
    if done.returncode != 0:
        raise GitError(done.stderr.strip() or f"git {' '.join(args)} failed")
    return done.stdout


def git_or_none(root: Path, *args: str, stdin: str | None = None, timeout: float | None = None) -> str | None:
    """git's output, or None when git is missing or the command fails."""
    try:
        done = _run(root, args, stdin, timeout)
    except (OSError, subprocess.SubprocessError):
        return None
    return done.stdout if done.returncode == 0 else None


def available() -> bool:
    """Whether a git command can be found (on the PATH)."""
    return shutil.which("git") is not None


def succeeds(root: Path, *args: str, timeout: float | None = None) -> bool:
    """Whether the git command runs and exits 0 (git missing: False)."""
    try:
        return _run(root, args, None, timeout).returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def merge_base(root: Path, base: str) -> str:
    """The commit this branch's change started from, against `base` (`check --base`, `next --base`, `diff`,
    `review`: all the same way). A repository with no remote named like `base`'s first part (a project not
    pushed yet) compares `origin/main` with its own `main`: the same branch. Otherwise a GitError that says
    which branches exist, instead of git's "Not a valid object name"."""
    try:
        return git(root, "merge-base", base, "HEAD").strip()
    except GitError as exc:
        twin = _local_twin(root, base)
        if twin:
            return git(root, "merge-base", twin, "HEAD").strip()
        raise GitError(_why_not(root, base, exc)) from exc


def _refs(root: Path) -> list[str]:
    """The branches and tags as a person types them: main, origin/main, v1.2 (no origin/HEAD)."""
    try:
        out = git(root, "for-each-ref", "--format=%(refname)", "refs/heads", "refs/remotes", "refs/tags")
    except GitError:
        logs.swallowed(log, "_refs: GitError")
        return []
    names = []
    for ref in out.split():
        for prefix in ("refs/heads/", "refs/tags/", "refs/remotes/"):
            if ref.startswith(prefix) and not ref.endswith("/HEAD") and ref[len(prefix):] not in names:
                names.append(ref[len(prefix):])
    return names


def _remotes(root: Path) -> list[str]:
    try:
        return git(root, "remote").split()
    except GitError:
        logs.swallowed(log, "_remotes: GitError")
        return []


def _local_twin(root: Path, base: str) -> str | None:
    """`origin/main` -> `main`, when there is no remote `origin` here and the local branch exists."""
    remote, _, branch = base.partition("/")
    if not branch or remote in _remotes(root):
        return None
    try:
        git(root, "rev-parse", "--verify", "--quiet", f"refs/heads/{branch}")
    except GitError:
        logs.swallowed(log, "_local_twin: GitError")
        return None
    return branch


def _why_not(root: Path, base: str, exc: GitError) -> str:
    """Why `base` cannot be compared with, and what exists instead."""
    try:
        git(root, "rev-parse", "--verify", "--quiet", "HEAD")
    except GitError:
        logs.swallowed(log, "_why_not: GitError")
        return "this branch has no commit yet: commit first, then compare"
    try:
        git(root, "rev-parse", "--verify", "--quiet", f"{base}^{{commit}}")
        return f"'{base}' has no commit in common with this branch ({exc})"
    except GitError:
        logs.swallowed(log, "_why_not: GitError")
        pass
    remote, _, branch = base.partition("/")
    refs = _refs(root)
    fetched = {r.split("/")[0] for r in refs if "/" in r}
    why = ("" if not branch or remote in fetched
           else f" (its remote '{remote}' was never fetched here: git fetch {remote})" if remote in _remotes(root)
           else f" (there is no remote '{remote}' here)")
    return (f"'{base}' is not a branch of this repository{why}. "
            + (f"Choose one that exists: {', '.join(refs[:12])}" if refs else "This repository has no other branch yet"))
