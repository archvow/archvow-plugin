"""Layer 0 of archvow: what every other module may use, and nothing that knows about specs or templates.

    errors    ArchvowError, the one base of every error archvow reports (message, hint, exit code)
    paths     every file and folder archvow owns, in one map
    config    every environment variable archvow reads, read once (Settings)
    logs      the diagnostic log: -v / -vv / ARCHVOW_LOG, ARCHVOW_LOG_FILE, the crash report
    git       the one way archvow runs git
    text      one-line texts, Markdown cells, the placeholder guard, the words that mean "nothing"
    hashing   the short digests archvow stores in vows (12 characters of sha256)
    files     writing files archvow owns (atomic, LF, UTF-8) and the lock around a spec change
    i18n      archvow's own texts in other languages (locale files under resources/)

Modules here import only the standard library, PyYAML, and each other (never archvow's other packages).
A test keeps it so.
"""
