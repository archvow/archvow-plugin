"""The diagnostic log: what archvow did and how long it took, for the person who asks.

Silent by default. `-v` (or ARCHVOW_LOG=info) prints the phases and their timings on stderr, `-vv` (or
ARCHVOW_LOG=debug) also the files read, each git call with its duration, the caches and every error archvow
caught and went on from. ARCHVOW_LOG_FILE=<path> appends the same records as JSON lines (time, level,
logger, message, duration_ms, command). stdout never carries a log line, so --json stays clean.

The last records are kept in memory, whatever the level: when archvow fails with an error it did not
expect (a bug), the crash report holds them (~/.cache/archvow/crash-<time>.txt).

What is never logged: answers, descriptions, briefs, names and e-mail addresses, secrets - only ids, paths,
counts and durations. Values given on the command line appear as <value> (`masked_command`).
"""

from __future__ import annotations

import json
import logging
import os
import platform
import sys
import time
import traceback
from collections import deque
from collections.abc import Iterator, Sequence
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path

from archvow.foundation.paths import cache_dir

ROOT = "archvow"
KEPT = 200  # records kept in memory for the crash report
LEVELS = {"debug": logging.DEBUG, "info": logging.INFO, "warning": logging.WARNING, "error": logging.ERROR}

_MEMORY: deque[str] = deque(maxlen=KEPT)
_COMMAND: list[str] = []  # the command being run, masked (set by setup)
COMMAND_WORDS: set[str] = set()  # archvow's command and verb names (archvow.cli fills it): kept as they are


def get(name: str) -> logging.Logger:
    """The logger of a module: `log = logs.get(__name__)`."""
    return logging.getLogger(name if name.startswith(ROOT) else f"{ROOT}.{name}")


class _Text(logging.Formatter):
    def __init__(self, tracebacks: bool = True) -> None:
        super().__init__()
        self.tracebacks = tracebacks

    def format(self, record: logging.LogRecord) -> str:
        when = datetime.fromtimestamp(record.created).strftime("%H:%M:%S.") + f"{int(record.msecs):03d}"
        line = f"archvow {when} {record.levelname.lower():<7} {record.getMessage()}"
        if self.tracebacks and record.exc_info and record.levelno <= logging.DEBUG:
            line += "\n" + "".join(traceback.format_exception(*record.exc_info)).rstrip()
        return line


class _Json(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        entry: dict[str, object] = {
            "time": datetime.fromtimestamp(record.created, UTC).isoformat(timespec="milliseconds"),
            "level": record.levelname.lower(), "logger": record.name, "message": record.getMessage(),
            "command": " ".join(_COMMAND)}
        duration = getattr(record, "duration_ms", None)
        if duration is not None:
            entry["duration_ms"] = duration
        if record.exc_info:
            entry["error"] = "".join(traceback.format_exception_only(record.exc_info[1])).strip()
        return json.dumps(entry, ensure_ascii=False)


class _Memory(logging.Handler):
    """The last records, as one line each (no traceback: cheap, even for the errors archvow goes on from)."""

    line_format = _Text(tracebacks=False)

    def emit(self, record: logging.LogRecord) -> None:
        try:
            _MEMORY.append(self.line_format.format(record))
        except Exception:  # noqa: BLE001 - the memory of the log must never stop archvow
            return


def level_from(verbosity: int, setting: str | None) -> int | None:
    """The level shown on stderr: -v info, -vv debug, else ARCHVOW_LOG, else nothing (None)."""
    if verbosity >= 2:
        return logging.DEBUG
    if verbosity == 1:
        return logging.INFO
    return LEVELS.get((setting or "").strip().lower())


def setup(argv: Sequence[str], verbosity: int = 0, setting: str | None = None, log_file: str | None = None) -> None:
    """Configure the log for one run of archvow (called once, by archvow.cli.main)."""
    _COMMAND[:] = masked_command(argv)
    logger = logging.getLogger(ROOT)
    for handler in list(logger.handlers):
        logger.removeHandler(handler)
    logger.setLevel(logging.DEBUG)
    logger.propagate = False
    logger.addHandler(_Memory(logging.DEBUG))
    level = level_from(verbosity, setting)
    if level is not None:
        shown = logging.StreamHandler(sys.stderr)
        shown.setLevel(level)
        shown.setFormatter(_Text())
        logger.addHandler(shown)
    if log_file:
        try:
            written = logging.FileHandler(log_file, encoding="utf-8")
        except OSError as exc:
            print(f"archvow: ARCHVOW_LOG_FILE={log_file} cannot be written ({exc.strerror}): no log file",
                  file=sys.stderr)
        else:
            written.setLevel(level if level is not None else logging.INFO)
            written.setFormatter(_Json())
            logger.addHandler(written)


def masked_command(argv: Sequence[str]) -> list[str]:
    """The command words and option names, every other value replaced by <value>: what a log may hold."""
    words: list[str] = []
    leading = True  # the leading words are the command (`decision make`), then come its arguments
    for word in argv:
        if word.startswith("-"):
            leading = False
            words.append(word.split("=", 1)[0] + ("=<value>" if "=" in word else ""))
        elif leading and word in COMMAND_WORDS and len(words) < 2:
            words.append(word)
        else:
            leading = False
            words.append("<value>")
    return words


def swallowed(log: logging.Logger, what: str) -> None:
    """Inside an `except` that goes on: say at debug level what was caught, with its traceback."""
    log.debug("%s - went on after %s", what, _current_error(), exc_info=sys.exc_info())


def _current_error() -> str:
    error = sys.exc_info()[1]
    return type(error).__name__ if error is not None else "nothing"


@contextmanager
def timed(log: logging.Logger, what: str, level: int = logging.INFO) -> Iterator[dict[str, object]]:
    """`with timed(log, "spec loaded") as note: ...; note["detail"] = "24 components"` logs
    'spec loaded: 24 components (38 ms)' when the block ends."""
    note: dict[str, object] = {}
    start = time.perf_counter()
    try:
        yield note
    finally:
        ms = round((time.perf_counter() - start) * 1000)
        detail = note.get("detail")
        log.log(level, "%s%s (%d ms)", what, f": {detail}" if detail else "", ms, extra={"duration_ms": ms})


def crash_report(error: BaseException, version: str, argv: Sequence[str]) -> Path | None:
    """Write what a developer of archvow needs to fix a bug; never inside the project. None if it cannot."""
    folder = cache_dir()
    stamp = datetime.now(UTC).strftime("%Y%m%d-%H%M%S")
    path = folder / f"crash-{stamp}-{os.getpid()}.txt"
    text = "\n".join([
        f"archvow {version} internal error",
        f"python {platform.python_version()} ({sys.executable})",
        f"system {platform.platform()}",
        f"command archvow {' '.join(masked_command(argv))}",
        "",
        "".join(traceback.format_exception(error)).rstrip(),
        "",
        f"last {len(_MEMORY)} log records:",
        *_MEMORY,
        "",
    ])
    try:
        folder.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8", newline="\n")
    except OSError:
        return None
    return path
