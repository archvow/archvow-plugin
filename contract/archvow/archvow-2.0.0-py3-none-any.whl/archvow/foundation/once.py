"""While a command only reads the project, each file is read and each template built once.

`archvow workspace --json` (what the IDE plugins run on every open and save) shows every component; each
component's view used to read the whole spec again, build its template again and read every pack.yaml again:
about 7 s on 200 components. A command that only reads (show, next, check, workspace...) runs inside
`reading()`: what `remember` builds is kept until the command ends. A command that writes never does, so
nothing it reads can be stale.

    with once.reading():
        ...                                   # the command
    once.remember(("template", name, root), lambda: build())   # anywhere below it

What is remembered is shared: the callers treat it as read-only (the spec keeps its own copy per call).
"""

from __future__ import annotations

from collections.abc import Callable, Hashable, Iterator
from contextlib import contextmanager
from typing import TypeVar

T = TypeVar("T")

_memo: dict[Hashable, object] = {}
_active = False


@contextmanager
def reading() -> Iterator[None]:
    """The command only reads: remember what it builds until it ends."""
    global _active
    _active = True
    _memo.clear()
    try:
        yield
    finally:
        _active = False
        _memo.clear()


def remember(key: Hashable, build: Callable[[], T]) -> T:
    """`build()`, once per key while a reading command runs; every time otherwise."""
    if not _active:
        return build()
    if key not in _memo:
        _memo[key] = build()
    return _memo[key]  # type: ignore[return-value]


def active() -> bool:
    """Whether the command running only reads."""
    return _active
