"""Writing the files archvow owns, and the lock around a spec change.

`write_text` writes a file whole or not at all: the text goes to a temporary file next to it, then
replaces it in one step (os.replace). Ctrl+C, a full disk or a crash never leave half a vow. UTF-8, LF
line endings on every system, and the file keeps its permissions (a hook stays executable).

`spec_lock(root)` is held while a command changes the spec (archvow.manifest.save): a second archvow - a
person's terminal and the IDE plugin at the same time - waits for it, then says who holds it.
"""

from __future__ import annotations

import contextlib
import copy
import functools
import os
import socket
import tempfile
import time
from collections.abc import Iterator
from pathlib import Path

import yaml

from archvow.foundation import logs
from archvow.foundation.errors import LockError
from archvow.foundation.paths import WRITE_LOCK_REL

log = logs.get("files")
WAIT_SECONDS = 10.0


def write_text(path: Path, text: str) -> None:
    """Replace the file's content with `text` atomically (UTF-8, LF), keeping its mode if it exists."""
    path.parent.mkdir(parents=True, exist_ok=True)
    mode = path.stat().st_mode & 0o7777 if path.exists() else None
    handle, temporary = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(handle, "w", encoding="utf-8", newline="\n") as out:
            out.write(text)
        if mode is not None:
            os.chmod(temporary, mode)
        else:
            umask = os.umask(0)
            os.umask(umask)
            os.chmod(temporary, 0o666 & ~umask)
        os.replace(temporary, path)
    except BaseException:
        with contextlib.suppress(OSError):
            os.unlink(temporary)
        raise


def _holder(lock: Path) -> str:
    try:
        return lock.read_text(encoding="utf-8").strip() or "another archvow"
    except OSError:
        return "another archvow"


def _stale(lock: Path) -> bool:
    """A lock left by an archvow that stopped without removing it (same machine, process gone)."""
    try:
        host, _, pid = lock.read_text(encoding="utf-8").split()[0].partition(":")
    except (OSError, IndexError):
        return False
    if host != socket.gethostname() or not pid.isdigit():
        return False
    try:
        os.kill(int(pid), 0)
    except ProcessLookupError:
        return True
    except OSError:  # it exists but belongs to someone else, or the system does not say
        return False
    return False


@contextlib.contextmanager
def spec_lock(root: Path, wait: float = WAIT_SECONDS) -> Iterator[None]:
    """Hold .archvow/write.local while the block runs; wait up to `wait` seconds for another holder."""
    lock = root / WRITE_LOCK_REL
    if not lock.parent.is_dir():  # not a project yet: nothing to protect
        yield
        return
    deadline = time.monotonic() + wait
    while True:
        try:
            handle = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o644)
        except FileExistsError:
            if _stale(lock):
                log.info("removed a lock left by a stopped archvow (%s)", _holder(lock))
                with contextlib.suppress(OSError):
                    lock.unlink()
                continue
            if time.monotonic() >= deadline:
                raise LockError(f"{_holder(lock)} is changing the spec of this project: wait for it to finish, "
                                f"or, if no archvow is running, delete {WRITE_LOCK_REL.as_posix()}") from None
            time.sleep(0.1)
            continue
        break
    try:
        with os.fdopen(handle, "w", encoding="utf-8") as out:
            out.write(f"{socket.gethostname()}:{os.getpid()} archvow (pid {os.getpid()})\n")
        yield
    finally:
        with contextlib.suppress(OSError):
            lock.unlink()


_LOADER = getattr(yaml, "CSafeLoader", yaml.SafeLoader)  # libyaml when available: same result, much faster


@functools.lru_cache(maxsize=1024)
def _parse(text: str) -> object:
    return yaml.load(text, Loader=_LOADER)


def parse_yaml(text: str) -> object:
    """Parse YAML safely. A command reads the same files many times: the parse is cached by
    content (never stale) and every caller gets its own copy to change."""
    return copy.deepcopy(_parse(text))
