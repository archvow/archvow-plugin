"""Briefs: the documents people write (user stories, functional specs), and the spec drawn from them.

A brief is a Markdown or text file in one of the project's briefs folders: the init answer `briefs`
(`briefs` by default; e.g. `-a briefs=briefs,specs` adds a Spec Kit `specs/` folder). An AI assistant
reads it and proposes the archvow commands ("Draft the spec from briefs/orders.md"); a person runs them.
Each item drawn from a brief says where it came from:

    archvow component add reader sales -d "..." --from briefs/sales.md#input-files

The item stores the file, the section (the slug of a Markdown heading, or none for the whole file)
and a short hash of that text. When the text changes, `archvow check` warns (ARCH039) and names the
items to review; once reviewed, `archvow brief accept <file>[#section]` records the new text.
Nothing here reads a brief's meaning: archvow only compares texts. Items that take `--from`: components,
questions (and so decisions), project rules and business examples (`example add --from`: a link only - a
person copies the example's rows into tests/examples/, archvow never reads them out of the brief).

The folders are an architects' choice: `--from` a file outside them is refused (it would not be scanned
for real-looking identifiers, TST002, and nobody chose it as a source), an item already drawn from one
gets an ARCH039 warning, and removing a folder is a weakening on a merge request (ARCH020).
"""

from __future__ import annotations

import re
import unicodedata
from pathlib import Path

from archvow.checks.engine import Checker
from archvow.foundation import logs
from archvow.foundation.errors import BriefError
from archvow.foundation.hashing import text_digest
from archvow.model import store

log = logs.get("briefs")

DEFAULT_FOLDER = "briefs"
EXTENSIONS = (".md", ".txt")
HEADING_RE = re.compile(r"^(#{1,6})\s+(.+?)\s*#*\s*$")


def folders(data: dict) -> list[str]:
    """The project's briefs folders, relative to the root (the init answer `briefs`; `briefs` when unset)."""
    value = (data.get("init_answers") or {}).get("briefs")
    items = value if isinstance(value, list) else str(value or "").split(",")
    found = [str(f).strip().strip("/") for f in items if str(f).strip().strip("/")]
    return list(dict.fromkeys(found)) if value is not None else [DEFAULT_FOLDER]


def folder_of(file: str, declared: list[str]) -> str | None:
    """The declared folder a file is in, or None."""
    return next((f for f in declared if file == f or file.startswith(f + "/")), None)


def folder_problems(values: list[str], package_path: str) -> list[str]:
    """What is wrong with the `briefs` answer: each folder inside the project, not hidden, not code or tests,
    and none inside another (empty list: fine)."""
    problems = []
    clean = []
    package = package_path.strip("/")
    for raw in values:
        name = str(raw).strip().replace("\\", "/").removeprefix("./").strip("/")
        parts = name.split("/")
        if not name or name.startswith("/") or str(raw).strip().startswith("/") or ":" in parts[0] or ".." in parts:
            problems.append(f"'{raw}': a folder of the project, given from its root (e.g. briefs, specs)")
        elif any(part.startswith(".") for part in parts):
            problems.append(f"'{name}': a hidden folder (.archvow, .github, .claude...) holds tools' files, not briefs")
        elif name == "tests" or name.startswith("tests/"):
            problems.append(f"'{name}': tests/ holds the tests and their data (already checked by TST002)")
        elif package and (name == package or name.startswith(package + "/") or package.startswith(name + "/")):
            problems.append(f"'{name}': the code is in {package}/ - briefs go in a folder of their own")
        else:
            clean.append(name)
    for name in clean:
        outer = next((o for o in clean if o != name and name.startswith(o + "/")), None)
        if outer:
            problems.append(f"'{name}' is inside '{outer}', already a briefs folder: keep only '{outer}'")
    return problems


def slug(heading: str) -> str:
    """A heading as its anchor: lower case, no accents, words joined by '-'."""
    text = unicodedata.normalize("NFKD", heading).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")


def sections(text: str) -> dict[str, str]:
    """Markdown heading slug -> its text (the heading and what follows, up to the next heading of the
    same or a higher level). Repeated headings get -2, -3... as on GitLab and GitHub."""
    lines = text.splitlines()
    heads = [(n, len(m.group(1)), m.group(2)) for n, line in enumerate(lines) if (m := HEADING_RE.match(line))]
    found: dict[str, str] = {}
    for index, (start, level, title) in enumerate(heads):
        end = next((n for n, lvl, _ in heads[index + 1:] if lvl <= level), len(lines))
        key = slug(title) or "section"
        unique, k = key, 2
        while unique in found:
            unique, k = f"{key}-{k}", k + 1
        found[unique] = "\n".join(lines[start:end])
    return found


def digest(text: str) -> str:
    """A short hash of a text, blind to trailing spaces and blank lines at the ends."""
    return text_digest(text)


def _text(root: Path, file: str, section: str | None) -> str:
    path = root / file
    if not path.is_file():
        raise BriefError(f"{file}: no such brief")
    text = path.read_text(encoding="utf-8", errors="replace")
    if not section:
        return text
    found = sections(text)
    if section not in found:
        known = ", ".join(f"#{s}" for s in found) or "none (a text file has no sections)"
        raise BriefError(f"{file}: no section #{section} (sections: {known})")
    return found[section]


def parse_ref(ref: str) -> tuple[str, str | None]:
    file, _, section = ref.strip().partition("#")
    return Path(file).as_posix().removeprefix("./"), (section.strip().lower() or None)


def add_folder_command(data: dict, folder: str) -> str:
    """The init --force an architect runs to add a briefs folder."""
    package = next((c.get("package") for c in data.get("containers") or []), "<package>")
    return f"archvow init {package} --force -a briefs={','.join([*folders(data), folder])}"


def source(root: Path, ref: str) -> dict:
    """`briefs/x.md#section` -> {file, section, hash}, checked: a Markdown or text file of a briefs folder
    that exists, and a section it has."""
    file, section = parse_ref(ref)
    if not file.endswith(EXTENSIONS):
        raise BriefError(f"{file}: a brief is a Markdown or text file ({', '.join(EXTENSIONS)}); "
                         "convert other documents to Markdown first")
    data = store.load(root) if store.is_project(root) else {}
    declared = folders(data)
    if folder_of(file, declared) is None:
        top = file.split("/")[0] if "/" in file else "."
        where = f"{top}/ is not a briefs folder" if top != "." else "the project root is not a briefs folder"
        raise BriefError(f"{file}: {where} of this project (briefs: {', '.join(declared)}) -> an architect "
                         f"adds it: {add_folder_command(data, top if top != '.' else '<folder>')}")
    entry = {"file": file, **({"section": section} if section else {})}
    entry["hash"] = digest(_text(root, file, section))
    return entry


def ref_of(entry: dict) -> str:
    return entry["file"] + (f"#{entry['section']}" if entry.get("section") else "")


def drawn_items(data: dict) -> list[tuple[str, dict]]:
    """Every item drawn from a brief: (what, its source) - components, decisions, business examples, rules."""
    found: list[tuple[str, dict]] = []
    for container in data.get("containers", []):
        for comp in container.get("components", []):
            if comp.get("source"):
                found.append((comp["id"], comp["source"]))
            for n, decision in enumerate(comp.get("decisions", []) or [], 1):
                if decision.get("source"):
                    found.append((f"{comp['id']} question {n}", decision["source"]))
            for example in comp.get("examples") or []:
                if example.get("source"):
                    found.append((f"{comp['id']} example {example.get('name')}", example["source"]))
    for rule in data.get("project_rules") or []:
        if rule.get("source"):
            found.append((rule["id"], rule["source"]))
    return found


def changed(root: Path, data: dict) -> dict[str, dict]:
    """Brief reference -> {items, reason} for every source whose text is not the recorded one."""
    out: dict[str, dict] = {}
    for what, entry in drawn_items(data):
        ref = ref_of(entry)
        try:
            now = digest(_text(root, entry["file"], entry.get("section")))
            reason = "changed" if now != entry.get("hash") else ""
        except BriefError as exc:
            logs.swallowed(log, "changed: BriefError")
            reason = str(exc)
        if reason:
            out.setdefault(ref, {"items": [], "reason": reason})["items"].append(what)
    return out


def accept(root: Path, ref: str) -> list[str]:
    """Record the current text of a brief (or one section) for every item drawn from it."""
    file, section = parse_ref(ref)
    data = store.load(root)
    stamped: list[str] = []
    entries: list[tuple[str, dict]] = drawn_items(data)
    for what, entry in entries:
        if entry["file"] != file or (section and entry.get("section") != section):
            continue
        entry["hash"] = digest(_text(root, entry["file"], entry.get("section")))
        stamped.append(what)
    if not stamped:
        raise BriefError(f"nothing in the spec is drawn from {ref}")
    store.save(root, data)
    return stamped


def coverage(root: Path, data: dict) -> dict[str, dict[str, list[str]]]:
    """Brief file -> section -> the items drawn from it (an empty list: nothing points to it)."""
    out: dict[str, dict[str, list[str]]] = {}
    for path in brief_files(root, data):
        rel = path.relative_to(root).as_posix()
        text = path.read_text(encoding="utf-8", errors="replace")
        out[rel] = {s: [] for s in sections(text)} or {"": []}
    for what, entry in drawn_items(data):
        out.setdefault(entry["file"], {}).setdefault(entry.get("section") or "", []).append(what)
    return out


def run_briefs(checker: Checker) -> None:
    """ARCH039: an item drawn from a brief whose text changed (or disappeared) since, or from a file outside
    the project's briefs folders."""
    declared = folders(checker.manifest)
    outside: dict[str, list[str]] = {}
    for what, entry in drawn_items(checker.manifest):
        if folder_of(entry["file"], declared) is None:
            outside.setdefault(entry["file"], []).append(what)
    for file, items in sorted(outside.items()):
        top = file.split("/")[0] if "/" in file else "<folder>"
        checker.add("ARCH039", f"{', '.join(items)} {'is' if len(items) == 1 else 'are'} drawn from {file}, outside "
                    f"the briefs folders ({', '.join(declared)}) -> an architect adds it: "
                    f"{add_folder_command(checker.manifest, top)}", file)
    for ref, found in changed(checker.root, checker.manifest).items():
        items = ", ".join(found["items"])
        if found["reason"] == "changed":
            message = (f"{ref} changed after {items} {'was' if len(found['items']) == 1 else 'were'} drawn from "
                       f"it -> review them, then: archvow brief accept {ref}")
        else:
            message = f"{found['reason']} - {items} {'was' if len(found['items']) == 1 else 'were'} drawn from it"
        checker.add("ARCH039", message, ref.partition("#")[0])


def brief_files(root: Path, data: dict) -> list[Path]:
    """Every Markdown or text file of the briefs folders."""
    found: set[Path] = set()
    for name in folders(data):
        base = root / name
        if base.is_dir():
            found |= {p for p in base.rglob("*") if p.is_file() and p.suffix in EXTENSIONS}
    return sorted(found)
