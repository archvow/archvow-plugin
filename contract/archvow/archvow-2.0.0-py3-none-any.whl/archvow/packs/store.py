"""Packs found, read, copied and recorded.

A pack is a folder with `pack.yaml` (name, version, the archvow versions it works with, a description, its
languages) and any of `templates/<template>/`, `agents/<agent>/agent.yaml`, `rules/<FAMILY>.yaml`,
`regimes/<id>.yaml` (a privacy regime, packs/regimes.py). archvow's own pack is resources/archvow. A project holds copies of the others in `.archvow/packs/<name>/`, recorded in project.vow
(`packs`: version, source, digest), so clones, the Git hook and the CI read only what the repository holds - no
environment variable, no install, no network.
"""

from __future__ import annotations

import importlib.metadata
import re
import shutil
from dataclasses import dataclass
from pathlib import Path

import yaml

from archvow import __version__
from archvow.foundation import logs, once
from archvow.foundation.errors import PackError
from archvow.foundation.hashing import parts_digest

log = logs.get("packs")

BUILTIN = Path(__file__).resolve().parent.parent / "resources" / "archvow"
PROJECT_PACKS = Path(".archvow/packs")
NAME_RE = re.compile(r"^[a-z][a-z0-9]*(-[a-z0-9]+)*$")
VERSION_RE = re.compile(r"^\d+\.\d+\.\d+$")
ENTRY_POINTS = "archvow.packs"  # a pip package names its pack folder here: acme = acme_archvow/pack
SKIPPED = {"__pycache__", ".git", ".DS_Store"}


@dataclass(frozen=True)
class Pack:
    """A pack as its pack.yaml describes it, and where it is."""

    name: str
    version: str
    root: Path
    description: str = ""
    archvow: str = ""  # the archvow versions it works with: ">=1.26,<2"
    builtin: bool = False

    @property
    def templates(self) -> Path:
        return self.root / "templates"

    @property
    def agents(self) -> Path:
        return self.root / "agents"

    @property
    def rules(self) -> Path:
        return self.root / "rules"

    def summary(self) -> dict:
        """What `catalog --json` and `workspace --json` say of it."""
        return {"name": self.name, "version": self.version, "description": self.description,
                "archvow": self.archvow, "builtin": self.builtin,
                "templates": sorted(p.parent.name for p in self.templates.glob("*/template.yaml")),
                "agents": sorted(p.parent.name for p in self.agents.glob("*/agent.yaml")),
                "rule_families": sorted(p.stem for p in self.rules.glob("*.yaml")),
                "regimes": sorted(p.stem for p in (self.root / "regimes").glob("*.yaml"))}


def read(folder: Path) -> Pack:
    """The pack in `folder`; PackError when it has no valid pack.yaml. Read once per reading command."""
    return once.remember(("pack", str(folder)), lambda: _read(folder))


def _read(folder: Path) -> Pack:
    path = folder / "pack.yaml"
    try:
        raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except OSError as error:
        raise PackError(f"{folder}: no pack.yaml - not a pack",
                        hint="a pack is a folder with pack.yaml: archvow pack new <name> --dir <folder>") from error
    except yaml.YAMLError as error:
        raise PackError(f"{path}: not valid YAML ({error})") from error
    if not isinstance(raw, dict):
        raise PackError(f"{path}: expected a mapping (name, version, archvow, description)")
    builtin = folder.resolve() == BUILTIN.resolve()
    name = str(raw.get("name") or "")
    version = __version__ if builtin else str(raw.get("version") or "")
    if not NAME_RE.match(name):
        raise PackError(f"{path}: name '{name}' must be lowercase letters, digits and dashes (acme, acme-data)")
    if not VERSION_RE.match(version):
        raise PackError(f"{path}: version '{version}' must be MAJOR.MINOR.PATCH (1.0.0)")
    return Pack(name=name, version=version, root=folder, description=str(raw.get("description") or ""),
                archvow=str(raw.get("archvow") or ""), builtin=builtin)


def builtin() -> Pack:
    """archvow's own pack: its templates, the agents it knows, its languages."""
    return read(BUILTIN)


def project_packs(root: Path | None) -> list[Pack]:
    """The packs copied into a project, by name (a broken copy is skipped here; `check` reports it)."""
    if root is None:
        return []
    found = []
    for path in sorted((root / PROJECT_PACKS).glob("*/pack.yaml")):
        try:
            found.append(read(path.parent))
        except PackError:
            logs.swallowed(log, "project_packs: PackError")
    return found


def all_packs(root: Path | None, extra: tuple[Path, ...] = ()) -> list[Pack]:
    """archvow's pack first, then the project's, then `extra` (a pack being written or checked, outside a project)."""
    found = [builtin(), *[p for p in project_packs(root) if p.name != "archvow"]]
    added = [read(folder) for folder in extra]
    return [*[p for p in found if p.name not in {a.name for a in added}], *added]


def digest(folder: Path) -> str:
    """What a copy holds: every file's path and content (12 characters, as the other digests archvow stores)."""
    files = sorted(p for p in folder.rglob("*")
                   if p.is_file() and not SKIPPED & set(p.relative_to(folder).parts))
    return parts_digest((p.relative_to(folder).as_posix(), p.read_bytes()) for p in files)


def _version(text: str) -> tuple[int, ...]:
    return tuple(int(part) for part in re.findall(r"\d+", text)[:3])


def fits(pack: Pack, version: str = __version__) -> bool:
    """Whether this archvow is in the pack's range (">=1.26,<2"; empty: any)."""
    have = _version(version)
    for condition in filter(None, (c.strip() for c in pack.archvow.split(","))):
        match = re.match(r"^(>=|<=|==|>|<)\s*(\d+(?:\.\d+){0,2})$", condition)
        if match is None:
            raise PackError(f"pack {pack.name}: archvow '{pack.archvow}' is not a version range (>=1.26,<2)")
        op, wanted = match.groups()
        want = _version(wanted)
        size = len(want)
        mine = have[:size]
        ok = {">=": mine >= want, "<=": mine <= want, "==": mine == want, ">": mine > want, "<": mine < want}[op]
        if not ok:
            return False
    return True


def require_fit(pack: Pack) -> None:
    if not fits(pack):
        raise PackError(f"pack {pack.name} {pack.version} needs archvow {pack.archvow}; this is archvow {__version__}",
                        hint=f"install an archvow in that range, or ask for a version of {pack.name} that fits")


def source_folder(source: str) -> Path:
    """The folder a pack comes from: a folder with pack.yaml, or an installed pip package that names its pack
    folder in the entry point group archvow.packs - read from its metadata, never imported (no company code
    runs)."""
    folder = Path(source).expanduser()
    if (folder / "pack.yaml").is_file():
        return folder.resolve()
    for distribution in importlib.metadata.distributions():
        names = {distribution.metadata.get("Name", ""), distribution.metadata.get("Name", "").replace("-", "_")}
        points = [p for p in distribution.entry_points if p.group == ENTRY_POINTS]
        for point in points:
            if source in names or source == point.name:
                located = Path(str(distribution.locate_file(point.value.replace(".", "/"))))
                if (located / "pack.yaml").is_file():
                    return located.resolve()
                raise PackError(f"package {source}: its entry point {ENTRY_POINTS} names {point.value}, "
                                "which holds no pack.yaml")
    raise PackError(f"'{source}' is neither a folder with pack.yaml nor an installed package with a pack",
                    hint=f"give the pack's folder, or pip install the package that declares it ({ENTRY_POINTS})")


def copy_in(root: Path, source: Path) -> Pack:
    """Copy a pack into the project (replacing an earlier copy); the copy, read back."""
    pack = read(source)
    require_fit(pack)
    if pack.name == "archvow":
        raise PackError("'archvow' is archvow's own pack: it comes with archvow and is never copied")
    target = root / PROJECT_PACKS / pack.name
    if source.resolve() != target.resolve():
        shutil.rmtree(target, ignore_errors=True)
        shutil.copytree(source, target, ignore=shutil.ignore_patterns(*SKIPPED, "*.pyc"))
    return read(target)


def recorded(data: dict) -> dict[str, dict]:
    """The packs project.vow records: name -> {version, source, digest}."""
    packs = data.get("packs") or {}
    return {str(k): dict(v or {}) for k, v in packs.items()} if isinstance(packs, dict) else {}


def record(data: dict, pack: Pack, source: str) -> None:
    """Write a pack's version, source and digest into the project's data (project.vow `packs`)."""
    packs = recorded(data)
    packs[pack.name] = {"version": pack.version, "source": source, "digest": digest(pack.root)}
    data["packs"] = dict(sorted(packs.items()))


def changed_by_hand(root: Path, data: dict) -> list[tuple[str, str]]:
    """The copies that differ from what `pack add` / `pack update` recorded: (name, why)."""
    found = []
    copies = {p.parent.name for p in (root / PROJECT_PACKS).glob("*/pack.yaml")}
    for name, entry in recorded(data).items():
        folder = root / PROJECT_PACKS / name
        if name not in copies:
            found.append((name, "recorded in project.vow, but its copy .archvow/packs/" + name + "/ is missing"))
        elif digest(folder) != entry.get("digest"):
            found.append((name, "its copy differs from what `archvow pack add` / `pack update` wrote"))
    for name in sorted(copies - set(recorded(data))):
        found.append((name, "copied into .archvow/packs/ but not recorded in project.vow (not added with `archvow pack add`)"))
    return found
