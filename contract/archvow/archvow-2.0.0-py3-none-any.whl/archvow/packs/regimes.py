"""Regimes: a pack's `regimes/<id>.yaml`, one law (or one company's reading of it) as data.

Two kinds. A privacy law (GDPR, the US state laws, GLBA, a pack's HIPAA): archvow's own engine checks what every
privacy law needs (the PRIV rules: every column classified, personal data never logged, special data
protected...), the regime adds what one law asks on top: its questions, the codes that fail while they are open,
its register, and which columns it covers. Operational resilience (DORA): questions to the components that run,
and the register of the project's third parties; its other checks (tickets, approvers, pinned packages, tests that
cannot be skipped) are archvow's code (checks/families/dora.py).

    name: US-PRIVACY               the name in the `rules` answer (-a rules=ARCH,US-PRIVACY); the file is its id
    prefix: USP                    its codes: USP001...
    letter: U                      its questions: U1, U2... (archvow decision make <component> U1 "...")
    kind: privacy                  privacy (default: PRIV is on with it) or resilience (DORA)
    default: false                 on in the default `rules` answer (GDPR only)
    title: ...                     title_fr: ...      (every text has its _fr twin; English when missing)
    law: ...                       what it follows, and `checked:` the date its texts were checked against it
    covers: [financial]            optional: only columns with one of these tags (default: every personal column)
    leaves_out: {glba: [financial]}  optional: columns with these tags are left out while that regime is on
    rules: {USP001: {title: ...}}  the codes of its questions (severity error unless `severity: warning`)
    questions:                     per role - the template says which of its types play it (`roles`)
      purpose: [{id: notice, rule: USP001, when: personal, tags: [children], text: ...}]
      store: [...]                 when: personal | writes | special | always; tags: only when such a column is there
      share: [...]
      run: [...]                   the components that run (a job, an app): resilience questions
    register: {file: PERSONAL_INFORMATION.md, title: ..., intro: ..., answers: ..., lists: answers}
                                   lists: answers (the columns and the questions' answers) or third_parties

No Python runs: archvow reads the file, a pack check proves it (archvow pack check).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

import yaml

from archvow.foundation import logs
from archvow.foundation.errors import PackError
from archvow.packs import store

log = logs.get("packs")

# where a component meets personal data (processes it, stores it, sends it), and the components that run
ROLES = ("purpose", "store", "share", "run")
KINDS = ("privacy", "resilience")
LISTS = ("answers", "third_parties")
WHEN = ("always", "personal", "writes", "special")
# What a column's tags may say beyond its class (archvow column set ... --tag health): regimes cover by them.
TAGS = ("health", "financial", "biometric", "children", "precise-location")
NAME_RE = re.compile(r"^[A-Z][A-Z0-9]*(-[A-Z0-9]+)*$")
PREFIX_RE = re.compile(r"^[A-Z]{2,8}$")
CODE_RE = re.compile(r"^([A-Z]{2,8})(\d{3})$")
TAKEN_LETTERS = ("O", "C")  # operations (archvow's DORA file) and a company's require_question rules
OWN_PREFIXES = ("ARCH", "STY", "SPK", "FAPI", "AGT", "TST", "DORA", "PRIV")  # archvow's code families


@dataclass(frozen=True)
class Regime:
    """One regime as its file says, in one language."""

    id: str
    name: str
    kind: str
    prefix: str
    letter: str
    default: bool
    title: str
    law: str
    checked: str
    covers: tuple[str, ...]
    leaves_out: dict[str, tuple[str, ...]]
    rules: dict[str, dict]
    questions: dict[str, list[dict]]
    register: dict[str, str]
    pack: str = "archvow"
    sources: tuple[str, ...] = field(default_factory=tuple)

    def summary(self) -> dict:
        """What `catalog --json` and `workspace --json` say of it."""
        return {"id": self.id, "name": self.name, "kind": self.kind, "pack": self.pack, "prefix": self.prefix,
                "letter": self.letter,
                "default": self.default, "title": self.title, "law": self.law, "checked": self.checked,
                "covers": list(self.covers), "rules": {c: r["title"] for c, r in self.rules.items()},
                "register": self.register.get("file", "")}

    def family(self) -> dict:
        """Its entry in a template's rule families: a compliance family, on when the project's `rules` names it."""
        return {"name": self.name, "title": self.title, "compliance": True, "default": self.default,
                "rule_set": self.id, "regime": True}


def _text(raw: dict, key: str, language: str) -> str:
    return str(raw.get(f"{key}_{language}") or raw.get(key) or "").strip()


def read_file(path: Path, language: str = "en", pack: str = "archvow") -> Regime:
    """The regime of one file, checked; PackError says what is wrong."""
    try:
        raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except (OSError, yaml.YAMLError) as error:
        raise PackError(f"{path}: cannot be read ({error})") from error
    problem = problem_of(path.stem, raw, own=pack == "archvow")
    if problem:
        raise PackError(f"{path}: {problem}", hint="docs/packs.md, \"A regime\": what a regime file holds")
    rules = {str(code): {"title": _text(rule or {}, "title", language) or str(code),
                         "severity": str((rule or {}).get("severity", "error"))}
             for code, rule in (raw.get("rules") or {}).items()}
    questions = {role: [{"id": str(q["id"]), "rule": str(q["rule"]), "when": str(q.get("when") or "personal"),
                         "tags": [str(t) for t in q.get("tags") or []], "text": _text(q, "text", language)}
                        for q in (raw.get("questions") or {}).get(role) or []]
                 for role in ROLES if (raw.get("questions") or {}).get(role)}
    register = {k: _text(raw.get("register") or {}, k, language) for k in ("file", "title", "intro", "answers")}
    register["lists"] = str((raw.get("register") or {}).get("lists") or "answers")
    return Regime(id=path.stem, name=str(raw["name"]), kind=str(raw.get("kind") or "privacy"),
                  prefix=str(raw["prefix"]), letter=str(raw["letter"]),
                  default=bool(raw.get("default", False)), title=_text(raw, "title", language),
                  law=_text(raw, "law", language), checked=str(raw.get("checked") or ""),
                  covers=tuple(str(t) for t in raw.get("covers") or []),
                  leaves_out={str(k): tuple(str(t) for t in v or []) for k, v in (raw.get("leaves_out") or {}).items()},
                  rules=rules, questions=questions, register=register, pack=pack,
                  sources=tuple(str(s) for s in raw.get("sources") or []))


def problem_of(regime_id: str, raw: object, own: bool = False) -> str:
    """What is wrong with a regime's declaration ('' when nothing). `own`: archvow's pack (GDPR, DORA, letter O)."""
    if not isinstance(raw, dict):
        return "expected a mapping (name, prefix, letter, title, rules, questions)"
    name, prefix, letter = str(raw.get("name") or ""), str(raw.get("prefix") or ""), str(raw.get("letter") or "")
    if not NAME_RE.match(name) or name.lower() != regime_id:
        return f"name must be the file's name in capitals ({regime_id.upper()})"
    if str(raw.get("kind") or "privacy") not in KINDS:
        return f"kind: {' or '.join(KINDS)}"
    if not PREFIX_RE.match(prefix) or (prefix in (*OWN_PREFIXES, "GDPR") and not own):
        return "prefix: 2 to 8 capital letters for its codes, not one of archvow's own families"
    if not re.fullmatch(r"[A-Z]", letter) or (letter in TAKEN_LETTERS and not own):
        return f"letter: one capital letter for its questions, not {' or '.join(TAKEN_LETTERS)}"
    if not str(raw.get("title") or "").strip():
        return "give its title (what the regime is, in a line)"
    for tag in [*(raw.get("covers") or []), *[t for v in (raw.get("leaves_out") or {}).values() for t in v or []]]:
        if tag not in TAGS:
            return f"tag '{tag}': one of {', '.join(TAGS)}"
    rules = raw.get("rules") or {}
    for code, rule in rules.items():
        match = CODE_RE.match(str(code))
        if not match or match.group(1) != prefix:
            return f"rule {code}: its prefix ({prefix}) and 3 digits"
        if not str((rule or {}).get("title") or "").strip():
            return f"rule {code}: give its title"
        if str((rule or {}).get("severity", "error")) not in ("error", "warning"):
            return f"rule {code}: severity is error or warning"
    questions = raw.get("questions") or {}
    if not isinstance(questions, dict) or not questions or set(questions) - set(ROLES):
        return f"questions: by role, {', '.join(ROLES)}"
    for role, items in questions.items():
        ids = [str((q or {}).get("id") or "") for q in items or []]
        if len(set(ids)) != len(ids):
            return f"questions.{role}: each id once"
        for q in items or []:
            problem = _question_problem(q, rules)
            if problem:
                return f"questions.{role}.{q.get('id') if isinstance(q, dict) else '?'}: {problem}"
    if not str((raw.get("register") or {}).get("file") or "").endswith(".md"):
        return "register.file: the name of the register archvow writes in compliance/ (PERSONAL_DATA.md)"
    if str((raw.get("register") or {}).get("lists") or "answers") not in LISTS:
        return f"register.lists: {' or '.join(LISTS)}"
    return ""


def _question_problem(question: object, rules: dict) -> str:
    if not isinstance(question, dict) or not re.fullmatch(r"[a-z][a-z0-9_]*", str(question.get("id") or "")):
        return "an id (snake_case), a rule and a text"
    if str(question.get("rule") or "") not in {str(c) for c in rules}:
        return "its rule must be one of the regime's rules"
    if str(question.get("when") or "personal") not in WHEN:
        return f"when: one of {', '.join(WHEN)}"
    if any(t not in TAGS for t in question.get("tags") or []):
        return f"tags: among {', '.join(TAGS)}"
    if not str(question.get("text") or "").strip():
        return "its text (the question, with an example answer: e.g. ...)"
    return ""


_CACHE: dict[tuple[Path, int, int, str, str], Regime] = {}


def _read_cached(path: Path, language: str, pack: str) -> Regime:
    stat = path.stat()
    key = (path, stat.st_mtime_ns, stat.st_size, language, pack)
    if key not in _CACHE:
        _CACHE[key] = read_file(path, language, pack)
    return _CACHE[key]


def available(root: Path | None, language: str = "en", extra: tuple[Path, ...] = ()) -> dict[str, Regime]:
    """Every regime the project can choose: archvow's, then its packs' (a pack's regime replaces one of the same
    id). A broken file is skipped here; `pack check` and `check` say why."""
    found: dict[str, Regime] = {}
    for pack in store.all_packs(root, extra):
        for path in sorted((pack.root / "regimes").glob("*.yaml")):
            try:
                found[path.stem] = _read_cached(path, language, pack.name)
            except PackError:
                logs.swallowed(log, f"regimes: {path} not read")
    return found


def chosen(root: Path | None, data: dict, language: str | None = None) -> list[Regime]:
    """The regimes the project's `rules` answer switches on (kept as `compliance` in project.vow), in that order."""
    names = [str(c) for c in data.get("compliance") or [] if c != "none"]
    regimes = available(root, language or str(data.get("language") or "en"))
    return [regimes[n] for n in names if n in regimes]


def in_scope(regime: Regime, columns: dict[str, str], tags: dict[str, set[str]], on: set[str]) -> dict[str, str]:
    """The personal columns (name -> class) a regime covers, among `columns`: its `covers` tags if it has some,
    minus what `leaves_out` names while that other regime is `on` (GLBA data left out of the state laws)."""
    kept = {}
    for name, kind in columns.items():
        own = tags.get(name, set())
        if regime.covers and not own & set(regime.covers):
            continue
        if any(other in on and own & set(left) for other, left in regime.leaves_out.items()):
            continue
        kept[name] = kind
    return kept
