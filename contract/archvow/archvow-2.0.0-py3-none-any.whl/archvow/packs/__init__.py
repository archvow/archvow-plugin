"""Packs, the one way to extend archvow (layer 1): a folder holding templates, agent profiles and declarative
rules - data only, never Python. archvow's own content is the `archvow` pack (resources/archvow); a project uses
its copies in `.archvow/packs/<name>/`, recorded with their version and digest in project.vow.

    store.py  find, read and copy packs; their digest; what the project recorded
    rules.py  the declarative rules of a pack (rules/<FAMILY>.yaml), read and checked

The commands that write packs are in spec/ (packs.py, pack_parts.py, pack_check.py).
May import: foundation, model.
"""
