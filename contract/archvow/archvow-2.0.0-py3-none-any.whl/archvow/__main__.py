"""Allow `python -m archvow`."""

import sys

from archvow.cli.main import main

sys.exit(main())
