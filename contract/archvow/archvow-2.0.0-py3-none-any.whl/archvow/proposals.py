"""The AI's proposals: decisions the AI proposed, kept apart from the decisions people made.

The vows (`.archvow/project.vow`, `.archvow/features/<f>/components/<c>.vow`) hold what people decided. In
mode `guided` or `free` (init answer `mode`), the AI may answer an open question itself with
`archvow decision propose <c> <n> "..."`; the answer goes into its feature's `proposals.vow`
(`.archvow/features/<f>/proposals.vow`: one per feature, so two features never share it), never into a
vow:

    vow 1 proposals
    proposal
      component clean_sales
      number 6
      question "..."
      answer "..."
      by ...
      on ...

A person reviews it: `archvow decision accept <c> <n>` moves the answer into the component's vow (marked
`origin: ai`), `archvow decision make <c> <n> "..."` replaces it with their own. Until then the
question no longer blocks the code (ARCH033), but `check` reports it (ARCH043): a warning, and in
mode `guided` an error for `check --complete` (the release gate). CODEOWNERS gives the files to the
architects in mode `guided` (a merge request carrying proposals needs their approval), not in mode
`free` (they review later, in a spec merge request). Mode `strict` has no proposals: the AI asks.
"""

from __future__ import annotations

from pathlib import Path

from archvow.checks.engine import Violation
from archvow.foundation.errors import ProposalError
from archvow.foundation.files import write_text
from archvow.foundation.git import git_or_none
from archvow.foundation.paths import FEATURES_REL, PROPOSALS_FILE, SHARED, proposals_vow
from archvow.foundation.text import one_line
from archvow.model import store, vowfile
from archvow.model.spec import find_component, mode, stamp, to_accept

HEADER = ("# archvow proposals - decisions the AI proposed (archvow decision propose), waiting for a person:\n"
          "# archvow decision accept <component> <n>, or archvow decision make <component> <n> \"...\".\n")




def load(root: Path) -> list[dict]:
    """Every feature's proposals."""
    found = []
    for path in sorted((root / FEATURES_REL).glob(f"*/{PROPOSALS_FILE}")):
        found += parse(path.read_text(encoding="utf-8"), path.relative_to(root).as_posix())
    return found


def load_at(root: Path, commit: str) -> list[dict]:
    """Every feature's proposals as they were at `commit`."""
    listing = git_or_none(root, "ls-tree", "-r", "--name-only", commit, "--", FEATURES_REL.as_posix()) or ""
    found = []
    for rel in sorted(n for n in listing.split("\n") if n.endswith("/" + PROPOSALS_FILE)):
        text = git_or_none(root, "show", f"{commit}:{rel}")
        found += parse(text, rel) if text else []
    return found


def parse(text: str, path: str) -> list[dict]:
    """The proposals in proposals.vow."""
    return list(store.read_vow(text, path, "proposals")[1].get("proposals") or [])


def save(root: Path, proposals: list[dict]) -> None:
    """Each proposal in its component's feature; a feature with nothing left to review loses the file (and its
    CODEOWNERS weight)."""
    homes = store.vow_files(root)[2]
    by_feature: dict[str, list[dict]] = {}
    for proposal in proposals:
        by_feature.setdefault(homes.get(proposal["component"], SHARED), []).append(proposal)
    for path in sorted((root / FEATURES_REL).glob(f"*/{PROPOSALS_FILE}")):
        if path.parent.name not in by_feature:
            path.unlink()
    for feature, items in by_feature.items():
        ordered = sorted(items, key=lambda p: (p["component"], int(p["number"])))
        path = root / proposals_vow(feature)
        path.parent.mkdir(parents=True, exist_ok=True)
        write_text(path, vowfile.dumps("proposals", {"proposals": ordered}, comment=HEADER))


def by_question(root: Path) -> dict[tuple[str, int], dict]:
    """(component, question number) -> its proposal."""
    return {(p["component"], int(p["number"])): p for p in load(root)}


def propose(root: Path, component_id: str, number: int, answer: str) -> dict:
    """The AI's answer to an open question, for a person to review. Refused in mode strict and for a
    question a person already answered."""
    data = store.load(root)
    if mode(data) == "strict":
        raise ProposalError("mode strict: the AI does not decide - ask the question and stop; a person answers "
                            f"with archvow decision make {component_id} {number} \"...\"")
    _, comp = find_component(data, component_id)
    decisions = comp.get("decisions", []) or []
    if not 1 <= number <= len(decisions):
        raise ProposalError(f"'{component_id}' has no question {number} (it has 1..{len(decisions)})")
    if (decisions[number - 1].get("answer") or "").strip():
        raise ProposalError(f"question {number} of {component_id} is already decided by a person")
    if not answer.strip():
        raise ProposalError("an answer is required")
    entry = {"component": component_id, "number": number, "question": decisions[number - 1]["question"],
             "answer": one_line(answer), **stamp(root)}
    proposals = [p for p in load(root) if (p["component"], int(p["number"])) != (component_id, number)]
    save(root, [*proposals, entry])
    return entry


def take(root: Path, component_id: str, number: int) -> dict | None:
    """Remove the proposal for a question (accepted, or replaced by a person's answer) and return it."""
    proposals = load(root)
    found = next((p for p in proposals if (p["component"], int(p["number"])) == (component_id, number)), None)
    if found is not None:
        save(root, [p for p in proposals if p is not found])
    return found




def drop_component(root: Path, component_id: str) -> None:
    save(root, [p for p in load(root) if p["component"] != component_id])


def renumber(root: Path, component_id: str, removed: int) -> None:
    """A question a person added was removed: the proposals after it move up by one."""
    kept = []
    for p in load(root):
        if p["component"] == component_id and int(p["number"]) == removed:
            continue
        if p["component"] == component_id and int(p["number"]) > removed:
            p = {**p, "number": int(p["number"]) - 1}
        kept.append(p)
    save(root, kept)


def run_proposals(checker) -> None:
    """ARCH043: a decision the AI proposed and no person reviewed yet (an error for the release gate in
    mode guided); a proposal for a question that no longer exists or was answered meanwhile."""
    data = checker.manifest
    project_mode = mode(data)
    components = {c["id"]: c for container in data.get("containers", []) for c in container.get("components", [])}
    for cid, comp in components.items():  # created by the AI, not accepted by a person yet
        if comp.get("origin") != "ai":
            continue
        message = (f"'{cid}' was created by the AI ({comp.get('created_by') or 'an agent'}), not accepted by a person "
                   f"yet -> a person checks it (archvow show {cid}), then archvow component accept {cid} (or "
                   f"component remove {cid})")
        where = store.where(comp)
        if project_mode == "guided" and checker.complete:
            checker.report.violations.append(Violation("ARCH043", "error", message, where, 0, 0,
                                                       checker.rules["ARCH043"][1]))
        else:
            checker.add("ARCH043", message, where)
    _added_by_ai(checker, components, project_mode)
    for p in load(checker.root):
        comp = components.get(p.get("component"))
        decisions = (comp or {}).get("decisions", []) or []
        number = int(p.get("number") or 0)
        if comp is None or not 1 <= number <= len(decisions) or (decisions[number - 1].get("answer") or "").strip():
            checker.add("ARCH043", f"{p.get('component')} question {number}: a proposal for a question that does not "
                        "exist or is already decided - archvow decision make or accept again, or remove it",
                        _file_of(comp))
            continue
        message = (f"'{p['component']}' decision {number} was proposed by the AI, not reviewed yet: "
                   f"\"{p['answer']}\" -> a person runs archvow decision accept {p['component']} {number} "
                   f"(or decision make {p['component']} {number} \"...\")")
        if project_mode == "guided" and checker.complete:
            checker.report.violations.append(_error(checker, message, _file_of(comp)))
        else:
            checker.add("ARCH043", message, _file_of(comp))


def _added_by_ai(checker, components: dict, project_mode: str) -> None:
    """ARCH043: a question, a hazard, an invariant or a rule an AI agent added, that no person kept yet."""
    data = checker.manifest
    found = []

    def vow_of(item: dict) -> str:
        return store.where(components.get(item.get("component")))

    for cid, comp in components.items():
        where = store.where(comp)
        for n, d in enumerate(comp.get("decisions", []) or [], 1):
            if to_accept(d):
                message = (f"'{cid}' question {n} was asked by the AI ({d['added_by']}), not kept by a person yet: "
                           f"\"{d['question']}\" -> a person answers it (archvow decision make {cid} {n} \"...\"), "
                           f"keeps it (archvow question accept {cid} {n}) or removes it (question remove)")
                found.append((message, where))
    for hazard in data.get("hazards", []) or []:
        if to_accept(hazard):
            message = (f"{hazard['id']} was added by the AI ({hazard['added_by']}), not kept by a person yet -> "
                       f"archvow hazard accept {hazard['id']} (or hazard edit / hazard remove)")
            found.append((message, vow_of(hazard)))
    for inv in data.get("invariants", []) or []:
        if to_accept(inv):
            prevents = ", ".join(inv.get("mitigates") or []) or "its hazard"
            message = (f"{inv['id']} was added by the AI ({inv['added_by']}), not kept by a person yet -> "
                       f"archvow hazard accept {prevents} (or invariant edit / invariant remove)")
            found.append((message, vow_of(inv)))
    for rule in data.get("project_rules", []) or []:
        if to_accept(rule):
            message = (f"{rule['id']} was added by the AI ({rule['added_by']}), not kept by a person yet: "
                       f"\"{rule['text']}\" -> archvow rule accept {rule['id']} (or rule edit / rule remove)")
            found.append((message, store.PROJECT_REL.as_posix()))
    for message, where in found:
        if project_mode == "guided" and checker.complete:
            checker.report.violations.append(Violation("ARCH043", "error", message, where, 0, 0,
                                                       checker.rules["ARCH043"][1]))
        else:
            checker.add("ARCH043", message, where)


def _file_of(comp: dict | None) -> str:
    """The proposals file of a component's feature."""
    return proposals_vow(str((comp or {}).get("feature") or SHARED)).as_posix()


def _error(checker, message: str, where: str):
    return Violation("ARCH043", "error", message, where, 0, 0, checker.rules["ARCH043"][1])


def proposed(root: Path) -> set[tuple[str, int, str]]:
    """What the AI proposes now, question by question: the console compares it before and after a command (the
    components whose proposals changed get their specs rendered again: they show the proposals)."""
    return {(p["component"], int(p["number"]), str(p.get("answer") or "")) for p in load(root)}
