"""The spec on disk: one vow for the project, one vow per component, in the .vow format.

Layout:

    .archvow/project.vow                   the project's vow
        system: {name, description}
        containers (container <id>: template "name@version", package, path)   # deployables (C4 level 2)
        rules: {CODE: {severity: error|warning|off, ...}}               # check severity overrides
        language, mode, families, compliance, ai_tools, reviewers, dependencies, init_answers,
        project rules (R1, R2...), third parties, hazards/invariants/dismissed of the whole system
    .archvow/features/<feature>/<feature>.vow          a feature: what the product does (description, brief)
    .archvow/features/<feature>/components/<id>.vow    one component's vow (C4 level 3, one Python module)
        type, layer, module, spec (written `ticket`), description, uses, symbols, decisions, columns...,
        container (only when the project has several), hazards (H1, H2...), invariants (INV1...),
        dismissed (its "not applicable" safety questions)
    .archvow/features/shared/              the feature init creates: what every feature uses
    .archvow/doc/                          what `archvow doc` writes: ignored by Git, never read back

The .vow syntax is in vowfile.py. In memory, `load` returns ONE dict, the same shape every module
has always used: containers hold their components (each with its `feature`, the folder it lives in),
`features` lists the features, and hazards, invariants and dismissals are
top-level lists carrying their `component`. Hazard and invariant ids are qualified there -
`clean_orders.H1`, `clean_orders.INV1` (`system.H1` for the whole system) - and stored short (`H1`)
in the component's own file. `save` splits the dict back into the files and writes only the ones
that changed.

A template question nobody answered yet is stored as `template_question <hash of its text>`
and read back with the template's current words; an answered question keeps its own words.

"""

from __future__ import annotations

import copy
import hashlib
import re
from pathlib import Path

from archvow.foundation import logs, once
from archvow.foundation.errors import ManifestError
from archvow.foundation.files import spec_lock, write_text
from archvow.foundation.hashing import short_digest
from archvow.foundation.paths import (
    COMPONENTS_DIR,
    FEATURES_REL,
    PROJECT_REL,
    SHARED,
    component_vow,
    feature_vow,
)
from archvow.model import vowfile
from archvow.model.spec import decision_statement
from archvow.templates import TemplateError, edge_case_text, load_template, template_name

log = logs.get("manifest")

SCHEMA_VERSION = 2
SYSTEM = "system"  # the scope of hazards and invariants of the whole system (no component)
ITEM_ID_RE = re.compile(r"^(?P<scope>[a-z][a-z0-9_]*)\.(?P<kind>H|INV)(?P<n>\d+)$", re.IGNORECASE)
COMPONENT_ITEMS = ("hazards", "invariants", "dismissed")

PROJECT_HEADER = (
    "# archvow vow of the project - what every component must follow: mode, checks, approved AI tools and\n"
    "# packages, rules R1, R2... (`archvow show` reads one component; `archvow doc` writes the whole project).\n"
    "# Never edit by hand: archvow init <package> --force -a <answer>=..., archvow rule add, archvow dependency\n"
    "# add. Set by hand, by an architect, reviewed in the merge request: only `rules` (severities and limits),\n"
    "# `allowed_paths`, `dependencies_by_path` and `layer_paths`. Format: docs/vow-format.md of archvow.\n"
)
FEATURE_HEADER = (
    "# archvow vow of the feature {id} - what the product does; its components are in components/.\n"
    "# Read: archvow show {id}. Never edit by hand: archvow feature add / rename / remove.\n"
)
COMPONENT_HEADER = (
    "# archvow vow of {id} - what it must be and do; archvow check holds the code to it.\n"
    "# Read: archvow show {id}. Change: archvow specify {id}. Never edit by hand.\n"
)


def is_project(root: Path) -> bool:
    return (root / PROJECT_REL).is_file()


def find_root(start: Path) -> Path:
    """Walk up from `start` to the directory holding .archvow/project.vow."""
    current = start.resolve()
    for candidate in (current, *current.parents):
        if (candidate / PROJECT_REL).is_file():
            return candidate
    raise ManifestError(f"no {PROJECT_REL.as_posix()} found in {start} or its parents")








# ------------------------------------------------------------------ ids


def qualify(scope: str | None, short: str) -> str:
    """'H1' of clean_orders -> 'clean_orders.H1' (already qualified ids are kept)."""
    return short if "." in str(short) else f"{scope or SYSTEM}.{short}"


def shorten(scope: str | None, item_id: str) -> str:
    """'clean_orders.H1' in clean_orders' own file -> 'H1' (another component's id stays whole)."""
    prefix = f"{scope or SYSTEM}."
    return item_id[len(prefix):] if str(item_id).startswith(prefix) else item_id


def next_item_id(items: list[dict], scope: str | None, kind: str) -> str:
    """The next hazard (kind H) or invariant (INV) id of one component: clean_orders.H3."""
    scope = scope or SYSTEM
    numbers = [int(m.group("n")) for i in items if (m := ITEM_ID_RE.match(str(i.get("id", ""))))
               and m.group("scope") == scope and m.group("kind").upper() == kind]
    return f"{scope}.{kind}{(max(numbers) + 1) if numbers else 1}"


def normalise_item_id(words: str | list[str]) -> str:
    """'clean_orders H1', 'clean_orders.h1' or ['clean_orders', 'H1'] -> 'clean_orders.H1'."""
    text = " ".join(words) if isinstance(words, list) else str(words)
    parts = text.replace(".", " ").split()
    if len(parts) == 2 and re.fullmatch(r"(?i)(H|INV)\d+", parts[1]):
        return f"{parts[0]}.{parts[1].upper()}"
    return text.strip()


# ------------------------------------------------------------------ template questions


def question_key(text: str) -> str:
    return short_digest(text)


def _template_texts(project: dict, root: Path | None) -> dict[str, str]:
    """hash -> current words, for every question the project's template asks."""
    containers = project.get("containers") or []
    language = project.get("language") or "en"
    texts: dict[str, str] = {}
    for container in containers:
        try:
            template = load_template(template_name(container)[0], root, language=language)
        except (TemplateError, KeyError):
            logs.swallowed(log, "_template_texts: TemplateError, KeyError")
            continue

        def walk(node: object) -> None:
            if isinstance(node, dict):
                for key, value in node.items():
                    if key == "edge_cases" and isinstance(value, list):
                        for item in value:
                            text = edge_case_text(item)
                            texts.setdefault(question_key(text), text)
                    else:
                        walk(value)
            elif isinstance(node, list):
                for item in node:
                    walk(item)

        walk(template.data)
    return texts


# ------------------------------------------------------------------ load


def load(root: Path) -> dict:
    """The whole spec as one dict (the caller's own copy: it may change it)."""
    return copy.deepcopy(once.remember(("spec", str(root.resolve())), lambda: _assembled(root)))


def _assembled(root: Path) -> dict:
    """The spec from its vows, shared (never changed by a caller), kept by the files' content: never stale."""
    if not is_project(root):
        raise ManifestError(f"{root / PROJECT_REL} does not exist")
    project_text = (root / PROJECT_REL).read_text(encoding="utf-8")
    features, components, homes = vow_files(root)
    where = str(root.resolve())
    texts = "\0".join([where, project_text, *(f"{k}\0{v}" for k, v in [*features.items(), *components.items()])])
    key = hashlib.sha256(texts.encode("utf-8")).digest()
    cached = _LOADED.get(where)
    if cached is None or cached[0] != key:
        with logs.timed(log, "spec loaded") as note:
            cached = (key, assemble(project_text, components, root, features, homes))
            note["detail"] = f"{len(components)} components"
        _LOADED[where] = cached
    return cached[1]


_LOADED: dict[str, tuple[bytes, dict]] = {}


def vow_files(root: Path) -> tuple[dict[str, str], dict[str, str], dict[str, str]]:
    """The features' vows (name -> text), the components' (id -> text) and where each component lives (id ->
    feature). A feature folder without its vow is still read: its components are not lost (check says so)."""
    features: dict[str, str] = {}
    components: dict[str, str] = {}
    homes: dict[str, str] = {}
    folder = root / FEATURES_REL
    for feature in sorted(p for p in folder.iterdir() if p.is_dir()) if folder.is_dir() else []:
        vow = feature / f"{feature.name}.vow"
        if vow.is_file():
            features[feature.name] = vow.read_text(encoding="utf-8")
        for path in sorted((feature / COMPONENTS_DIR).glob("*.vow")):
            if path.stem in homes:
                raise ManifestError(f"the component '{path.stem}' is in two features: {homes[path.stem]} and "
                                    f"{feature.name} - keep one (git rm the other file)")
            components[path.stem] = path.read_text(encoding="utf-8")
            homes[path.stem] = feature.name
    return features, components, homes


def read_vow(text: str, label: str, kind: str) -> tuple[str | None, dict]:
    """One .vow file of this kind -> (the name on its first line, its data)."""
    try:
        found, name, data = vowfile.loads(text, label)
    except vowfile.VowError as exc:
        raise ManifestError(str(exc)) from None
    if found != kind:
        raise ManifestError(f"{label}: a vow of a {found}, where archvow expects the vow of a {kind}")
    return name, data


def assemble(project_text: str, component_texts: dict[str, str], root: Path | None,
             feature_texts: dict[str, str] | None = None, homes: dict[str, str] | None = None) -> dict:
    """Project vow + feature vows + component vows -> the one in-memory dict."""
    data = {"schema_version": SCHEMA_VERSION, **read_vow(project_text, PROJECT_REL.as_posix(), "project")[1]}
    homes = homes or {}
    named = dict(feature_texts or {})
    data["features"] = []
    for name in sorted({*named, *homes.values()}):
        label = feature_vow(name).as_posix()
        found, feature = read_vow(named[name], label, "feature") if name in named else (name, {})
        if found not in (None, name):
            raise ManifestError(f"{label}: the vow of `{found}` in the folder of `{name}` - the folder is "
                                "named after its feature")
        data["features"].append({"name": name, **feature})
    data.setdefault("containers", [])
    data.setdefault("rules", {})
    for name in COMPONENT_ITEMS:  # the whole system's own items carry no component
        items = data.get(name) or []
        for item in items:
            item.setdefault("component", None)
            _expand(item, None)
        data[name] = items
    by_container = {c["id"]: c for c in data["containers"]}
    for container in data["containers"]:
        container["components"] = []
    texts: dict[str, str] | None = None
    comps = []
    for cid, text in component_texts.items():
        label = component_vow(homes.get(cid, SHARED), cid).as_posix()
        name, comp = read_vow(text, label, "component")
        if name not in (None, cid):
            raise ManifestError(f"{label}: the vow of `{name}` in the file of `{cid}` - the file is named "
                                "after its component")
        comp = {"id": cid, "feature": homes.get(cid, SHARED), **comp}
        for name in COMPONENT_ITEMS:
            for item in comp.pop(name, None) or []:
                item = {"component": comp["id"], **item}
                _expand(item, comp["id"])
                data.setdefault(name, []).append(item)
        for decision in comp.get("decisions") or []:
            if "template_question" in decision:
                if texts is None:
                    texts = _template_texts(data, root)
                ref = decision.pop("template_question")
                decision["question"] = texts.get(str(ref), f"(a question the template no longer asks: {ref})")
                decision.setdefault("answer", None)
        comps.append(comp)
    comps.sort(key=lambda c: (str(c.get("layer", "")), str(c["id"])))
    for comp in comps:
        owner = by_container.get(comp.pop("container", None)) or (data["containers"] or [None])[0]
        if owner is None:
            raise ManifestError(f"component {comp['id']} belongs to no container")
        owner["components"].append(_order_decision_keys(comp))
    inherit_type_answers(data)
    link_decision_invariants(data)
    for name in ("hazards", "invariants"):
        data[name] = sorted(data.get(name) or [], key=_item_order)
    data["dismissed"] = data.get("dismissed") or []
    if not data["dismissed"]:
        data.pop("dismissed")
    return data


def link_decision_invariants(data: dict) -> None:
    """An invariant saved as `from_decision N` says what decision N of its component answers now."""
    comps = {c["id"]: c for ct in data.get("containers") or [] for c in ct.get("components") or []}
    for inv in data.get("invariants") or []:
        if inv.get("from_decision") and inv.get("component") in comps:
            inv["statement"] = decision_statement(data, comps[inv["component"]], int(inv["from_decision"]))


TYPE_ORIGIN = "type"  # a decision answered once for every component of a type (never saved in the component)


def inherit_type_answers(data: dict) -> None:
    """The architects answer a question once for a type (`type_answers` of the project vow): every
    component of that type with that question still open gets the answer, marked origin "type". A
    component's own answer always wins; `split` writes the inherited ones back as open."""
    shared = {(str(a.get("type")), str(a.get("question"))): a for a in data.get("type_answers") or []}
    if not shared:
        return
    for container in data.get("containers") or []:
        for comp in container.get("components") or []:
            for decision in comp.get("decisions") or []:
                if str(decision.get("answer") or "").strip():
                    continue
                found = shared.get((str(comp.get("type")), str(decision.get("question"))))
                if found:
                    decision["answer"] = found.get("answer")
                    decision.update({k: found[k] for k in ("by", "on") if k in found})
                    decision["origin"] = TYPE_ORIGIN


def _order_decision_keys(comp: dict) -> dict:
    """Decisions read back as {question, answer, ...}: the order every module has always printed."""
    for i, decision in enumerate(comp.get("decisions") or []):
        if "question" in decision:
            comp["decisions"][i] = {"question": decision["question"], "answer": decision.get("answer"),
                                    **{k: v for k, v in decision.items() if k not in ("question", "answer")}}
    return comp


def _item_order(item: dict) -> tuple:
    match = ITEM_ID_RE.match(str(item.get("id", "")))
    if not match:
        return ("", 0, str(item.get("id")))
    return (match.group("scope"), int(match.group("n")), "")


def _expand(item: dict, scope: str | None) -> None:
    if "id" in item:
        item["id"] = qualify(scope, item["id"])
    if item.get("mitigates"):
        item["mitigates"] = [qualify(scope, h) for h in item["mitigates"]]


# ------------------------------------------------------------------ save


def split(data: dict, root: Path | None) -> tuple[str, dict[str, str], dict[str, tuple[str, str]]]:
    """The one in-memory dict -> (project vow text, {feature: its vow text}, {component id: (its feature, its vow
    text)})."""
    data = copy.deepcopy(data)
    features = {}
    for feature in data.pop("features", None) or []:
        feature = dict(feature)
        name = feature.pop("name")
        features[name] = vowfile.dumps("feature", feature, name=name, comment=FEATURE_HEADER.format(id=name))
    data["schema_version"] = SCHEMA_VERSION
    several = len(data.get("containers") or []) > 1
    owned: dict[str, dict[str, list]] = {}
    system: dict[str, list] = {}
    known = {c["id"] for container in data.get("containers") or [] for c in container.get("components", [])}
    for name in COMPONENT_ITEMS:
        for item in data.pop(name, None) or []:
            scope = item.get("component")
            item = {k: v for k, v in item.items() if k != "component"} if scope in known else dict(item)
            if name == "invariants" and item.get("from_decision"):
                item.pop("statement", None)  # the decision's words: never copied into the vow
            if scope in known:
                _shorten(item, scope)
                owned.setdefault(scope, {}).setdefault(name, []).append(item)
            else:
                item.pop("component", None) if scope is None else None
                _shorten(item, None)
                system.setdefault(name, []).append(item)
    texts_of: dict[str, dict[str, str]] = {}  # per container: its template's questions
    components: dict[str, tuple[str, str]] = {}
    containers = []
    for container in data.get("containers") or []:
        comps = container.pop("components", None) or []
        containers.append(container)
        for comp in comps:
            comp = dict(comp)
            if several:
                comp["container"] = container["id"]
            decisions = []
            for decision in comp.get("decisions") or []:
                if decision.get("origin") == TYPE_ORIGIN:  # the project's answer: not the component's own
                    decision = {"question": decision.get("question", ""), "answer": None}
                if decision.get("answer") is None and set(decision) <= {"question", "answer"}:
                    if container["id"] not in texts_of:
                        texts_of[container["id"]] = _template_texts(data | {"containers": [container]}, root)
                    texts = texts_of[container["id"]]
                    key = question_key(decision.get("question", ""))
                    if texts.get(key) == decision.get("question"):
                        decisions.append({"template_question": key})
                        continue
                decisions.append(decision)
            if "decisions" in comp:
                comp["decisions"] = decisions
            for name in COMPONENT_ITEMS:
                if owned.get(comp["id"], {}).get(name):
                    comp[name] = owned[comp["id"]][name]
            cid, feature = comp.pop("id"), str(comp.pop("feature", None) or SHARED)
            if feature not in features:  # a feature named only by its components: its vow is written too
                features[feature] = vowfile.dumps("feature", {}, name=feature, comment=FEATURE_HEADER.format(id=feature))
            components[cid] = (feature, vowfile.dumps("component", comp, name=cid,
                                                      comment=COMPONENT_HEADER.format(id=cid)))
    project = {k: v for k, v in data.items() if k != "containers"}
    ordered = {"system": project.pop("system", {}), "containers": containers}
    ordered.update({k: v for k, v in project.items() if k != "schema_version"})
    for name, items in system.items():
        ordered[name] = items
    return vowfile.dumps("project", ordered, comment=PROJECT_HEADER), features, components


def _shorten(item: dict, scope: str | None) -> None:
    if "id" in item:
        item["id"] = shorten(scope, item["id"])
    if item.get("mitigates"):
        item["mitigates"] = [shorten(scope, h) for h in item["mitigates"]]


def save(root: Path, data: dict) -> Path:
    """Write the spec; only files whose text changes are written, and a component's file moves with it when it
    changes feature. Returns the project vow path."""
    project_text, features, components = split(data, root)
    with spec_lock(root):  # a second archvow (the IDE, another terminal) waits for this one
        path = root / PROJECT_REL
        path.parent.mkdir(parents=True, exist_ok=True)
        _write_if_changed(path, project_text)
        for name, text in features.items():
            _write_if_changed(root / feature_vow(name), text)
        for cid, (feature, text) in components.items():
            _write_if_changed(root / component_vow(feature, cid), text)
        folder = root / FEATURES_REL
        for stale in sorted(folder.glob(f"*/{COMPONENTS_DIR}/*.vow")) if folder.is_dir() else []:
            if components.get(stale.stem, ("",))[0] != stale.parent.parent.name:
                stale.unlink()  # removed, or moved to another feature
        for feature in sorted(p for p in folder.iterdir() if p.is_dir()) if folder.is_dir() else []:
            if feature.name not in features:
                _remove_feature_folder(feature)
    _LOADED.pop(str(root.resolve()), None)
    return path


def _remove_feature_folder(folder: Path) -> None:
    """A feature removed or renamed: its vow and its empty components/ go; anything else stays (proposals)."""
    (folder / f"{folder.name}.vow").unlink(missing_ok=True)
    components = folder / COMPONENTS_DIR
    if components.is_dir() and not any(components.iterdir()):
        components.rmdir()
    if not any(folder.iterdir()):
        folder.rmdir()


def _write_if_changed(path: Path, text: str) -> bool:
    try:
        if path.read_text(encoding="utf-8") == text:
            return False
    except OSError:
        logs.swallowed(log, "_write_if_changed: OSError")
        pass
    path.parent.mkdir(parents=True, exist_ok=True)
    write_text(path, text)
    return True


def where(component: dict | None) -> str:
    """The file a finding about one component (or the project, None) points to."""
    if not component:
        return PROJECT_REL.as_posix()
    return component_vow(str(component.get("feature") or SHARED), component["id"]).as_posix()


# ------------------------------------------------------------------ helpers


def container(data: dict, container_id: str | None) -> dict:
    containers = data.get("containers", [])
    if container_id is None:
        if len(containers) != 1:
            ids = ", ".join(c["id"] for c in containers)
            raise ManifestError(f"several containers ({ids}); pass --container")
        return containers[0]
    for item in containers:
        if item["id"] == container_id:
            return item
    raise ManifestError(f"unknown container '{container_id}'")


def name_values(name: str) -> dict[str, str]:
    """The placeholders a component type may use: {name} orders_clean, {NAME} ORDERS_CLEAN,
    {Name} OrdersClean (a class name)."""
    return {"name": name, "NAME": name.upper(), "Name": "".join(p.capitalize() for p in name.split("_"))}


def test_path(component: dict) -> str:
    """Where a component's test lives: tests/<layer>/[<group>/]test_<id>.py."""
    group = f"{component['group']}/" if component.get("group") else ""
    return f"tests/{component['layer']}/{group}test_{component['id']}.py"


def source_path(container_data: dict, component: dict) -> str:
    """The component's file: <container path>/<layer>/[<group>/]<id>.py."""
    return f"{container_data['path']}/" + "/".join(component["module"].split(".")[1:]) + ".py"


def hazards(data: dict) -> list[dict]:
    """The hazards: what must never happen (dismissed safety questions are not hazards)."""
    return list(data.get("hazards", []) or [])


def dismissals(data: dict) -> list[dict]:
    """Safety questions answered "not applicable", with the reason (`archvow hazard dismiss`)."""
    return list(data.get("dismissed") or [])


def answered_safety(data: dict) -> set[tuple[str | None, str | None]]:
    """(component, guide word) pairs whose safety question has an answer: a hazard or a dismissal."""
    return ({(h.get("component"), h.get("guide_word")) for h in data.get("hazards", []) or []}
            | {(d.get("component"), d.get("guide_word")) for d in data.get("dismissed") or []})


def instructed_tools(data: dict) -> list[str]:
    """AI tools that get instructions and may have their files here: the approved assistants
    (they write code) and the approved reviewers (they only write review reports)."""
    tools = [*(data.get("ai_tools") or []), *(data.get("reviewers") or [])]
    return [t for t in dict.fromkeys(tools) if t != "none"]
