"""The vows on disk and in memory (layer 1): store.py loads and saves them (one per component, ids, Git history),
vowfile.py is the .vow syntax, spec.py reads the spec in memory (find a component, the rules that apply, who
recorded an item), types.py names the shapes of the spec. Imports only foundation/ and templates.py.
"""
