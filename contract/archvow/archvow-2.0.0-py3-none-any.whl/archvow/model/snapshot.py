"""What a command changed in the vows: a snapshot before it (a digest per vow file), compared after it. The console
renders again only the specs of what changed; nothing is kept between commands.
"""

from __future__ import annotations

from pathlib import Path

from archvow.foundation.hashing import short_digest
from archvow.foundation.paths import (
    COMPONENT_FILE,
    COMPONENTS_REL,
    PROJECT_REL,
)


def snapshot(root: Path) -> dict[str, str]:
    """What the vows say now, file by file - "*" for the project's vow, then each component id - as digests of
    their text. The console takes one before a command and compares after it (`changed_since`): only the specs
    of what changed are rendered again. Nothing is kept between commands."""
    found: dict[str, str] = {}
    project = root / PROJECT_REL
    if project.is_file():
        found["*"] = short_digest(project.read_text(encoding="utf-8"))
    folder = root / COMPONENTS_REL
    if folder.is_dir():
        for component in sorted(folder.iterdir()):
            vow = component / COMPONENT_FILE
            if vow.is_file():
                found[component.name] = short_digest(vow.read_text(encoding="utf-8"))
    return found


def changed_since(root: Path, before: dict[str, str]) -> set[str]:
    """The vows a command changed, added or removed since `before` (`snapshot`): component ids, "*" the project's."""
    after = snapshot(root)
    return {key for key in before.keys() | after.keys() if before.get(key) != after.get(key)}
