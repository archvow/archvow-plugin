"""The spec as it was at a commit (`archvow check --base`, `archvow diff --base`, `archvow changes`): the same
vows, read from Git instead of the disk, assembled the same way.
"""

from __future__ import annotations

import subprocess
from pathlib import Path

from archvow.foundation import logs
from archvow.foundation.git import git_or_none
from archvow.foundation.paths import ARCHVOW_DIR, COMPONENTS_DIR, FEATURES_REL, PROJECT_REL
from archvow.model.store import assemble

log = logs.get("manifest")



def load_at(root: Path, commit: str) -> dict | None:
    """The spec as it was at `commit`; None when archvow was not there yet."""
    listing = git_or_none(root, "ls-tree", "-r", "--name-only", commit, "--", ARCHVOW_DIR.as_posix())
    if listing is None:
        return None
    names = set(listing.split("\n"))
    if PROJECT_REL.as_posix() not in names:
        return None
    prefix = FEATURES_REL.as_posix() + "/"
    vows = sorted(n for n in names if n.startswith(prefix) and n.endswith(".vow") and n.count("/") in (3, 4))
    feature_paths = [n for n in vows if n.count("/") == 3 and n.split("/")[3] == n.split("/")[2] + ".vow"]
    component_paths = [n for n in vows if n.count("/") == 4 and n.split("/")[3] == COMPONENTS_DIR]
    texts = _cat(root, commit, [PROJECT_REL.as_posix(), *feature_paths, *component_paths])
    features = {p.split("/")[2]: texts.get(p, "") for p in feature_paths}
    components = {p.split("/")[4][:-4]: texts.get(p, "") for p in component_paths}
    homes = {p.split("/")[4][:-4]: p.split("/")[2] for p in component_paths}
    return assemble(texts.get(PROJECT_REL.as_posix(), ""), components, root, features, homes)


def _cat(root: Path, commit: str, paths: list[str]) -> dict[str, str]:
    """Several files at one commit, with one `git cat-file --batch`."""
    if not paths:
        return {}
    try:
        done = subprocess.run(["git", "-C", str(root), "cat-file", "--batch"], capture_output=True,
                              input="".join(f"{commit}:{p}\n" for p in paths).encode("utf-8"), check=False)
    except FileNotFoundError:
        logs.swallowed(log, "_cat: FileNotFoundError")
        return {}
    out, pos, result = done.stdout, 0, {}
    for path in paths:
        end = out.index(b"\n", pos)
        header = out[pos:end].decode("utf-8", "replace").split()
        pos = end + 1
        if len(header) < 3 or header[1] == "missing":
            continue
        size = int(header[2])
        result[path] = out[pos:pos + size].decode("utf-8", "replace")
        pos += size + 1
    return result
