"""Features: what the product does (orders, invoices), each a folder of the spec holding its components.

A feature holds no decision of its own: it names what its components serve, and links the brief people wrote.
Which feature uses which is never written: it is worked out from the components' `uses`.

    features(data)            the features, by name (`shared` first: what every feature uses)
    components_of(data, f)    the components of one feature, in build order (layer, then name)
    feature_uses(data)        feature -> {other feature: [(component, the component it uses), ...]}
    cycle(data)               a loop between features (the first found), or []
"""

from __future__ import annotations

import re

from archvow.foundation.errors import SpecError
from archvow.foundation.paths import SHARED

NAME_RE = re.compile(r"^[a-z][a-z0-9_]*$")


def features(data: dict) -> list[dict]:
    """The features, `shared` first, then by name."""
    found = {str(f["name"]): f for f in data.get("features") or []}
    for comp in all_components(data):  # a feature named only by its components is a feature too
        found.setdefault(str(comp.get("feature") or SHARED), {"name": str(comp.get("feature") or SHARED)})
    return sorted(found.values(), key=lambda f: (f["name"] != SHARED, f["name"]))


def all_components(data: dict) -> list[dict]:
    return [c for container in data.get("containers") or [] for c in container.get("components") or []]


def feature_of(component: dict) -> str:
    return str(component.get("feature") or SHARED)


def components_of(data: dict, feature: str) -> list[dict]:
    """The components of one feature, in build order: the lowest layer first, then by name."""
    return sorted((c for c in all_components(data) if feature_of(c) == feature),
                  key=lambda c: (str(c.get("layer", "")), str(c["id"])))


def find(data: dict, name: str) -> dict:
    """The feature called `name`; SpecError says which ones exist."""
    for feature in features(data):
        if feature["name"] == name:
            return feature
    known = ", ".join(f["name"] for f in features(data)) or "none"
    raise SpecError(f"no feature '{name}' (features: {known})", hint=f"archvow feature add {name} -d \"...\"")


def check_name(name: str) -> str:
    if not NAME_RE.match(name):
        raise SpecError(f"feature name '{name}': lower case letters, digits and _, starting with a letter "
                        "(it names a folder)")
    return name


def home_for(data: dict, name: str | None) -> tuple[str, bool]:
    """Where a new component goes: the feature named (it must exist), or the project's one feature besides
    `shared`. The project's first component makes one, named after the project (True: made); with several,
    say which."""
    if name:
        return find(data, check_name(name))["name"], False
    own = [f["name"] for f in features(data) if f["name"] != SHARED]
    if len(own) == 1:
        return own[0], False
    if own:
        raise SpecError(f"which feature? the project has {', '.join(own)}",
                        hint="--feature <name> (or --feature shared: what every feature uses)")
    made = re.sub(r"[^a-z0-9_]+", "_", str((data.get("system") or {}).get("name") or "main").lower()).strip("_")
    made = made if NAME_RE.match(made) else "main"
    data.setdefault("features", []).append({"name": made, "description": str((data.get("system") or {})
                                                                              .get("description") or "")})
    return made, True


def feature_uses(data: dict) -> dict[str, dict[str, list[tuple[str, str]]]]:
    """Which feature uses which, from the components' `uses`: feature -> {other: [(component, used)]}."""
    home = {c["id"]: feature_of(c) for c in all_components(data)}
    out: dict[str, dict[str, list[tuple[str, str]]]] = {}
    for comp in all_components(data):
        mine = feature_of(comp)
        for used in comp.get("uses") or []:
            other = home.get(used)
            if other is not None and other != mine:
                out.setdefault(mine, {}).setdefault(other, []).append((comp["id"], used))
    return out


def used_by(data: dict, feature: str) -> dict[str, list[tuple[str, str]]]:
    """The features that use this one: other -> [(their component, the one of this feature it uses)]."""
    return {other: pairs[feature] for other, pairs in feature_uses(data).items() if feature in pairs}


def entry_points(data: dict) -> set[str]:
    """The components nothing uses: the app, the jobs - where the features are plugged in."""
    used = {u for c in all_components(data) for u in c.get("uses") or []}
    return {c["id"] for c in all_components(data) if c["id"] not in used}


def shared_misuses(data: dict) -> list[tuple[str, str, str]]:
    """`shared` using a feature from anything but an entry point: (component, used, its feature)."""
    entries = entry_points(data)
    return [(comp, used, other) for other, pairs in feature_uses(data).get(SHARED, {}).items()
            for comp, used in pairs if comp not in entries]


def cycle(data: dict) -> list[str]:
    """The first loop between features (`shared` left out: what it uses comes from its entry points), or []."""
    graph = {f: {o for o in others if o != SHARED} for f, others in feature_uses(data).items() if f != SHARED}
    state: dict[str, int] = {}
    path: list[str] = []

    def visit(node: str) -> list[str]:
        state[node] = 1
        path.append(node)
        for nxt in sorted(graph.get(node, ())):
            if state.get(nxt) == 1:
                return [*path[path.index(nxt):], nxt]
            if nxt not in state:
                found = visit(nxt)
                if found:
                    return found
        path.pop()
        state[node] = 2
        return []

    for node in sorted(graph):
        if node not in state:
            found = visit(node)
            if found:
                return found
    return []
