"""The spec in memory, read: find a component, the rules that apply to it, who recorded an item and when, what
an item still waits for. Data in, data out: nothing here loads or saves.
"""

from __future__ import annotations

from collections.abc import Mapping
from datetime import UTC
from pathlib import Path

from archvow.foundation.errors import SpecError
from archvow.foundation.git import git_or_none
from archvow.foundation.i18n import DEFAULT_LANGUAGE, tr
from archvow.foundation.text import one_line
from archvow.model.types import Component, Container, Origin, Rule, Spec, Stamp


def find_component(data: Spec, component_id: str) -> tuple[Container, Component]:
    for container in data.get("containers", []):
        for component in container.get("components", []):
            if component["id"] == component_id:
                return container, component
    import difflib

    known = [c["id"] for ct in data.get("containers", []) for c in ct.get("components", [])]
    close = difflib.get_close_matches(component_id, known, n=1)
    hint = f" Did you mean '{close[0]}'?" if close else ""
    raise SpecError(f"unknown component '{component_id}'.{hint} Components in this project: "
                    f"{', '.join(known) or 'none'}. Declare a new one with "
                    f"`archvow component add <type> <name> -d \"...\"` (`archvow catalog` lists the types).")


def required_text(text: str, what: str) -> str:
    """Spec texts are never empty, and fit on one line (they appear in lists and tables)."""
    if not str(text).strip():
        raise SpecError(f"{what} is required")
    return one_line(text)


def rule_scope(rule: Rule, language: str = DEFAULT_LANGUAGE) -> str:
    """Who a rule applies to, in words: 'sales_reader, orders_reader', 'every reader', 'all components'."""
    scope = rule.get("scope") or {}
    if scope.get("all"):
        return tr(language, "all components")
    if scope.get("type"):
        return tr(language, "every {type}", type=scope["type"])
    return ", ".join(scope.get("components") or [])


def rule_applies(rule: Rule, component: Component) -> bool:
    scope = rule.get("scope") or {}
    return bool(scope.get("all") or (scope.get("type") and scope["type"] == component.get("type"))
                or component.get("id") in (scope.get("components") or []))


def rules_for(data: Spec, component: Component) -> list[Rule]:
    """The project rules that apply to a component, in their R order."""
    return [r for r in data.get("project_rules") or [] if rule_applies(r, component)]


def stamp(root: Path) -> Stamp:
    """Who and when, recorded on every human decision (`archvow audit` cross-checks Git)."""
    import getpass
    from datetime import datetime

    who = (git_or_none(root, "config", "user.email") or "").strip()
    when = datetime.now(UTC).isoformat()  # microseconds: unique, so audit finds the right commit
    return {"by": who or getpass.getuser(), "on": when}


def ai_origin(added_by: str | None, why: str | None) -> Origin:
    """What an item records about where it came from: the AI agent that added it (`added_by`), and why it was
    added, in a few words (`why`, a person may give one too)."""
    reason = one_line(why) if why and why.strip() else ""
    return {**({"added_by": added_by} if added_by else {}), **({"why": reason} if reason else {})}


def to_accept(item: Mapping[str, object]) -> bool:
    """An item an AI agent added that no person kept yet - a question no person answered yet either."""
    return bool(item.get("added_by")) and not item.get("accepted") and not str(item.get("answer") or "").strip()


def decision_statement(data: Spec, comp: Component, number: int) -> str:
    """What an invariant linked to decision `number` says: the decision's answer, "(decision N)"."""
    language = data.get("language") or DEFAULT_LANGUAGE
    decisions = comp.get("decisions") or []
    answer = (decisions[number - 1].get("answer") or "").strip() if 0 < number <= len(decisions) else ""
    if not answer:
        return tr(language, "decision {number} (not made any more)", number=number)
    return tr(language, "{answer} (decision {number})", answer=answer.rstrip("."), number=number)


MODES = ("strict", "guided", "free")


def mode(data: Mapping[str, object]) -> str:
    """The project's mode: how much the AI decides on its own (strict when the vow says nothing)."""
    value = str(data.get("mode") or "strict")
    return value if value in MODES else "strict"


SEVERITIES = ("critical", "high", "medium", "low")
