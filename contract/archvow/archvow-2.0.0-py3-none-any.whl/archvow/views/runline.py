"""The run line: how to try the project locally, or why it cannot run yet.

`archvow next` ends with one line per entry point (the types a template lists under `run: types`),
and `archvow show <entry point>` shows it too:

    Try it locally: SPARK_MASTER="local[*]" ./entrypoint.sh daily_sales --input-path <input_path>
    Not ready to run yet: daily_sales_main needs clean_sales (planned), revenue_writer (started)

An entry point is ready when it and everything it needs (its `uses`, followed through, plus the
components every one depends on - `implicit_dependency`) is coded and has no placeholder left.
The arguments come from the parameters decision of the template's `run: arguments_from` component
(`input_path: str, run_date: date, output_format: str = "parquet"`, no default = required): one
`--name-with-dashes <name>` per required parameter; a parameter typed `secret` is never put on the command line - the line says which
environment variable it needs. The line is only for a laptop: deployment (a cluster, Kubernetes, a
serverless platform) keeps its own settings and is never printed here.
"""

from __future__ import annotations

import re

from archvow.foundation.text import says_nothing

PARAMETER_RE = re.compile(r"^\s*([a-z_][a-z0-9_]*)\s*:\s*([^=(]+?)\s*(?:=\s*([^()]+?))?\s*(\((.*)\))?\s*$")


def parameters(answer: str | None) -> list[dict] | None:
    """`input_path: str, run_date: date = today` (older answers: `input_path: str (required)`) -> [{name, type, default, required}].
    None when the answer cannot be read that way (a sentence, not a list)."""
    text = (answer or "").strip().rstrip(".")
    if not text or says_nothing(text):
        return [] if text else None
    found = []
    for part in re.split(r"[,;\n]\s*(?=[a-z_][a-z0-9_]*\s*:)", text):
        match = PARAMETER_RE.match(part)
        if not match:
            return None
        name, kind, default, _, note = match.groups()
        required = default is None or "required" in (note or "") or "obligatoire" in (note or "")
        found.append({"name": name, "type": kind.strip(), "default": (default or "").strip(), "required": required})
    return found


def _arguments(params: list[dict] | None) -> tuple[str, list[str]]:
    """The command-line arguments, and the environment variables the secrets need."""
    if params is None:
        return "<its arguments>", []
    args, secrets = [], []
    for p in params:
        if p["type"].lower() == "secret":
            env = re.search(r"[A-Z][A-Z0-9_]+", p["default"])
            secrets.append(env.group(0) if env else p["name"].upper())
        elif p["required"]:
            args.append(f"--{p['name'].replace('_', '-')} <{p['name']}>")
    return " ".join(args), secrets


def _needs(comps: dict, cid: str) -> list[str]:
    """What an entry point needs to run: its `uses`, followed through, in dependency order."""
    seen: list[str] = []

    def visit(current: str) -> None:
        for dep in comps.get(current, {}).get("uses", []) or []:
            if dep in comps and dep not in seen:
                visit(dep)
                seen.append(dep)

    visit(cid)
    return seen


def run_lines(data: dict, templates: dict, report) -> list[dict]:
    """One line per entry point: how to try it locally, or what it still needs ({component, ready, line})."""
    status = {c.component: c.status for c in report.components}
    lines = []
    for container in data.get("containers", []):
        template = templates.get(container["id"])
        run = (template.data.get("run") if template else None) or {}
        if not run.get("command"):
            continue
        comps = {c["id"]: c for c in container.get("components", [])}
        always = [cid for cid, c in comps.items()
                  if ((template.component_types.get(c.get("type")) or {}).get("implicit_dependency"))]
        source = comps.get((run.get("arguments_from") or {}).get("component", ""))
        number = int((run.get("arguments_from") or {}).get("question") or 1)
        decisions = (source or {}).get("decisions") or []
        answer = decisions[number - 1].get("answer") if len(decisions) >= number else None
        for cid, comp in comps.items():
            if comp.get("type") not in (run.get("types") or []):
                continue
            missing = []
            for need in [*always, *_needs(comps, cid), cid]:
                left = left_to_do(report, container["id"], need)
                if left:
                    missing.append(f"{need} (started)")
                elif status.get(need, "planned") == "planned":
                    missing.append(f"{need} (planned)")
            missing = list(dict.fromkeys(missing))
            if missing:
                lines.append({"component": cid, "ready": False,
                              "line": f"Not ready to run yet: {cid} needs {', '.join(missing)}"})
                continue
            arguments, secrets = _arguments(parameters(answer) if source else [])
            command = run["command"].format(name=comp.get("name", cid), arguments=arguments,
                                            module=comp.get("module", "")).rstrip()
            then = [run["then"].format(path=_path(r)) for r in _routes(comps) if run.get("then")][:1]
            line = f"Try it locally: {command}" + "".join(f", then {t}" for t in then)
            if secrets:
                line += f"  (needs {', '.join(secrets)} in the environment)"
            lines.append({"component": cid, "ready": True, "line": line})
    return lines


def _routes(comps: dict) -> list[dict]:
    """The GET routes the spec declares (a curl needs no body)."""
    return [s for c in comps.values() for s in c.get("symbols", []) or []
            if s.get("kind") == "route" and s.get("method") == "GET"]


def _path(route: dict) -> str:
    return re.sub(r"\{([a-z_][a-z0-9_]*)\}", r"<\1>", route.get("path", "/"))


def left_to_do(report, container: str, component: str) -> str:
    """For a component whose file already exists: its public names still missing or placeholders."""
    symbols = [s for s in report.statuses if s.container == container and s.component == component
               and s.status == "planned" and s.reason]
    if not symbols:
        return ""
    parts = [f"{s.symbol} {'missing' if s.reason == 'missing' else 'is a placeholder'}" for s in symbols]
    return "started - " + ", ".join(parts)
