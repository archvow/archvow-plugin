"""What archvow writes for people and the AI to read. Never edit it by hand; run `archvow docs`.

Two kinds of output, kept apart on purpose:

Specs - depend only on the vows (.archvow/spec.vow and .archvow/components/<c>/spec.vow).
Committed and protected by CODEOWNERS; they change only when the spec changes. `archvow docs
--check` (the Git hook, CI) fails if they are stale or were edited by hand.
  .archvow/components/<c>/spec.md   one component's spec: the task to implement it (the AI's card)
  .archvow/spec.md                  the whole project on one page: architecture diagram, components
                                    (trace), the project's rules R1..., hazards, invariants,
                                    personal data (GDPR), third parties (DORA), briefs, and the
                                    checks of every family that is on, with their severity

Status report - depends on the code. Written to .archvow/status.md, which is gitignored, so
implementing code never touches protected files.
  .archvow/status.md   planned / implemented / tested / verified / drift, evidence per
                       invariant, open questions, coloured diagram
"""

from __future__ import annotations

import re
from pathlib import Path

from archvow.briefs import coverage, drawn_items, ref_of
from archvow.checks.engine import Report
from archvow.checks.run import run_check
from archvow.compliance import compliance_views
from archvow.foundation import logs
from archvow.foundation.files import write_text
from archvow.foundation.i18n import tr
from archvow.foundation.paths import OWNERS_BEGIN, OWNERS_END, STATUS_REL
from archvow.foundation.text import md_cell
from archvow.model import store
from archvow.model.spec import rule_applies, rule_scope
from archvow.templates import TemplateError, load_template, template_name
from archvow.views.cards import render_prompt
from archvow.views.rule_families import generated_header, in_reading_order, language_of, rule_files

log = logs.get("docs")

CARD_HEADER = ("<!-- archvow spec of {id} - the task the AI or the developer implements. Generated from "
               "spec.vow in this folder, do not edit. -->")
PROJECT_HEADER = ("<!-- archvow spec of the project - all components, rules, hazards and checks on one page. "
                  "Generated from the vows (.archvow/spec.vow, .archvow/components/), do not edit. -->")
STATUS_HEADER = ("<!-- archvow status - what the code does today against the spec. Generated from the vows "
                 "and the code; local report, not committed (gitignored). -->\n\n")
COLORS = {
    "planned": "fill:#eeeeee,stroke:#888,color:#333",
    "implemented": "fill:#fff4ce,stroke:#c9a400,color:#333",
    "tested": "fill:#e3f0ff,stroke:#1e6bd6,color:#0d2c57",
    "verified": "fill:#dff6dd,stroke:#2e7d32,color:#1b3d1d",
    "drift": "fill:#fde7e9,stroke:#c62828,color:#5c1111",
}


def card_path(root: Path, component_id: str) -> Path:
    return root / store.COMPONENTS_REL / component_id / store.CARD_FILE


def card(root: Path, data: dict, component_id: str, shared: dict | None = None) -> str:
    """One component's spec.md. `shared`: reused by every card of one run (render_prompt)."""
    return (tr(language_of(data), CARD_HEADER, id=component_id) + "\n\n"
            + render_prompt(root, component_id, include_status=False, shared=shared))


def project_spec(root: Path, data: dict) -> str:
    """The project's spec.md: every project-wide view, one section each."""
    lang = language_of(data)
    sections = [
        _diagram(root, data, None),
        _trace(data),
        _project_rules(data),
        _hazards(data),
        _invariants(data),
    ]
    sections += list(compliance_views(root, data).values())
    if drawn_items(data):  # only a project that draws its spec from briefs has this section
        sections.append(_briefs(data))
    families = rule_files(root, data)
    out = [tr(lang, PROJECT_HEADER) + "\n\n",
           tr(lang, "# {name} - the project's spec", name=data["system"]["name"]) + "\n\n",
           tr(lang, "Each component's own spec (its task): `.archvow/components/<component>/spec.md`, or "
              "`archvow show <component>`.") + "\n\n"]
    out += [_section(text) for text in sections]
    if families:
        out.append(tr(lang, "## Checks") + "\n\n"
                   + tr(lang, "What `archvow check` verifies on every component's code, family by family (the "
                      "families the project turned on). Severity shown is the effective one (template "
                      "defaults + the `rules` overrides of .archvow/spec.vow). Silence a single line only "
                      "with a reason: `# archvow: ignore[CODE] -- why`.") + "\n\n")
        out += [_section(text, 2) for text in in_reading_order(root, data, families)]
    return "".join(out).rstrip("\n") + "\n"




def _section(text: str, depth: int = 1) -> str:
    """A view as a section of spec.md: no header comment, headings one (or `depth`) level down."""
    text = re.sub(r"\A\s*<!--.*?-->\s*", "", text, flags=re.DOTALL)
    lines = []
    fence = False
    for line in text.split("\n"):
        if line.startswith("```"):
            fence = not fence
        if not fence and re.match(r"#{1,5} ", line):
            line = "#" * depth + line
        lines.append(line)
    return "\n".join(lines).rstrip("\n") + "\n\n"




def spec_views(root: Path, only: set[str] | None = None) -> dict[Path, str]:
    """Committed specs: a pure function of the vows (and template). `only`: the component cards to
    render (the others are left out of the result); None renders every one."""
    data = store.load(root)
    views: dict[Path, str] = {root / store.ARCHVOW_DIR / store.CARD_FILE: project_spec(root, data)}
    shared: dict = {"data": data}  # read once for every card
    for container in data.get("containers", []):
        for comp in container.get("components", []):
            if only is None or comp["id"] in only:
                views[card_path(root, comp["id"])] = card(root, data, comp["id"], shared)
    owners = owners_view(root, data)
    if owners:
        views[owners[0]] = owners[1]
    return views


CODEOWNERS_FILES = (".gitlab/CODEOWNERS", ".github/CODEOWNERS")


def owners_view(root: Path, data: dict) -> tuple[Path, str] | None:
    """The project's CODEOWNERS with its block of component owners brought up to date: each component
    that has `owners` gets its vow folder approved by them (or the architects). The block is last, so it
    wins over the architects' line for .archvow/components/. Nothing to do without a CODEOWNERS file."""
    path = next((root / rel for rel in CODEOWNERS_FILES if (root / rel).is_file()), None)
    if path is None:
        return None
    text = path.read_text(encoding="utf-8")
    if OWNERS_BEGIN in text:
        start = text.index(OWNERS_BEGIN)
        end = text.find(OWNERS_END, start)
        end = len(text) if end < 0 else end + len(OWNERS_END)
        text = text[:start].rstrip("\n") + "\n" + text[end:].lstrip("\n")
    architects = str((data.get("init_answers") or {}).get("architects") or "").split()
    lines = []
    for container in data.get("containers", []):
        for comp in sorted(container.get("components", []), key=lambda c: c["id"]):
            if comp.get("owners"):
                who = " ".join(dict.fromkeys([*comp["owners"], *architects]))
                lines.append(f"/{(store.COMPONENTS_REL / comp['id']).as_posix()}/ {who}")
    if lines:
        text = text.rstrip("\n") + "\n\n" + "\n".join([OWNERS_BEGIN, *lines, OWNERS_END]) + "\n"
    return path, text


def touched_cards(data: dict, changed: set[str]) -> set[str] | None:
    """The cards a change can alter: the changed components, the ones using them, and the ones
    linked to them by an invariant. None (every card) when the project's own vow changed."""
    if not changed or "*" in changed:
        return None
    comps = [c for container in data.get("containers", []) for c in container.get("components", [])]
    out = set(changed)
    out |= {c["id"] for c in comps if set(c.get("uses") or []) & changed}
    hazard_owner = {h["id"]: h.get("component") for h in data.get("hazards", []) or []}
    for inv in data.get("invariants", []) or []:
        owners = {inv.get("component"), *(hazard_owner.get(h) for h in inv.get("mitigates") or [])}
        if owners & changed:
            out |= {o for o in owners if o}
    return out


def generate(root: Path, changed: set[str] | None = None) -> list[Path]:
    """Write the specs and the local status. `changed` (the component ids whose vow a command just
    changed, "*" for the project's): only the cards that can differ are rendered again."""
    data = store.load(root)
    only = touched_cards(data, changed) if changed is not None else None
    views = spec_views(root, only)
    components = {c["id"] for container in data.get("containers", []) for c in container.get("components", [])}
    folder = root / store.COMPONENTS_REL
    if folder.is_dir():
        for sub in folder.iterdir():
            if sub.is_dir() and sub.name not in components and (sub / store.CARD_FILE).is_file():
                (sub / store.CARD_FILE).unlink()
                if not any(sub.iterdir()):
                    sub.rmdir()
    report = run_check(root)
    views[root / STATUS_REL] = _status(root, data, report)
    written = []
    for path, text in views.items():
        try:
            if path.read_text(encoding="utf-8") == text:
                continue
        except OSError:
            logs.swallowed(log, "generate: OSError")
            pass
        path.parent.mkdir(parents=True, exist_ok=True)
        write_text(path, text)
        written.append(path)
    log.info("views: %d of %d written", len(written), len(views))
    return written


def check_views(root: Path) -> list[str]:
    """Problems with the committed specs: stale, edited by hand, missing or orphaned."""
    problems = []
    views = spec_views(root)
    for path, text in views.items():
        rel = path.relative_to(root).as_posix()
        if not path.is_file():
            problems.append(f"{rel} is missing")
        elif path.read_text(encoding="utf-8") != text:
            problems.append(f"{rel} differs from the vows (stale or edited by hand)")
    folder = root / store.COMPONENTS_REL
    if folder.is_dir():
        for path in sorted(folder.glob(f"*/{store.CARD_FILE}")):
            if path not in views:
                problems.append(f"{path.relative_to(root).as_posix()} has no component vow next to it")
    return problems


# ------------------------------------------------------------------ the specs






def _trace(data: dict) -> str:
    lang = language_of(data)
    lines = [generated_header(data), tr(lang, "# Traceability - {name}", name=data["system"]["name"]) + "\n\n",
             tr(lang, "What exists, where, and why. Implementation status: `archvow check` or "
                "`{status}` (local).", status=STATUS_REL) + "\n\n",
             tr(lang, "| Spec | Layer | Component | Type | File | Public symbols | Invariants |") + "\n",
             "|---|---|---|---|---|---|---|\n"]
    by_component: dict[str, list[str]] = {}
    for inv in data.get("invariants", []) or []:
        if inv.get("component"):
            by_component.setdefault(inv["component"], []).append(inv["id"])
    rows = []
    for container in data["containers"]:
        for comp in container.get("components", []):
            file = f"{container['path']}/" + "/".join(comp["module"].split(".")[1:]) + ".py"
            symbols = ", ".join(f"`{s['name']}`" for s in comp.get("symbols", []))
            rows.append((comp.get("spec") or "-", comp["layer"], comp["id"], comp["type"], f"`{file}`",
                         symbols, ", ".join(by_component.get(comp["id"], [])) or "-"))
    lines += ["| " + " | ".join(row) + " |\n" for row in sorted(rows)]
    return "".join(lines)


ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3}
TESTED_BY = {"example_test": 'a test marked @pytest.mark.invariant("{id}")',
             "property_test": 'a Hypothesis @given test marked @pytest.mark.invariant("{id}")',
             "runtime": "a guard in the code marked `# archvow: enforces[{id}]`",
             "static": "archvow check rule {rule}", "model_check": "the model {evidence}, checked in CI",
             "proof": "the proof {evidence}, checked in CI"}


def _hazards(data: dict) -> str:
    """Hazards: what must never happen, and which invariant prevents it."""
    lang = language_of(data)
    prevented: dict[str, list[str]] = {}
    for inv in data.get("invariants", []) or []:
        for hid in inv.get("mitigates", []) or []:
            prevented.setdefault(hid, []).append(inv["id"])
    system = tr(lang, "system")
    out = [generated_header(data), tr(lang, "# Hazards - {name}", name=data["system"]["name"]) + "\n\n",
           tr(lang, "What must never happen, and the invariant that prevents it (what is always true, so it "
              "cannot happen: Invariants, below). A critical or high hazard needs one; medium and low may "
              "have one.") + "\n\n",
           tr(lang, "| Hazard | Component | Severity | What must never happen | Prevented by |") + "\n",
           "|---|---|---|---|---|\n"]
    for h in sorted(store.hazards(data), key=lambda x: (ORDER.get(x.get("severity"), 9), x.get("id", ""))):
        guards = prevented.get(h["id"])
        if guards:
            by = ", ".join(guards)
        elif h.get("severity") in ("critical", "high"):
            by = tr(lang, "**nothing yet**: archvow invariant add {c} \"...\" --prevents {id}",
                    c=h.get("component") or "system", id=h["id"])
        else:
            by = tr(lang, "- (optional for {severity})", severity=h.get("severity"))
        out.append(f"| {h['id']} | {h.get('component') or system} | {h['severity']} | "
                   f"{md_cell(h['description'])} | {by} |\n")
    dismissed = store.dismissals(data)
    if dismissed:
        out.append("\n" + tr(lang, "## Not applicable") + "\n\n"
                   + tr(lang, "Safety questions that cannot happen here, and why.") + "\n\n"
                   + tr(lang, "| Component | Question | Why it cannot happen here |") + "\n|---|---|---|\n")
        out += [f"| {d.get('component') or system} | {d.get('guide_word')} | {md_cell(d.get('rationale', ''))} |\n"
                for d in dismissed]
    return "".join(out)


def _invariants(data: dict) -> str:
    """Invariants: what is always true, the hazard it prevents, and the test that checks it."""
    lang = language_of(data)
    hazards = {h["id"]: h for h in store.hazards(data)}
    system = tr(lang, "system")
    out = [generated_header(data), tr(lang, "# Invariants - {name}", name=data["system"]["name"]) + "\n\n",
           tr(lang, "What is always true, so a hazard cannot happen (Hazards, above), and what checks it. "
              "`archvow check` fails while a coded component's invariant is not tested.") + "\n\n",
           tr(lang, "| Invariant | Component | Always true | Prevents | Tested by |") + "\n|---|---|---|---|---|\n"]
    for inv in data.get("invariants", []) or []:
        prevents = ", ".join(f"{h} ({hazards[h]['severity']})" if h in hazards else h
                             for h in inv.get("mitigates", []) or [])
        how = tr(lang, TESTED_BY.get(inv.get("verify"), "{id}"), id=inv["id"], rule=inv.get("rule"),
                 evidence=inv.get("evidence"))
        out.append(f"| {inv['id']} | {inv.get('component') or system} | {md_cell(inv['statement'])} | "
                   f"{prevents} | {md_cell(how)} |\n")
    return "".join(out)


def _diagram(root: Path, data: dict, report: Report | None) -> str:
    status = {(c.container, c.component): c.status for c in report.components} if report else {}
    out = [tr(language_of(data), "# Architecture - {name}", name=data["system"]["name"]) + "\n\n",
           f"{data['system'].get('description', '')}\n\n", "```mermaid\nflowchart TB\n"]
    for container in data["containers"]:
        try:
            layer_names = load_template(template_name(container)[0], root).layer_names
        except TemplateError:
            logs.swallowed(log, "_diagram: TemplateError")
            layer_names = sorted({c["layer"] for c in container.get("components", [])})
        out.append(f'  subgraph {container["id"]}["{container["id"]} ({container["template"]})"]\n')
        out.append("    direction TB\n")
        for layer in layer_names:
            comps = [c for c in container.get("components", []) if c["layer"] == layer]
            out.append(f'    subgraph {container["id"]}__{layer}["{layer}"]\n')
            for comp in comps:
                css = f':::{status.get((container["id"], comp["id"]), "planned")}' if report else ""
                spec = f' - {comp["spec"]}' if comp.get("spec") else ""
                out.append(f'      {container["id"]}__{comp["id"]}["{comp["id"]}<br/>'
                           f'<small>{comp["type"]}{spec}</small>"]{css}\n')
            if not comps:
                out.append(f'      {container["id"]}__{layer}__empty[" "]:::empty\n')
            out.append("    end\n")
        out.append("  end\n")
        for comp in container.get("components", []):
            for used in comp.get("uses", []) or []:
                out.append(f'  {container["id"]}__{comp["id"]} --> {container["id"]}__{used}\n')
    if report:
        out += [f"  classDef {name} {style}\n" for name, style in COLORS.items()]
    out.append("  classDef empty fill:none,stroke:none\n```\n")
    if report:
        out.append("\n" + tr(language_of(data), "Legend: grey planned, yellow implemented, blue tested, green verified "
                                           "(all invariants tested), red drift.") + "\n")
    return "".join(out)




def _project_rules(data: dict) -> str:
    """Rules: the project's own rules (archvow rule add), who they apply to, one test each."""
    lang = language_of(data)
    components = [c for container in data["containers"] for c in container.get("components", [])]
    out = [generated_header(data), tr(lang, "# Project rules - {name}", name=data["system"]["name"]) + "\n\n",
           tr(lang, "The project's own rules, in plain words (`archvow rule add`). Each component a rule "
              "applies to implements it and has a test for it.") + "\n\n",
           tr(lang, "| Rule | Applies to | Components today | What it says |") + "\n|---|---|---|---|\n"]
    for rule in data.get("project_rules") or []:
        covered = ", ".join(c["id"] for c in components if rule_applies(rule, c)) or "-"
        out.append(f"| {rule['id']} | {rule_scope(rule, lang)} | {covered} | {md_cell(rule.get('text', ''))} |\n")
    if not data.get("project_rules"):
        out.append(tr(lang, "| - | - | - | none yet: archvow rule add <component> \"Given ..., when ..., then ...\" |") + "\n")
    return "".join(out)


# ------------------------------------------------------------------ status report (gitignored)


def _status(root: Path, data: dict, report: Report) -> str:
    lang = language_of(data)
    yes, no = tr(lang, "yes"), tr(lang, "no")
    errors = len(report.errors)
    state = tr(lang, "clean") if not errors else tr(lang, "{n} error(s)", n=errors)
    out = [tr(lang, STATUS_HEADER.strip()) + "\n\n", tr(lang, "# Status - {name}", name=data["system"]["name"]) + "\n\n",
           tr(lang, "Check: **{state}**, {n} warning(s).", state=state, n=len(report.violations) - errors) + "\n\n",
           tr(lang, "## Components") + "\n\n",
           tr(lang, "| Component | Type | Status | Tested | Invariants verified | Open questions | Pending assumptions |")
           + "\n|---|---|---|---|---|---|---|\n"]
    for c in sorted(report.components, key=lambda c: (c.layer, c.component)):
        out.append(f"| {c.component} | {c.type} | {c.status} | {yes if c.tested else no} | "
                   f"{c.invariants_verified}/{c.invariants_total} | {c.open_questions} | "
                   f"{c.pending_assumptions} |\n")
    out.append("\n" + tr(lang, "## Invariants") + "\n\n" + tr(lang, "| Invariant | Component | Tested | Tested by |")
               + "\n|---|---|---|---|\n")
    for inv in report.invariants:
        evidence = "<br/>".join(inv.get("evidence") or []) or "-"
        out.append(f"| {inv['id']} | {inv.get('component') or tr(lang, 'system')} | "
                   f"{yes if inv.get('verified') else no} | {evidence} |\n")
    loose = [f"`{file}" + (f"#{section}`" if section else "`") for file, parts in coverage(root, data).items()
             for section, items in parts.items() if not items]
    if loose:
        out.append("\n" + tr(lang, "## Briefs") + "\n\n" + tr(lang, "Sections nothing in the spec is drawn from:")
                   + "\n\n" + "".join(f"- {ref}\n" for ref in loose))
    out.append("\n" + tr(lang, "## Diagram") + "\n\n" + _diagram(root, data, report).split("\n\n", 2)[-1])
    return "".join(out)


def _briefs(data: dict) -> str:
    """Briefs: each brief section, and what the spec draws from it (manifest only)."""
    lang = language_of(data)
    lines = [generated_header(data), tr(lang, "# Briefs - {name}", name=data["system"]["name"]) + "\n\n",
             tr(lang, "Where the spec comes from: each component, question and rule drawn from a brief "
                "(`--from`). `archvow check` warns when a section changes (ARCH039); after review, "
                "`archvow brief accept <brief>` records its new text.") + "\n\n",
             tr(lang, "| Brief | Drawn from it | Text recorded |") + "\n|---|---|---|\n"]
    by_ref: dict[str, list[tuple[str, str]]] = {}
    for what, entry in drawn_items(data):
        by_ref.setdefault(ref_of(entry), []).append((what, entry.get("hash", "")))
    for ref in sorted(by_ref):
        items = by_ref[ref]
        hashes = ", ".join(sorted({h for _, h in items}))
        lines.append(f"| `{ref}` | {', '.join(w for w, _ in items)} | `{hashes}` |\n")
    return "".join(lines)
