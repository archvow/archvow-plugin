"""Turn the spec into an AI task, and decide what can be built next.

The task leads with what must never happen, then the exact API, then the decisions
made. When a question is still open it tells the implementer to stop and ask instead of
choosing, because a plausible-looking default is a design decision taken silently.
"""

from __future__ import annotations

from pathlib import Path

from archvow import header
from archvow import proposals as ai
from archvow.briefs import ref_of
from archvow.checks.engine import Report
from archvow.checks.run import run_check
from archvow.examples import ACTUAL, PARTS, card_file, files_of, folder, level, scenario_text
from archvow.foundation.errors import SpecError
from archvow.foundation.i18n import tr
from archvow.model import store
from archvow.model.spec import find_component, mode, rule_scope, rules_for
from archvow.privacy import columns_line, known_columns, personal_flow
from archvow.questions import component_questions
from archvow.tasks import next_task, summary, tasks_for
from archvow.templates import TemplateError, load_template, template_name
from archvow.toreview import localized, pending
from archvow.views.rule_families import rule_family_names


def situation(question: str) -> str:
    """A vow question's situation, without its closing 'what must never happen?' - `specify` asks
    that in its own prompt, and a spec only lists the open ones (the same words in every card)."""
    head, _, tail = question.rpartition(":")
    return head.rstrip() if head and tail.strip().endswith("?") and len(tail) < 60 else question




EVIDENCE_HOWTO = {
    "example_test": 'a pytest test decorated with @pytest.mark.invariant("{id}")',
    "property_test": 'a Hypothesis @given test decorated with @pytest.mark.invariant("{id}") '
                     "(it searches for counterexamples, not one example)",
    "runtime": "a runtime guard in this component that fails the job when violated, "
               "marked with the comment `# archvow: enforces[{id}]`",
    "model_check": "the model at {evidence}, checked in CI by its model checker",
    "proof": "the proof at {evidence}, checked in CI by its proof checker",
    "static": "archvow check rule {rule} (already enforced, nothing to write)",
}


def _file_of(container: dict, component: dict) -> str:
    return store.source_path(container, component)


def _def_line(symbol: dict) -> str:
    if symbol.get("kind") == "class":
        return f"class {symbol['name']}"
    if symbol.get("kind") == "constant":
        return f"{symbol['name']}: {symbol.get('annotation', '...')}"
    if symbol.get("kind") == "route":
        return f"@router.{symbol['method'].lower()}(\"{symbol['path']}\")  def {symbol['name']}(...)"
    return f"def {symbol['name']}{symbol.get('signature', '(...)')}"


def render_prompt(root: Path, component_id: str, report: Report | None = None,
                  include_status: bool = True, task: int | None = None, shared: dict | None = None) -> str:
    """The component's spec as a task. Without status it depends only on the vows. When the
    card is cut into tasks (tasks.py), with status it shows one of them: `task`, or the next open one.
    `shared`: what every card of one run reads alike (the spec, templates, personal-data flows, check
    families), filled by the first one and reused by the next ones (`next`, ARCH044's `task_text`)."""
    shared = {} if shared is None else shared
    if "data" not in shared:
        shared["data"] = store.load(root)
    data = shared["data"]
    container, comp = find_component(data, component_id)
    templates = shared.setdefault("templates", {})
    if container["id"] not in templates:
        try:
            templates[container["id"]] = load_template(template_name(container)[0], root)
        except TemplateError as exc:
            raise SpecError(str(exc)) from exc
    template = templates[container["id"]]
    status = None
    if include_status:
        report = report or run_check(root)
        status = next((c for c in report.components if c.component == component_id), None)
    by_id = {c["id"]: c for c in container.get("components", [])}
    hazards = {h["id"]: h for h in data.get("hazards", []) or []}
    invariants = [i for i in data.get("invariants", []) or [] if i.get("component") == component_id]
    system_invariants = [i for i in data.get("invariants", []) or [] if not i.get("component")]
    open_q = [(n, d) for n, d in enumerate(comp.get("decisions", []) or [], 1) if not (d.get("answer") or "").strip()]
    decided = [(n, d) for n, d in enumerate(comp.get("decisions", []) or [], 1) if (d.get("answer") or "").strip()]
    accepted = [a for a in comp.get("assumptions", []) or [] if a.get("status") == "accepted"]
    rejected = [a for a in comp.get("assumptions", []) or [] if a.get("status") == "rejected"]
    layer = template.layer(comp["layer"]) or {}
    lang = data.get("language") or "en"
    T = lambda message, **values: tr(lang, message, **values)

    out: list[str] = []
    spec = f" - {comp['spec']}" if comp.get("spec") else ""
    kind = f", {comp['kind']}" if comp.get("kind") else ""
    out.append(T("# Task: implement `{id}` ({type}){spec}", id=component_id, type=comp["type"] + kind, spec=spec) + "\n")
    out.append(f"{comp.get('description', '')}\n")
    if comp.get("source"):
        out.append(T("Source: {ref} (for context; this spec wins over the brief).",
                     ref=f"`{ref_of(comp['source'])}`") + "\n")
    if status is not None:
        out.append(T("Current status: **{status}**.", status=status.status) + "\n")

    if "flows" not in shared:
        shared["flows"] = personal_flow(root, data)
    flows = shared["flows"]
    extra = component_questions(root, data, comp, template, flows)
    open_extra = [q for q in extra if not q["answer"]]
    tasks = tasks_for(root, data, comp, template, report if status is not None else None, extra)
    if task is not None and not tasks:
        raise SpecError(f"'{component_id}' is one task: its spec is small enough (archvow prompt {component_id})")
    if task is not None and not 1 <= task <= len(tasks):
        raise SpecError(f"'{component_id}' has tasks T1..T{len(tasks)}")
    focus = tasks[task - 1] if task is not None else next_task(tasks) if status is not None else None
    if tasks:
        out.append(T("## Tasks") + "\n")
        out.append(T("This spec is cut into {n} tasks: implement one at a time, in order; after each one, "
                     "`archvow check` and `pytest` pass. A task is done when the code exists and each of its "
                     "items has a marked test.", n=len(tasks)) + "\n")
        for t in tasks:
            mark = "" if t.done is None else (" ✔" if t.done else " ✖")
            now = T("  <- now") if focus is not None and t.number == focus.number else ""
            out.append(f"- **T{t.number}**{mark} {summary(t, lang)}{now}")
        if len(tasks) > 3:
            out.append(T("- More than 3 tasks: the architects may prefer to split this component."))
        out.append("")
    keys = None if focus is None else {i.key for i in focus.items}
    project_mode = mode(data)
    proposed = {n: p for (c, n), p in ai.by_question(root).items() if c == component_id} \
        if status is not None and project_mode != "strict" else {}
    to_propose = [(n, d) for n, d in open_q if n not in proposed]
    if to_propose and project_mode != "strict":
        out.append(T("## Decisions to propose before coding") + "\n")
        out.append(T({"guided": "Do not choose silently. For each question: take its suggested answer when it has "
                                "one, or choose yours, and record it before coding with "
                                "`archvow decision propose {id} <number> \"<answer>\"`; then go on. Stop and ask "
                                "only when there is no suggestion and the choice changes the data or the results.",
                      "free": "Choose each answer yourself and record it before coding with "
                              "`archvow decision propose {id} <number> \"<answer>\"`; then go on. A person "
                              "reviews them later."}[project_mode], id=component_id) + "\n")
        out += [f"{n}. {d['question']}" for n, d in to_propose]
        out.append("")
    due = pending(data, comp)
    if due:  # ARCH057: the component changed after these were recorded; a person looks at them first
        out.append(T("## STOP - recorded before the component changed, not reviewed yet") + "\n")
        out.append(T("Do **not** implement this component yet: what it is changed after these items were recorded, "
                     "and each may no longer hold. A person looks at each one, records again the ones that no "
                     "longer hold (`archvow decision make {id} <number> \"<answer>\"`, a hazard changed with "
                     "`archvow hazard edit`...), then runs `archvow component accept {id}`.", id=component_id) + "\n")
        out += [f"- {line}" for line in localized(due, lang)]
        out.append("")
    if (open_q and project_mode == "strict") or open_extra:
        out.append(T("## STOP - decisions still to make") + "\n")
        out.append(T("Do **not** implement this component and do not pick a reasonable default. "
                     "Ask the human these questions and wait. They record each answer with "
                     "`archvow decision make {id} <number> \"<answer>\"`. When the description, a brief or "
                     "the conversation already answers one, do not ask it: give that command with the answer "
                     "in it, for the human to check and run.", id=component_id) + "\n")
        known = columns_line(known_columns(root, container, comp, template, code=False), component_id)
        if known:  # its own names, from the vows: the questions are about them
            out.append(T("Known columns (classified in the spec): {names}",
                         names=known.removeprefix("Known columns: ")) + "\n")
        starts = template.choices(comp) if template else {}  # no default: answers to start from, none chosen
        out += [f"{n}. {d['question']}" + (("\n   " + T("to start from: {choices}", choices=" | ".join(starts[d["question"]])))
                                            if d["question"] in starts else "")
                for n, d in open_q] if project_mode == "strict" else []
        out += [f"{q['key']}. {q['question']}" for q in open_extra]
        out.append("")
    if proposed:
        out.append(T("## Decisions proposed by the AI (not reviewed yet: implement them as written)") + "\n")
        out += [f"{n}. {p['question']}\n   **{p['answer']}**" for n, p in sorted(proposed.items())]
        out.append("")

    out.append(T("## Must never happen") + "\n")
    tested = {i["id"]: i.get("verified") for i in (report.invariants if report is not None else [])} \
        if status is not None else {}
    own_hazards = [h for h in store.hazards(data) if h.get("component") == component_id]
    shown: set[str] = set()
    for h in own_hazards:
        out.append(f"- **{h['id']}** ({h['severity']}) {h['description']}")
        for inv in [i for i in invariants + system_invariants if h["id"] in (i.get("mitigates") or [])]:
            shown.add(inv["id"])
            out.append(T("  - prevented by **{id}**: {statement}", id=inv["id"], statement=inv["statement"]))
            how = T(EVIDENCE_HOWTO.get(inv.get("verify"), ""), id=inv.get("id"), evidence=inv.get("evidence"),
                    rule=inv.get("rule"))
            mark = "" if inv["id"] not in tested else (" ✔" if tested[inv["id"]] else " ✖")
            out.append(T("  - tested by: {how}", how=how) + mark)
        if not any(h["id"] in (i.get("mitigates") or []) for i in invariants + system_invariants) \
                and h["severity"] in ("critical", "high"):
            out.append(T("  - prevented by nothing yet: do not invent a guard; say so in your answer."))
    for inv in [i for i in invariants + system_invariants if i["id"] not in shown]:
        guarded = ", ".join(f"{h} {hazards[h]['severity']}: {hazards[h]['description']}"
                            for h in inv.get("mitigates", []) if h in hazards)
        how = T(EVIDENCE_HOWTO.get(inv.get("verify"), ""), id=inv.get("id"), evidence=inv.get("evidence"),
                rule=inv.get("rule"))
        scope = "" if inv.get("component") else T(" (system-wide)")
        out.append(f"- **{inv['id']}**{scope}: {inv['statement']}")
        out.append(T("  - prevents: {hazards}", hazards=guarded))
        out.append(T("  - tested by: {how}", how=how))
    words = template.type_of(comp).get("guide_words", []) or []
    answered = store.answered_safety(data)
    texts = template.data.get("guide_words", {}) or {}
    open_numbers = [(n, w) for n, w in enumerate(words, 1) if (component_id, w) not in answered]
    if open_numbers:
        out.append(T("- Safety questions still open (archvow show {id}) - do not invent hazards or "
                     "guards; say in your answer that they are open:", id=component_id))
        out += [f"  S{n}. {situation(texts.get(w, w))}" for n, w in open_numbers]
    elif not own_hazards and not invariants and not system_invariants:
        out.append(T("- Nothing: the safety analysis found nothing this component must guard against."))
    for rule in layer.get("must_never", []) or []:
        out.append(T("- Layer `{layer}`: never {rule}.", layer=comp["layer"], rule=rule))
    out.append("")

    out += _personal_section(T, template, comp, flows.get(component_id, {}))
    out.append(T("## Create exactly") + "\n")
    out.append(T("- File: `{file}` - no other new file except its test.", file=_file_of(container, comp)))
    out.append(T("- Public API (nothing else may be public; helpers start with `_`):"))
    out += [f"  - `{_def_line(s)}`" for s in comp.get("symbols", [])]
    uses = comp.get("uses") or []
    if uses:
        out.append(T("- May use only these components:"))
        out += [f"  - `{by_id[u]['module']}` ({by_id[u]['type']})" for u in uses if u in by_id]
    else:
        out.append(T("- May not import other components (foundations in {layer} excepted).",
                     layer=template.rename_layers("p0_common")))
    users = [c["id"] for ct in data.get("containers", []) for c in ct.get("components", [])
             if component_id in (c.get("uses") or [])]
    if users:  # what a change to it may break: the AI knows before it changes anything
        out.append(T("- Used by: {users} - their tests must stay green.", users=", ".join(f"`{u}`" for u in users)))
    for requirement in template.type_of(comp).get("requirements", []) or []:
        out.append(f"- {requirement.replace('{name}', comp.get('name') or comp['id'])}")  # e.g. the entry point's name
    out.append("")

    header_lines = template.data.get("file_header") or []
    if header_lines:
        out.append(T("## File header") + "\n")
        out.append(T("Start the file with this docstring. Fill in the `<...>` values: the person "
                     "responsible, the AI assistant you are (or `none`), today's date.") + "\n")
        out.append("```python")
        out.append('"""' + T("<One-line summary of what this module does>."))
        out.append("")
        out += header.render(header_lines, data, comp)
        out.append('"""')
        out.append("```")
        out.append("")

    kind = template.type_of(comp).get("test", "none")
    if kind != "none":
        out.append(T("## Tests to write") + "\n")
        out.append(T("- File: `{test}` - required, the build fails without it (ARCH017).",
                     test=store.test_path(comp)))
        explanation = (template.data.get("test_kinds") or {}).get(kind, "")
        out.append(T("- Kind: **{kind}**", kind=kind) + (f" - {explanation}" if explanation else ""))
        if decided or rules_for(data, comp):
            out.append(T("- One test per decision and per rule below, named after it, e.g. "
                         "`test_empty_input_returns_empty_dataframe`, and marked with it: "
                         "`@pytest.mark.decision(3)`, `@pytest.mark.rule(\"R2\")` (ARCH038)."))
        if invariants:
            ids = ", ".join(i["id"] for i in invariants)
            out.append(T("- The test of {ids}, as described under *Must never happen*.", ids=ids))
        for hint in template.type_of(comp).get("test_hints", []) or []:
            out.append(f"- {hint}")
        out.append("")

    answers = [(n, d) for n, d in decided if keys is None or str(n) in keys]
    project_rules = [r for r in rules_for(data, comp) if keys is None or r["id"] in keys]
    if focus is not None:
        out.append(T("## Now: task T{n} of {total}", n=focus.number, total=len(tasks)) + "\n")
        out.append(T("Implement only T{n} ({what}). Keep what the earlier tasks built working; the later "
                     "tasks wait.", n=focus.number, what=summary(focus, lang)) + "\n")
    if project_rules:
        out.append(T("## Rules (implement exactly, one test each)") + "\n")
        out += [f"- **{r['id']}** {r['text']}" + ("" if (r.get("scope") or {}).get("components") == [component_id]
                                                  else f" ({rule_scope(r, lang)})") for r in project_rules]
        out.append("")
    business = [e for e in comp.get("examples") or [] if keys is None or e["name"] in keys]
    if business:
        out += _examples_section(T, template, comp, business, root)
    if answers:
        out.append(T("## Decisions made (implement exactly, do not reinterpret)") + "\n")
        out += [f"{n}. {d['question']}\n   **{d['answer']}**"
                + (T(" (the same for every {type})", type=comp.get("type")) if d.get("origin") == store.TYPE_ORIGIN else "")
                for n, d in answers]
        out.append("")
    answered_extra = [q for q in extra if q["answer"] and (keys is None or q["key"] in keys)]
    if answered_extra:
        out.append(T("## Decisions made for personal data and operations (implement exactly)") + "\n")
        out += [f"{q['key']}. {q['question']}\n   **{q['answer']}**" for q in answered_extra]
        out.append("")
    if accepted or rejected:
        out.append(T("## Reviewed assumptions") + "\n")
        out += [T("- accepted: {text}", text=a["text"]) for a in accepted]
        out += [T("- REJECTED (do not rely on it): {text}", text=a["text"]) for a in rejected]
        out.append("")

    out.append(T("## Assumptions") + "\n")
    out.append(T("Anything this spec does not define is not yours to decide. Ask before coding. If you "
                 "still had to assume something, list it in your answer and record it with "
                 "`archvow assumption add {id} \"<assumption>\"`. Until a person accepts or rejects it, CI fails "
                 "(ARCH034).", id=component_id) + "\n")

    out.append(T("## Definition of done") + "\n")
    out.append(T("- `archvow check` reports no errors for this component."))
    if "families" not in shared:
        shared["families"] = rule_family_names(root, data)
    families = shared["families"]
    if families:
        out.append(T("- Checks on this code: {families} - what each one checks: `archvow doc` (Checks).",
                     families=", ".join(families)))
    out.append(T("- `ruff format .` run, then `ruff check .` and `pytest` pass."))
    out.append(T("- Every invariant above is tested."))
    if users:
        out.append(T("- The tests of the components that use it still pass."))
    if comp.get("examples"):
        out.append(T("- Every example above has its marked test, and its files are the ones recorded."))
    out.append(T("- You did not edit `.archvow/`, `AGENTS.md`, `ruff.toml`, CI files or other "
                 "components' tests, and added no `# noqa` / `# type: ignore` / suppressions."))
    out.append(T("- Working code that breaks these rules is not done."))
    return "\n".join(out) + "\n"


def _examples_section(T, template, comp: dict, business: list[dict], root: Path | None = None) -> list[str]:
    """The business examples: the files to read and compare (small ones printed, by kind), the rule each one
    shows, the mark of each test; the test writes actual/ and decides pass or fail."""
    integration = level(template, comp) == "integration"
    out = [T("## Examples (reproduce exactly)") + "\n",
           T("Given by the business team. For each one, a test reads `input/`, runs the component and compares what it "
             "gives with `expected/`. Never change these files: archvow compares them with the ones a person recorded "
             "(ARCH055); an example that looks wrong is a question for a person.") + "\n",
           T("The test also writes what the component gave to `{actual}/`, with the same file names and format as "
             "`expected/` (not locked, not committed): people see where it differs. Open every file with "
             "`encoding=\"utf-8\"` (and `newline=\"\"` for CSV) and compare what you read (rows, JSON objects), not "
             "bytes. Write each example's test before the code it checks: it fails until the code exists, and is "
             "never changed to pass.", actual=ACTUAL) + "\n"]
    for e in business:
        mark = f'@pytest.mark.example("{e["name"]}")' + (" @pytest.mark.integration" if integration else "")
        ticket = f" ({e['ticket']})" if e.get("ticket") else ""
        rule = T(" - rule {rule}", rule=e["rule"]) if e.get("rule") else ""
        rel = folder(comp["id"], e["name"])
        out.append(f"- **{e['name']}**{ticket}{rule}: `{rel}/` - " + T("its test is marked {mark}", mark=f"`{mark}`"))
        scenario = scenario_text(root, rel) if root is not None else None
        if scenario:  # the business team's words for it: what the rows mean
            out.append("\n  ```gherkin\n" + "\n".join("  " + line for line in scenario.splitlines()) + "\n  ```")
        if root is not None:
            found = files_of(root, rel)
            for part in PARTS:
                for path in found[part]:
                    shown = card_file(path)
                    name = path.relative_to(root / rel).as_posix()
                    if shown is None:
                        out.append(f"\n  `{name}`: " + T("too big to print here - read the file"))
                        continue
                    out.append(f"\n  `{name}`\n\n" + "\n".join("  " + line for line in shown))
    out.append("")
    return out


def _personal_section(T, template, comp: dict, flow: dict) -> list[str]:
    """The card's personal-data section: the columns and their class, or the personal columns the
    component handles, writes, removes or pseudonymises, and what the code must never do with them."""
    ctype = template.type_of(comp)
    out: list[str] = []
    columns = comp.get("columns") or {}
    if ctype.get("columns") and columns:
        out.append(T("## Personal data") + "\n")
        out.append(T("Columns and their class (personal data). Define exactly these; a new column is classified "
                     "first (`archvow column set`), or the build fails (PRIV001):"))
        out += [f"- `{name}`: {kind}" for name, kind in columns.items()]
    elif flow.get("handles"):
        out.append(T("## Personal data") + "\n")
        out.append(T("Personal columns it handles: {columns}.", columns=", ".join(
            f"`{n}` ({k})" for n, k in flow["handles"].items())))
        out.append(T("- Never show, print or log their values, nor collected rows (PRIV002): log counts."))
        out.append(T("- Never partition or bucket files by them (PRIV004)."))
        if flow.get("writes"):
            out.append(T("- It writes: {columns}.", columns=", ".join(f"`{n}`" for n in flow["writes"])))
        if flow.get("pseudonymised"):
            out.append(T("- Pseudonymised before it: {columns}.", columns=", ".join(flow["pseudonymised"])))
        privacy = comp.get("privacy") or {}
        if privacy.get("removes"):
            out.append(T("- It removes: {columns} (they must not leave it).", columns=", ".join(privacy["removes"])))
        if privacy.get("pseudonymises"):
            out.append(T("- It pseudonymises or encrypts: {columns} (test it).",
                         columns=", ".join(privacy["pseudonymises"])))
    if out:
        out.append("")
    return out










CLARIFY = """\
Read the spec below, the brief it is drawn from (its **Source**, when it has one) and the specs of \
the components it uses and that use it. List the cases it does not define: unclear inputs, edge cases, \
error handling, ordering, dates, re-runs, performance limits, data volumes, anything two developers \
could implement differently. At most {max}, the riskiest first (what changes the data or the results).

Rules:
- Do **not** propose answers or defaults. Only questions; humans decide.
- Do not repeat questions already listed (answered or open) in the spec.
- Record each question yourself, with what leaves it open in a few words:

    archvow question add {id} "<question>" --why "<what in the spec or the brief leaves it open>"

Each one is marked as added by the AI: a person answers it (`archvow decision make {id} <n> "<answer>"`), \
keeps it to answer later (`archvow question accept {id} <n>`) or removes it. Until it is answered, it \
blocks the implementation."""


def render_clarify(root: Path, component_id: str, most: int = 5) -> str:
    """A task asking the AI to find ambiguities - at most `most`, the riskiest first - and to answer none."""
    data = store.load(root)
    find_component(data, component_id)
    card = render_prompt(root, component_id, include_status=False)
    lang = data.get("language") or "en"
    return (
        tr(lang, "# Task: find what is ambiguous in the spec of `{id}` - do not write code", id=component_id)
        + "\n\n" + tr(lang, CLARIFY, id=component_id, max=most) + "\n\n"
        "---\n\n" + card
    )
