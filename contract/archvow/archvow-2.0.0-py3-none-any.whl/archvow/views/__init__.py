"""What archvow writes for people and agents (layer 3): a component's task (component_doc.py), the docs
(project_doc.py, feature_doc.py), the build plan (plan.py), the run line, a finding's guide (guidance.py), the search, a file's
place (locate.py), the release report (changes.py), the spec diff, the audit, the doctor. Imports layers 0-2.
"""
