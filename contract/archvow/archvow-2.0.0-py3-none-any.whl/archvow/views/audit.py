"""`archvow audit`: who took each human decision, when, and in which commit.

Every decision, assumption review, hazard and invariant carries `by` / `on` (written by the
archvow command that recorded it). The audit cross-checks them with Git: the commit that
introduced the record and its author. A record nobody committed, or committed by someone else
than who recorded it (for example an AI agent's account), is flagged for review.
"""

from __future__ import annotations

from pathlib import Path

from archvow.foundation import logs
from archvow.foundation.errors import GitError
from archvow.foundation.git import git
from archvow.foundation.paths import FEATURES_REL
from archvow.model import store

log = logs.get("audit")

# the vows: a decision keeps the commit that first recorded it
SPEC_PATHS = (store.PROJECT_REL.as_posix(), FEATURES_REL.as_posix())
SEP = "\x1f"


def _commit_of(root: Path, token: str) -> dict | None:
    """First commit that added `token` to the spec (a vow)."""
    if not token:
        return None
    try:
        out = git(root, "log", "--reverse", f"--format=%h{SEP}%an{SEP}%ae{SEP}%aI{SEP}%s",
                   f"-S{token}", "--", *SPEC_PATHS)
    except GitError:
        logs.swallowed(log, "_commit_of: GitError")
        return None
    line = next((li for li in out.splitlines() if li.strip()), "")
    if not line:
        return None
    sha, name, email, date, subject = line.split(SEP, 4)
    return {"commit": sha, "author": name, "email": email, "date": date, "subject": subject}


def _entry(root: Path, kind: str, ref: str, text: str, by: str | None, on: str | None) -> dict:
    commit = _commit_of(root, on or "")
    flags = []
    if not by:
        flags.append("no record of who decided (edited by hand or recorded before audit support)")
    elif commit is None:
        flags.append("not committed yet")
    elif by not in (commit["email"], commit["author"]):
        flags.append(f"recorded by {by} but committed by {commit['email']}")
    return {"kind": kind, "ref": ref, "text": text, "by": by, "on": on, "commit": commit,
            "flags": flags}


def run_audit(root: Path) -> list[dict]:
    data = store.load(root)
    rows: list[dict] = []
    for container in data.get("containers", []):
        for comp in container.get("components", []):
            for n, d in enumerate(comp.get("decisions", []) or [], 1):
                if (d.get("answer") or "").strip():
                    rows.append(_entry(root, "decision", f"{comp['id']} #{n}",
                                       f"{d['question']} -> {d['answer']}", d.get("by"), d.get("on")))
            for n, a in enumerate(comp.get("assumptions", []) or [], 1):
                rows.append(_entry(root, "assumption", f"{comp['id']} #{n}", a.get("text", ""),
                                   a.get("by"), a.get("on")))
                if a.get("status") in ("accepted", "rejected"):
                    rows.append(_entry(root, f"assumption {a['status']}", f"{comp['id']} #{n}",
                                       a.get("text", ""), a.get("reviewed_by"), a.get("reviewed_on")))
    for h in data.get("hazards", []) or []:
        rows.append(_entry(root, f"hazard {h.get('severity')}", h.get("id", "?"), h.get("description") or "",
                           h.get("by"), h.get("on")))
    for d in data.get("dismissed") or []:
        rows.append(_entry(root, "not applicable", f"{d.get('component') or 'system'} {d.get('guide_word')}",
                           d.get("rationale", ""), d.get("by"), d.get("on")))
    for i in data.get("invariants", []) or []:
        rows.append(_entry(root, f"invariant ({i.get('verify')})", i.get("id", "?"),
                           i.get("statement", ""), i.get("by"), i.get("on")))
    return rows


def render_audit(rows: list[dict]) -> str:
    if not rows:
        return "Nothing to audit yet: no decisions, assumptions, hazards or invariants recorded."
    lines = []
    for r in rows:
        commit = r["commit"]
        where = f"{commit['commit']} \"{commit['subject']}\"" if commit else "not committed"
        lines.append(f"{r['kind']} {r['ref']} - by {r['by'] or '?'} on {(r['on'] or '?')[:10]} - {where}")
        lines.append(f"    {r['text']}")
        lines += [f"    ! {flag}" for flag in r["flags"]]
    flagged = sum(1 for r in rows if r["flags"])
    lines.append(f"\n{len(rows)} record(s), {flagged} flagged.")
    return "\n".join(lines)
