"""Templates: found in the packs, inheritance (`extends`) and file overlay.

A template is a folder `templates/<name>/` of a pack (packs/store.py) holding `template.yaml` plus an optional
`files/` folder (the project skeleton). Its full name is `<pack>/<name>` (archvow/pyspark-pipeline,
acme/acme-pyspark): the short name is enough when one pack only has it. The packs are archvow's own and the
project's copies (.archvow/packs/); a template of one pack may extend a template of another.

Languages: a pack may translate what it generates. `template.<lang>.yaml` overrides the texts
of `template.yaml` (questions asked by each component type, guide words, layer rules...) and
`files-<lang>/` overrides files of `files/`. A project uses one language (manifest `language`,
English when absent); everything not translated falls back to the pack's own text.
"""

from __future__ import annotations

import copy
import keyword
import re
from dataclasses import dataclass, field
from pathlib import Path

import yaml

from archvow import __version__, agents
from archvow.foundation import logs, once
from archvow.foundation.errors import TemplateError
from archvow.foundation.files import parse_yaml
from archvow.foundation.i18n import DEFAULT_LANGUAGE
from archvow.foundation.paths import PROJECT_REL
from archvow.model import vowfile
from archvow.packs import regimes
from archvow.packs import store as packs
from archvow.packs.regimes import Regime

log = logs.get("templates")



def edge_case_text(item: object) -> str:
    """A question of a component type: a string, or {question, suggested}."""
    return str(item["question"]) if isinstance(item, dict) else str(item)


def edge_case_suggestion(item: object) -> str | None:
    """The template's suggested answer to a question, when it gives one."""
    return str(item["suggested"]) if isinstance(item, dict) and item.get("suggested") else None


def edge_case_choices(item: object) -> list[str]:
    """The answers a question offers to start from, when it has no safe default (none pre-selected)."""
    return [str(c) for c in item.get("choices") or []] if isinstance(item, dict) else []


@dataclass
class Template:
    """A fully resolved template (inheritance and language already applied)."""

    name: str
    data: dict
    dirs: list[Path] = field(default_factory=list)  # base template first, child last
    language: str = DEFAULT_LANGUAGE
    pack: str = "archvow"  # the pack it comes from
    agent_names: tuple[str, ...] = ()  # the agents the project's packs describe (`ai_tools` offers them)
    regimes: tuple[Regime, ...] = ()  # the privacy regimes the project's packs hold (`rules` offers them)

    @property
    def version(self) -> str:
        return str(self.data.get("version", "0.0.0"))

    @property
    def qualified(self) -> str:
        """`<pack>/<name>`: how project.vow, `catalog` and `init` name it."""
        return f"{self.pack}/{self.name}"

    @property
    def ref(self) -> str:
        return f"{self.qualified}@{self.version}"

    @property
    def layers(self) -> list[dict]:
        return self.data.get("layers", [])

    def rename_layers(self, text: str) -> str:
        """A text of the template's files with the layers' folders the template names (`layer_names`)."""
        return _rename_words(text, _renames(self.data))

    def layer(self, name: str) -> dict | None:
        return next((layer for layer in self.layers if layer["name"] == name), None)

    @property
    def layer_names(self) -> list[str]:
        return [layer["name"] for layer in self.layers]

    @property
    def component_types(self) -> dict:
        return self.data.get("component_types", {})

    def kinds(self, type_name: str) -> list[str]:
        """The kinds a component type offers (`kinds:`, e.g. a reader: files, table, jdbc...), default first."""
        ctype = self.component_types.get(type_name) or {}
        names = list(ctype.get("kinds") or {})
        default = ctype.get("default_kind")
        return [default, *[n for n in names if n != default]] if default in names else names

    def type_of(self, comp: dict) -> dict:
        """A component's type as it applies to it: the type, with its kind's own description,
        symbols, questions, safety questions and hints over it (a reader of kind jdbc...)."""
        ctype = dict(self.component_types.get(comp.get("type")) or {})
        kinds = ctype.pop("kinds", None) or {}
        kind = comp.get("kind") or ctype.get("default_kind")
        ctype.pop("default_kind", None)
        if kind not in kinds:
            return ctype
        own = kinds.get(kind) or {}
        merged = merge(ctype, own)
        if "safety_decisions" in own:  # numbers point to the kind's own questions: never mixed
            merged["safety_decisions"] = dict(own["safety_decisions"] or {})
        return merged

    @property
    def rules(self) -> dict:
        return self.data.get("rules", {})

    def suggested_answers(self, comp: dict) -> dict[str, str]:
        """{question: suggested answer} for a component: its type's questions, or a starting component's."""
        initial = next((c for c in self.data.get("initial_components", []) or [] if c.get("id") == comp.get("id")),
                       None)
        source = initial if initial is not None else self.type_of(comp)
        return {edge_case_text(q): s for q in source.get("edge_cases") or [] if (s := edge_case_suggestion(q))}

    def choices(self, comp: dict) -> dict[str, list[str]]:
        """{question: [answers to start from]} for a component's questions that have no default."""
        initial = next((c for c in self.data.get("initial_components", []) or [] if c.get("id") == comp.get("id")),
                       None)
        source = initial if initial is not None else self.type_of(comp)
        return {edge_case_text(q): c for q in source.get("edge_cases") or [] if (c := edge_case_choices(q))}

    def find(self, rel: str) -> Path:
        """Find a pack file, the most specific (child) pack winning."""
        for directory in reversed(self.dirs):
            candidate = directory / rel
            if candidate.is_file():
                return candidate
        raise TemplateError(f"{self.name}: file '{rel}' not found in pack(s)")

    def skeleton_files(self) -> dict[str, Path]:
        """Relative path -> source path for the project skeleton (child overrides base)."""
        result: dict[str, Path] = {}
        folders = ["files"] if self.language == DEFAULT_LANGUAGE else ["files", f"files-{self.language}"]
        for directory in self.dirs:
            for folder in folders:  # a translated file replaces the original of the same pack
                root = directory / folder
                if not root.is_dir():
                    continue
                for path in sorted(root.rglob("*")):
                    if path.is_file():
                        result[path.relative_to(root).as_posix()] = path
        return result

    def _question_summary(self, question: dict) -> dict:
        """Questions as the IDE wizard needs them: choices resolved, flags explicit."""
        result = dict(question)
        override = (self.data.get("questions_defaults") or {}).get(question.get("id"))
        if override is not None:
            result["default"] = override
        elif question.get("choices_from") == "rule_families" and question.get("default") is None:
            result["default"] = ",".join(self.recommended_families())
        source = question.get("choices_from")
        if source == "rule_families":
            result["choices"] = [*self.selectable_families(), "all", "none"]
        elif source == "agents":  # any agent's name; the agents the packs describe are offered
            result["suggestions"] = [*self.agent_names, "none"]
        result.setdefault("required", False)
        result.setdefault("multiple", False)
        return result

    def _families(self) -> list[tuple[str, dict]]:
        """(name, entry) of every rule family, once per name (its regimes' included)."""
        found: dict[str, dict] = {}
        for prefix, entry in (self.data.get("rule_families") or {}).items():
            found.setdefault(str((entry or {}).get("name") or prefix).upper(), entry or {})
        return list(found.items())

    @property
    def COMPLIANCE(self) -> tuple[str, ...]:
        """The families that bring questions, registers or views and are kept as `compliance` in project.vow (TST,
        the regimes: DORA, GDPR...): `compliance: true` in `rule_families`."""
        return tuple(name for name, entry in self._families() if entry.get("compliance"))

    def selectable_families(self) -> list[str]:
        """The rule families the `rules` answer chooses from, by name, in the project doc's reading order: the code families
        (ARCH, STYLE, SPARK...), the regimes (DORA, GDPR, GLBA, US-PRIVACY...), then TST. PRIV is not chosen: it
        is on with any privacy regime."""
        entries = [(name, entry) for name, entry in self._families() if not entry.get("automatic")]
        code = [n for n, e in entries if not e.get("compliance")]
        regimes = [n for n, e in entries if e.get("regime")]
        return code + regimes + [n for n, e in entries if e.get("compliance") and not e.get("regime")]

    def family_title(self, name: str) -> str:
        return next((str((v or {}).get("title") or "") for k, v in (self.data.get("rule_families") or {}).items()
                     if str((v or {}).get("name") or k).upper() == name), "")

    def recommended_families(self) -> list[str]:
        """The `rules` default: every family but those marked `default: false` (DORA, for banks and insurers; the
        US regimes)."""
        entries = dict(self._families())
        return [n for n in self.selectable_families() if entries.get(n, {}).get("default", True)]

    def summary(self) -> dict:
        """JSON-friendly description, used by `catalog --json` (IDE wizard)."""
        return {
            "name": self.qualified,
            "pack": self.pack,
            "version": self.version,
            "language": self.data.get("language"),
            "kind": self.data.get("kind"),
            "style": self.data.get("style"),
            "description": self.data.get("description", ""),
            "extends": self.data.get("_extends_chain", []),
            "questions": [self._question_summary(q) for q in self.data.get("questions", [])],
            "layers": [
                {"name": layer["name"], "description": layer.get("description", ""),
                 "may_import": layer.get("may_import", [])}
                for layer in self.layers
            ],
            "component_types": {
                key: {
                    "layer": value.get("layer"),
                    "description": value.get("description", ""),
                    "addable": value.get("addable", True),
                    "name_pattern": value.get("name_pattern"),
                    "name_hint": value.get("name_hint", ""),
                    "module": value.get("module"),
                    "symbols": value.get("symbols", []),
                    "implicit_dependency": bool(value.get("implicit_dependency", False)),
                    "signature_overridable": bool(value.get("signature_overridable", False)),
                    "kinds": self._kinds_summary(key),
                }
                for key, value in self.component_types.items()
            },
            "source": str(self.dirs[-1]) if self.dirs else None,
        }


    def _kinds_summary(self, type_name: str) -> list[dict]:
        """`component add <type> <name> -k <kind>`: each kind with what it is, the default one first (an IDE
        offers them in a list). The default kind's own description, else the type's."""
        ctype = self.component_types.get(type_name) or {}
        declared = ctype.get("kinds") or {}
        default = ctype.get("default_kind")
        return [{"name": kind, "description": str((declared.get(kind) or {}).get("description")
                                                  or (ctype.get("description", "") if kind == default else "")),
                 "default": kind == default}
                for kind in self.kinds(type_name)]


def discover(project_root: Path | None, extra: tuple[Path, ...] = ()) -> dict[str, Path]:
    """`<pack>/<template>` -> its folder, in every pack the project can use (archvow's, then its copies; `extra`: a
    pack being written or checked)."""
    return dict(once.remember(("templates", str(project_root), extra), lambda: _discover(project_root, extra)))


def _discover(project_root: Path | None, extra: tuple[Path, ...]) -> dict[str, Path]:
    found: dict[str, Path] = {}
    for pack in packs.all_packs(project_root, extra):
        for manifest in sorted(pack.templates.glob("*/template.yaml")):
            found[f"{pack.name}/{manifest.parent.name}"] = manifest.parent
    return found


def resolve(name: str, project_root: Path | None, pack: str | None = None, extra: tuple[Path, ...] = ()) -> str:
    """The full name of a template given as `<pack>/<template>` or by its short name: the short name of a
    template that one pack only has; inside a pack (`extends`), that pack's own first."""
    found = discover(project_root, extra)
    if "/" in name:
        if name not in found:
            raise TemplateError(f"unknown template '{name}' (available: {', '.join(sorted(found)) or 'none'})")
        return name
    if pack is not None and f"{pack}/{name}" in found:
        return f"{pack}/{name}"
    matches = sorted(q for q in found if q.split("/", 1)[1] == name)
    if not matches:
        raise TemplateError(f"unknown template '{name}' (available: {', '.join(sorted(found)) or 'none'})")
    if len(matches) > 1:
        raise TemplateError(f"template '{name}' is in several packs: {', '.join(matches)}",
                            hint="name it with its pack: archvow init <package> -t <pack>/<template>")
    return matches[0]


def project_language(project_root: Path | None) -> str:
    """The language of the project in `project_root` (English when it names none, or no project)."""
    if project_root is None:
        return DEFAULT_LANGUAGE
    path = project_root / PROJECT_REL
    try:
        stamp = path.stat().st_mtime_ns
    except OSError:
        logs.swallowed(log, "project_language: OSError")
        return DEFAULT_LANGUAGE
    cached = _LANGUAGE_CACHE.get(path)
    if cached is None or cached[0] != stamp:
        try:
            text = path.read_text(encoding="utf-8")
            data = vowfile.loads(text, path.name)[2]
        except (vowfile.VowError, OSError):
            logs.swallowed(log, "project_language: vowfile.VowError, OSError")
            data = {}
        language = data.get("language") if isinstance(data, dict) else None
        cached = (stamp, str(language or DEFAULT_LANGUAGE))
        _LANGUAGE_CACHE[path] = cached
    return cached[1]


_LANGUAGE_CACHE: dict[Path, tuple[int, str]] = {}


def load_template(name: str, project_root: Path | None, _chain: tuple[str, ...] = (),
                  language: str | None = None, extra: tuple[Path, ...] = ()) -> Template:
    """Load a pack by name, resolve its `extends` chain, in the project's language.

    `language` defaults to the language of the project in `project_root` (English if none). Built once per
    reading command (foundation/once.py); the template is shared then: never changed by a caller.
    """
    if language is None:
        language = project_language(project_root)
    key = ("template", name, str(project_root), _chain, language, extra)
    return once.remember(key, lambda: _load_template(name, project_root, _chain, language, extra))


def _load_template(name: str, project_root: Path | None, _chain: tuple[str, ...], language: str,
                   extra: tuple[Path, ...]) -> Template:
    qualified = resolve(name, project_root, _chain[-1].split("/", 1)[0] if _chain else None, extra)
    if qualified in _chain:
        raise TemplateError(f"template inheritance cycle: {' -> '.join((*_chain, qualified))}")
    pack, short = qualified.split("/", 1)
    directory = discover(project_root, extra)[qualified]
    raw = _read_yaml(directory / "template.yaml")
    if pack == "archvow":  # archvow's own templates carry archvow's version (one source)
        raw["version"] = __version__
    translated = directory / f"template.{language}.yaml"
    if language != DEFAULT_LANGUAGE and translated.is_file():
        raw = merge(raw, _read_yaml(translated))
    raw["name"] = short
    parent_name = raw.pop("extends", None)
    if not parent_name:
        raw["_extends_chain"] = []
        if _chain:
            return Template(name=short, data=raw, dirs=[directory], language=language, pack=pack)
        return _with_regimes(Template(name=short, data=_apply_layer_names(short, raw), dirs=[directory],
                                      language=language, pack=pack), project_root, extra)
    parent = load_template(str(parent_name), project_root, (*_chain, qualified), language=language, extra=extra)
    merged = merge(parent.data, raw)
    merged["abstract"] = bool(raw.get("abstract", False))  # a base is abstract, what extends it is not
    merged["_extends_chain"] = [parent.qualified, *parent.data.get("_extends_chain", [])]
    if not _chain:  # the template asked for: its layers get the folders it names, everywhere
        merged = _apply_layer_names(short, merged)
    found = Template(name=short, data=merged, dirs=[*parent.dirs, directory], language=language, pack=pack,
                     agent_names=tuple(sorted(agents.profiles(project_root))) if not _chain else ())
    return found if _chain else _with_regimes(found, project_root, extra)


def _with_regimes(template: Template, project_root: Path | None, extra: tuple[Path, ...]) -> Template:
    """The template with the regimes of the project's packs: each one a compliance rule family (its prefix -> name,
    title, `rule_set`), so the `rules` answer offers it and the check switches its codes."""
    found = tuple(regimes.available(project_root, template.language, extra).values())
    families = dict(template.data.get("rule_families") or {})
    for regime in found:
        families[regime.prefix] = regime.family()
    template.data["rule_families"] = families
    template.regimes = found
    return template


def _renames(data: dict) -> dict[str, str]:
    """`layer_names`, the layer -> folder pairs that change something (built-in name -> new name)."""
    return {old: new for old, new in (data.get("layer_names") or {}).items() if old != new}


def _rename_words(value: object, renames: dict[str, str]) -> object:
    """Every layer name in a value (a text, or the strings of a list or mapping) replaced as a whole
    word: p2_io in "p2_io components" or "{{ package }}.p2_io.reader", never inside another name."""
    if not renames:
        return value
    if isinstance(value, str):
        pattern = re.compile(r"(?<![A-Za-z0-9_])(" + "|".join(map(re.escape, renames)) + r")(?![A-Za-z0-9_])")
        return pattern.sub(lambda m: renames[m.group(1)], value)
    if isinstance(value, list):
        return [_rename_words(item, renames) for item in value]
    if isinstance(value, dict):
        return {_rename_words(k, renames): _rename_words(v, renames) for k, v in value.items()}
    return value


LAYER_FOLDER_RE = re.compile(r"^[a-z_][a-z0-9_]*$")


def check_layer_names(template_name: str, layers: list[str], names: dict) -> None:
    """`layer_names` maps existing layers to folders: valid package names, all different."""
    if not isinstance(names, dict):
        raise TemplateError(f"template '{template_name}': layer_names must map a layer to its folder")
    unknown = [old for old in names if old not in layers]
    if unknown:
        raise TemplateError(f"template '{template_name}': layer_names: unknown layer(s) {', '.join(unknown)} "
                            f"(the layers are {', '.join(layers)})")
    bad = [str(new) for new in names.values()
           if not LAYER_FOLDER_RE.match(str(new)) or keyword.iskeyword(str(new))]
    if bad:
        raise TemplateError(f"template '{template_name}': layer_names: {', '.join(bad)} - a folder name is "
                            "a Python package name: lower case, digits and _, not a keyword")
    folders = [names.get(layer, layer) for layer in layers]
    twice = sorted({f for f in folders if folders.count(f) > 1})
    if twice:
        raise TemplateError(f"template '{template_name}': layer_names: {', '.join(twice)} given to two layers")


def _apply_layer_names(template_name: str, data: dict) -> dict:
    names = data.get("layer_names") or {}
    check_layer_names(template_name, [layer["name"] for layer in data.get("layers", [])], names)
    renames = _renames(data)
    if not renames:
        return data
    renamed = {key: (value if key == "layer_names" else _rename_words(value, renames)) for key, value in data.items()}
    renamed["layer_names"] = dict(names)  # kept as written: the built-in name -> its folder (for the files)
    return renamed


def merge(base: dict, child: dict) -> dict:
    """Deep-merge a child template over its parent.

    Dicts merge recursively; `layers` merge by name, `questions` and `initial_components` by id
    (new entries are appended); `allowed_paths`, `executable_files` and `answer_rules` add to the parent's; any other value from the
    child replaces the parent's.
    """
    result = copy.deepcopy(base)
    for key, value in child.items():
        if key in ADDITIVE_LISTS and isinstance(value, list):
            kept = list(result.get(key) or [])
            result[key] = kept + [copy.deepcopy(v) for v in value if v not in kept]
        elif key in NAMED_LISTS and isinstance(value, list):
            result[key] = _merge_layers(result.get(key, []), value, NAMED_LISTS[key])
        elif isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = merge(result[key], value)
        else:
            result[key] = copy.deepcopy(value)
    return result


NAMED_LISTS = {"layers": "name", "questions": "id", "initial_components": "id"}
ADDITIVE_LISTS = {"allowed_paths", "executable_files", "answer_rules"}  # a child adds to the base's list, never loses it


def _merge_layers(base: list[dict], child: list[dict], key: str = "name") -> list[dict]:
    items = [copy.deepcopy(item) for item in base]
    index = {item[key]: i for i, item in enumerate(items)}
    for item in child:
        if item[key] in index:
            items[index[item[key]]] = merge(items[index[item[key]]], item)
        else:
            items.append(copy.deepcopy(item))
    return items


def _read_yaml(path: Path) -> dict:
    try:
        data = parse_yaml(path.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError as exc:
        raise TemplateError(f"{path}: invalid YAML: {exc}") from exc
    if not isinstance(data, dict):
        raise TemplateError(f"{path}: expected a mapping at top level")
    return data


def templates_of(root: Path, data: dict) -> dict[str, Template]:
    """Container id -> its template (containers whose template cannot load are left out)."""
    found = {}
    for container in data.get("containers", []):
        try:
            found[container["id"]] = load_template(template_name(container)[0], root)
        except TemplateError:
            logs.swallowed(log, "templates_of: TemplateError")
            continue
    return found


def template_name(container_data: dict) -> tuple[str, str | None]:
    """Split 'name@version' into (name, version)."""
    ref = container_data["template"]
    name, _, version = ref.partition("@")
    return name, version or None
