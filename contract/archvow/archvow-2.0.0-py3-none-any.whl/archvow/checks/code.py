"""Reading Python code (layer 2): what the checks of every family need to understand a file - signatures, the
symbols a file defines and whether they are still placeholders, routes, method chains, import targets. Pure
functions of the `ast` tree; no rule lives here.
"""

from __future__ import annotations

import ast

HTTP_METHODS = {"get": "GET", "post": "POST", "put": "PUT", "patch": "PATCH", "delete": "DELETE"}
OPEN_CALLS = {"open", "builtins.open", "io.open"}  # file I/O (SPK001) that also blocks (FAPI001)


def canonical_signature(signature: str) -> str:
    tree = ast.parse(f"def _f{signature}:\n    pass\n")
    return render_signature(tree.body[0])


def render_signature(node: ast.FunctionDef | ast.AsyncFunctionDef) -> str:
    text = f"({ast.unparse(node.args)})"
    if node.returns is not None:
        text += f" -> {ast.unparse(node.returns)}"
    return text


def canonical_expr(text: str) -> str:
    return ast.unparse(ast.parse(text, mode="eval").body)


def receiver_name(node: ast.expr) -> str | None:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return node.attr
    return None


def chain(call: ast.Call) -> tuple[list[ast.Call], ast.expr]:
    """Return the calls of a fluent chain (outermost first) and its root expression."""
    calls: list[ast.Call] = []
    node: ast.expr = call
    while isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
        calls.append(node)
        node = node.func.value
    return calls, node


def _is_stub_body(body: list[ast.stmt]) -> bool:
    """A body that only holds the place: a docstring, `pass`, `...` or `raise NotImplementedError`."""
    statements = [s for s in body if not isinstance(s, ast.Pass)
                  and not (isinstance(s, ast.Expr) and isinstance(s.value, ast.Constant))]
    if not statements:
        return True
    if len(statements) != 1 or not isinstance(statements[0], ast.Raise):
        return False
    exc = statements[0].exc
    target = exc.func if isinstance(exc, ast.Call) else exc
    return isinstance(target, ast.Name) and target.id == "NotImplementedError"


# An empty exception class is complete (`class OrderNotFoundError(Exception): pass`).
_EXCEPTION_SUFFIXES = ("Error", "Exception", "Warning")


def _is_exception_class(node: ast.ClassDef) -> bool:
    for base in node.bases:
        name = base.attr if isinstance(base, ast.Attribute) else getattr(base, "id", "")
        if name.endswith(_EXCEPTION_SUFFIXES):
            return True
    return node.name.endswith(_EXCEPTION_SUFFIXES)


def _constant_is_stub(value: ast.expr | None) -> bool:
    if not isinstance(value, ast.Call) or len(value.args) != 1:
        return False
    arg = value.args[0]
    return isinstance(arg, ast.List) and not arg.elts


def root_name(node: ast.expr) -> str | None:
    while isinstance(node, (ast.Attribute, ast.Call, ast.Subscript)):
        node = node.func if isinstance(node, ast.Call) else node.value
    return node.id if isinstance(node, ast.Name) else None


def body_length(node: ast.FunctionDef | ast.AsyncFunctionDef) -> int:
    """Lines of a function's body, without its signature and docstring (STY002)."""
    body = node.body
    if (body and isinstance(body[0], ast.Expr) and isinstance(body[0].value, ast.Constant)
            and isinstance(body[0].value.value, str)):
        body = body[1:]
    if not body:
        return 0
    return (node.end_lineno or node.lineno) - body[0].lineno + 1


def module_logger(node: ast.stmt) -> bool:
    """`logger = logging.getLogger(__name__)`: the module's own logger (ARCH059), never a declared symbol."""
    if not (isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)):
        return False
    value = node.value
    return (isinstance(value, ast.Call) and ast.unparse(value.func) in ("logging.getLogger", "getLogger")
            and len(value.args) == 1 and not value.keywords and ast.unparse(value.args[0]) == "__name__")


def defined_names(node: ast.stmt) -> list[str]:
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
        return [node.name]
    if isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
        return [node.target.id]
    if isinstance(node, ast.Assign):
        names = [t.id for t in node.targets if isinstance(t, ast.Name)]
        return [n for n in names if not (n.startswith("__") and n.endswith("__"))]
    return []


def symbol_status(node: ast.stmt) -> str:
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        return "planned" if _is_stub_body(node.body) else "implemented"
    if isinstance(node, ast.ClassDef):
        empty = _is_stub_body(node.body) and not _is_exception_class(node)
        return "planned" if empty else "implemented"
    if isinstance(node, (ast.AnnAssign, ast.Assign)):
        return "planned" if _constant_is_stub(node.value) else "implemented"
    return "implemented"


def resolve_from(node: ast.ImportFrom, current_pkg: str) -> str:
    if not node.level:
        return node.module or ""
    parts = current_pkg.split(".")
    base = parts[: len(parts) - (node.level - 1)] if node.level > 1 else parts
    return ".".join([*base, node.module] if node.module else base)


def route_of(node: ast.stmt) -> tuple[str, str] | None:
    """(METHOD, path) of a function decorated with @<router>.<method>("<path>", ...), else None."""
    if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        return None
    for deco in node.decorator_list:
        if (isinstance(deco, ast.Call) and isinstance(deco.func, ast.Attribute)
                and deco.func.attr in HTTP_METHODS and deco.args
                and isinstance(deco.args[0], ast.Constant) and isinstance(deco.args[0].value, str)):
            return HTTP_METHODS[deco.func.attr], deco.args[0].value
    return None


def symbols_of_file(source: str) -> list[dict]:
    """The public contract a file has today, as spec symbols (adopting an existing module): its
    functions with their signatures, classes, constants and every route."""
    tree = ast.parse(source)
    symbols: list[dict] = []
    for node in tree.body:
        route = route_of(node)
        if route is not None:
            symbols.append({"kind": "route", "name": node.name, "method": route[0], "path": route[1]})  # type: ignore[union-attr]
            continue
        for name in defined_names(node):
            if name.startswith("_"):
                continue
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                symbols.append({"kind": "function", "name": name, "signature": render_signature(node)})
            elif isinstance(node, ast.ClassDef):
                symbols.append({"kind": "class", "name": name})
            else:
                symbols.append({"kind": "constant", "name": name})
    return symbols
