"""Where a file sits (layer 2): the layer of a file - mapped in the project's `layer_paths`, else the folder under
its package - and which layers a layer may use. Read by the engine, the ARCH families, `component add --file` and
`init --adopt`.
"""

from __future__ import annotations

from pathlib import Path

from archvow.templates import Template


def layer_paths(manifest: dict) -> list[tuple[str, str]]:
    """The project's `layer_paths` ({layer: [path, ...]}, paths from the project root) as (path, layer)
    pairs, longest path first: a file keeps its place and still belongs to a layer (adopted code)."""
    pairs = []
    for layer, paths in (manifest.get("layer_paths") or {}).items():
        for path in paths or []:
            clean = str(path).strip().replace("\\", "/").removeprefix("./").lstrip("/")
            if clean:
                pairs.append((clean, str(layer)))
    return sorted(pairs, key=lambda pair: -len(pair[0].rstrip("/")))


def mapped_layer(pairs: list[tuple[str, str]], rel: str) -> str | None:
    """The layer `layer_paths` gives the file `rel` (a .py entry is that file, any other a folder)."""
    for path, layer in pairs:
        if path.endswith(".py"):
            if rel == path:
                return layer
        elif rel.startswith(path.rstrip("/") + "/"):
            return layer
    return None


def file_layer_of(root: Path, manifest: dict, template: Template, rel: str, module: str) -> str | None:
    """A file's layer outside a check run (component add --file, init --adopt)."""
    mapped = mapped_layer(layer_paths(manifest), rel)
    if mapped is not None:
        return mapped
    parts = module.split(".")
    return parts[1] if len(parts) > 1 and template.layer(parts[1]) is not None else None


def layer_allowed(template: Template, source: str | None, target: str | None) -> bool:
    """A layer may use itself and the layers its template lists in `may_import`."""
    if source == target:
        return True
    layer = template.layer(source or "")
    return bool(layer) and target in layer.get("may_import", [])
