"""The check engine (layer 2): engine.py checks the code against the spec (Violation, Report, Checker, the rule
table); the rule families (safety.py, privacy.py, baseline.py... beside this package) import it; run.py is the
one place that knows them all and runs them in order (`archvow check`). Imports layers 0 and 1, and the families.
"""
