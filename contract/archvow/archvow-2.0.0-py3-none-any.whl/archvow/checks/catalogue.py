"""The rule catalogue (layer 2): every rule archvow knows - its code, default severity and title - the floor no
project can switch off, the default parameters, and which rules are on in a project (`rule_sets`, the `rules`
answer, a pack's declarative rules). The one place to read when you look for a rule; its code lives in
checks/families/ (or in a family module beside this package).
"""

from __future__ import annotations

import re

from archvow.packs import rules as pack_rules
from archvow.templates import Template

# code -> (default severity, title). Templates and the manifest may override
# severities ("error" | "warning" | "off") and parameters.
RULES: dict[str, tuple[str, str]] = {
    # Architecture / drift
    "ARCH001": ("error", "Module not declared in the spec"),
    "ARCH002": ("error", "Public symbol not declared in the spec"),
    "ARCH003": ("error", "Declared symbol not implemented, or still a placeholder (reported with --complete)"),
    "ARCH004": ("error", "Signature/annotation differs from the spec"),
    "ARCH005": ("error", "Illegal dependency between layers"),
    "ARCH006": ("error", "Undeclared dependency between components (missing in `uses`)"),
    "ARCH007": ("error", "Import forbidden in this layer"),
    "ARCH008": ("error", "Declared module file not created (reported with --complete)"),
    "ARCH009": ("error", "Invalid entry in a vow"),
    "ARCH010": ("error", "File outside any layer (neither a layer folder nor mapped in `layer_paths`)"),
    "ARCH011": ("error", "Suppression without a justification"),
    "ARCH012": ("warning", "Project template version differs from installed template"),
    "ARCH013": ("error", "File cannot be parsed"),
    "ARCH014": ("error", "Entry of a vow differs from what its template generates (hand-edited?)"),
    "ARCH015": ("error", "Python file outside the architecture (no container, not an allowed path)"),
    "ARCH016": ("error", "Test file does not follow the test layout"),
    "ARCH017": ("error", "Implemented component without its test"),
    "ARCH018": ("error", "Component file without a correct file header"),
    "ARCH019": ("warning", "Component without the data contract its type works on (a reader without its schema)"),
    "ARCH020": ("error", "Guard weakened compared to the base branch"),
    "ARCH040": ("error", "Configuration of an AI assistant not approved for this repository"),
    "ARCH041": ("error", "Review by an AI tool not approved as a reviewer"),
    "ARCH042": ("error", "Review by the AI tool that wrote the code (self-review)"),
    "ARCH030": ("error", "Critical/high hazard that no invariant prevents"),
    "ARCH031": ("error", "An invariant of an implemented component is not tested yet"),
    "ARCH032": ("error", "An invariant's test is not of the kind it requires"),
    "ARCH033": ("error", "Implemented while a decision is still to make"),
    "ARCH034": ("error", "Implemented on an assumption nobody reviewed yet"),
    "ARCH035": ("warning", "Safety question of a component not answered (no hazard, no dismissal)"),
    "ARCH036": ("error", "Invalid hazard, dismissal, invariant or project rule entry"),
    "ARCH037": ("error", "Invariant tested too weakly for the hazard's severity"),
    "ARCH038": ("warning", "A decision or rule of an implemented component has no marked test"),
    "ARCH043": ("warning", "What the AI proposed or added (a decision, a component, a question, a hazard, a rule) is not reviewed by a person yet (an error at the release gate in mode guided)"),
    "ARCH044": ("warning", "A component's task is too long for one AI session (over max_tokens)"),
    "ARCH045": ("warning", "A test marked as evidence checks nothing (an error in mode strict and with --complete)"),
    "ARCH046": ("error", "A marked test did not run and pass in the test report (check --test-report)"),
    "ARCH050": ("error", "A file in .archvow/ that archvow does not write (nobody owns it in CODEOWNERS)"),
    "ARCH051": ("error", "An AI agent runs archvow outside a sandbox (it can write outside the project)"),
    "ARCH052": ("error", "An AI agent runs archvow in YOLO mode (it acts without asking anyone)"),
    "ARCH054": ("error", "An AI agent runs a command only a person runs (it decides or changes the spec)"),
    "ARCH053": ("warning", ("Code an AI agent wrote, with no proof it ran protected (an error when it ran "
                            "blocked, or in mode strict)")),
    "ARCH039": ("warning", "A brief changed after the spec was drawn from it"),
    "ARCH055": ("error", "A business example's files differ from the ones a person recorded"),
    "ARCH056": ("warning", "A business example has no marked test (an error in mode strict and with --complete)"),
    "ARCH057": ("warning", "An item recorded before its component changed is not reviewed yet (an error with --complete)"),
    "ARCH058": ("error", "The project is over its limit of components or lines of code (a warning from 90 %)"),
    "ARCH059": ("error", "Logging configured outside the logging_setup foundation (one place configures it)"),
    "ARCH060": ("error", "A pack's copy changed outside `archvow pack add` / `pack update`"),
    "ARCH061": ("error", "Features use each other in a loop"),
    "ARCH062": ("error", "shared uses a feature from a component other than an entry point"),
    "ARCH021": ("warning", "New suppression compared to the base branch"),
    "ARCH022": ("error", "Change too big for one merge request (files or lines over the budget)"),
    "ARCH023": ("error", "Third-party package imported without approval"),
    "ARCH024": ("warning", "Package in requirements.txt or pyproject.toml without approval (an error in mode strict)"),
    # PySpark (Palantir PySpark style guide + layer purity)
    "SPK001": ("error", "Spark/file I/O outside an I/O layer"),
    "SPK002": ("error", "Spark action or execution control in a lazy-only layer"),
    "SPK003": ("error", "SparkSession built outside the session layer"),
    "SPK004": ("error", "join() without explicit how= keyword"),
    "SPK005": ("error", "Right join (swap the DataFrames and use a left join)"),
    "SPK006": ("warning", "Python or pandas UDF used (prefer native pyspark.sql.functions)"),
    "SPK007": ("error", "Non-standard PySpark import (use functions as F, types as T, Window as W)"),
    "SPK008": ("warning", "Backslash line continuation (wrap the expression in parentheses)"),
    "SPK009": ("warning", "Method chain longer than allowed"),
    "SPK010": ("warning", "Window ordered without an explicit frame (rowsBetween/rangeBetween)"),
    "SPK011": ("error", "Empty Window.partitionBy() (moves all data to one partition)"),
    "SPK012": ("error", "Empty column filled with '' or 'NA' (use F.lit(None))"),
    "SPK013": ("warning", "withColumnRenamed() (prefer .alias() inside a select)"),
    "SPK014": ("warning", "distinct()/dropDuplicates() (fix the cause of duplicates instead)"),
    # FastAPI (template fastapi-service)
    "FAPI001": ("error", "Blocking call inside an async function (it stops every other request)"),
    "FAPI002": ("error", "HTTPException outside the HTTP layers (raise a domain error instead)"),
    "FAPI003": ("error", "FastAPI app created outside an app component"),
    "FAPI004": ("error", "on_event startup/shutdown handler (use the lifespan of the app)"),
    "FAPI005": ("warning", "Route without a response model or return type"),
    # Agents (template langgraph-agent)
    "AGT001": ("error", "A model provider imported, or a model created, outside the models foundation"),
    "AGT002": ("error", "A model named by its id in the code (choose it by role in the models foundation)"),
    "AGT003": ("error", "Graph compiled without the memory's checkpointer"),
    "AGT004": ("error", "Graph without a step limit (recursion_limit)"),
    "AGT005": ("error", "An agent can read untrusted content, read private data and act, with no person's approval"),
    "AGT006": ("error", "A model's text parsed by hand (json.loads) instead of a structured output"),
    "AGT007": ("error", "The index searched outside a retriever (no access filter)"),
    "AGT008": ("error", "The index written without stable ids (a re-run duplicates it)"),
    "AGT009": ("error", "Tool without a docstring or without a type for each argument"),
    "AGT010": ("error", "Tool argument naming the user, filled by the model (take it from the access scope)"),
    "AGT011": ("error", "MCP server connected outside an mcp_client component"),
    "AGT012": ("error", "Prompt pulled from a hub at run time"),
    # Size limits (Palantir: file <= 250 lines, function <= 70 lines), short scripts, few comments
    "STY001": ("warning", "File longer than allowed"),
    "STY002": ("warning", "Function longer than allowed"),
    "STY003": ("warning", "Shell script longer than allowed (move the logic into Python)"),
    "STY004": ("warning", "Too many comment lines for the code (say it in names and docstrings)"),
    # Personal data in the code, for every privacy regime on (GDPR, US-PRIVACY, GLBA... - the regimes' own
    # questions and codes come from their files, packs/regimes.py)
    "PRIV001": ("error", "Column not classified in the spec (personal, special or none)"),
    "PRIV002": ("error", "Personal data printed, shown or logged"),
    "PRIV003": ("error", "Special (sensitive) data written without a tested pseudonymisation or encryption"),
    "PRIV004": ("error", "Files partitioned or bucketed by a personal column (values end up in paths)"),
    "PRIV005": ("error", "Personal data in a URL (path or query parameter: it ends up in access logs)"),
    "PRIV006": ("warning", "Classified column not found in the code"),
    # Test data (`rules` answer TST, on by default)
    "TST001": ("error", "A test reads data from outside tests/ (database, cloud storage, absolute path)"),
    "TST002": ("error", "Real-looking personal identifier in test data"),
    "TST003": ("error", "Binary or too large data file in tests/ (a real extract?)"),
}

# Checks that stay on in every mode and whatever the `rules` answer says: the few that protect a
# critical project (guards weakened, critical/high hazards without a tested invariant, unapproved
# AI tools, a file in .archvow/ nobody owns, an AI agent unprotected, a business example's files
# changed, personal data unclassified or written in the clear).
FLOOR = ("ARCH020", "ARCH030", "ARCH031", "ARCH040", "ARCH050", "ARCH051", "ARCH052", "ARCH053", "ARCH054",
         "ARCH055", "ARCH060", "PRIV001", "PRIV003")
def family_name(code: str, families: dict) -> str:
    """The family a rule belongs to (rules/<NAME>.md): the template's `rule_families` (longest code
    prefix), else the code's letters (a company's custom rules)."""
    prefix = max((p for p in families if code.startswith(p)), key=len, default=None)
    if prefix is not None:
        return str((families[prefix] or {}).get("name") or prefix).upper()
    match = re.match(r"[A-Z]+", code)
    return match.group(0) if match else code


def chosen_families(manifest: dict) -> set[str] | None:
    """The code families of the `rules` answer `check` applies (None: all of them)."""
    chosen = manifest.get("families")
    if chosen is None or "all" in chosen:
        return None
    return {str(f).upper() for f in chosen if f != "none"}


def _entry(code: str, families: dict) -> dict:
    prefix = max((p for p in families if code.startswith(p)), key=len, default=None)
    return (families.get(prefix) or {}) if prefix is not None else {}


def compliance_names(families: dict) -> set[str]:
    """The compliance families by name (TST, PRIV, the regimes): switched by `compliance`, not `families`."""
    return {str((e or {}).get("name") or p).upper() for p, e in families.items() if (e or {}).get("compliance")}


def family_enabled(code: str, families: dict, chosen: set[str] | None) -> bool:
    """A compliance family (`compliance: true`: TST, PRIV and the regimes) is switched by `rule_enabled`;
    the code families by the `rules` answer (`families` in project.vow)."""
    if code in FLOOR or chosen is None or _entry(code, families).get("compliance"):
        return True
    return family_name(code, families) in chosen


# Rule families a template switches on with `rule_sets:`, or the project with the compliance part of its `rules`
# answer (TST; PRIV when a privacy regime is on). A regime's codes (DORA, GDPR, USP...) are switched by its family
# entry's `rule_set` (the regime's id). The other rules - and a pack's declarative rules - apply to every project.
RULE_SETS = {"SPK": "pyspark", "FAPI": "fastapi", "AGT": "agent", "TST": "tst", "PRIV": "priv"}


def rule_enabled(code: str, rule_sets: set[str] | list[str], families: dict | None = None) -> bool:
    """False for a rule of a family (the PySpark SPK rules, a regime's USP rules) the project does not use."""
    family = next((name for prefix, name in RULE_SETS.items() if code.startswith(prefix)), None)
    if family is None and families:
        family = _entry(code, families).get("rule_set")
    return family is None or family in rule_sets


def project_rule_sets(templates: list[Template], manifest: dict) -> set[str]:
    """The families switched on: the templates' `rule_sets`, the compliance families of `rules`, and `priv` (the
    PRIV rules) when one of them is a privacy regime."""
    sets = {s for t in templates for s in (t.data.get("rule_sets") or [])}
    compliance = {str(c) for c in manifest.get("compliance") or [] if c != "none"}
    privacy = {r.id for t in templates for r in t.regimes if r.kind == "privacy"}
    return sets | compliance | ({"priv"} if compliance & privacy else set())


def custom_rules(templates: list[Template]) -> dict[str, dict]:
    """The declarative rules the templates' packs bring (rules/<FAMILY>.yaml, packs/rules.py): code -> rule."""
    found: dict[str, dict] = {}
    for template in templates:
        found |= pack_rules.template_rules(template)
    return found


def all_rules(templates: list[Template]) -> dict[str, tuple[str, str]]:
    """archvow's rules, the privacy regimes' and the templates' custom rules: code -> (default severity, title)."""
    rules = dict(RULES)
    for regime in {r.id: r for t in templates for r in t.regimes}.values():
        for code, rule in regime.rules.items():
            rules.setdefault(code, (rule["severity"], rule["title"]))
    for code, rule in custom_rules(templates).items():
        rules.setdefault(code, (str(rule.get("severity", "error")), str(rule.get("title", code))))
    return rules


DEFAULT_PARAMS = {"SPK009": {"max_chain": 5}, "TST003": {"max_kb": 200, "max_rows": 1000}, "STY001": {"max_lines": 250}, "STY002": {"max_lines": 70},
                  "STY003": {"max_lines": 150}, "STY004": {"max_percent": 30, "min_code_lines": 20},
                  "ARCH022": {"max_files": 30, "max_added_lines": 1000, "max_deleted_lines": 300},
                  "ARCH044": {"max_tokens": 4000}}
