"""AGENT rules (AGT001-AGT012) of the langgraph-agent template: where models come from, how tools,
graphs and retrieval are written, and the Rule of Two. The template switches them on with
`rule_sets: [agent]` and says which component types play which part (`agent_roles`)."""

from __future__ import annotations

import ast
import re
from pathlib import Path

from archvow.checks.catalogue import rule_enabled
from archvow.checks.engine import Checker, SourceFile
from archvow.foundation import logs
from archvow.imports import Names
from archvow.model import store
from archvow.templates import Template

log = logs.get("agentcheck")

# Packages that talk to a model provider (AGT001): only the models foundation imports them.
PROVIDER_PACKAGES = (
    "langchain_openai", "langchain_anthropic", "langchain_ollama", "langchain_google_genai",
    "langchain_google_vertexai", "langchain_aws", "langchain_mistralai", "langchain_groq", "langchain_fireworks",
    "langchain_huggingface", "langchain_cohere", "langchain_together", "langchain_deepseek", "langchain_xai",
    "langchain_nvidia_ai_endpoints", "langchain_ibm", "langchain_community.chat_models",
    "langchain_community.embeddings", "langchain_community.llms", "openai", "anthropic", "ollama", "google.genai",
    "google.generativeai", "mistralai", "cohere", "groq", "litellm", "vertexai",
)
MODEL_FACTORIES = {"langchain.chat_models.init_chat_model", "langchain.embeddings.init_embeddings",
                   "langchain.chat_models.base.init_chat_model"}
# A model named by its id in the code (AGT002): "gpt-4o", "anthropic:claude-sonnet-4-5", "qwen3:4b"...
MODEL_ID = re.compile(
    r"^(?:[a-z_-]+:)?(?:gpt-[0-9o]|o[134](?:-mini|-pro)?$|o[134]-|chatgpt-|claude-|gemini-|mistral-|mixtral|codestral|"
    r"llama[0-9.-]|qwen[0-9]|deepseek-|phi-?[0-9]|gemma[0-9-]|text-embedding-|nomic-embed|mxbai-embed|bge-|"
    r"command-r|grok-)", re.IGNORECASE)
VECTOR_SEARCHES = {"similarity_search", "similarity_search_with_score", "similarity_search_by_vector",
                   "similarity_search_with_relevance_scores", "asimilarity_search", "asimilarity_search_with_score",
                   "max_marginal_relevance_search", "amax_marginal_relevance_search", "as_retriever", "query_points"}
VECTOR_WRITES = {"add_documents", "aadd_documents", "add_texts", "aadd_texts", "add_embeddings"}
MCP_CLIENTS = {"MultiServerMCPClient", "ClientSession", "streamablehttp_client", "streamable_http_client",
               "sse_client", "stdio_client", "load_mcp_tools"}
IDENTITY_NAMES = {"user", "user_id", "username", "user_name", "user_email", "email", "tenant", "tenant_id",
                  "customer_id", "account_id", "employee_id", "owner_id"}
INJECTED = ("InjectedState", "InjectedToolArg", "InjectedStore", "ToolRuntime", "InjectedToolCallId", "RunnableConfig")
APPROVALS = ("interrupt(", "interrupt_before", "interrupt_on", "HumanInTheLoopMiddleware")
YES = ("yes", "oui", "y", "o")


def _decorated_as_tool(node: ast.FunctionDef | ast.AsyncFunctionDef) -> bool:
    for deco in node.decorator_list:
        target = deco.func if isinstance(deco, ast.Call) else deco
        name = target.id if isinstance(target, ast.Name) else target.attr if isinstance(target, ast.Attribute) else ""
        if name == "tool":
            return True
    return False


def _said_yes(answer: object) -> bool:
    words = re.findall(r"[a-zà-ÿ]+", str(answer or "").lower())
    return bool(words) and words[0] in YES


class AgentChecks:
    """The AGT rules on one file of a project made from a template with `rule_sets: [agent]`."""

    def __init__(self, checker: Checker, template: Template, container: dict, component: dict | None,
                 layer: dict | None, rel: str, names: Names) -> None:
        self.c = checker
        self.template = template
        self.container = container
        self.component = component or {}
        self.layer = (layer or {}).get("name")
        self.rel = rel
        self.names = names
        roles = template.data.get("agent_roles") or {}
        self.settings_ids = set(roles.get("settings_ids") or ["models", "settings"])
        self.retriever_types = set(roles.get("retriever_types") or ["retriever"])
        self.mcp_types = set(roles.get("mcp_types") or ["mcp_client"])
        self.tool_types = set(roles.get("tool_types") or ["tool"])
        self.agent_types = set(roles.get("agent_types") or ["agent", "graph"])
        self.ctype = self.component.get("type")
        self.cid = self.component.get("id")

    def run(self, tree: ast.Module) -> None:
        in_models = self.cid == "models"
        for node in ast.walk(tree):
            if isinstance(node, (ast.Import, ast.ImportFrom)) and not in_models:
                self._provider_import(node)
            elif isinstance(node, ast.Call):
                self._call(node, in_models)
            elif isinstance(node, ast.Constant) and isinstance(node.value, str) and self.cid not in self.settings_ids:
                self._model_id(node)
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                self._tool_function(node)
        if self.ctype == "graph":
            self._graph(tree)
        if self.ctype in self.agent_types:
            self._rule_of_two()

    # ---- AGT001, AGT002: models come from the models foundation only
    def _provider_import(self, node: ast.Import | ast.ImportFrom) -> None:
        modules = [a.name for a in node.names] if isinstance(node, ast.Import) else [node.module or ""]
        for module in modules:
            hit = next((p for p in PROVIDER_PACKAGES if module == p or module.startswith(p + ".")), None)
            if hit:
                self.c.add("AGT001", f"'{module}' talks to a model provider: only the models foundation imports it; "
                           'here, ask for a model with models.chat("<role>") or models.embeddings()',
                           self.rel, node.lineno)

    def _model_id(self, node: ast.Constant) -> None:
        text = node.value.strip()
        if " " in text or len(text) > 80 or not MODEL_ID.match(text):
            return
        self.c.add("AGT002", f"'{text}' names a model in the code: models are chosen in the models foundation, "
                   'by role - ask for models.chat("<role>")', self.rel, node.lineno, node.col_offset)

    # ---- the calls: AGT001 factories, AGT006-AGT008, AGT011, AGT012
    def _call(self, node: ast.Call, in_models: bool) -> None:
        func = node.func
        called = self.names.full_name(func) or ""
        attr = func.attr if isinstance(func, ast.Attribute) else func.id if isinstance(func, ast.Name) else ""
        line, col = node.lineno, node.col_offset
        if called in MODEL_FACTORIES and not in_models:
            self.c.add("AGT001", f"{attr}() creates a model: only the models foundation does; here, ask for "
                       'models.chat("<role>") or models.embeddings()', self.rel, line, col)
        if called in ("json.loads", "json.load") and self.layer == "p3_agents":
            self.c.add("AGT006", "json.loads() parses a model's text by hand: read it through a structured output "
                       "(model.with_structured_output(<a schema component>))", self.rel, line, col)
        if attr in VECTOR_SEARCHES and isinstance(func, ast.Attribute) and self.ctype not in self.retriever_types:
            self.c.add("AGT007", f".{attr}() searches the index outside a retriever: only a retriever searches it, "
                       "filtered by the user's access scope - use one", self.rel, line, col)
        if attr in VECTOR_WRITES and isinstance(func, ast.Attribute):
            keywords = {k.arg for k in node.keywords}
            if "ids" not in keywords and not (attr in ("add_texts", "aadd_texts") and len(node.args) >= 3):
                self.c.add("AGT008", f".{attr}() writes to the index without ids: a re-run duplicates every chunk - "
                           "give stable ids (source id, chunk number, content hash)", self.rel, line, col)
        if attr in MCP_CLIENTS and self.ctype not in self.mcp_types:
            self.c.add("AGT011", f"{attr}() connects to an MCP server outside an mcp_client component: only an "
                       "approved mcp_client component opens that connection", self.rel, line, col)
        receiver = ast.unparse(func.value) if isinstance(func, ast.Attribute) else ""
        if attr == "pull_prompt" or (attr == "pull" and receiver.split(".")[-1] == "hub") \
                or called in ("langchain.hub.pull", "langchainhub.Client.pull"):
            self.c.add("AGT012", f"{ast.unparse(func)}() pulls a prompt at run time: keep the prompt in the code "
                       "(a prompt component), versioned and reviewed with it", self.rel, line, col)

    # ---- AGT009, AGT010: tools
    def _tool_function(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        public_tool = self.ctype in self.tool_types and node.name == self.component.get("name")
        if not (_decorated_as_tool(node) or public_tool) or node.name.startswith("_"):
            return
        args = [*node.args.posonlyargs, *node.args.args, *node.args.kwonlyargs]
        untyped = [a.arg for a in args if a.annotation is None and a.arg not in ("self", "cls")]
        if ast.get_docstring(node) is None or untyped:
            missing = "a docstring" if ast.get_docstring(node) is None else ""
            if untyped:
                missing += (" and " if missing else "") + "a type for " + ", ".join(untyped)
            self.c.add("AGT009", f"tool {node.name} needs {missing}: the model only knows a tool by its docstring "
                       "and its typed arguments", self.rel, node.lineno)
        for arg in args:
            annotation = ast.unparse(arg.annotation) if arg.annotation is not None else ""
            if arg.arg in IDENTITY_NAMES and not any(i in annotation for i in INJECTED):
                self.c.add("AGT010", f"tool {node.name}: '{arg.arg}' is filled by the model, so anyone can ask for "
                           "another user's data - take the user from the injected access scope "
                           "(Annotated[AccessScope, InjectedState(...)] or InjectedToolArg)", self.rel, node.lineno)

    # ---- AGT003, AGT004: graphs
    def _graph(self, tree: ast.Module) -> None:
        compiled = False
        for node in ast.walk(tree):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "compile" \
                    and ast.unparse(node.func.value) not in ("re", "regex"):
                compiled = True
                if "checkpointer" not in {k.arg for k in node.keywords}:
                    self.c.add("AGT003", "the graph is compiled without a checkpointer: compile it with the memory "
                               "foundation's (compile(checkpointer=get_checkpointer())), so a conversation and an "
                               "approval can resume", self.rel, node.lineno)
        limited = any((isinstance(n, ast.keyword) and n.arg == "recursion_limit")
                      or (isinstance(n, ast.Constant) and n.value == "recursion_limit") for n in ast.walk(tree))
        if compiled and not limited:
            self.c.add("AGT004", "the graph has no step limit: give it one (with_config(recursion_limit=25), or "
                       "recursion_limit in its config), so a loop stops", self.rel, 1)

    # ---- AGT005: the Rule of Two
    def _rule_of_two(self) -> None:
        tools = self._tools_used()
        risks = {"untrusted": [], "private": [], "acts": []}
        for tool in tools:
            numbers = self.template.type_of(tool).get("risk_decisions") or {}
            decisions = tool.get("decisions") or []
            for risk, number in numbers.items():
                if 0 < number <= len(decisions) and _said_yes(decisions[number - 1].get("answer")):
                    risks.setdefault(risk, []).append(tool["id"])
        if not all(risks.get(r) for r in ("untrusted", "private", "acts")):
            return
        sources = [self._source(self.component), *(self._source(t) for t in tools if t["id"] in risks["acts"])]
        if any(a in text for text in sources for a in APPROVALS):
            return
        self.c.add("AGT005", f"{self.cid} can read untrusted content ({', '.join(risks['untrusted'])}), read private "
                   f"data ({', '.join(risks['private'])}) and act ({', '.join(risks['acts'])}) with no person's "
                   "approval: make the acting tool wait for one (interrupt())", self.rel, 1)

    def _tools_used(self) -> list[dict]:
        by_id = {c["id"]: c for k in self.c.manifest.get("containers") or [] for c in k.get("components") or []}
        seen, todo, tools = set(), list(self.component.get("uses") or []), []
        while todo:
            cid = todo.pop()
            if cid in seen or cid not in by_id:
                continue
            seen.add(cid)
            comp = by_id[cid]
            if comp.get("type") in self.tool_types:
                tools.append(comp)
            todo.extend(comp.get("uses") or [])
        return tools

    def _source(self, comp: dict) -> str:
        try:
            return (Path(self.c.root) / store.source_path(self.container, comp)).read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            logs.swallowed(log, "_source: OSError, UnicodeDecodeError")
            return ""


def check_file(checker: Checker, file: SourceFile) -> None:
    """The AGT rules of one file, when the template turns them on (checks/run.py gives this to the engine)."""
    if rule_enabled("AGT001", checker.rule_sets):
        AgentChecks(checker, file.template, file.container, file.component, file.layer, file.rel,
                    file.names).run(file.tree)
