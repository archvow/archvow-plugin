"""FASTAPI rules (FAPI001-FAPI005), on for a template with `rule_sets: [fastapi]`: nothing blocks the event loop,
HTTP errors only in the HTTP layers, one place creates the app, the lifespan instead of on_event, typed responses.
"""

from __future__ import annotations

import ast
import re

from archvow.checks.catalogue import rule_enabled
from archvow.checks.code import HTTP_METHODS, OPEN_CALLS, route_of
from archvow.checks.engine import Checker, SourceFile
from archvow.imports import Names
from archvow.templates import Template

# Calls that block the event loop when made inside `async def` (FAPI001), by full name: an alias
# (`from time import sleep as nap`) is resolved first (imports.Names).
BLOCKING_CALLS = {"time.sleep", "requests.get", "requests.post", "requests.put", "requests.patch",
                  "requests.delete", "requests.request", "urllib.request.urlopen", "subprocess.run",
                  "subprocess.call", "subprocess.check_output", "httpx.get", "httpx.post", "httpx.put",
                  "httpx.patch", "httpx.delete"}

# a Response returned as is: FastAPI does not validate it against a response model (FAPI005)
RESPONSE_RE = re.compile(r"Response$")


def check_file(checker: Checker, file: SourceFile) -> None:
    """The FAPI rules on one file, when the template turns them on (checks/run.py gives this to the engine)."""
    if rule_enabled("FAPI001", checker.rule_sets):
        FastAPIVisitor(checker, file.template, file.layer, file.component, file.rel, file.names).visit(file.tree)


class FastAPIVisitor(ast.NodeVisitor):
    """FastAPI rules: the event loop, where HTTP lives, one app, lifespan, typed responses. Where HTTP
    lives and where the app is made (FAPI002/003) need the file's layer; the others run on every file."""

    def __init__(self, checker: Checker, template: Template, layer: dict | None, component: dict | None,
                 rel: str, names: Names) -> None:
        self.c = checker
        self.names = names
        self.layer = layer
        self.rel = rel
        self.http_layers = list(template.data.get("http_layers") or [])
        self.app_type = template.data.get("app_type")
        self.component = component
        self.in_async = False

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._route(node)
        outer, self.in_async = self.in_async, True
        self.generic_visit(node)
        self.in_async = outer

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._route(node)
        outer, self.in_async = self.in_async, False  # a nested def runs elsewhere (thread pool)
        self.generic_visit(node)
        self.in_async = outer

    def _route(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        route = route_of(node)
        if route is None:
            return
        deco = next(d for d in node.decorator_list if isinstance(d, ast.Call)
                    and isinstance(d.func, ast.Attribute) and d.func.attr in HTTP_METHODS)
        keywords = {k.arg for k in deco.keywords}  # type: ignore[union-attr]
        # a route answering with a Response class (response_class= or returned as is) has no model to check
        if "response_model" in keywords or "response_class" in keywords or node.returns is not None:
            return
        if not _returns_response(node):
            self.c.add("FAPI005", f"route {route[0]} {route[1]}: declare what it returns (a return type "
                       "or response_model=), so the response is validated and documented", self.rel, node.lineno)

    def visit_Call(self, node: ast.Call) -> None:
        func = node.func
        called = self.names.full_name(func) if self.in_async else None
        if called in BLOCKING_CALLS:
            shown = ast.unparse(func) + ("()" if ast.unparse(func) == called else f"() ({called})")
            self.c.add("FAPI001", f"'{shown}' blocks the event loop inside async def: use an async client "
                       "(httpx.AsyncClient, asyncio.sleep) or a plain def", self.rel, node.lineno, node.col_offset)
        elif called in OPEN_CALLS:
            self.c.add("FAPI001", f"{ast.unparse(func)}() blocks the event loop inside async def: use a plain def",
                       self.rel, node.lineno, node.col_offset)
        name = func.id if isinstance(func, ast.Name) else func.attr if isinstance(func, ast.Attribute) else ""
        if name == "HTTPException" and self.layer is not None and self.layer["name"] not in self.http_layers:
            self.c.add("FAPI002", f"HTTPException belongs to {', '.join(self.http_layers)}: raise a domain error "
                       "here and map it to an HTTP status in the app's exception handlers", self.rel, node.lineno)
        if name == "FastAPI" and self.layer is not None and (self.component or {}).get("type") != self.app_type:
            self.c.add("FAPI003", f"create the FastAPI app only in the '{self.app_type}' component",
                       self.rel, node.lineno)
        if isinstance(func, ast.Attribute) and func.attr == "on_event":
            self.c.add("FAPI004", "on_event is deprecated: put startup and shutdown in the app's lifespan",
                       self.rel, node.lineno)
        self.generic_visit(node)


def _returns_response(node: ast.FunctionDef | ast.AsyncFunctionDef) -> bool:
    """The route returns a Response object it builds (RedirectResponse(...), or a name assigned from one)."""
    def builds_response(value: ast.expr | None) -> bool:
        if not isinstance(value, ast.Call):
            return False
        func = value.func
        name = func.id if isinstance(func, ast.Name) else func.attr if isinstance(func, ast.Attribute) else ""
        return bool(RESPONSE_RE.search(name))

    built = {target.id for sub in ast.walk(node) if isinstance(sub, ast.Assign) and builds_response(sub.value)
             for target in sub.targets if isinstance(target, ast.Name)}
    return any(isinstance(sub, ast.Return) and (builds_response(sub.value) or (
        isinstance(sub.value, ast.Name) and sub.value.id in built)) for sub in ast.walk(node))
