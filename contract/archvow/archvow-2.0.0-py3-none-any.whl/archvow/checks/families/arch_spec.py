"""ARCH rules on the spec's own entries, once per container: every component of a known type, in its type's
layer, named and placed as `archvow component add` would write it (ARCH009, ARCH014), using only the layers its
own layer may use (ARCH005) and the data contract its type works on (ARCH019); `layer_paths` naming real layers.
"""

from __future__ import annotations

import re

from archvow.checks.code import canonical_signature
from archvow.checks.engine import Checker
from archvow.checks.layers import layer_allowed
from archvow.model import features as feats
from archvow.model import store
from archvow.templates import Template

GROUP_RE = re.compile(r"^[a-z][a-z0-9_]*$")


def check_container(checker: Checker, container: dict, template: Template) -> None:
    """The entries of one container against its template (checks/run.py gives this to the engine)."""
    check_layer_paths(checker, template)
    check_manifest(checker, container, container.get("components", []), template)
    if container is (checker.manifest.get("containers") or [None])[0]:  # once for the project
        check_features(checker)


def check_features(checker: Checker) -> None:
    """ARCH061: no loop between features (one would be two features that cannot be told apart). ARCH062: `shared`
    is what every feature uses; it uses a feature only from an entry point (the app, a job: nothing uses it)."""
    data = checker.manifest
    by_id = {c["id"]: c for c in feats.all_components(data)}
    loop = feats.cycle(data)
    if loop:
        uses = feats.feature_uses(data)
        first, second = loop[0], loop[1]
        comp, used = uses[first][second][0]
        checker.add("ARCH061", f"features in a loop: {' -> '.join(loop)} ({comp} uses {used}) - keep one direction: "
                    f"move what both need to shared (archvow component move {used} shared), or merge the two "
                    "features", store.where(by_id[comp]))
    for comp, used, feature in feats.shared_misuses(data):
        checker.add("ARCH062", f"'{comp}' (shared) uses '{used}' of the feature {feature}: only an entry point of "
                    f"shared (the app, a job - nothing uses it) plugs the features in -> archvow component move "
                    f"{comp} {feature}", store.where(by_id[comp]))


def missing_contracts(comp: dict, ctype: dict, by_id: dict) -> list[str]:
    """The types a component must use and does not (`requires_uses`: a reader needs its schema)."""
    used = {(by_id.get(u) or {}).get("type") for u in comp.get("uses") or []}
    return [t for t in ctype.get("requires_uses") or [] if t not in used]


def check_layer_paths(checker: Checker, template: Template) -> None:
    """ARCH009: `layer_paths` names layers of the template, each path once."""
    seen: dict[str, str] = {}
    for path, layer in checker.layer_map:
        if template.layer(layer) is None:
            checker.add("ARCH009", f"layer_paths: '{layer}' is not a layer of template {template.name} "
                        f"(layers: {', '.join(template.layer_names)})", str(store.PROJECT_REL))
        elif path in seen and seen[path] != layer:
            checker.add("ARCH009", f"layer_paths: '{path}' is mapped to {seen[path]} and {layer}",
                        str(store.PROJECT_REL))
        seen[path] = layer


def check_manifest(checker: Checker, container: dict, components: list[dict], template: Template) -> None:
    where = str(store.PROJECT_REL)
    ids = [c.get("id") for c in components]
    by_id = {c.get("id"): c for c in components}
    for dup in {i for i in ids if ids.count(i) > 1}:
        checker.add("ARCH009", f"duplicate component id '{dup}'", where)
    for comp in components:
        cid = comp.get("id", "?")
        ctype = template.type_of(comp) if comp.get("type") in template.component_types else None
        if ctype is None:
            checker.add("ARCH009", f"component '{cid}': unknown type '{comp.get('type')}'", where)
            continue
        if comp.get("layer") != ctype["layer"]:
            checker.add("ARCH009", f"component '{cid}': type '{comp['type']}' belongs in layer '{ctype['layer']}'", where)
        expected_prefix = f"{container['package']}.{ctype['layer']}."
        if comp.get("adopted"):
            check_adopted(checker, container, comp, ctype, template, where)
        elif not str(comp.get("module", "")).startswith(expected_prefix):
            checker.add("ARCH009", f"component '{cid}': module must live under {expected_prefix}*", where)
        pattern = ctype.get("name_pattern")
        if pattern and not re.fullmatch(pattern, str(comp.get("name", ""))):
            checker.add("ARCH009", f"component '{cid}': name '{comp.get('name')}' does not match {pattern}", where)
        if not str(comp.get("description", "")).strip():
            checker.add("ARCH009", f"component '{cid}': a description is required (if it is hard to explain, it is a bad idea)", where)
        check_shape(checker, container, comp, ctype, template)
        for used in comp.get("uses", []) or []:
            target = by_id.get(used)
            if target is None:
                checker.add("ARCH009", f"component '{cid}': uses unknown component '{used}'", where)
            elif not layer_allowed(template, comp.get("layer"), target.get("layer")):
                checker.add("ARCH005", f"component '{cid}' ({comp.get('layer')}) may not use '{used}' ({target.get('layer')})", where)
        for needed in missing_contracts(comp, ctype, by_id):
            checker.add("ARCH019", f"'{cid}' uses no {needed}: the columns it works on are written nowhere -> "
                        f"archvow component add {needed} <name> -d \"...\", then archvow component edit {cid} -u <name>_{needed}", where)


def check_adopted(checker: Checker, container: dict, comp: dict, ctype: dict, template: Template, where: str) -> None:
    """An adopted component keeps its file where it is: `layer_paths` must put it in its type's layer."""
    rel = store.source_path(container, comp)
    if not (checker.root / rel).is_file():
        return  # its file is gone: ARCH008 with --complete
    layer = checker.file_layer(container, template, rel, str(comp.get("module", "")))
    if layer != ctype["layer"]:
        checker.add("ARCH009", f"component '{comp.get('id')}': {rel} is in layer {layer or 'none'}, a "
                    f"{comp.get('type')} belongs in {ctype['layer']} - map it in `layer_paths`", where)


def check_shape(checker: Checker, container: dict, comp: dict, ctype: dict, template: Template) -> None:
    """Every entry must be exactly what `archvow component add` (or the template) would produce."""
    cid = comp.get("id", "?")
    where = store.where(comp)  # the component's own vow
    if not ctype.get("addable", True):
        initial = {c.get("id") for c in template.data.get("initial_components", [])}
        if cid not in initial:
            checker.add("ARCH014", f"component '{cid}': type '{comp.get('type')}' is template-owned; "
                        "it cannot be declared by hand", where)
        return
    if "module" not in ctype:
        return
    name = str(comp.get("name", ""))
    fmt = store.name_values(name)
    base = ctype["module"].format(**fmt)
    group = comp.get("group")
    if group is not None and not GROUP_RE.fullmatch(str(group)):
        checker.add("ARCH014", f"component '{cid}': group '{group}' must be a snake_case folder name", where)
    folder = f"{group}." if group else ""
    expected_module = f"{container['package']}.{ctype['layer']}.{folder}{base}"
    if comp.get("adopted"):  # its module is its existing file; its symbols are what the file had
        if cid != base:
            checker.add("ARCH014", f"component '{cid}': a {comp.get('type')} named '{name}' must be id '{base}'",
                        where)
        return
    if comp.get("module") != expected_module or cid != base:
        checker.add("ARCH014", f"component '{cid}': a {comp.get('type')} named '{name}' must be "
                    f"id '{base}', module {expected_module}", where)
    expected = ctype.get("symbols", [])
    actual = comp.get("symbols", []) or []
    if len(actual) != len(expected) and not ctype.get("extra_symbols", False):
        checker.add("ARCH014", f"component '{cid}': declares {len(actual)} symbol(s), "
                    f"template '{comp.get('type')}' defines {len(expected)}", where)
    for index, (want, got) in enumerate(zip(expected, actual, strict=False)):
        want_name = want["name"].format(**fmt)
        if got.get("name") != want_name or got.get("kind", "function") != want.get("kind", "function"):
            checker.add("ARCH014", f"component '{cid}': symbol must be {want.get('kind', 'function')} "
                        f"'{want_name}', the spec says {got.get('kind', 'function')} '{got.get('name')}'", where)
            continue
        if "signature" in want and not (index == 0 and ctype.get("signature_overridable")):
            if canonical_signature(str(got.get("signature", "()"))) != canonical_signature(want["signature"]):
                checker.add("ARCH014", f"component '{cid}': '{want_name}' signature must be "
                            f"{want['signature']}", where)
        if "annotation" in want and got.get("annotation") != want["annotation"]:
            checker.add("ARCH014", f"component '{cid}': '{want_name}' must be annotated "
                        f"{want['annotation']}", where)
