"""ARCH rules on the code against the spec, file by file: every module declared and in a layer (ARCH001,
ARCH010), its file header (ARCH018), every public symbol declared, implemented and with the spec's signature
(ARCH002-ARCH004), imports that respect the layers, the `uses` and the forbidden packages (ARCH005-ARCH007),
logging configured only by the logging_setup foundation (ARCH059).
"""

from __future__ import annotations

import ast

from archvow import header
from archvow.checks.code import (
    canonical_expr,
    canonical_signature,
    defined_names,
    module_logger,
    render_signature,
    resolve_from,
    route_of,
    symbol_status,
)
from archvow.checks.engine import Checker, SourceFile, SymbolStatus
from archvow.checks.layers import layer_allowed
from archvow.imports import Names
from archvow.templates import Template

# Calls that configure logging (ARCH059): only the logging_setup foundation makes them.
LOGGING_CONFIG_CALLS = {"logging.basicConfig", "logging.config.dictConfig", "logging.config.fileConfig",
                        "logging.captureWarnings", "logging.setLoggerClass", "logging.disable"}


def check_file(checker: Checker, file: SourceFile) -> None:
    """Where the file sits, its header, its symbols and its imports (checks/run.py gives this to the engine)."""
    parts = file.module.split(".")
    component, layer, rel = file.component, file.layer, file.rel
    if component is None and not file.is_init:
        if layer is None and len(parts) > 1:
            package = checker.manifest["containers"][0]["package"]
            checker.add("ARCH001", f"{file.module} is not declared and sits in no layer: map it in `layer_paths` "
                        f"(archvow init {package} --force --adopt proposes it), then archvow component add "
                        f"<type> <name> --file {rel}", rel)
        else:
            checker.add("ARCH001", f"{file.module} is not declared; add it with `archvow component add`", rel)
    elif layer is None and len(parts) > 1:
        checker.add("ARCH010", f"'{parts[1]}' is not a layer of template {file.template.name} "
                    f"(layers: {', '.join(file.template.layer_names)}): move the file or map it in `layer_paths`",
                    rel)
    header_lines = file.template.data.get("file_header") or []
    if component is not None and header_lines:
        for issue in header.problems(ast.get_docstring(file.tree), header_lines, checker.manifest, component):
            checker.add("ARCH018", issue, rel, 1)
    check_symbols(checker, file.container, component, file.tree, rel, file.is_init)
    if layer is not None:  # where the file sits: layers it may import, forbidden imports
        check_imports(checker, file.container, file.template, file.by_module, component, layer, file.tree,
                      file.module, rel, file.is_init)


def check_logging_setup(checker: Checker, file: SourceFile) -> None:
    """ARCH059 on one file (checks/run.py runs it after the families' own file checks)."""
    check_logging(checker, file.module, file.tree, file.rel, file.names)


def check_logging(checker: Checker, module: str, tree: ast.Module, rel: str, names: Names) -> None:
    """ARCH059: only the logging_setup foundation configures logging; the other modules only log."""
    setup = {c.get("module") for k in checker.manifest.get("containers") or []
             for c in k.get("components") or [] if c.get("id") == "logging_setup"}
    if not setup or module in setup:
        return
    where = " or ".join(sorted(str(m) for m in setup if m))
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        called = names.full_name(node.func) or ""
        func = node.func
        attr = func.attr if isinstance(func, ast.Attribute) else ""
        receiver = ast.unparse(func.value) if isinstance(func, ast.Attribute) else ""
        root_logger = receiver in ("logging.root", "logging.getLogger()") or (
            isinstance(func, ast.Attribute) and isinstance(func.value, ast.Call)
            and (names.full_name(func.value.func) or "") == "logging.getLogger" and not func.value.args)
        if called in LOGGING_CONFIG_CALLS or attr in ("addHandler", "removeHandler") \
                or (attr == "setLevel" and root_logger):
            shown = ast.unparse(func)
            checker.add("ARCH059", f"{shown}() configures logging: that belongs to {where} (setup_logging); here, "
                        "only log with logging.getLogger(__name__)", rel, node.lineno, node.col_offset)


def check_symbols(checker: Checker, container: dict, component: dict | None, tree: ast.Module,
                  rel: str, is_init: bool) -> None:
    public: dict[str, ast.stmt] = {}
    for node in tree.body:
        if module_logger(node):  # logger = logging.getLogger(__name__): how a module logs, not a symbol
            continue
        for name in defined_names(node):
            if not name.startswith("_"):
                public[name] = node
    if is_init or component is None:
        if is_init:
            for name, node in public.items():
                checker.add("ARCH002", f"'{name}' defined in a package __init__; put it in a declared component",
                            rel, node.lineno)
        return
    declared = {s["name"]: s for s in component.get("symbols", [])}
    for node in tree.body:  # a route is public whatever its name: it must be declared
        route = route_of(node)
        if route and node.name.startswith("_"):
            checker.add("ARCH002", f"route {route[0]} {route[1]} on private '{node.name}' is not declared in "
                        f"component '{component['id']}' (archvow component edit {component['id']} -r ...)", rel, node.lineno)
    for name, node in public.items():
        if name not in declared:
            checker.add("ARCH002", f"'{name}' is not declared in component '{component['id']}' "
                        "(make it private with a leading underscore or declare it)", rel, node.lineno)
    for name, spec in declared.items():
        node = public.get(name)
        if node is None:
            if checker.complete:
                checker.add("ARCH003", f"'{name}' of component '{component['id']}' is planned "
                            "but not implemented", rel)
            checker.report.statuses.append(
                   SymbolStatus(container["id"], component["id"], name, "planned", "missing"))
            continue
        _compare_symbol(checker, component, spec, node, rel)
        status = symbol_status(node)
        if status == "planned" and checker.complete:
            checker.add("ARCH003", f"'{name}' of component '{component['id']}' is still a placeholder "
                        "(only pass, ..., a docstring or raise NotImplementedError): implement it", rel,
                        node.lineno)
        checker.report.statuses.append(SymbolStatus(container["id"], component["id"], name, status,
                                                    "placeholder" if status == "planned" else ""))


def _compare_symbol(checker: Checker, component: dict, spec: dict, node: ast.stmt, rel: str) -> None:
    kind = spec.get("kind", "function")
    name = spec["name"]
    if kind == "function":
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            checker.add("ARCH004", f"'{name}' should be a function", rel, node.lineno)
        elif spec.get("signature"):
            expected = canonical_signature(spec["signature"])
            actual = render_signature(node)
            if expected != actual:
                checker.add("ARCH004", f"'{name}' signature is {actual}, the spec says {expected} -> write the "
                            "spec's signature, or a person changes the spec: archvow component edit "
                            f"{component['id']} --signature \"{actual}\"", rel, node.lineno)
    elif kind == "route":
        route = route_of(node)
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) or route is None:
            checker.add("ARCH004", f"'{name}' should be a route: @<router>.{spec['method'].lower()}"
                        f"(\"{spec['path']}\")", rel, node.lineno)
        elif route != (spec["method"], spec["path"]):
            checker.add("ARCH004", f"'{name}' is {route[0]} {route[1]}, the spec says "
                        f"{spec['method']} {spec['path']}", rel, node.lineno)
    elif kind == "class":
        if not isinstance(node, ast.ClassDef):
            checker.add("ARCH004", f"'{name}' should be a class", rel, node.lineno)
    elif kind == "constant":
        annotation = node.annotation if isinstance(node, ast.AnnAssign) else None
        if spec.get("annotation"):
            expected = canonical_expr(spec["annotation"])
            actual = ast.unparse(annotation) if annotation is not None else "<none>"
            if expected != actual:
                checker.add("ARCH004", f"'{name}' annotation is {actual}, the spec says {expected}", rel, node.lineno)


def check_imports(checker: Checker, container: dict, template: Template, by_module: dict,
                  component: dict | None, layer: dict, tree: ast.Module,
                  module: str, rel: str, is_init: bool) -> None:
    package = container["package"]
    forbidden = set(layer.get("forbidden_imports", []))
    current_pkg = module if is_init else module.rpartition(".")[0]
    for node in ast.walk(tree):
        targets: list[tuple[str, int]] = []
        if isinstance(node, ast.Import):
            for alias in node.names:
                targets.append((alias.name, node.lineno))
        elif isinstance(node, ast.ImportFrom):
            base = resolve_from(node, current_pkg)
            for alias in node.names:
                full = f"{base}.{alias.name}" if base and alias.name != "*" else base
                targets.append((full, node.lineno))
        for target, line in targets:
            if not target:
                continue
            top = target.split(".")[0]
            if top in forbidden:
                checker.add("ARCH007", f"layer '{layer['name']}' may not import '{top}'", rel, line)
            if top == package:
                _check_internal_edge(checker, container, template, by_module, component, layer, target, rel, line)


def _check_internal_edge(checker: Checker, container: dict, template: Template, by_module: dict,
                         component: dict | None, layer: dict, target: str, rel: str, line: int) -> None:
    target_layer = checker.module_layer(container, template, target) if "." in target else None
    if target_layer is None:
        return  # a module in no layer: ARCH001/ARCH010 on that file already say so
    if not layer_allowed(template, layer["name"], target_layer):
        allowed = ", ".join(layer.get("may_import", [])) or "nothing"
        checker.add("ARCH005", f"layer '{layer['name']}' may not import from '{target_layer}' "
                    f"(allowed: {allowed})", rel, line)
        return
    target_component = _owning_component(by_module, target)
    if component is None or target_component is None or target_component is component:
        return
    ctype = template.type_of(target_component)
    if ctype.get("implicit_dependency"):
        return
    if target_component["id"] not in (component.get("uses") or []):
        checker.add("ARCH006", f"'{component['id']}' imports '{target_component['id']}' but does not "
                    "declare it in `uses`", rel, line)


def _owning_component(by_module: dict, target: str) -> dict | None:
    parts = target.split(".")
    for end in range(len(parts), 1, -1):
        candidate = ".".join(parts[:end])
        if candidate in by_module:
            return by_module[candidate]
    return None
