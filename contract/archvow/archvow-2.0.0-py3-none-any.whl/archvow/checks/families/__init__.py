"""The rule families that read the project's code (layer 2), one module per family: arch_spec (the spec's own
entries), arch_code (the code against the spec), arch_project (the files around the code), style, spark, fastapi
and agent. Each gives the engine what it checks in a container or in a file; checks/run.py hands them over in
order. They import checks/engine.py, checks/catalogue.py and checks/code.py - never each other.
"""
