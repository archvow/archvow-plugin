"""SPARK rules (SPK001-SPK014, the PySpark style guide and layer purity), on for a template with
`rule_sets: [pyspark]`: I/O only in I/O layers, actions only where execution is allowed, one place builds the
SparkSession, explicit joins and window frames, native functions before UDFs, the F/T/W imports, short chains.
"""

from __future__ import annotations

import ast
import io
import re
import tokenize

from archvow.checks.code import OPEN_CALLS, chain, receiver_name, root_name
from archvow.checks.engine import Checker, SourceFile
from archvow.foundation import logs
from archvow.imports import Names
from archvow.templates import Template

log = logs.get("check")


IO_ATTRS = {"read", "readStream", "write", "writeStream", "saveAsTable", "insertInto", "table"}
ACTION_ATTRS = {
    "collect", "toPandas", "show", "take", "first", "head", "count", "foreach",
    "foreachPartition", "toLocalIterator", "cache", "persist", "checkpoint", "unpersist",
}
GROUPED_PARENTS = {"groupBy", "groupby", "rollup", "cube", "pivot"}
FUNCTION_NAMESPACES = {"F", "T", "W"}
UDF_NAMES = {"udf", "pandas_udf", "udtf"}
# group/partition methods that run Python (pandas, Arrow) code: vectorised UDFs (SPK006)
PANDAS_METHODS = {"applyInPandas", "applyInPandasWithState", "mapInPandas", "mapInArrow", "applyInArrow"}
# RDD, streaming and MLlib reads and writes (SPK001), besides IO_ATTRS
IO_CALLS = {"textFile", "wholeTextFiles", "binaryFiles", "binaryRecords", "sequenceFile", "pickleFile",
            "hadoopFile", "newAPIHadoopFile", "saveAsTextFile", "saveAsSequenceFile", "saveAsPickleFile",
            "saveAsHadoopFile", "saveAsNewAPIHadoopFile", "socketTextStream", "textFileStream"}
# `.save(sc, path)` / `Model.load(sc, path)`: MLlib models take the SparkContext first
SPARK_CONTEXT_NAMES = {"sc", "spark_context", "sparkContext", "context"}
# spark.sql(...) statements that read or write storage
SQL_IO_RE = re.compile(r"^\s*(LOAD|CREATE|INSERT|DROP|ALTER|TRUNCATE|MSCK|REFRESH|CACHE)\b", re.IGNORECASE)
SPARK_ALIASES = {"pyspark.sql.functions": "F", "pyspark.sql.types": "T", "pyspark.sql.window": "W"}
LOG_FILE_CALLS = {"logging.FileHandler", "logging.handlers.RotatingFileHandler",  # a log file is file I/O (SPK001)
                  "logging.handlers.TimedRotatingFileHandler", "logging.handlers.WatchedFileHandler"}


def check_file(checker: Checker, file: SourceFile) -> None:
    """SPK001-SPK007 and SPK009-SPK014 on one file (checks/run.py gives this to the engine). The rules about
    where code lives need the file's layer; the others run on every file, adopted code included."""
    check_imports(checker, file.tree, file.rel)
    SparkVisitor(checker, file.template, file.layer, file.rel, file.names).visit(file.tree)


def check_imports(checker: Checker, tree: ast.Module, rel: str) -> None:
    """SPK007 on every file: functions as F, types as T, Window as W."""
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                _check_alias(checker, alias.name, alias.asname, rel, node.lineno)
        elif isinstance(node, ast.ImportFrom) and not node.level and node.module:
            for alias in node.names:
                _check_from(checker, node.module, alias.name, alias.asname, rel, node.lineno)


def _check_alias(checker: Checker, name: str, asname: str | None, rel: str, line: int) -> None:
    expected = SPARK_ALIASES.get(name)
    if expected and asname != expected:
        checker.add("SPK007", f"import {name} as {expected}", rel, line)


def _check_from(checker: Checker, base: str, name: str, asname: str | None, rel: str, line: int) -> None:
    full = f"{base}.{name}"
    if full in SPARK_ALIASES and asname != SPARK_ALIASES[full]:
        checker.add("SPK007", f"use `from {base} import {name} as {SPARK_ALIASES[full]}`", rel, line)
    elif base == "pyspark.sql.types" and name == "Row":
        checker.add("SPK007", "Row is not a type: use `from pyspark.sql import Row`", rel, line)
    elif base == "pyspark.sql" and name == "Window" and asname not in (None, "W"):
        checker.add("SPK007", "import Window as-is or as W", rel, line)
    elif base in SPARK_ALIASES:
        checker.add("SPK007", f"do not import names from {base}; use the {SPARK_ALIASES[base]}. "
                    "namespace (avoids shadowing builtins like sum/max)", rel, line)


def check_backslashes(checker: Checker, file: SourceFile) -> None:
    """SPK008 on one file: no backslash continuation (checks/run.py runs it after the other file checks)."""
    source, rel = file.source, file.rel
    try:
        tokens = list(tokenize.generate_tokens(io.StringIO(source).readline))
    except (tokenize.TokenError, SyntaxError):
        logs.swallowed(log, "check_backslashes: tokenize.TokenError, SyntaxError")
        return
    string_lines: set[int] = set()
    for tok in tokens:
        if tok.type == tokenize.STRING:
            string_lines.update(range(tok.start[0], tok.end[0]))
    for number, text in enumerate(source.splitlines(), start=1):
        if text.rstrip().endswith("\\") and number not in string_lines and not text.lstrip().startswith("#"):
            checker.add("SPK008", "backslash continuation; wrap the expression in parentheses", rel, number)


class SparkVisitor(ast.NodeVisitor):
    """PySpark rules. Those about where code lives (SPK001-003) need the file's layer; the others run on
    every file, in a layer or not (adopted code is checked before it is mapped)."""

    def __init__(self, checker: Checker, template: Template, layer: dict | None, rel: str, names: Names) -> None:
        self.c = checker
        self.layer = layer
        self.rel = rel
        self.names = names
        self.session_layer = template.data.get("session_layer")
        self.chain_seen: set[int] = set()
        self.joined: list[set[str]] = []  # per scope: names assigned from a join (SPK014)
        self.imported = _imported_names(names)

    def _io_free(self) -> bool:
        return self.layer is not None and not self.layer.get("io_allowed", False)

    def _io(self, what: str, node: ast.AST) -> None:
        if self._io_free():
            self.c.add("SPK001", f"{what} performs I/O; move it to an I/O layer "
                       f"(layer '{self.layer['name']}' is I/O-free)", self.rel, node.lineno,  # type: ignore[index]
                       node.col_offset)

    def visit_Module(self, node: ast.Module) -> None:
        self._scope(node)

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._scope(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._scope(node)

    def _scope(self, node: ast.AST) -> None:
        self.joined.append(_joins(node))
        self.generic_visit(node)
        self.joined.pop()

    def visit_Attribute(self, node: ast.Attribute) -> None:
        if node.attr in IO_ATTRS and receiver_name(node.value) not in FUNCTION_NAMESPACES \
                and self._spark_io_receiver(node):
            self._io(f"'.{node.attr}'", node)
        if node.attr in UDF_NAMES and receiver_name(node.value) == "F":
            self.c.add("SPK006", _udf_message(f"F.{node.attr}"), self.rel, node.lineno, node.col_offset)
        if (node.attr == "builder" and self.names.short_name(node.value) == "SparkSession"
                and self.layer is not None and self.layer["name"] != self.session_layer):
            self.c.add("SPK003", f"build the SparkSession only in '{self.session_layer}'",
                       self.rel, node.lineno, node.col_offset)
        self.generic_visit(node)

    def _spark_io_receiver(self, node: ast.Attribute) -> bool:
        """`.table`, `.saveAsTable`, `.insertInto`: once per chain (after `.read`/`.write` it is the same
        I/O), and `.table` not on a module other than pyspark (pyarrow's pa.table builds a table)."""
        if node.attr in {"read", "readStream", "write", "writeStream"}:
            return True
        inner = node.value
        while isinstance(inner, (ast.Attribute, ast.Call, ast.Subscript)):
            inner = inner.func if isinstance(inner, ast.Call) else inner.value
            if isinstance(inner, ast.Attribute) and inner.attr in {"read", "readStream", "write", "writeStream"}:
                return False
        if node.attr == "table":
            root = root_name(node.value)
            full = self.imported.get(root or "")
            if full and not full.startswith("pyspark"):
                return False  # pa.table(...) of pyarrow, a module function, not Spark
        return True

    def visit_Name(self, node: ast.Name) -> None:
        if isinstance(node.ctx, ast.Load) and self.names.short_name(node) in UDF_NAMES:
            self.c.add("SPK006", _udf_message(node.id, self.names.short_name(node)), self.rel, node.lineno,
                       node.col_offset)

    def visit_Call(self, node: ast.Call) -> None:
        called = self.names.full_name(node.func)
        if (called in OPEN_CALLS or called in LOG_FILE_CALLS or (called == "logging.basicConfig" and any(
                k.arg in ("filename", "filemode") for k in node.keywords))) and self._io_free():
            what = "writes a log file" if called not in OPEN_CALLS else "performs file I/O"
            self.c.add("SPK001", f"{ast.unparse(node.func)}() {what}" + (
                " (logs go to stderr: the cluster keeps them)" if called not in OPEN_CALLS else ""),
                       self.rel, node.lineno, node.col_offset)
        if isinstance(node.func, ast.Attribute):
            self._check_io_call(node, node.func)
            self._check_method(node, node.func)
            self._check_chain(node)
        self.generic_visit(node)

    def _check_io_call(self, node: ast.Call, func: ast.Attribute) -> None:
        """SPK001 beyond spark.read/write: RDD and streaming files, MLlib models and data, SQL statements."""
        if func.attr in IO_CALLS:
            self._io(f"'.{func.attr}()'", node)
        elif receiver_name(func.value) == "MLUtils" and func.attr.startswith(("load", "save")):
            self._io(f"MLUtils.{func.attr}()", node)
        elif func.attr in {"save", "load"} and node.args and _context_argument(node.args[0]):
            self._io(f"'.{func.attr}(sc, ...)'", node)
        elif (func.attr == "sql" and node.args and isinstance(node.args[0], ast.Constant)
              and isinstance(node.args[0].value, str) and SQL_IO_RE.match(node.args[0].value)):
            self._io(f"spark.sql(\"{node.args[0].value.split()[0].upper()} ...\")", node)

    def _check_method(self, node: ast.Call, func: ast.Attribute) -> None:
        attr = func.attr
        receiver = receiver_name(func.value)
        calls, _ = chain(node)
        parent = calls[1].func.attr if len(calls) > 1 else None  # type: ignore[union-attr]
        if (attr in ACTION_ATTRS and self.layer is not None and self.layer.get("lazy_only", False)
                and receiver not in FUNCTION_NAMESPACES and parent not in GROUPED_PARENTS):
            self.c.add("SPK002", f"'.{attr}()' triggers execution; layer '{self.layer['name']}' must stay lazy",
                       self.rel, node.lineno, node.col_offset)
        if attr == "join":
            self._check_join(node, func)
        if attr in PANDAS_METHODS:
            self.c.add("SPK006", f"'.{attr}()' runs pandas/Arrow code in Python workers: acceptable when "
                       "native functions cannot do it - prefer them", self.rel, node.lineno, node.col_offset)
        if attr == "partitionBy" and not node.args and not node.keywords and receiver in {"Window", "W"}:
            self.c.add("SPK011", "empty partitionBy(); use an aggregation instead", self.rel, node.lineno)
        if attr == "lit" and receiver == "F" and node.args:
            arg = node.args[0]
            if isinstance(arg, ast.Constant) and arg.value in ("", "NA", "N/A", "null", "NULL"):
                self.c.add("SPK012", f"F.lit({arg.value!r}) as an empty value; use F.lit(None)", self.rel, node.lineno)
        if attr == "withColumnRenamed":
            self.c.add("SPK013", "use F.col(...).alias(...) in a select", self.rel, node.lineno)
        if (attr in {"distinct", "dropDuplicates", "drop_duplicates"} and receiver not in FUNCTION_NAMESPACES
                and self._after_join(func.value)):
            self.c.add("SPK014", f"'.{attr}()' after a join can hide a join explosion; fix the join keys "
                       "or justify it", self.rel, node.lineno)

    def _after_join(self, value: ast.expr) -> bool:
        """The DataFrame comes from a join: in the same chain, or a name this scope assigned from one."""
        if _has_join(value):
            return True
        name = receiver_name(value)
        return bool(name and self.joined and name in self.joined[-1])

    def _check_join(self, node: ast.Call, func: ast.Attribute) -> None:
        receiver = func.value
        if isinstance(receiver, ast.Constant) or receiver_name(receiver) in {"path", "os", "sep"}:
            return  # str.join / os.path.join
        has_on = len(node.args) >= 2 or any(k.arg == "on" for k in node.keywords)
        if not has_on:
            return
        how = next((k.value for k in node.keywords if k.arg == "how"), None)
        if how is None:
            self.c.add("SPK004", "specify the join type as a keyword, e.g. how='inner'",
                       self.rel, node.lineno, node.col_offset)
        elif isinstance(how, ast.Constant) and str(how.value).lower() in {"right", "right_outer", "rightouter"}:
            self.c.add("SPK005", "swap the DataFrames and use how='left'", self.rel, node.lineno, node.col_offset)

    def _check_chain(self, node: ast.Call) -> None:
        if id(node) in self.chain_seen:
            return
        calls, root = chain(node)
        self.chain_seen.update(id(c) for c in calls)
        names = [c.func.attr for c in reversed(calls)]  # type: ignore[union-attr]
        max_chain = self.c.param("SPK009", "max_chain")
        if len(calls) > max_chain and receiver_name(root) not in FUNCTION_NAMESPACES:
            self.c.add("SPK009", f"chain of {len(calls)} calls (max {max_chain}); split into named steps",
                       self.rel, node.lineno)
        if (receiver_name(root) in {"Window", "W"} and "orderBy" in names
                and not {"rowsBetween", "rangeBetween"} & set(names)):
            self.c.add("SPK010", "add .rowsBetween(...) or .rangeBetween(...)", self.rel, node.lineno)


def _udf_message(shown: str, name: str | None = None) -> str:
    name = name or shown.split(".")[-1]
    if name == "pandas_udf":
        return f"'{shown}' creates a vectorised (pandas) UDF: acceptable when native functions cannot do it - prefer them"
    if name == "udtf":
        return f"'{shown}' creates a Python table function (UDTF): rows go through Python - prefer native functions"
    return f"'{shown}' creates a Python UDF: rows go through Python one by one - prefer native functions"


def _imported_names(names: Names) -> dict[str, str]:
    """Names bound by an import in the file, with what they import."""
    return names.imported()


def _context_argument(node: ast.expr) -> bool:
    """`sc` or `spark.sparkContext` given first: MLlib's save(sc, path) / load(sc, path)."""
    if isinstance(node, ast.Name):
        return node.id in SPARK_CONTEXT_NAMES
    return isinstance(node, ast.Attribute) and node.attr in SPARK_CONTEXT_NAMES


def _joins(scope: ast.AST) -> set[str]:
    """Names a scope assigns from an expression that joins (SPK014 looks for distinct() after a join)."""
    found: set[str] = set()
    for node in ast.walk(scope):
        if isinstance(node, (ast.Assign, ast.AnnAssign)) and node.value is not None and _has_join(node.value):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            found.update(t.id for t in targets if isinstance(t, ast.Name))
    return found


def _has_join(expr: ast.AST) -> bool:
    for node in ast.walk(expr):
        if (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "join"
                and not isinstance(node.func.value, ast.Constant)
                and receiver_name(node.func.value) not in {"path", "os", "sep"}):
            return True
    return False
