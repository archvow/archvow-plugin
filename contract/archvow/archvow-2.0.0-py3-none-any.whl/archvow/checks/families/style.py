"""STYLE rules (Palantir's sizes): a file and a function stay short (STY001, STY002), comments do not replace
names and docstrings (STY004), a shell script stays a launcher (STY003).
"""

from __future__ import annotations

import ast
import io
import tokenize

from archvow.checks.code import body_length
from archvow.checks.engine import IGNORED_DIRS, Checker, SourceFile
from archvow.foundation import logs

log = logs.get("check")


def check_file(checker: Checker, file: SourceFile) -> None:
    """STY001, STY002 and STY004 on one file (checks/run.py gives this to the engine)."""
    check_sizes(checker, file.tree, file.source, file.rel)


def check_sizes(checker: Checker, tree: ast.Module, source: str, rel: str) -> None:
    lines = source.count("\n") + (0 if source.endswith("\n") or not source else 1)
    max_file = checker.param("STY001", "max_lines")
    if lines > max_file:
        checker.add("STY001", f"{lines} lines (max {max_file}); split the module", rel, 1)
    max_fn = checker.param("STY002", "max_lines")
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            length = body_length(node)
            if length > max_fn:
                checker.add("STY002", f"'{node.name}' is {length} lines (max {max_fn}, docstring and signature not counted)", rel, node.lineno)
    check_comments(checker, source, rel)


def check_comments(checker: Checker, source: str, rel: str) -> None:
    """STY004: comment lines against code lines; good names and docstrings say the rest."""
    try:
        tokens = list(tokenize.generate_tokens(io.StringIO(source).readline))
    except (tokenize.TokenError, SyntaxError):
        logs.swallowed(log, "check_comments: tokenize.TokenError, SyntaxError")
        return
    skip = {tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT,
            tokenize.ENDMARKER}
    code = {line for tok in tokens if tok.type not in skip for line in range(tok.start[0], tok.end[0] + 1)}
    first_code = min(code, default=0)  # the comment block above the first code: licence, copyright, SPDX
    comments = {tok.start[0] for tok in tokens if tok.type == tokenize.COMMENT and tok.start[0] not in code
                and tok.start[0] > first_code
                and not tok.string.startswith(("#!", "# noqa", "# type:", "# archvow:", "# pragma"))}
    percent, minimum = checker.param("STY004", "max_percent"), checker.param("STY004", "min_code_lines")
    if len(code) >= minimum and len(comments) * 100 > percent * len(code):
        checker.add("STY004", f"{len(comments)} comment lines for {len(code)} lines of code (max {percent}%); "
                    "rename, extract a function or move the explanation into the docstring", rel, 1)


def check_scripts(checker: Checker) -> None:
    """STY003: a shell script stays short; its logic belongs in tested Python code."""
    max_lines = checker.param("STY003", "max_lines")
    for path in sorted(checker.root.rglob("*.sh")):
        rel = path.relative_to(checker.root)
        if any(part.startswith(".") or part in IGNORED_DIRS for part in rel.parts[:-1]):
            continue
        lines = len(path.read_text(encoding="utf-8", errors="replace").splitlines())
        if lines > max_lines:
            checker.add("STY003", f"{lines} lines (max {max_lines}); move the logic into a Python "
                        "component and keep the script a launcher", rel.as_posix(), 1)
