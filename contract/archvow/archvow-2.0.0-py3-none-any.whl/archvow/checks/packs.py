"""The packs of a project, checked (layer 2): ARCH060, a copy that differs from what `pack add` / `pack update`
recorded; ARCH009, a pack this archvow cannot use (its archvow range, a rule or an agent profile it cannot read).
"""

from __future__ import annotations

from archvow import agents
from archvow.checks.engine import Checker
from archvow.foundation.errors import PackError
from archvow.packs import rules as pack_rules
from archvow.packs import store as packs


def run_packs(checker: Checker) -> None:
    for name, why in packs.changed_by_hand(checker.root, checker.manifest):
        checker.add("ARCH060", f"pack {name}: {why} - an architect runs `archvow pack update {name}` (or "
                    f"`pack add`), never edits the copy", (packs.PROJECT_PACKS / name).as_posix())
    for pack in packs.project_packs(checker.root):
        where = (packs.PROJECT_PACKS / pack.name / "pack.yaml").as_posix()
        try:
            packs.require_fit(pack)
            pack_rules.pack_rules(pack.root)
            for profile in sorted(pack.agents.glob("*/agent.yaml")):
                agents.read(profile.parent, pack.name)
        except PackError as error:
            checker.add("ARCH009", f"pack {pack.name}: {error}", where)
