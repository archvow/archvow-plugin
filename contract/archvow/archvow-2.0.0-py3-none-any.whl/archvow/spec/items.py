"""An item of the spec by its id (clean_orders.H1, R2...), and the next free id.
"""

from __future__ import annotations

import re
from pathlib import Path

from archvow.foundation.errors import SpecError
from archvow.model import store
from archvow.model.spec import (
    find_component,
    stamp,
    to_accept,
)
from archvow.templates import (
    edge_case_text,
    load_template,
    template_name,
)

ITEM_ID = re.compile(r"^[a-z][a-z0-9_]*\.(?i:H|INV)\d+$|^[Rr]\d+$")


def find_item(data: dict, item_id: str) -> tuple[str, dict]:
    """A hazard (clean_orders.H1), an invariant (clean_orders.INV1) or a project rule (R1), by its id."""
    wanted = store.normalise_item_id(item_id)
    match = store.ITEM_ID_RE.match(wanted)
    if match:
        wanted = f"{match.group('scope')}.{match.group('kind').upper()}{match.group('n')}"
        kind = "hazard" if match.group("kind").upper() == "H" else "invariant"
    elif re.fullmatch(r"(?i)R\d+", wanted):
        wanted, kind = wanted.upper(), "rule"
    else:
        raise SpecError(f"{item_id!r} is not an id: a hazard <component>.H1, an invariant <component>.INV1 "
                        "or a rule R1")
    pool = {"hazard": data.get("hazards"), "invariant": data.get("invariants"), "rule": data.get("project_rules")}
    for item in pool[kind] or []:
        if str(item.get("id", "")) == wanted:
            return kind, item
    raise SpecError(f"no {kind} {wanted} (archvow show <component> lists them)")


def template_question_count(root: Path, data: dict, component_id: str) -> int:
    """How many of a component's questions come from its template (the first ones)."""
    container, comp = find_component(data, component_id)
    template = load_template(template_name(container)[0], root)
    initial = next((c for c in template.data.get("initial_components", []) or [] if c.get("id") == comp["id"]), None)
    source = initial if initial is not None else template.type_of(comp)
    texts = [edge_case_text(q) for q in source.get("edge_cases") or []]
    decisions = comp.get("decisions", []) or []
    count = min(len(texts), len(decisions))
    known = set(texts)
    while count and decisions[count - 1].get("question") not in known:  # a component made before the
        count -= 1  # template gained a question: what follows its own questions is a person's
    return count


def _next_id(items: list[dict], scope: str | None, kind: str) -> str:
    """Hazards and invariants are numbered per component: clean_orders.H1, clean_orders.INV2."""
    return store.next_item_id(items, scope, kind)


def keep(root: Path, item: dict) -> None:
    """A person changed or answered an item the AI added: it is the team's now."""
    if to_accept(item):
        item["accepted"] = stamp(root)
