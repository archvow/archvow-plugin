"""What the AI added, kept by a person: a question, a hazard (with its invariants), a rule.
"""

from __future__ import annotations

from pathlib import Path

from archvow.foundation.errors import SpecError
from archvow.model import store
from archvow.model.spec import (
    find_component,
    stamp,
    to_accept,
)
from archvow.spec.items import find_item
from archvow.spec.rules import _find_rule


def accept_question(root: Path, component_id: str, number: int) -> dict:
    """A person keeps a question the AI asked, to answer later (answering it keeps it too)."""
    data = store.load(root)
    _, comp = find_component(data, component_id)
    decisions = comp.get("decisions", []) or []
    if not 1 <= number <= len(decisions):
        raise SpecError(f"'{component_id}' has no question {number} (it has 1..{len(decisions)})")
    entry = decisions[number - 1]
    if not to_accept(entry):
        raise SpecError(f"question {number} of {component_id} is not an AI's question waiting for a person "
                        f"(archvow show {component_id})")
    entry["accepted"] = stamp(root)
    store.save(root, data)
    return entry


def accept_hazard(root: Path, hazard_id: str) -> dict:
    """A person keeps a hazard the AI added, with the invariants the AI added to prevent it."""
    data = store.load(root)
    _, hazard = find_item(data, hazard_id)
    guards = [i for i in data.get("invariants", []) or [] if hazard["id"] in (i.get("mitigates") or []) and to_accept(i)]
    if not to_accept(hazard) and not guards:
        raise SpecError(f"{hazard['id']} has nothing the AI added waiting for a person (archvow show {hazard['id']})")
    signed = stamp(root)
    for item in ([hazard] if to_accept(hazard) else []) + guards:
        item["accepted"] = signed
    store.save(root, data)
    return {**hazard, "invariants": [i["id"] for i in guards]}


def accept_rule(root: Path, rule_id: str) -> dict:
    """A person keeps a rule the AI added."""
    data = store.load(root)
    rule = _find_rule(data, rule_id)
    if not to_accept(rule):
        raise SpecError(f"{rule['id']} is not a rule the AI added waiting for a person (archvow show {rule['id']})")
    rule["accepted"] = stamp(root)
    store.save(root, data)
    return rule
