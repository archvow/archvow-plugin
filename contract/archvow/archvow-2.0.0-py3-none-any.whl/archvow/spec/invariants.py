"""`archvow invariant add|edit|remove`: what must always hold so a hazard cannot happen, and how it is
verified.
"""

from __future__ import annotations

from pathlib import Path

from archvow.foundation.errors import SpecError
from archvow.foundation.text import a_or_an, one_line, says_nothing
from archvow.model import store
from archvow.model.spec import (
    SEVERITIES,
    ai_origin,
    decision_statement,
    find_component,
    required_text,
    stamp,
)
from archvow.spec.items import _next_id, find_item, keep
from archvow.templates import (
    Template,
    load_template,
    template_name,
)

VERIFY_METHODS = ("static", "example_test", "property_test", "runtime", "model_check", "proof")


def edit_invariant(root: Path, invariant_id: str, statement: str | None = None, verify: str | None = None) -> dict:
    """Change an invariant's words or how it is proven; its id, its hazards and its test marker stay."""
    data = store.load(root)
    _, inv = find_item(data, invariant_id)
    if statement is None and verify is None:
        raise SpecError("say what changes: the words in quotes, --verify, or both")
    if statement is not None:
        if inv.get("from_decision"):
            raise SpecError(f"{inv['id']} is decision {inv['from_decision']}: change the decision (archvow decision "
                            f"make {inv.get('component')} {inv['from_decision']} \"...\")")
        required_text(statement, "the invariant's statement")
        if says_nothing(statement):
            raise SpecError(f"\"{statement.strip()}\" protects nothing: remove the invariant instead "
                            f"(archvow invariant remove {inv['id']})")
        others = dict(data, invariants=[i for i in data.get("invariants") or [] if i is not inv])
        same = _same_invariant(others, statement, inv.get("mitigates") or [], None, inv.get("component"))
        if same:
            raise SpecError(f"{same['id']} already says this")
        inv["statement"] = one_line(statement)
    if verify is not None:
        if verify not in VERIFY_METHODS:
            raise SpecError(f"verify must be one of {', '.join(VERIFY_METHODS)}")
        container = (data["containers"] or [{}])[0]
        floor = load_template(template_name(container)[0], root).data.get("verification_floor") or {}
        for hid in inv.get("mitigates") or []:
            severity = next((h.get("severity") for h in data.get("hazards", []) if h["id"] == hid), None)
            allowed = floor.get(severity) or []
            if allowed and verify not in allowed:
                raise SpecError(f"{hid} is {severity}: a {verify} is not enough (ARCH037), it needs one of "
                                f"{', '.join(allowed)}")
        inv["verify"] = verify
    keep(root, inv)
    inv.update(stamp(root))
    inv.pop("review", None)
    store.save(root, data)
    return inv


def remove_invariant(root: Path, invariant_id: str) -> dict:
    """Remove an invariant - never one that is the last guard of a critical or high hazard."""
    data = store.load(root)
    _, inv = find_item(data, invariant_id)
    others = check_invariant_removable(data, inv)
    data["invariants"] = others
    store.save(root, data)
    return inv


def check_invariant_removable(data: dict, inv: dict) -> list[dict]:
    """The other invariants, if `inv` is not the last guard of a critical or high hazard."""
    others = [i for i in data.get("invariants", []) or [] if i is not inv]
    for hid in inv.get("mitigates") or []:
        hazard = next((h for h in data.get("hazards", []) or [] if h["id"] == hid), None)
        guarded = any(hid in (i.get("mitigates") or []) for i in others)
        if hazard and hazard.get("severity") in ("critical", "high") and not guarded:
            raise SpecError(f"{inv['id']} is the only guard of {hid} ({hazard['severity']}: "
                            f"{hazard.get('description')}): add another first (archvow invariant add "
                            f"{hazard.get('component') or 'system'} \"...\" --prevents {hid}), or remove the "
                            f"hazard (archvow hazard remove {hid})")
    return others


def weakest_verification(template: Template, severity: str | None) -> str:
    """The proof a severity accepts with the least effort: a test, or a property test for critical."""
    allowed = (template.data.get("verification_floor", {}) or {}).get(severity or "")
    for method in ("example_test", "property_test", "runtime", "static", "model_check", "proof"):
        if not allowed or method in allowed:
            return method
    return "property_test"


def add_invariant(root: Path, statement: str | None, *, verify: str | None = None, mitigates: list[str] | None = None,
                  component: str | None = None, evidence: str | None = None,
                  rule: str | None = None, from_decision: int | None = None, added_by: str | None = None,
                  why: str | None = None) -> dict:
    """Record an invariant. Without `mitigates`: the component's one hazard that has no invariant
    yet. Without `verify`: the weakest proof its severity accepts (`weakest_verification`).
    `from_decision` N: the invariant is decision N of the component - no words of its own, its answer is
    shown (and follows the decision), and a test marked decision(N) proves it when an example test is enough.
    Refused: words that say nothing ("none"), the same words already protecting that hazard, a verification
    weaker than the hazard's severity needs."""
    data = store.load(root)
    comp = None
    if component:
        container, comp = find_component(data, component)
    else:
        container = data["containers"][0]
    if from_decision is not None:
        if comp is None:
            raise SpecError("--from-decision needs a component: archvow invariant add <component> --from-decision N")
        decisions = comp.get("decisions") or []
        if not 1 <= int(from_decision) <= len(decisions):
            raise SpecError(f"'{component}' has no decision {from_decision} (it has 1..{len(decisions)})")
        if not (decisions[int(from_decision) - 1].get("answer") or "").strip():
            raise SpecError(f"decision {from_decision} of {component} is not made yet: archvow decision make "
                            f"{component} {from_decision} \"...\"")
        if says_nothing(decisions[int(from_decision) - 1]["answer"]):
            raise SpecError(f"decision {from_decision} of {component} says \"{decisions[int(from_decision) - 1]['answer']}\": "
                            "it protects nothing - answer the safety question not applicable instead "
                            f"(archvow hazard dismiss {component} <S-number>)")
        statement = decision_statement(data, comp, int(from_decision))
    required_text(statement, "the invariant's statement")
    if says_nothing(statement):
        raise SpecError(f"an invariant says what is always true; \"{statement.strip()}\" protects nothing. If nothing "
                        f"can go wrong here, answer the safety question not applicable instead: archvow hazard "
                        f"dismiss {component or 'system'} <S-number> \"<why>\"")
    hazards = data.get("hazards", []) or []
    if not mitigates:
        guarded = {h for inv in data.get("invariants", []) or [] for h in inv.get("mitigates", []) or []}
        candidates = [h["id"] for h in store.hazards(data) if h.get("component") == component
                      and h["id"] not in guarded]
        if len(candidates) != 1:
            where = component or "system"
            raise SpecError(f"say which hazard it prevents: --prevents <component>.H<n> ({where} has "
                            + (f"{len(candidates)} without an invariant: {', '.join(candidates)})" if candidates
                               else "no hazard without an invariant)"))
        mitigates = candidates
    known = {h["id"] for h in data.get("hazards", [])}
    mitigates = [store.normalise_item_id(h) if "." in h else store.qualify(component, h.upper()) for h in mitigates]
    unknown = [h for h in mitigates if h not in known]
    if unknown:
        raise SpecError(f"unknown hazard(s): {', '.join(unknown)}")
    if verify is None:  # after the ids are qualified: --prevents H1 is the component's H1, and its severity counts
        ranked = [s for s in SEVERITIES if s in {h.get("severity") for h in hazards if h.get("id") in mitigates}]
        template = load_template(template_name(container)[0], root)
        verify = weakest_verification(template, ranked[0] if ranked else None)
    if verify not in VERIFY_METHODS:
        raise SpecError(f"verify must be one of {', '.join(VERIFY_METHODS)}")
    same = _same_invariant(data, statement, mitigates, from_decision, component)
    if same:
        raise SpecError(f"{same['id']} already says this and protects {', '.join(same.get('mitigates') or [])} - "
                        "nothing to add")
    floor = (load_template(template_name(container)[0], root).data.get("verification_floor") or {})
    warnings = []
    for hid in mitigates:
        severity = next((h.get("severity") for h in data.get("hazards", []) if h["id"] == hid), None)
        allowed = floor.get(severity) or []
        if allowed and verify not in allowed:
            warnings.append(f"{hid} is {severity}: {a_or_an(verify)} is not enough, `archvow check` will fail (ARCH037) - "
                            f"it needs one of {', '.join(allowed)}, e.g. --verify {allowed[0]}")
    if verify in ("model_check", "proof") and not evidence:
        raise SpecError(f"verify={verify} needs --evidence (path of the model or proof file)")
    if verify == "static" and not rule:
        raise SpecError("verify=static needs --rule (the archvow rule add code that enforces it)")
    invariants = data.setdefault("invariants", [])
    entry = {"id": _next_id(invariants, component, "INV"), "statement": one_line(statement), "component": component,
             "mitigates": mitigates, "verify": verify}
    if from_decision is not None:
        entry["from_decision"] = int(from_decision)  # saved as the link only: the statement is the decision's
    if evidence:
        entry["evidence"] = evidence
    if rule:
        entry["rule"] = rule
    entry.update(stamp(root))
    entry.update(ai_origin(added_by, why))
    invariants.append(entry)
    store.save(root, data)
    return {**entry, **({"warnings": warnings} if warnings else {})}




def _same_invariant(data: dict, statement: str, mitigates: list[str], from_decision: int | None,
                    component: str | None) -> dict | None:
    """An invariant that already says this (or links the same decision) for one of these hazards."""
    words = " ".join(str(statement).lower().split())
    for inv in data.get("invariants") or []:
        if not set(inv.get("mitigates") or []) & set(mitigates):
            continue
        if from_decision is not None and inv.get("component") == component and inv.get("from_decision") == from_decision:
            return inv
        if " ".join(str(inv.get("statement") or "").lower().split()) == words:
            return inv
    return None
