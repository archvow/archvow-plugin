"""`archvow rule add|edit|remove`: rules of what components do, in plain words.
"""

from __future__ import annotations

from pathlib import Path

from archvow.foundation.errors import SpecError
from archvow.model import store
from archvow.model.spec import (
    ai_origin,
    find_component,
    required_text,
    stamp,
)
from archvow.spec.items import keep
from archvow.templates import (
    load_template,
    template_name,
)


def add_rule(root: Path, text: str, *, components: list[str] | None = None, type_name: str | None = None,
             all_components: bool = False, source: dict | None = None, added_by: str | None = None,
             why: str | None = None) -> dict:
    """Record a rule in your own words (best: "Given ..., when ..., then ..."), for one or several
    components, every component of a type (future ones too) or all components. One test each."""
    if sum(bool(x) for x in (components, type_name, all_components)) != 1:
        raise SpecError("say who the rule applies to: components (a,b), --type <type> or --all")
    data = store.load(root)
    if components:
        for cid in components:
            find_component(data, cid)
        scope: dict = {"components": list(dict.fromkeys(components))}
    elif type_name:
        types = {t for c in data["containers"] for t in load_template(template_name(c)[0], root).component_types}
        if type_name not in types:
            raise SpecError(f"unknown component type '{type_name}' (types: {', '.join(sorted(types))})")
        scope = {"type": type_name}
    else:
        scope = {"all": True}
    rules = data.setdefault("project_rules", [])
    number = max((int(r["id"][1:]) for r in rules if str(r.get("id", "")).startswith("R")), default=0) + 1
    entry = {"id": f"R{number}", "text": required_text(text, "the rule"), "scope": scope, **stamp(root),
             **({"source": source} if source else {}), **ai_origin(added_by, why)}
    rules.append(entry)
    store.save(root, data)
    return entry


def _find_rule(data: dict, rule_id: str) -> dict:
    wanted = str(rule_id).upper()
    wanted = wanted if wanted.startswith("R") else f"R{wanted}"
    for rule in data.get("project_rules") or []:
        if rule.get("id") == wanted:
            return rule
    known = ", ".join(r["id"] for r in data.get("project_rules") or []) or "none yet"
    raise SpecError(f"no rule {rule_id} (rules: {known}; archvow show lists them)")


def edit_rule(root: Path, rule_id: str, text: str) -> dict:
    data = store.load(root)
    rule = _find_rule(data, rule_id)
    rule["text"] = required_text(text, "the rule")
    keep(root, rule)
    rule.update(stamp(root))
    store.save(root, data)
    return rule


def remove_rule(root: Path, rule_id: str) -> dict:
    data = store.load(root)
    rule = _find_rule(data, rule_id)
    data["project_rules"] = [r for r in data["project_rules"] if r is not rule]
    store.save(root, data)
    return rule
