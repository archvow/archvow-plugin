"""The init answers: their defaults and choices, how one is checked, what follows from them (derive),
and the AI's automatic approval they turn on.
"""

from __future__ import annotations

import re
from pathlib import Path

from jinja2 import Environment, StrictUndefined
from jinja2.sandbox import SandboxedEnvironment

from archvow import agents
from archvow.foundation.errors import SpecError
from archvow.model import store
from archvow.templates import (
    Template,
    load_template,
    template_name,
)

PACKAGE_RE = re.compile(r"^[a-z][a-z0-9_]*$")


DEFAULT_TEMPLATE = "archvow/python-app"


def verbatim_prefixes(template: Template) -> tuple[str, ...]:
    """The folders of files/ copied exactly as they are, .j2 included: `verbatim_folders` (a folder
    and everything under it)."""
    return tuple(f"{str(folder).strip('/')}/" for folder in template.data.get("verbatim_folders") or [])


def _env() -> Environment:
    """Templates are data: a template's files and expressions render in Jinja's sandbox, so a changed
    template file in a merge request cannot run Python on the architect's machine."""
    return SandboxedEnvironment(undefined=StrictUndefined, keep_trailing_newline=True, autoescape=False)


def resolved_choices(template: Template, question: dict) -> list | None:
    """Static `choices`, the rule families, or None for `choices_from: agents` (any agent name: checked as a
    name, the packs' agents offered)."""
    source = question.get("choices_from")
    if not source:
        return question.get("choices")
    if source == "rule_families":  # the families `rules` chooses from: their names, not the code prefixes
        return [*template.selectable_families(), "all", "none"]
    if source == "agents":
        return None
    raise SpecError(f"question '{question.get('id')}': choices_from {source} - only rule_families or agents")


def answers_with_defaults(template: Template, answers: dict) -> dict:
    result = {}
    for question in template.data.get("questions", []):
        qid = question["id"]
        result[qid] = check_answer(template, question,
                                   answers.get(qid, question_default(template, question, result)))
    unknown = set(answers) - set(result)
    if unknown:
        raise SpecError(f"unknown answer(s): {', '.join(sorted(unknown))}")
    return result


def question_default(template: Template, question: dict, known: dict | None = None) -> object:
    """A question's default: the company's, else `default_from` (it follows an earlier answer, e.g.
    sandbox: yes in mode strict), else `default`."""
    company = (template.data.get("questions_defaults") or {}).get(question["id"])
    if company is not None:
        return company
    for other, values in (question.get("default_from") or {}).items():
        earlier = (known or {}).get(other)
        if earlier is None:  # not answered yet: that question's own default
            earlier = next((q.get("default") for q in template.data.get("questions", []) if q["id"] == other), None)
        if str(earlier) in (values or {}):
            return values[str(earlier)]
    default = question.get("default")
    if default is None and question.get("choices_from") == "rule_families":
        return ",".join(template.recommended_families())  # every family but those marked default: false
    return default


def split_rules(template: Template, chosen: list[str]) -> tuple[list[str], list[str]]:
    """The one `rules` answer as the manifest keeps it: the code families (`families`: ARCH, STYLE,
    SPARK..., or all) and the compliance ones (`compliance`: the regimes - dora, gdpr... - tst, or none)."""
    every = template.selectable_families()
    names = every if "all" in chosen else [c for c in chosen if c != "none"]
    code = [n for n in names if n not in template.COMPLIANCE]
    compliance = [n.lower() for n in names if n in template.COMPLIANCE]
    all_code = [n for n in every if n not in template.COMPLIANCE]
    families = ["all"] if code == all_code else (code or ["none"])
    return families, compliance or ["none"]


def rules_context(template: Template, chosen: list[str]) -> dict:
    """What the template's files read of the `rules` answer: `families`, `compliance` and `privacy` (the names
    of the privacy regimes on: GDPR, US-PRIVACY...). A template that asks no `rules`: its recommended families."""
    families, compliance = split_rules(template, chosen or template.recommended_families())
    return {"families": families, "compliance": compliance,
            "privacy": [r.name for r in template.regimes if r.id in compliance and r.kind == "privacy"]}


def rules_answer(template: Template, data: dict) -> str:
    """The `rules` answer back from what the manifest keeps (init --force keeps it)."""
    every = template.selectable_families()
    families = data.get("families")
    if families is None or "all" in families:
        code = [n for n in every if n not in template.COMPLIANCE]
    else:
        code = [str(f).upper() for f in families if f != "none"]
    compliance = [str(c).upper() for c in data.get("compliance") or [] if c != "none"]
    names = [n for n in every if n in code or n in compliance]
    if names == every:
        return "all"
    return ",".join(names) or "none"


def check_answer(template: Template, question: dict, value: object) -> object:
    """One answer, checked against its question (required, choices, pattern) and normalised."""
    qid = question["id"]
    if value is None or str(value).strip() == "":
        if question.get("required"):
            raise SpecError(f"'{qid}' is required - {question.get('prompt', qid)}: pass -a {qid}=...")
        value = ""
    if isinstance(value, str):
        value = " ".join(value.split())
    choices = resolved_choices(template, question)
    if question.get("multiple"):
        items = value if isinstance(value, list) else [v.strip() for v in str(value).split(",") if v.strip()]
        if question.get("choices_from") == "rule_families":  # family names in any case: arch,spark
            items = [v if v.lower() in ("all", "none") else v.upper() for v in (str(i) for i in items)]
            items = [v.lower() if v.lower() in ("all", "none") else v for v in items]
        unknown = [v for v in items if choices and v not in choices]
        if unknown:
            raise SpecError(f"answer '{qid}': {', '.join(unknown)} not in {choices}")
        if question.get("choices_from") == "agents":
            bad = [str(v) for v in items if v != "none" and not agents.NAME_RE.match(str(v))]
            if bad:
                raise SpecError(f"answer '{qid}': {', '.join(bad)} - an agent's name is lowercase letters, digits, "
                                "- and _ (claude-code, copilot, acme-assistant); archvow catalog lists the agents "
                                "it has a profile for, any other gets the standard one")
        for alone in ("none", "all"):
            if alone in items and len(items) > 1:
                raise SpecError(f"answer '{qid}': '{alone}' cannot be combined with other values")
        return list(dict.fromkeys(items))
    if choices and str(value) not in [str(c) for c in choices]:
        raise SpecError(f"answer '{qid}={value}' not in {choices}",
                        hint=f"give one of them: -a {qid}={choices[0]} (on an existing project, with init --force)")
    pattern = question.get("pattern")
    if pattern and not re.fullmatch(pattern, str(value)):
        raise SpecError(f"answer '{qid}={value}' is invalid: {question.get('pattern_hint', pattern)}")
    return value


DORA_APPROVERS = ("DORA needs two people who can approve guard changes, or a group (separation of duties: "
                  "an author never approves their own change) - e.g. -a architects=\"@first @second\" or "
                  "-a architects=@acme/architects")


def dora_approvers_problem(template: Template, answers: dict) -> str:
    """With DORA among the rules, a single architect who is not a group: what to do, else ''."""
    rules = answers.get("rules")
    if rules is None:
        rules = question_default(template, next((q for q in template.data.get("questions", [])
                                                 if q["id"] == "rules"), {"id": "rules"}))
    chosen = [str(r).strip().upper() for r in (rules if isinstance(rules, list) else str(rules or "").split(","))]
    if not ({"ALL", "DORA"} & set(chosen)) or "DORA" not in template.selectable_families():
        return ""
    owners = str(answers.get("architects") or "").split()
    return "" if len(owners) >= 2 or any("/" in o for o in owners) else DORA_APPROVERS


def derive(template: Template, context: dict) -> dict:
    """Values computed from the answers (`derived:`), after the answers are checked together
    (`answer_rules:`): e.g. ci_tool = the platform's own CI when `ci` is `auto`."""
    env = _env()
    for rule in template.data.get("answer_rules") or []:
        if not env.compile_expression(rule["check"])(**context):
            raise SpecError(env.from_string(rule["message"]).render(**context))
    derived = {}
    for name, expression in (template.data.get("derived") or {}).items():
        derived[name] = env.compile_expression(expression)(**context, **derived)
    return derived


def auto_approval(template: Template, context: dict) -> dict:
    """What the approved AI assistants may do without asking (`auto_approve` yes), from the template's
    `auto_approved`: {"commands": ["archvow check", "ruff check *", ...], "edit": ["src/acme", "tests"],
    "claude": [Claude Code allow rules], "cursor": [Cursor CLI allow rules]}. Empty when the answer is no."""
    if str(context.get("auto_approve", "no")) != "yes":
        return {"commands": [], "edit": [], "claude": [], "cursor": []}
    spec = template.data.get("auto_approved") or {}
    env = _env()
    commands = [env.from_string(str(c)).render(**context) for c in spec.get("commands") or []]
    if str(context.get("mode") or "strict") != "strict":  # guided/free: the AI proposes, a person decides
        commands.append("archvow decision propose *")
    commands = list(dict.fromkeys(commands))
    edit = [env.from_string(str(e)).render(**context).strip("/") for e in spec.get("edit") or []]
    claude, cursor = [], []
    for command in commands:
        any_args = command.endswith(" *")
        words = command.removesuffix(" *")
        claude.append(f"Bash({words}:*)" if any_args else f"Bash({words})")
        base, _, rest = words.partition(" ")
        cursor.append(f"Shell({base}:{rest}*)" if any_args else
                      (f"Shell({base}:{rest})" if rest else f"Shell({base})"))
    claude += [f"Edit({folder}/**)" for folder in edit]
    cursor += [f"Write({folder}/**)" for folder in edit]
    return {"commands": commands, "edit": edit, "claude": list(dict.fromkeys(claude)),
            "cursor": list(dict.fromkeys(cursor))}


def auto_approve_notes(root: Path) -> list[str]:
    """Lines init prints when auto_approve is yes and an approved assistant keeps its permissions
    outside the project: where to add the commands, and the commands."""
    data = store.load(root)
    if str((data.get("init_answers") or {}).get("auto_approve", "no")) != "yes":
        return []
    known = agents.profiles(root)
    elsewhere = {t: known[t].permissions for t in data.get("ai_tools") or [] if t in known and known[t].permissions}
    if not elsewhere:
        return []
    container = data["containers"][0]
    template = load_template(template_name(container)[0], root)
    context = {**template.data.get("context", {}), **(data.get("init_answers") or {}),
               "mode": data.get("mode") or "strict", "src": "src", "package": container.get("package", "")}
    auto = auto_approval(template, context)
    lines = [f"{tool}: {where}" for tool, where in elsewhere.items()]
    shown = {}  # "x" and "x *" -> "x ..." (any arguments); an exact command stays as it is
    for command in auto["commands"]:
        words = command.removesuffix(" *")
        shown[words] = shown.get(words, False) or command.endswith(" *")
    lines.append("commands (... = any arguments): " + ", ".join(f"{w} ..." if a else w for w, a in shown.items()))
    lines.append("edits: " + ", ".join(f"{e}/" for e in auto["edit"]))
    return lines
