"""`archvow decision make|add` and the AI's proposals accepted: answers to a component's questions, one
component or a whole type.
"""

from __future__ import annotations

from pathlib import Path

from archvow import toreview
from archvow.foundation.errors import SpecError
from archvow.foundation.text import one_line
from archvow.model import store
from archvow.model.spec import (
    find_component,
    required_text,
    stamp,
)
from archvow.proposals import ProposalError, by_question, take
from archvow.templates import (
    edge_case_suggestion,
    edge_case_text,
    load_template,
    template_name,
)


def suggested_answer(root: Path, data: dict, component_id: str, number: int) -> str | None:
    """The template's suggested answer to question `number` of a component, if it has one."""
    container, comp = find_component(data, component_id)
    decisions = comp.get("decisions", []) or []
    if not 1 <= number <= len(decisions):
        return None
    template = load_template(template_name(container)[0], root)
    return template.suggested_answers(comp).get(decisions[number - 1].get("question"))


def decide(root: Path, component_id: str, question: int | str, answer: str, source: dict | None = None,
           origin: str | None = None) -> dict:
    """Answer an edge-case question (or add a new question with its answer)."""
    data = store.load(root)
    _, component = find_component(data, component_id)
    decisions = component.setdefault("decisions", [])
    if not answer.strip():
        raise SpecError("an answer is required")
    if isinstance(question, int) or str(question).isdigit():
        index = int(question) - 1
        if not 0 <= index < len(decisions):
            raise SpecError(f"'{component_id}' has no question {question} (it has 1..{len(decisions)}; "
                            f"see archvow show {component_id})")
        before = (decisions[index].get("answer") or "").strip()
        if before and before != one_line(answer):
            for inv in data.get("invariants") or []:  # the invariants that ARE this decision: their hazards
                if inv.get("component") == component_id and inv.get("from_decision") == index + 1:
                    for hazard in data.get("hazards") or []:
                        if hazard["id"] in (inv.get("mitigates") or []):
                            hazard["review"] = f"decision {index + 1} changed on {toreview.today()}"
        decisions[index]["answer"] = one_line(answer)
        decisions[index].update(stamp(root))
        decisions[index].pop("origin", None)
        decisions[index].pop("review", None)  # recorded again: looked at after the component's change
        if origin:  # the AI proposed it, a person accepted it (archvow decision accept)
            decisions[index]["origin"] = origin
        decision = decisions[index]
    else:
        decision = {"question": required_text(question, "the question"), "answer": one_line(answer), **stamp(root),
                    **({"source": source} if source else {})}
        decisions.append(decision)
    store.save(root, data)
    return decision


def type_questions(root: Path, data: dict, type_name: str) -> list[tuple[str, str | None]]:
    """[(question, suggested answer)] a component type asks, numbered from 1 like archvow show."""
    container = (data.get("containers") or [None])[0]
    if container is None:
        raise SpecError("no container in this project")
    template = load_template(template_name(container)[0], root)
    if type_name not in template.component_types:
        raise SpecError(f"unknown component type '{type_name}' (types: {', '.join(sorted(template.component_types))})")
    return [(edge_case_text(q), edge_case_suggestion(q)) for q in template.type_of({"type": type_name}).get("edge_cases") or []]


def decide_for_type(root: Path, type_name: str, number: int, answer: str | None) -> dict:
    """Answer question `number` once for every component of a type, today and later. A component that
    already has its own answer keeps it. answer None: the template's suggestion. Returns the entry with
    `components` (who takes it) and `own` (who keeps their own answer)."""
    data = store.load(root)
    asked = type_questions(root, data, type_name)
    if not 1 <= number <= len(asked):
        listing = "; ".join(f"{n}. {q}" for n, (q, _) in enumerate(asked, 1))
        raise SpecError(f"a {type_name} has no question {number} (it has 1..{len(asked)}: {listing})")
    question, suggested = asked[number - 1]
    if answer is None:
        if not suggested:
            raise SpecError(f"question {number} of a {type_name} has no suggested answer: give yours "
                            f"(archvow decision make --type {type_name} {number} \"...\")")
        answer = suggested
    entry = {"type": type_name, "question": question, "answer": one_line(answer), **stamp(root)}
    shared = [a for a in data.get("type_answers") or []
              if not (a.get("type") == type_name and a.get("question") == question)]
    data["type_answers"] = [*shared, entry]
    own, takes = _type_users(data, type_name, question)
    store.save(root, data)
    return {**entry, "number": number, "components": takes, "own": own}


def unset_for_type(root: Path, type_name: str, number: int) -> dict:
    """Stop answering question `number` for the whole type: each component answers it on its own again."""
    data = store.load(root)
    asked = type_questions(root, data, type_name)
    if not 1 <= number <= len(asked):
        raise SpecError(f"a {type_name} has no question {number} (it has 1..{len(asked)})")
    question = asked[number - 1][0]
    found = [a for a in data.get("type_answers") or [] if a.get("type") == type_name and a.get("question") == question]
    if not found:
        raise SpecError(f"question {number} of a {type_name} is not answered for the whole type")
    _, takes = _type_users(data, type_name, question)
    data["type_answers"] = [a for a in data["type_answers"] if a not in found]
    if not data["type_answers"]:
        data.pop("type_answers")
    store.save(root, data)
    return {"type": type_name, "question": question, "number": number, "components": takes}


def _type_users(data: dict, type_name: str, question: str) -> tuple[list[str], list[str]]:
    """(components of the type with their own answer to it, components that take the type's answer)."""
    own, takes = [], []
    for container in data.get("containers") or []:
        for comp in container.get("components") or []:
            if comp.get("type") != type_name:
                continue
            decision = next((d for d in comp.get("decisions") or [] if d.get("question") == question), None)
            if decision is None:
                continue
            mine = str(decision.get("answer") or "").strip() and decision.get("origin") != store.TYPE_ORIGIN
            (own if mine else takes).append(comp["id"])
    return own, takes


def accept_proposal(root: Path, component_id: str, number: int) -> dict:
    """A person accepts the AI's answer: it becomes a decision of the component's vow (origin: ai)."""
    proposal = by_question(root).get((component_id, number))
    if proposal is None:
        raise ProposalError(f"the AI proposed nothing for question {number} of {component_id} "
                            f"(archvow show {component_id})")
    decision = decide(root, component_id, number, proposal["answer"], origin="ai")
    take(root, component_id, number)
    return decision
