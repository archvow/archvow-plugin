"""The commands that change the spec (layer 3), one module per thing they change: init (and answers.py,
project_files.py), components, decisions, rules, items, hazards, invariants, questions (and assumptions),
acceptance (what the AI added, kept by a person). They load and save through model/store.py; imports layers 0-2.
"""
