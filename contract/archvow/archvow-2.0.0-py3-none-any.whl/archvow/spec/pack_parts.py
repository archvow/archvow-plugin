"""`pack agent` and `pack rule`: an agent profile, a declarative rule, written into a pack.

A profile holds only what differs from the standard (archvow/agents.py); `--extends <known agent>` starts from that
agent's profile and files. A rule goes into rules/<FAMILY>.yaml (the family is the code's letters), and only when it
catches its bad example and passes its good one.
"""

from __future__ import annotations

import shutil
from pathlib import Path

import yaml

from archvow import agents
from archvow.custom import catches
from archvow.foundation.errors import PackError
from archvow.foundation.files import write_text
from archvow.packs import rules as pack_rules
from archvow.packs import store as packs
from archvow.spec.packs import rerecord

INSTRUCTION_KINDS = ("import", "rules")  # a pointer to AGENTS.md, or the rules copied where the agent reads them
RULES_TEXT = {
    "en": ("# Instructions for {name}\n\nThe rules for every AI assistant are in AGENTS.md at the repository root; "
           "they are copied below so they apply even when that file is not loaded. If the two differ, AGENTS.md "
           "wins.\n\n{{{{ agents_rules }}}}"),
    "fr": ("# Instructions pour {name}\n\nLes règles de tout assistant IA sont dans AGENTS.md, à la racine du dépôt ; "
           "elles sont recopiées ci-dessous pour s'appliquer même quand ce fichier n'est pas chargé. En cas de "
           "différence, AGENTS.md fait foi.\n\n{{{{ agents_rules }}}}"),
}


def add_agent(root: Path | None, folder: Path, name: str, *, extends: str | None = None, title: str | None = None,
              env: list[str] | None = None, processes: list[str] | None = None, instructions: str | None = None,
              skills: str | None = None, unsafe: list[str] | None = None, fix: str | None = None,
              review_command: str | None = None, review_secret: str | None = None, owns: list[str] | None = None,
              permissions: str | None = None) -> Path:
    """`pack agent <pack> <agent>`: agents/<agent>/agent.yaml (+ its instructions file)."""
    if not agents.NAME_RE.match(name):
        raise PackError(f"'{name}': an agent's name is lowercase letters, digits, - and _ (acme-assistant)")
    pack = packs.read(folder)
    target = pack.agents / name
    if target.exists():
        raise PackError(f"{target} already exists")
    data: dict = {}
    if extends:
        known = agents.profiles(root)
        if extends not in known:
            raise PackError(f"--extends {extends}: no agent profile of that name ({', '.join(sorted(known))})")
        base = known[extends]
        data = yaml.safe_load((base.folder / "agent.yaml").read_text(encoding="utf-8")) or {}
        for files in sorted(base.folder.glob("files*")):
            shutil.copytree(files, target / files.name)
    given = {"title": title, "skills": skills, "fix": fix, "permissions": permissions}
    data |= {k: v for k, v in given.items() if v}
    if env or processes:
        data["detect"] = {**(data.get("detect") or {}), **({"env": env} if env else {}),
                          **({"processes": processes} if processes else {})}
    if unsafe:
        data["yolo"] = unsafe
    if review_command:
        data["review"] = {"command": review_command, **({"secret": review_secret} if review_secret else {})}
    if owns:
        data["owns"] = owns
    if instructions:
        _instructions(target, name, instructions, data, _languages(folder))
    target.mkdir(parents=True, exist_ok=True)
    head = (f"# {data.get('title') or name}: how it differs from the standard (AGENTS.md, .agents/skills, "
            f"AI_AGENT/AGENT={name}).\n# The keys: archvow/agents.py (docs/packs.md).\n")
    write_text(target / "agent.yaml", head + (yaml.safe_dump(data, sort_keys=False, allow_unicode=True, width=110)
                                               if data else "{}\n"))
    agents.read(target, pack.name)  # what was written reads back
    rerecord(root, folder)
    return target


def _instructions(target: Path, name: str, given: str, data: dict, languages: list[str]) -> None:
    """--instructions FILE:KIND: the agent's instructions file, in each language of the pack."""
    rel, _, kind = given.rpartition(":")
    if not rel or kind not in INSTRUCTION_KINDS:
        raise PackError(f"--instructions {given}: write FILE:KIND, KIND one of {', '.join(INSTRUCTION_KINDS)} "
                        "(.acme/instructions.md:rules, ACME.md:import)")
    for language in languages:
        folder = "files" if language == "en" else f"files-{language}"
        if kind == "import":
            if language == "en":
                (target / folder / rel).parent.mkdir(parents=True, exist_ok=True)
                write_text(target / folder / rel, "@AGENTS.md\n")
            continue
        text = RULES_TEXT.get(language, RULES_TEXT["en"]).format(name=name)
        path = target / folder / f"{rel}.j2"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8", newline="\n")  # as the rules end it: no newline added
    data["owns"] = list(dict.fromkeys([*(data.get("owns") or []), rel.split("/")[0] if "/" in rel else rel]))


def _languages(folder: Path) -> list[str]:
    raw = yaml.safe_load((folder / "pack.yaml").read_text(encoding="utf-8")) or {}
    return [str(lang) for lang in raw.get("languages") or ["en"]]


def add_rule(root: Path | None, folder: Path, code: str, rule: dict) -> Path:
    """`pack rule <pack> <CODE>`: the rule in rules/<FAMILY>.yaml, refused unless it catches its bad example and
    passes its good one."""
    rule = {k: v for k, v in rule.items() if v not in (None, "", [])}
    problem = pack_rules.problem_of(code, rule)
    if problem:
        raise PackError(f"{code}: {problem}")
    verdict = example_problem(code, rule)
    if verdict:
        raise PackError(verdict, hint="change the target, or the examples (--bad, --good)")
    pack = packs.read(folder)
    path = pack.rules / f"{pack_rules.family(code)}.yaml"
    existing = pack_rules.read_file(path) if path.is_file() else {}
    if code in existing:
        raise PackError(f"{code} is already in {path.name}")
    existing[code] = rule
    head = (f"# Rules of family {pack_rules.family(code)} (docs/packs.md of archvow). archvow pack rule writes them;"
            " archvow pack check proves each one.\n")
    write_text(path, head + yaml.safe_dump(existing, sort_keys=False, allow_unicode=True, width=110))
    rerecord(root, folder)
    return path


def example_problem(code: str, rule: dict) -> str:
    """'' when the rule catches its bad example and passes its good one, else what fails."""
    if rule.get("kind") == "require_question":
        return ""
    shaped = pack_rules.localized(rule, "en")
    if not catches(shaped, str(rule["bad"])):
        return f"{code} does not catch its bad example: {_short(rule['bad'])}"
    if catches(shaped, str(rule["good"])):
        return f"{code} also catches its good example: {_short(rule['good'])}"
    return ""


def _short(text: object) -> str:
    one = " ".join(str(text).split())
    return one if len(one) <= 60 else one[:57] + "..."
