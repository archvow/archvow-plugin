"""The commands that change features: add, rename, remove a feature; move a component to another one.

A feature is a folder of the spec (`.archvow/features/<feature>/`): its vow says what the product does there and
links the brief; its components live in its `components/`. Renaming a feature moves its folder; a component
moved to another feature moves its file. Nothing else changes: a component keeps its id, its uses, its tests.
"""

from __future__ import annotations

from pathlib import Path

from archvow.foundation.errors import SpecError
from archvow.foundation.paths import SHARED
from archvow.foundation.text import one_line
from archvow.model import features as feats
from archvow.model import store
from archvow.model.spec import find_component, stamp


def add_feature(root: Path, name: str, description: str, brief: str | None = None,
                created_by: str | None = None) -> dict:
    """`archvow feature add <name> -d "..." [--brief briefs/x.md]`."""
    data = store.load(root)
    feats.check_name(name)
    if any(f["name"] == name for f in feats.features(data)):
        raise SpecError(f"the feature '{name}' already exists")
    if not description.strip():
        raise SpecError("a description is required: what the product does in this feature")
    entry: dict = {"name": name, "description": one_line(description)}
    if brief:
        rel = brief.replace("\\", "/").removeprefix("./")
        if not (root / rel.split("#", 1)[0]).is_file():
            raise SpecError(f"--brief {brief}: no such file (give its path from the project root)")
        entry["brief"] = rel
    if created_by:
        entry.update({"origin": "ai", "created_by": created_by, **stamp(root)})
    data.setdefault("features", []).append(entry)
    store.save(root, data)
    return entry


def rename_feature(root: Path, old: str, new: str) -> dict:
    """`archvow feature rename <old> <new>`: its folder moves, its components keep everything else."""
    data = store.load(root)
    feature = feats.find(data, old)
    if old == SHARED:
        raise SpecError("shared keeps its name: it is what every feature uses")
    feats.check_name(new)
    if any(f["name"] == new for f in feats.features(data)):
        raise SpecError(f"the feature '{new}' already exists")
    data["features"] = [f for f in data.get("features") or [] if f["name"] != old] + [{**feature, "name": new}]
    for comp in feats.components_of(data, old):
        comp["feature"] = new
    store.save(root, data)
    return {"name": new, "was": old, "components": [c["id"] for c in feats.components_of(data, new)]}


def remove_feature(root: Path, name: str) -> dict:
    """`archvow feature remove <name>`: refused while it has components (move or remove them first)."""
    data = store.load(root)
    feature = feats.find(data, name)
    if name == SHARED:
        raise SpecError("shared cannot be removed: it is what every feature uses")
    members = [c["id"] for c in feats.components_of(data, name)]
    if members:
        raise SpecError(f"the feature '{name}' still has {len(members)} component(s): {', '.join(members)}",
                        hint="archvow component move <component> <feature>, or component remove <component>")
    data["features"] = [f for f in data.get("features") or [] if f["name"] != name]
    store.save(root, data)
    return feature


def move_component(root: Path, component_id: str, feature: str) -> dict:
    """`archvow component move <component> <feature>`: its file moves; its id, uses and tests stay."""
    data = store.load(root)
    _, comp = find_component(data, component_id)
    target = feats.find(data, feats.check_name(feature))["name"]
    if feats.feature_of(comp) == target:
        raise SpecError(f"'{component_id}' is already in {target}")
    was = feats.feature_of(comp)
    comp["feature"] = target
    store.save(root, data)
    return {"id": component_id, "feature": target, "was": was, "file": store.where(comp)}
