"""`archvow hazard add|dismiss|edit|remove`: what must never happen, the guide words of the safety
questions, and what a hazard suggests.
"""

from __future__ import annotations

from pathlib import Path

from archvow import toreview
from archvow.foundation.errors import SpecError
from archvow.foundation.i18n import DEFAULT_LANGUAGE, tr
from archvow.foundation.text import a_or_an, one_line, says_nothing
from archvow.model import store
from archvow.model.spec import (
    SEVERITIES,
    ai_origin,
    find_component,
    required_text,
    stamp,
)
from archvow.privacy import personal_flow
from archvow.spec.items import _next_id, find_item, keep
from archvow.templates import (
    Template,
    load_template,
    template_name,
)


def remove_hazard(root: Path, hazard_id: str) -> dict:
    """Remove a hazard; the invariants that prevented it no longer point to it."""
    data = store.load(root)
    _, hazard = find_item(data, hazard_id)
    data["hazards"] = [h for h in data.get("hazards", []) or [] if h is not hazard]
    unlinked, removed = [], []
    for inv in data.get("invariants", []) or []:
        if hazard["id"] in (inv.get("mitigates") or []):
            inv["mitigates"] = [m for m in inv["mitigates"] if m != hazard["id"]]
            (unlinked if inv["mitigates"] else removed).append(inv["id"])
    # an invariant that would protect nothing goes with its hazard (it failed check with ARCH036 before)
    data["invariants"] = [i for i in data.get("invariants", []) or [] if i["id"] not in removed]
    store.save(root, data)
    return {**hazard, "unlinked": unlinked, "removed_invariants": removed}


def orphans_of(data: dict, hazard_id: str) -> list[dict]:
    """The invariants that protect only this hazard: they go with it."""
    return [i for i in data.get("invariants", []) or [] if (i.get("mitigates") or []) == [hazard_id]]


def edit_hazard(root: Path, hazard_id: str, description: str | None = None, severity: str | None = None) -> dict:
    """Change a hazard's words or severity; its id, its invariants and their tests stay. What protects it is
    to review (ARCH057): a person checks that it still does."""
    data = store.load(root)
    _, hazard = find_item(data, hazard_id)
    if description is None and severity is None:
        raise SpecError("say what changes: the words in quotes, --severity critical|high|medium|low, or both")
    if severity is not None and severity not in SEVERITIES:
        raise SpecError(f"severity must be one of {', '.join(SEVERITIES)}")
    changed = []
    if description is not None and one_line(required_text(description, "what must never happen")) != hazard.get("description"):
        hazard["description"] = one_line(description)
        changed.append("words")
    if severity is not None and severity != hazard.get("severity"):
        hazard["severity"] = severity
        changed.append("severity")
    if not changed:
        raise SpecError(f"{hazard['id']} already says this - nothing changed")
    keep(root, hazard)
    hazard.update(stamp(root))
    hazard.pop("review", None)
    day = toreview.today()
    guards = [i for i in data.get("invariants", []) or [] if hazard["id"] in (i.get("mitigates") or [])]
    for inv in guards:
        inv["review"] = f"{hazard['id']} changed on {day}"
    container = (data["containers"] or [{}])[0]
    allowed = (load_template(template_name(container)[0], root).data.get("verification_floor") or {}).get(
        hazard["severity"]) or []
    weak = [i for i in guards if allowed and i.get("verify") not in allowed]
    warnings = [f"{i['id']} is proven by {a_or_an(i.get('verify') or '')}: a {hazard['severity']} hazard needs one of "
                f"{', '.join(allowed)} (ARCH037) - archvow invariant edit {i['id']} --verify {allowed[0]}" for i in weak]
    store.save(root, data)
    return {**hazard, "changed": changed, "to_review": [i["id"] for i in guards],
            **({"warnings": warnings} if warnings else {})}


def reopen_safety_question(root: Path, component: str, question: str) -> dict:
    """Undo a "not applicable": the safety question is open again."""
    data = store.load(root)
    container, comp = find_component(data, component)
    template = load_template(template_name(container)[0], root)
    word = resolve_guide_word(template, comp, question)
    entry = next((d for d in data.get("dismissed") or [] if d.get("component") == component
                  and d.get("guide_word") == word), None)
    if entry is None:
        hazard = next((h for h in data.get("hazards", []) or [] if h.get("component") == component
                       and h.get("guide_word") == word), None)
        hint = f": it is answered by {hazard['id']} (archvow hazard remove {hazard['id']})" if hazard else ""
        raise SpecError(f"{question} of {component} is not marked not applicable{hint}")
    data["dismissed"] = [d for d in data["dismissed"] if d is not entry]
    if not data["dismissed"]:
        data.pop("dismissed")
    store.save(root, data)
    return entry


def add_hazard(root: Path, description: str | None, *, guide_word: str, severity: str,
               component: str | None = None, rationale: str | None = None, added_by: str | None = None,
               why: str | None = None) -> dict:
    """Record a hazard: what must never happen, for one safety question of a component.

    `guide_word` is the question's number in `archvow show`, or its guide word. Without a
    description, the template's suggestion for that question is used."""
    data = store.load(root)
    comp = None
    if component:
        container, comp = find_component(data, component)
    else:
        container = data["containers"][0]
    template = load_template(template_name(container)[0], root)
    guide_word = resolve_guide_word(template, comp, guide_word)
    if severity not in SEVERITIES:
        raise SpecError(f"severity must be one of {', '.join(SEVERITIES)}")
    if description is None:
        description = safety_suggestion(template, data, comp, guide_word).get("hazard")
        if not description:
            raise SpecError("no suggestion for this question: write what must never happen, in quotes")
    suggestion = safety_suggestion(template, data, comp, guide_word)
    warnings = []
    if suggestion.get("not_applicable"):
        decision = suggestion["decision"]
        warnings.append(f"decision {decision['number']} says \"{decision['answer']}\": this hazard contradicts it - "
                        f"change decision {decision['number']} (archvow decision make {component} "
                        f"{decision['number']} \"...\") or remove the hazard and answer not applicable "
                        f"(archvow hazard dismiss {component} {guide_word})")
    special = _special_columns(root, data, component) if guide_word == "exposed" else []
    if special and severity != "critical":
        warnings.append(f"PRIV003: {', '.join(special)} {'is' if len(special) == 1 else 'are'} special (sensitive) "
                        f"data - an exposed hazard is expected critical (archvow hazard edit <id> --severity critical)")
    hazards = data.setdefault("hazards", [])
    entry = {"id": _next_id(hazards, component, "H"), "component": component, "guide_word": guide_word,
             "severity": severity, "description": required_text(description, "what must never happen")}
    if rationale:
        entry["rationale"] = one_line(rationale)
    entry.update(stamp(root))
    entry.update(ai_origin(added_by, why))
    hazards.append(entry)
    store.save(root, data)
    return {**entry, **({"warnings": warnings} if warnings else {})}


def _special_columns(root: Path, data: dict, component: str | None, kinds: tuple = ("special",)) -> list[str]:
    """The columns of these classes a component handles (its own and what flows to it)."""
    if not component:
        return []
    handles = (personal_flow(root, data).get(component) or {}).get("handles") or {}
    return sorted(n for n, k in handles.items() if k in kinds)


def dismiss_question(root: Path, component: str | None, guide_word: str, rationale: str) -> dict:
    """Answer a safety question "not applicable", with the reason. It is not a hazard: no H number."""
    data = store.load(root)
    comp = None
    if component:
        container, comp = find_component(data, component)
    else:
        container = data["containers"][0]
    template = load_template(template_name(container)[0], root)
    guide_word = resolve_guide_word(template, comp, guide_word)
    suggestion = safety_suggestion(template, data, comp, guide_word)
    if not (rationale or "").strip():
        rationale = suggestion.get("not_applicable") or ""  # the decision that says there is nothing to protect
    if not (rationale or "").strip():
        raise SpecError("say why it cannot happen here: a dismissal needs a reason")
    if guide_word == "exposed":
        personal = _special_columns(root, data, component, ("personal", "special"))
        if personal:
            raise SpecError(f"PRIV003: {component} handles personal data ({', '.join(personal)}) - its "
                            f"\"exposed\" question cannot be not applicable: declare the hazard (archvow hazard add "
                            f"{component} exposed critical), or classify the columns again if they are not personal "
                            f"(archvow column set <schema> <columns> none)")
    warnings = []
    decision = suggestion.get("decision")
    if decision and not suggestion.get("not_applicable"):
        warnings.append(f"decision {decision['number']} says \"{decision['answer']}\": check that the question "
                        "really cannot happen, the decision expects something to protect")
    if (component, guide_word) in store.answered_safety(data):
        target = f" {component}" if component else ""
        raise SpecError(f"this safety question of {component or 'the system'} is already answered "
                        f"(archvow show{target})")
    entry = {"component": component, "guide_word": guide_word, "rationale": one_line(rationale),
             **stamp(root)}
    data.setdefault("dismissed", []).append(entry)
    store.save(root, data)
    return {**entry, **({"warnings": warnings} if warnings else {})}


def safety_suggestion(template: Template, data: dict, comp: dict | None, guide_word: str) -> dict:
    """What the template suggests for one safety question: `hazard` and `invariant` texts, and the
    component's `decision` that already answers it. An answered decision covers the question: its answer is
    the invariant (recorded as a link to the decision, never a copy); a decision that says there is nothing
    to protect ("none") makes it `not_applicable` instead, with that reason."""
    language = data.get("language") or DEFAULT_LANGUAGE
    ctype = template.type_of(comp) if comp else {}
    suggestion = {**((template.data.get("safety_suggestions") or {}).get(guide_word) or {}),
                  **((ctype.get("safety_suggestions") or {}).get(guide_word) or {})}
    number = (ctype.get("safety_decisions") or {}).get(guide_word)
    decisions = (comp or {}).get("decisions", []) or []
    if number and number <= len(decisions) and (decisions[number - 1].get("answer") or "").strip():
        answer = decisions[number - 1]["answer"]
        suggestion["decision"] = {"number": number, "answer": answer}
        if says_nothing(answer):
            suggestion.pop("invariant", None)
            suggestion["not_applicable"] = tr(language, "decision {number}: {answer}", number=number,
                                              answer=answer.rstrip("."))
        else:
            suggestion["invariant"] = tr(language, "{answer} (decision {number})", answer=answer.rstrip("."),
                                         number=number)
    return suggestion


def suggestion_for(root: Path, component: str | None, question: str) -> tuple[str, dict]:
    """The guide word of a safety question (number or word) and the template's suggestion for it."""
    data = store.load(root)
    comp = find_component(data, component)[1] if component else None
    container = find_component(data, component)[0] if component else data["containers"][0]
    template = load_template(template_name(container)[0], root)
    word = resolve_guide_word(template, comp, question)
    return word, safety_suggestion(template, data, comp, word)


def safety_questions(template: Template, comp: dict | None) -> list[str]:
    """The guide words a component answers, in the order `archvow show` numbers them."""
    if comp is None:  # the whole system: every guide word of the template
        return list(template.data.get("guide_words", {}) or {})
    ctype = template.type_of(comp)
    return list(ctype.get("guide_words", []) or [])


def resolve_guide_word(template: Template, comp: dict | None, value: str) -> str:
    """A safety question's number (`archvow show` shows it) or its guide word."""
    words = safety_questions(template, comp)
    value = str(value).strip()
    if value[:1] in ("S", "s") and value[1:].isdigit():  # S2: the safety question's number in `show`
        value = value[1:]
    if str(value).isdigit():
        number = int(value)
        if not 1 <= number <= len(words):
            target = f" {comp['id']}" if comp else ""
            raise SpecError(f"safety question S{number} does not exist: there are {len(words)} "
                            f"(archvow show{target})")
        return words[number - 1]
    if value not in (template.data.get("guide_words", {}) or {}):
        raise SpecError(f"unknown safety question '{value}': give its number from archvow show (S1, S2...) "
                        f"(or a guide word: {', '.join(template.data.get('guide_words', {}) or {})})")
    return value
