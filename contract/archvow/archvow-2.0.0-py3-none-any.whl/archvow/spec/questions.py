"""`archvow question add|remove` and the assumptions: open questions and what the implementer assumed.
"""

from __future__ import annotations

from pathlib import Path

from archvow.foundation.errors import SpecError
from archvow.model import store
from archvow.model.spec import (
    ai_origin,
    find_component,
    required_text,
    stamp,
)
from archvow.spec.items import template_question_count

ASSUMPTION_STATES = ("proposed", "accepted", "rejected")


def remove_question(root: Path, component_id: str, number: int) -> dict:
    """Remove a question a person added (ask, or decide with a new question); the template's stay."""
    data = store.load(root)
    _, comp = find_component(data, component_id)
    decisions = comp.get("decisions", []) or []
    if not 1 <= number <= len(decisions):
        raise SpecError(f"'{component_id}' has no question {number} (it has 1..{len(decisions)})")
    if number <= template_question_count(root, data, component_id):
        raise SpecError(f"question {number} comes from the template: it stays - answer it "
                        f"(archvow decision make {component_id} {number} \"...\")")
    entry = decisions.pop(number - 1)
    store.save(root, data)
    return entry


def ask(root: Path, component_id: str, question: str, source: dict | None = None, *,
        added_by: str | None = None, why: str | None = None) -> dict:
    """Record an open question (for example raised by the AI before coding). `added_by`: the AI agent that
    asked it - the question is the AI's until a person keeps it (question accept) or answers it."""
    data = store.load(root)
    _, component = find_component(data, component_id)
    entry = {"question": required_text(question, "the question"), "answer": None, **({"source": source} if source else {}),
             **ai_origin(added_by, why)}
    component.setdefault("decisions", []).append(entry)
    store.save(root, data)
    return entry


def assume(root: Path, component_id: str, text: str) -> dict:
    """Record an assumption made by the implementer. It blocks until a human reviews it."""
    data = store.load(root)
    _, component = find_component(data, component_id)
    entry = {"text": required_text(text, "the assumption"), "status": "proposed", **stamp(root)}
    component.setdefault("assumptions", []).append(entry)
    store.save(root, data)
    return entry


def review_assumption(root: Path, component_id: str, number: int, status: str) -> dict:
    if status not in ("accepted", "rejected"):
        raise SpecError("status must be accepted or rejected")
    data = store.load(root)
    _, component = find_component(data, component_id)
    assumptions = component.setdefault("assumptions", [])
    if not 1 <= number <= len(assumptions):
        if not assumptions:
            raise SpecError(f"'{component_id}' has no assumption to review")
        raise SpecError(f"'{component_id}' has no assumption {number} (it has 1..{len(assumptions)}; "
                        f"see archvow show {component_id})")
    assumptions[number - 1]["status"] = status
    assumptions[number - 1].pop("review", None)  # looked at again after the component's change
    reviewed = stamp(root)
    assumptions[number - 1]["reviewed_by"] = reviewed["by"]
    assumptions[number - 1]["reviewed_on"] = reviewed["on"]
    store.save(root, data)
    return assumptions[number - 1]
