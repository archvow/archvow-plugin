"""AI drafts of an answer (3.2): one of the project's AI assistants writes a draft, a person reads it and saves it.

`archvow draft <component> <question>` runs one of the project's approved AI assistants (`ai_tools`) the way `archvow
review` runs a reviewer - without a person - but text only: the tool gets the question and the component's task,
and may not use a tool, write a file or run a command (its profile's `draft` command says how). archvow writes
nothing: the draft is printed, the person changes it or not, then saves it with the usual command and
`--drafted-with <tool>` (plus `--unchanged` when they kept it word for word). The saved answer is the person's: no
To review, no second accept - archvow records beside it that it came from an AI draft, and show, doc and the
merge request's spec changes say so.

On or off for the whole project: `ai_drafts` in project.vow, asked at init (no by default in mode strict, yes in
guided and free).
"""

from __future__ import annotations

import os
import shlex
import shutil
import subprocess
from pathlib import Path
from typing import Any

from archvow import agents, questions
from archvow.foundation.errors import SpecError
from archvow.model import drafted, store
from archvow.model import features as feats
from archvow.model.drafted import mark
from archvow.model.spec import find_component
from archvow.views.component import safety_worksheet

PROMPT_VARIABLE = "ARCHVOW_DRAFT_PROMPT"
TIMEOUT = 180  # seconds: a CLI starts, reads the prompt, answers


on = drafted.on  # the project's ai_drafts answer (model/drafted.py: `check --base` reads it too)


def allowed(data: dict[str, Any]) -> str | None:
    """None when drafts are on, else why not (the IDEs say it on the button)."""
    if on(data):
        return None
    return ("AI drafts are off for this project (ai_drafts: no in project.vow) - an architect turns them on: "
            "archvow init <package> --force -a ai_drafts=yes")


def tools(root: Path, data: dict[str, Any], kind: str = "draft", names: list[str] | None = None) -> list[dict[str, Any]]:
    """The project's AI tools whose profile can run this `kind` of work without a person (`draft`, `skill`;
    `review` for the reviewers), in the project's order, each with whether its command is on this machine. The
    first installed one is the default."""
    known = agents.profiles(root)
    out = []
    for name in (data.get("ai_tools") or []) if names is None else names:
        profile = known.get(name)
        command = str((getattr(profile, kind) if profile else {}).get("command") or "")
        if not command:
            continue
        program = shlex.split(command)[0]
        out.append({"name": name, "title": (profile.title if profile else "") or name, "program": program,
                    "installed": which(program) is not None})
    return out


# Where the assistants' installers put their command. An IDE started from the Dock or a desktop menu may not have
# them on its PATH even when a terminal does.
PLACES = ("~/.local/bin", "~/.claude/local", "~/.npm-global/bin", "~/.bun/bin", "/opt/homebrew/bin", "/usr/local/bin")


def which(program: str) -> str | None:
    """The program's path: on the PATH, else in the usual install folders."""
    return shutil.which(program) or shutil.which(program, path=os.pathsep.join(
        str(Path(place).expanduser()) for place in PLACES))


def check_drafted_with(data: dict[str, Any], tool: str | None) -> None:
    """`--drafted-with`: refused in mode strict, and for a tool the project did not approve."""
    if tool is None:
        return
    why = allowed(data)
    if why:
        raise SpecError(why)
    if tool not in (data.get("ai_tools") or []):
        approved = ", ".join(data.get("ai_tools") or []) or "none"
        raise SpecError(f"'{tool}' is not one of the project's AI assistants ({approved})")


def _question(root: Path, data: dict[str, Any], component: str, ref: str) -> tuple[str, str]:
    """The question asked by `ref` (2, P1, S3), and what an answer to it is."""
    container, comp = find_component(data, component)
    ref = ref.strip().upper()
    if ref.isdigit():
        decisions = comp.get("decisions") or []
        if not 1 <= int(ref) <= len(decisions):
            raise SpecError(f"'{component}' has no question {ref} (see archvow show {component})")
        return decisions[int(ref) - 1]["question"], "the decision: the answer the team records in the spec"
    if ref.startswith("S") and ref[1:].isdigit():
        sheet = safety_worksheet(root, component, data)
        asked = sheet[0]["questions"] if sheet else []
        if not 1 <= int(ref[1:]) <= len(asked):
            raise SpecError(f"'{component}' has no safety question {ref} (see archvow show {component})")
        return (asked[int(ref[1:]) - 1]["question"],
                "the hazard: what must never happen here, in one sentence (or, if it cannot happen, why)")
    if questions.is_key(ref):
        found = next((q for q in questions.component_questions(root, data, comp) if q["key"] == ref), None)
        if found is None:
            raise SpecError(f"'{component}' has no question {ref} (see archvow show {component})")
        return found["question"], "the decision: the answer the team records in the spec"
    raise SpecError(f"'{ref}' is not a question of {component}: a number (2), P1/O1/C1, or a safety question S1")


def _context(data: dict[str, Any], component: str) -> list[str]:
    """What the AI tool knows of the component: what it must do, where it is, what it uses, what is decided."""
    _, comp = find_component(data, component)
    feature = feats.feature_of(comp)
    try:
        about = str(feats.find(data, feature).get("description") or "")
    except SpecError:
        about = ""
    lines = [f"The component {component} ({comp.get('type')}, layer {comp.get('layer')}), in the feature {feature}"
             + (f": {about}" if about else "") + ".", f"What it must do: {comp.get('description') or '-'}"]
    if comp.get("uses"):
        lines.append(f"It uses: {', '.join(comp['uses'])}")
    decided = [d for d in comp.get("decisions") or [] if d.get("answer")]
    if decided:
        lines.append("Already decided:")
        lines += [f"- {d['question']} -> {d['answer']}" for d in decided]
    return lines


def prompt(root: Path, component: str, ref: str) -> str:
    """What the AI tool reads: the question, what to write, and what the spec says of the component."""
    data = store.load(root)
    question, wanted = _question(root, data, component, ref)
    language = "French" if str(data.get("language") or "en") == "fr" else "English"
    return "\n".join([
        f"Draft an answer to one question about the component {component}.",
        "",
        f"Question: {question}",
        f"Write {wanted}.",
        "",
        f"- Write in {language}, in plain words, as short as the answer allows (one to five lines).",
        "- Use only what is below. If something you need is missing, say what is missing instead of guessing.",
        "- Give the answer only: no introduction, no Markdown headings, no commands.",
        "- A person reads your draft, changes it if needed, and saves it as their own answer.",
        "",
        *_context(data, component),
    ])


def run(root: Path, component: str, ref: str, tool: str | None) -> dict[str, Any]:
    """Run the AI tool on the question's prompt, text only; its answer is the draft. archvow writes nothing."""
    data = store.load(root)
    why = allowed(data)
    if why:
        raise SpecError(why)
    found = tools(root, data)
    if not found:
        raise SpecError("none of the project's AI assistants can write a draft "
                        f"(ai_tools: {', '.join(data.get('ai_tools') or []) or 'none'})",
                        hint="copy the prompt instead: archvow draft <component> <question> --prompt")
    chosen = next((t for t in found if t["name"] == tool), None) if tool else \
        next((t for t in found if t["installed"]), None)
    if chosen is None:
        names = ", ".join(t["name"] for t in found)
        raise SpecError(f"'{tool}' cannot draft here (the project's AI assistants that can: {names})" if tool
                        else f"none of the project's AI assistants is installed on this machine ({names})")
    if not chosen["installed"]:
        raise SpecError(f"{chosen['title']} is not installed on this computer: no '{chosen['program']}' command "
                        "(the IDE's own plugin is not enough - drafts use the command)")
    text = prompt(root, component, ref)
    command = str(agents.profiles(root)[chosen["name"]].draft["command"])
    argv = [text if word in (f"${PROMPT_VARIABLE}", f"${{{PROMPT_VARIABLE}}}") else word for word in shlex.split(command)]
    argv[0] = which(argv[0]) or argv[0]
    try:
        result = subprocess.run(argv, cwd=root, capture_output=True, text=True, encoding="utf-8", errors="replace",
                                timeout=TIMEOUT, check=False, stdin=subprocess.DEVNULL,
                                env={**os.environ, PROMPT_VARIABLE: text})
    except subprocess.TimeoutExpired as error:
        raise SpecError(f"{chosen['title']} gave no draft within {TIMEOUT} s") from error
    except OSError as error:
        raise SpecError(f"{chosen['title']} could not start: {error}") from error
    draft = result.stdout.strip()
    if result.returncode != 0 or not draft:
        # the reason is on stdout when the tool printed one (stderr may hold only warnings), else on stderr
        said = " | ".join(line.strip() for line in (result.stdout.strip() or result.stderr.strip()).splitlines()[-3:])
        raise SpecError(f"{chosen['title']} gave no draft (exit {result.returncode})" + (f": {said}" if said else ""))
    return {"component": component, "question": ref.upper(), "tool": chosen["name"], "title": chosen["title"],
            "draft": draft}


def record(root: Path, component: str | None, refs: list[str], tool: str | None, unchanged: bool = False,
           hazard: str | None = None) -> None:
    """After a person saved answers (decisions 2, P1) or a hazard: mark them as drafted by `tool`, or unmark them
    when the person wrote them (an old mark never stays on a new answer)."""
    data = store.load(root)
    entries: list[dict[str, Any]] = []
    if hazard:
        entries = [h for h in store.hazards(data) if h.get("id") == hazard]
    elif component:
        _, comp = find_component(data, component)
        keyed = {q["key"]: q for q in questions.component_questions(root, data, comp)} if any(
            questions.is_key(r) for r in refs) else {}
        for ref in refs:
            ref = ref.strip().upper()
            if ref.isdigit() and 1 <= int(ref) <= len(comp.get("decisions") or []):
                entries.append(comp["decisions"][int(ref) - 1])
            elif ref in keyed:
                found = (comp.get("answers") or {}).get(f"{keyed[ref]['set']}.{keyed[ref]['id']}")
                if found:
                    entries.append(found)
    changed = False
    for entry in entries:
        before = (entry.get("drafted_with"), entry.get("draft"))
        mark(entry, tool, unchanged)
        changed |= before != (entry.get("drafted_with"), entry.get("draft"))
    if changed:
        store.save(root, data)
