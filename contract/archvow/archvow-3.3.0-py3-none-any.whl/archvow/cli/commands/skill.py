"""`archvow skill <skill> <target>`: one of the project's AI assistants does a skill on the spec, in the background.
"""

from __future__ import annotations

import argparse

from archvow import skills
from archvow.cli.args import Builder
from archvow.cli.output import print_result, project_root


def cmd_skill(args: argparse.Namespace) -> int:
    root = project_root(args)
    if args.prompt:
        text = skills.prompt(root, args.skill, args.target, args.max)
        print_result(args, {"skill": args.skill, "target": args.target, "prompt": text}, text)
        return 0
    outcome = skills.run(root, args.skill, args.target, args.tool, args.max)
    lines = [outcome["message"]]
    lines += [f"  {c['section']}: {c['ref']} - {c['detail']}" for c in outcome["changes"]]
    lines.append(f"Log: {outcome['log']}")
    print_result(args, outcome, "\n".join(lines))
    return 0 if outcome["status"] == "done" else 1


def declare_skill(b: Builder) -> None:
    """`archvow skill`: its parser."""
    p = b.command("skill", cmd_skill, "let one of the project's AI assistants do a skill on the spec, in the "
                  "background (what it adds is the AI's, To review)", True,
                  examples="""
        archvow skill clarify orders_schema               # find missing questions, with the first AI assistant installed here
        archvow skill clarify orders_schema --max 3 --with codex
        archvow skill analyze orders_schema               # the hazards and invariants it may need
        archvow skill draft-spec briefs/orders.md#pricing # a draft of the spec, from a brief
        archvow skill implement orders_schema --prompt    # only the instructions: Implement is your own agent's work
        """)
    p.add_argument("skill", choices=list(skills.SKILLS), help="the skill: draft-spec, clarify, analyze (run here); "
                   "implement and review give their instructions with --prompt")
    p.add_argument("target", help="the component (draft-spec: the brief, briefs/<file>.md or briefs/<file>.md#<section>)")
    p.add_argument("--with", dest="tool", metavar="TOOL",
                   help="which of the project's AI assistants (default: the first one installed on this computer)")
    p.add_argument("--max", type=int, metavar="N", help="clarify: at most N questions, the riskiest first (default 5)")
    p.add_argument("--prompt", action="store_true", help="print the instructions, to give them to an AI yourself, "
                   "and run nothing")
