"""`archvow template new|rule|question|agent|check|update`: templates, the one way to extend archvow.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any

from archvow.cli.args import Builder
from archvow.cli.commands.template_settings import template_settings
from archvow.cli.console import style as ui
from archvow.cli.output import as_json, print_result, project_root
from archvow.foundation import logs
from archvow.foundation.errors import TemplateError
from archvow.model import store
from archvow.spec.template_check import check_template
from archvow.spec.template_new import new_template
from archvow.spec.template_parts import add_agent, add_rule, proved_scope, target_folder
from archvow.spec.template_question import add_question
from archvow.spec.template_use import update
from archvow.templates import split_names
from archvow.templating import rules as pack_rules

log = logs.get("cli")


def _project(args: argparse.Namespace) -> Path | None:
    """The project the command is in, or None (a template is written outside any project)."""
    try:
        return project_root(args)
    except store.ManifestError:
        logs.swallowed(log, "_project: store.ManifestError")
        return None


def _folder(args: argparse.Namespace) -> tuple[Path | None, Path]:
    root = _project(args)
    return root, target_folder(args.template, root)


def _words(text: str | None) -> list[str]:
    return [w.strip() for w in (text or "").replace(" ", ",").split(",") if w.strip()]


def _shown(root: Path | None, path: Path) -> str:
    try:
        return path.relative_to(root).as_posix() if root is not None else str(path)
    except ValueError:
        return str(path)


def cmd_template_new(args: argparse.Namespace) -> int:
    parent = Path(args.dir or ".")
    extends = split_names(args.extends) if args.extends else []
    sources = tuple(Path(f) for f in args.source or [])
    settings = template_settings(args, extends, sources, parent) if extends else {}
    folder = new_template(args.name, parent, extends, args.description, args.version,
                          tuple(_words(args.languages)) or ("en",), settings, sources)
    print_result(args, {"template": args.name, "folder": str(folder), "extends": extends},
                 ui.ok(f"Created template {args.name} in {folder}") + "\n"
                 f"Next: edit template.yaml, add its files in files/; rules: archvow template rule {folder} ...; "
                 f"questions: archvow template question {folder} ...; then archvow template check {folder}")
    return 0


def cmd_template_agent(args: argparse.Namespace) -> int:
    root, folder = _folder(args)
    target = add_agent(root, folder, args.name, extends=args.extends, title=args.title, env=_words(args.detect_env),
                       processes=_words(args.detect_process), instructions=args.instructions, skills=args.skills,
                       unsafe=args.unsafe_flag, fix=args.fix, review_command=args.review_command,
                       review_secret=args.review_secret, owns=_words(args.owns), permissions=args.permissions,
                       draft_command=args.draft_command, skill_command=args.skill_command)
    print_result(args, {"agent": args.name, "folder": str(target)},
                 ui.ok(f"Created {_shown(root, target)}/agent.yaml") + f" - a project approves it with "
                 f"-a ai_tools=...,{args.name}")
    return 0


def cmd_template_rule(args: argparse.Namespace) -> int:
    root, folder = _folder(args)
    rule = {"kind": args.kind, "target": _words(args.target) if args.kind in ("forbid_import", "forbid_call",
                                                                                 "forbid_file", "only_in")
            else args.target, "in_types": _words(args.in_types), "in_layers": _words(args.in_layers),
            "severity": args.severity, "message": args.message, "message_fr": args.message_fr, "fix": args.fix,
            "fix_fr": args.fix_fr, "why": args.why, "why_fr": args.why_fr, "error": args.error, "bad": args.bad,
            "good": args.good, "final": True if args.final else None}
    path = add_rule(root, folder, args.code, rule)
    scope = proved_scope({k: v for k, v in rule.items() if v})
    print_result(args, {"rule": args.code, "file": str(path), "untested": None, "scope": scope or None},
                 ui.ok(f"Recorded {args.code} in {_shown(root, path)}") + ": it catches its bad example and passes "
                 "its good one" + (f"; {scope}" if scope else "") + ("; final" if args.final else ""))
    return 0


def cmd_template_question(args: argparse.Namespace) -> int:
    root, folder = _folder(args)
    texts = {"fr": {k: v for k, v in (("question", args.text_fr), ("suggested", args.suggested_fr)) if v}} \
        if args.text_fr else {}
    result = add_question(root, folder, args.type, args.id, args.text, args.suggested, _words(args.choices) or None,
                          texts)
    gained = result["components"]
    shown = ui.ok(f"Recorded question {args.id} of {args.type} in {_shown(root, Path(result['file']))}")
    if gained:
        shown += "\n" + ui.warn(f"{len(gained)} component(s) now ask it, not answered yet: "
                                + "; ".join(gained[:6]) + (" ..." if len(gained) > 6 else "")
                                + " - a built one shows drift (ARCH033) until someone answers it")
    print_result(args, {"question": args.id, "type": args.type, **result}, shown)
    return 0


def cmd_template_update(args: argparse.Namespace) -> int:
    root = project_root(args)
    data = store.load(root)
    result = update(root, data, args.source or [])
    store.save(root, data)
    lines = [ui.ok(f"{c['template']}: {c['before'] or 'new'} -> {c['now'] or 'removed'}") for c in result["changed"]]
    if not lines:
        lines = [ui.ok("The project's templates are up to date")]
    if result["questions"]:
        lines.append(ui.warn("New questions, not answered yet: " + "; ".join(result["questions"][:6])
                             + (" ..." if len(result["questions"]) > 6 else "")))
    lines.append(ui.dim("  review it (git diff, archvow check --base), then: archvow init <package> --force rewrites "
                        "the generated files from the new versions"))
    print_result(args, result, "\n".join(lines))
    return 0


def cmd_template_check(args: argparse.Namespace) -> int:
    root = _project(args)
    if args.template == "project":
        raise TemplateError("the project's own additions are checked with the project: archvow check")
    found, problems, proved = check_template(target_folder(args.template, root))
    if args.json:
        print(as_json({"template": found.summary() if found else None, "problems": problems, "proved": proved}))
        return 1 if problems else 0
    for line in proved:
        print(ui.ok(line))
    for line in problems:
        print(ui.error(line), file=sys.stderr)
    print(f"\n{len(problems)} problem(s)" if problems else "\n" + ui.ok("The template is ready to share"))
    return 1 if problems else 0


def declare_template(b: Builder) -> None:
    """`archvow template`: its parsers."""
    sub = b.noun("template", "templates: what a project is built and checked against - layers, component types, "
                 "questions, rules, agents, regimes, files (data only)",
                 "new|rule|question|agent|check|update", examples="""
        archvow template new acme-pyspark --extends pyspark-pipeline --dir ~/templates -d "ACME's pipelines"
        archvow template rule ~/templates/acme-pyspark ACME001 --kind forbid_import ...
        archvow template check ~/templates/acme-pyspark
        archvow init my_pipeline -t ~/templates/acme-pyspark      # the chain is copied into .archvow/templates/
        archvow template question project writer retention --text "How long is the data kept - e.g. 30 days?"
        archvow template update                                   # a new version, reviewed in the merge request
        """)
    _declare_new(b, sub)
    _declare_rule(b, sub)
    _declare_question(b, sub)
    _declare_agent(b, sub)
    p = b.command("check", cmd_template_check, "test a template before sharing it (its chain, every part, every "
                  "language, a project from it)", True, parent=sub, examples="archvow template check ~/templates/acme")
    p.add_argument("template", help="the template's folder")
    p = b.command("update", cmd_template_update, "take the project's templates again from where they came from "
                  "(a new version, reviewed in the merge request)", True, parent=sub, examples="""
        archvow template update
        archvow template update --from ../company/templates     # another folder, or an installed package
        """)
    p.add_argument("--from", dest="source", action="append", metavar="SOURCE",
                   help="a folder of templates, a template's folder or an installed package to take them from "
                   "(repeatable)")


def _target(p: argparse.ArgumentParser) -> None:
    p.add_argument("template", help="a template's folder, or `project` (this project's own additions, "
                   ".archvow/template/)")


def _declare_new(b: Builder, sub: argparse._SubParsersAction[Any]) -> None:
    p = b.command("new", cmd_template_new, "create a template: from scratch, or extending others", True, parent=sub,
                  usage="archvow template new NAME [--extends BASE[,BLOCK...]] [--dir FOLDER] [options]", examples="""
        archvow template new acme-pyspark --extends pyspark-pipeline -d "ACME's pipelines" --dir ~/templates
        archvow template new acme --dir ~/templates -d "ACME's rules for every stack"   # a building block
        archvow template new django-service --extends python-base -d "A Django service" --dir ~/templates
        archvow template new edge-agent -d "Written from scratch" --dir ~/templates     # no --extends
            # with --extends and no options, a terminal asks the company defaults
        """)
    p.add_argument("name", help="its name: lowercase letters, digits and dashes (acme-pyspark)")
    p.add_argument("-d", "--description", required=True, metavar="TEXT", help="what it is for, in one line")
    p.add_argument("--extends", metavar="TEMPLATES", help="the templates it builds on, comma-separated: one stack "
                   "(the one with layers) and building blocks; none: from scratch")
    p.add_argument("--dir", metavar="FOLDER", help="the folder to create it in (default: here)")
    p.add_argument("--from", dest="source", action="append", metavar="FOLDER",
                   help="a folder holding a template it extends (repeatable); archvow's and installed packages' "
                   "are found without it")
    p.add_argument("--version", default="1.0.0", help="its version (default: 1.0.0)")
    p.add_argument("--languages", default="en,fr", help="its languages, English always (default: en,fr)")
    p.add_argument("-a", "--answer", action="append", metavar="KEY=VALUE",
                   help="a company default for an init answer, repeatable (-a ci=jenkins); a project can override it")
    p.add_argument("--allowed-paths", metavar="FOLDERS",
                   help="top folders of Python files that are not components (devops,tools): no ARCH015 there")
    p.add_argument("--verbatim-folders", metavar="FOLDERS", dest="verbatim_folders",
                   help="folders of files/ copied exactly as they are, .j2 included (templates,deploy/ansible)")
    p.add_argument("--layer", action="append", metavar="LAYER=FOLDER",
                   help="rename a layer's folder, repeatable (--layer p1_domain=domain)")
    p.add_argument("--no-input", action="store_true", help="never ask: without options, settings stay examples")


def _declare_question(b: Builder, sub: argparse._SubParsersAction[Any]) -> None:
    p = b.command("question", cmd_template_question, "add a question to a component type (in the project: every "
                  "existing component of that type gets it)", True, parent=sub,
                  usage="archvow template question TEMPLATE TYPE ID --text TEXT [options]", examples="""
        archvow template question project view rate_limit \\
            --text "How many calls per user and minute, and above it - e.g. 60, then 429?" --suggested "60, then 429"
        archvow template question ~/templates/acme-pyspark writer retention --text "How long is it kept - e.g. 30 days?"
        """)
    _target(p)
    p.add_argument("type", help="the component type that asks it")
    p.add_argument("id", help="its id: lower case letters, digits and _ (rate_limit); a template below may reword it")
    p.add_argument("--text", required=True, metavar="TEXT", help="the question, with an example answer: "
                   "\"... - e.g. ...?\"")
    p.add_argument("--suggested", metavar="TEXT", help="the answer it suggests (decision make takes it)")
    p.add_argument("--choices", metavar="ANSWERS", help="answers to start from, comma-separated (none pre-selected)")
    p.add_argument("--text-fr", metavar="TEXT", help="the question in French")
    p.add_argument("--suggested-fr", metavar="TEXT", help="the suggested answer in French")


def _declare_agent(b: Builder, sub: argparse._SubParsersAction[Any]) -> None:
    p = b.command("agent", cmd_template_agent, "add an agent profile (only what differs from the standard)",
                  True, parent=sub, usage="archvow template agent TEMPLATE NAME [options]", examples="""
        archvow template agent ~/templates/acme acme-assistant --title "ACME Assistant" --detect-env ACME_ASSISTANT \\
            --instructions .acme/instructions.md:rules --unsafe-flag=--no-confirm --owns .acme
        archvow template agent project claude-code --extends claude-code --review-command "claude -p ..."
        """)
    _target(p)
    p.add_argument("name", help="the agent's name, as a project approves it (acme-assistant)")
    p.add_argument("--extends", metavar="AGENT", help="start from a known agent's profile and files")
    p.add_argument("--title", help="how AGENTS.md names it (ACME Assistant)")
    p.add_argument("--detect-env", metavar="VARIABLES", help="variables it sets where it runs commands (NAME or "
                   "NAME=start), comma-separated")
    p.add_argument("--detect-process", metavar="PROGRAMS", help="the programs it runs, comma-separated")
    p.add_argument("--instructions", metavar="FILE:KIND", help="its own instructions file: KIND import (a pointer "
                   "to AGENTS.md) or rules (AGENTS.md's rules copied there)")
    p.add_argument("--skills", metavar="FOLDER", help="where it reads skills, when not .agents/skills (a copy)")
    p.add_argument("--unsafe-flag", action="append", metavar="FLAG", help="an option that lets it act without "
                   "asking, repeatable (archvow refuses to run under it)")
    p.add_argument("--fix", metavar="TEXT", help="how to start it again, protected")
    p.add_argument("--review-command", metavar="COMMAND", help="how `archvow review` runs it without a person "
                   "(the task is in $ARCHVOW_REVIEW_PROMPT)")
    p.add_argument("--review-secret", metavar="NAME", help="the CI secret its review command needs")
    p.add_argument("--draft-command", metavar="COMMAND", help="how `archvow draft` runs it, text only: no tool, no "
                   "file, no command (the question is in $ARCHVOW_DRAFT_PROMPT)")
    p.add_argument("--skill-command", metavar="COMMAND", help="how `archvow skill` runs it in the background: it may "
                   "read the project and run archvow, nothing else (the task is in $ARCHVOW_SKILL_PROMPT)")
    p.add_argument("--owns", metavar="FILES", help="its files, comma-separated: flagged while it is not approved")
    p.add_argument("--permissions", metavar="TEXT", help="where a person lists its auto-approved commands, when "
                   "that is outside the project")


def _declare_rule(b: Builder, sub: argparse._SubParsersAction[Any]) -> None:
    p = b.command("rule", cmd_template_rule, "add a declarative rule (refused unless it catches its bad example "
                  "and passes its good one)", True, parent=sub,
                  usage="archvow template rule TEMPLATE CODE --kind KIND --target TARGET --message TEXT [options]",
                  examples="""
        archvow template rule ~/templates/acme ACME001 --kind forbid_import --target legacy_billing \\
            --message "No direct use of the old billing API" --fix "use acme_billing.client" \\
            --bad "import legacy_billing" --good "import acme_billing.client" --final
        archvow template rule project TEAM001 --kind only_in --target celery --in-layers p3_services \\
            --message "Tasks are sent from services only" --bad "import celery" --good "import json"
        """)
    _target(p)
    p.add_argument("code", help="its code: the company's letters and 3 digits (ACME001)")
    p.add_argument("--kind", required=True, choices=list(pack_rules.KINDS), help="what it checks")
    p.add_argument("--target", required=True, help="what the kind looks for (modules, calls or files: "
                   "comma-separated; a pattern, a keyword or a question: as it is)")
    p.add_argument("--in-types", metavar="TYPES", help="only in these component types, comma-separated")
    p.add_argument("--in-layers", metavar="LAYERS", help="only in these layers, comma-separated")
    p.add_argument("--severity", default="error", choices=["error", "warning"], help="error (default) or warning")
    p.add_argument("--final", action="store_true", help="no template below and no project may make it weaker")
    p.add_argument("--message", required=True, metavar="TEXT", help="what the finding says")
    p.add_argument("--message-fr", metavar="TEXT", help="the same, in French")
    p.add_argument("--fix", metavar="TEXT", help="how to fix it")
    p.add_argument("--fix-fr", metavar="TEXT", help="the same, in French")
    p.add_argument("--why", metavar="TEXT", help="why the rule exists")
    p.add_argument("--why-fr", metavar="TEXT", help="the same, in French")
    p.add_argument("--error", metavar="TEXT", help="the error people saw when it went wrong (Java heap space): "
                   "archvow show \"<pasted error>\" finds this rule by it")
    p.add_argument("--bad", metavar="CODE", help="an example it must catch (a file path for forbid_file)")
    p.add_argument("--good", metavar="CODE", help="an example it must pass")
