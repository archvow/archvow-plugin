"""The template commands that write a template: `template new`, `template rule`, `template agent`,
`template question`.

A template is written in a folder (`template new <name> --dir <folder>`); the project's own additions in
.archvow/template/ (the target `project`). A profile holds only what differs from the standard (archvow/agents.py);
`--extends <known agent>` starts from that agent's profile and files. A rule goes into rules/<FAMILY>.yaml (the
family is the code's letters), and only when it catches its bad example and passes its good one. A question goes
into template.yaml, under its component type; in the project, every existing component of that type gets it.
"""

from __future__ import annotations

import shutil
from pathlib import Path
from typing import Any

import yaml

from archvow import agents
from archvow.custom import catches, matches
from archvow.foundation.errors import ArchvowError, TemplateError
from archvow.foundation.files import write_text
from archvow.foundation.i18n import tr
from archvow.model import store as spec_store
from archvow.templates import load_template
from archvow.templating import rules as pack_rules
from archvow.templating import store

INSTRUCTION_KINDS = ("import", "rules")  # a pointer to AGENTS.md, or the rules copied where the agent reads them
RULES_TEXT = ("# Instructions for {name}\n\nThe rules for every AI assistant are in AGENTS.md at the repository root; "
              "they are copied below so they apply even when that file is not loaded. If the two differ, AGENTS.md "
              "wins.\n\n{{{{ agents_rules }}}}")  # in another language: the locale file (foundation/i18n.tr)


def add_agent(root: Path | None, folder: Path, name: str, *, extends: str | None = None, title: str | None = None,
              env: list[str] | None = None, processes: list[str] | None = None, instructions: str | None = None,
              skills: str | None = None, unsafe: list[str] | None = None, fix: str | None = None,
              review_command: str | None = None, review_secret: str | None = None, owns: list[str] | None = None,
              permissions: str | None = None, draft_command: str | None = None, skill_command: str | None = None) -> Path:
    """`template agent <template|project> <agent>`: agents/<agent>/agent.yaml (+ its instructions file)."""
    if not agents.NAME_RE.match(name):
        raise TemplateError(f"'{name}': an agent's name is lowercase letters, digits, - and _ (acme-assistant)")
    target = folder / "agents" / name
    if target.exists():
        raise TemplateError(f"{target} already exists")
    data: dict[str, Any] = {}
    if extends:
        known = agents.profiles(root)
        if extends not in known:
            raise TemplateError(f"--extends {extends}: no agent profile of that name ({', '.join(sorted(known))})")
        base = known[extends]
        if base.folder is None:  # the standard profile has nothing to copy
            raise TemplateError(f"--extends {extends}: no profile describes it, so there is nothing to extend")
        data = yaml.safe_load((base.folder / "agent.yaml").read_text(encoding="utf-8")) or {}
        for files in sorted(base.folder.glob("files*")):
            shutil.copytree(files, target / files.name)
    given = {"title": title, "skills": skills, "fix": fix, "permissions": permissions}
    data |= {k: v for k, v in given.items() if v}
    if env or processes:
        data["detect"] = {**(data.get("detect") or {}), **({"env": env} if env else {}),
                          **({"processes": processes} if processes else {})}
    if unsafe:
        data["yolo"] = unsafe
    if review_command:
        data["review"] = {"command": review_command, **({"secret": review_secret} if review_secret else {})}
    for key, command in (("draft", draft_command), ("skill", skill_command)):  # archvow draft, archvow skill (3.3)
        if command:
            data[key] = {"command": command}
    if owns:
        data["owns"] = owns
    if instructions:
        _instructions(target, name, instructions, data, _languages(folder))
    target.mkdir(parents=True, exist_ok=True)
    head = (f"# {data.get('title') or name}: how it differs from the standard (AGENTS.md, .agents/skills, "
            f"AI_AGENT/AGENT={name}).\n# The keys: archvow/agents.py (docs/templates.md).\n")
    write_text(target / "agent.yaml", head + (yaml.safe_dump(data, sort_keys=False, allow_unicode=True, width=110)
                                               if data else "{}\n"))
    agents.read(target, folder.name)  # what was written reads back
    return target


def _instructions(target: Path, name: str, given: str, data: dict[str, Any], languages: list[str]) -> None:
    """--instructions FILE:KIND: the agent's instructions file, in each language of the template."""
    rel, _, kind = given.rpartition(":")
    if not rel or kind not in INSTRUCTION_KINDS:
        raise TemplateError(f"--instructions {given}: write FILE:KIND, KIND one of {', '.join(INSTRUCTION_KINDS)} "
                        "(.acme/instructions.md:rules, ACME.md:import)")
    for language in languages:
        folder = "files" if language == "en" else f"files-{language}"
        if kind == "import":
            if language == "en":
                (target / folder / rel).parent.mkdir(parents=True, exist_ok=True)
                write_text(target / folder / rel, "@AGENTS.md\n")
            continue
        text = tr(language, RULES_TEXT).format(name=name)
        path = target / folder / f"{rel}.j2"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8", newline="\n")  # as the rules end it: no newline added
    data["owns"] = list(dict.fromkeys([*(data.get("owns") or []), rel.split("/")[0] if "/" in rel else rel]))


def _languages(folder: Path) -> list[str]:
    """The languages a template is written in (English always); the project's own additions: the project's."""
    if folder.name == store.OWN.name and folder.parent.name == ".archvow":
        return ["en"]
    return list(store.meta(folder).languages) if store.is_template(folder) else ["en"]


def add_rule(root: Path | None, folder: Path, code: str, rule: dict[str, Any]) -> Path:
    """`template rule <template|project> <CODE>`: the rule in rules/<FAMILY>.yaml, refused unless it catches its
    bad example and passes its good one."""
    rule = {k: v for k, v in rule.items() if v not in (None, "", [])}
    problem = pack_rules.problem_of(code, rule)
    if problem:
        raise TemplateError(f"{code}: {problem}")
    verdict = example_problem(code, rule) or scope_problem(code, rule, places(folder, root))
    if verdict:
        raise TemplateError(verdict, hint="change the target, the scope (--in-layers, --in-types) or the examples")
    path = folder / "rules" / f"{pack_rules.family(code)}.yaml"
    existing = pack_rules.read_file(path) if path.is_file() else {}
    if code in existing:
        raise TemplateError(f"{code} is already in {path.name}")
    existing[code] = rule
    head = (f"# Rules of family {pack_rules.family(code)} (docs/templates.md of archvow). archvow template rule "
            "writes them; archvow template check proves each one.\n")
    folder.mkdir(parents=True, exist_ok=True)
    _own_manifest(folder)
    write_text(path, head + yaml.safe_dump(existing, sort_keys=False, allow_unicode=True, width=110))
    return path


def example_problem(code: str, rule: dict[str, Any]) -> str:
    """'' when the rule catches its bad example and passes its good one, else what fails."""
    if rule.get("kind") == "require_question":
        return ""
    shaped = pack_rules.localized(rule, "en")
    if not catches(shaped, str(rule["bad"])):
        return f"{code} does not catch its bad example: {_short(rule['bad'])}"
    if catches(shaped, str(rule["good"])):
        return f"{code} also catches its good example: {_short(rule['good'])}"
    return ""


def places(folder: Path, root: Path | None = None) -> dict[str, set[str]]:
    """The layers and component types a rule of this template can look in: those of its chain (the project's, for
    its own additions). A building block with no layers says nothing here: the templates that extend it prove the
    scope of its rules (template check)."""
    found: dict[str, set[str]] = {"in_layers": set(), "in_types": set()}
    try:
        if is_own(folder, root):
            loaded = [load_template(c["template"], root) for c in spec_store.load(root).get("containers") or []] \
                if root is not None else []
        else:
            loaded = [load_template(folder.name, None, extra=(folder,))]
    except ArchvowError:
        return found  # template check reports the template itself
    for template in loaded:
        found["in_layers"] |= {str(layer.get("name")) for layer in template.layers}
        found["in_types"] |= set(template.component_types)
    return found


def scope_problem(code: str, rule: dict[str, Any], where: dict[str, set[str]]) -> str:
    """'' when a rule's scope (in_layers / in_types) is proved, else what fails. A scope is proved when each name is
    a layer or a component type of the template's chain, some layer or type of it is left out (a
    scope naming them all limits nothing; 2.6.0 compared the bad example inside and outside the scope, which a scoped
    rule can never catch outside by construction - the check could not fail), and the bad example is caught where the
    rule looks (for only_in: outside where the import is allowed)."""
    names = {key: [str(v) for v in rule.get(key) or []] for key in ("in_layers", "in_types")}
    if rule.get("kind") == "require_question" or not any(names.values()):
        return ""
    if rule.get("kind") == "forbid_file":
        return f"{code}: in_layers / in_types do not apply to forbid_file (it names files by their path)"
    for key, given in names.items():
        unknown = [n for n in given if n not in where[key]]
        if unknown and (where["in_layers"] or where["in_types"]):
            known = ", ".join(sorted(where[key])) or "none"
            return (f"{code}: {key} {', '.join(unknown)} is no {'layer' if key == 'in_layers' else 'component type'}"
                    f" of this template ({known})")
    for key, given in names.items():  # a file is in scope when its layer OR its type is named (custom._inside)
        if given and where[key] and set(given) >= where[key]:
            what = "layer" if key == "in_layers" else "component type"
            return (f"{code}: {key} names every {what} of this template ({', '.join(sorted(where[key]))}): "
                    "the scope limits nothing - leave it out, or name only where the rule applies")
    shaped = pack_rules.localized(rule, "en")
    looked = rule.get("kind") != "only_in"  # only_in: its bad example is an import outside where it is allowed
    if not matches(shaped, str(rule.get("bad") or ""), inside=looked):
        return f"{code}: its bad example is not caught inside its scope"
    return ""


def proved_scope(rule: dict[str, Any]) -> str:
    """How the proof line names a proved scope, or ""."""
    scope = "; ".join(f"{key} {', '.join(str(v) for v in rule[key])}" for key in ("in_layers", "in_types")
                      if rule.get(key))
    return f"its scope ({scope}) names its template's places, and limits it" if scope and rule.get(
        "kind") != "require_question" else ""


def _short(text: object) -> str:
    one = " ".join(str(text).split())
    return one if len(one) <= 60 else one[:57] + "..."


# ---- where a command writes


def is_own(folder: Path, root: Path | None) -> bool:
    """Whether `folder` is the project's own additions (.archvow/template/)."""
    return root is not None and folder.resolve() == (root / store.OWN).resolve()


def target_folder(target: str, root: Path | None) -> Path:
    """`<template|project>` of a command: `project` (this project's own additions), or a template's folder. A copy
    in .archvow/templates/ is never written: its template changes at its source, then `template update`."""
    if target == store.OWN_NAME:
        if root is None:
            raise TemplateError("`project` is this project's own additions: run the command inside an archvow "
                                "project", hint="or give a template's folder")
        return root / store.OWN
    folder = Path(target).expanduser()
    if root is not None and not folder.is_absolute() and not folder.exists() and (root / folder).exists():
        folder = root / folder
    if not store.is_template(folder):
        hint = "give the template's folder (archvow template new <name> --dir <folder> makes one), or `project`"
        if root is not None and (root / store.PROJECT_TEMPLATES / target).is_dir():
            hint = (f"{target} is a copy in {store.PROJECT_TEMPLATES.as_posix()}/: change it at its source, then "
                    f"archvow template update - or add to this project only: archvow template ... project ...")
        raise TemplateError(f"'{target}' is not a template's folder", hint=hint)
    folder = folder.resolve()
    if root is not None and folder.parent == (root / store.PROJECT_TEMPLATES).resolve():
        raise TemplateError(f"{folder.name} is a copy of a template: archvow writes it at init and template update "
                            "only (ARCH060)", hint=f"change {folder.name} at its source, then archvow template "
                            "update - or add to this project only: archvow template ... project ...")
    return folder


OWN_MANIFEST = """\
# This project's own additions to its templates (archvow template rule|question|agent project ...): applied
# last, over every template of the project. A guard, like project.vow: the architects review its changes.
# Everything a template.yaml can hold may be written here, by hand too (docs/templates.md).
"""


def _own_manifest(folder: Path) -> None:
    """The project's own additions get their template.yaml when the first one is written."""
    if folder.name == store.OWN.name and folder.parent.name == ".archvow" and not (folder / store.MANIFEST).exists():
        write_text(folder / store.MANIFEST, OWN_MANIFEST)
