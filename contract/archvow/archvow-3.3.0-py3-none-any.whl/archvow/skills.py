"""AI skills run by archvow (3.3): one of the project's AI assistants does a skill on the spec, in the background.

`archvow skill <skill> <target>` runs one of the project's approved AI assistants (`ai_tools`) without a person, the
way `archvow review` runs a reviewer and `archvow draft` a draft. The rule: archvow runs an AI only when everything it
can change goes through archvow - so only the skills that change the spec run here (draft-spec, clarify,
analyze). The assistant may read the project and run archvow, nothing else (its profile's `skill` command says how);
archvow marks the run as the assistant's (AI_AGENT), so everything it adds is the AI's, To review, as from a copy-paste.
After the run archvow checks that only the spec (.archvow/) changed.

Implement writes code: it is the developer's own agent's work, in its session and its sandbox - archvow hands it
the task (`--prompt`) and never runs it. Review has its own approved tools (`reviewers`) and command
(`archvow review --with`).

On or off for the whole project: `ai_skills` in project.vow, asked at init (no by default in mode strict, yes in
guided and free). A project that needs agents in a sandbox (ARCH051) runs none from here: a run started by a
person's editor is not in one.
"""

from __future__ import annotations

import os
import re
import shlex
import signal
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

from archvow import agents
from archvow.agent import sandbox_required
from archvow.drafts import tools, which
from archvow.foundation.errors import SpecError
from archvow.foundation.i18n import tr
from archvow.model import drafted, store
from archvow.model.spec import find_component
from archvow.templates import available, project_language
from archvow.views.specdiff import compare

PROMPT_VARIABLE = "ARCHVOW_SKILL_PROMPT"
TIMEOUT = 20 * 60  # seconds: an agent reads the spec, runs a few archvow commands
LOG = ".archvow/doc/skill-run.log"  # .archvow/doc/ is never committed

# name: (label, what it is given, whether it takes --max); in French through the locale (foundation/i18n.tr)
SKILLS: dict[str, tuple[str, str, bool]] = {
    "draft-spec": ("Draft from a brief", "brief", False),
    "clarify": ("Find missing questions", "component", True),
    "analyze": ("Find risks", "component", False),
    "implement": ("Implement", "component", False),
    "review": ("Review changes", "component", False),
}
RULES = ("Change the project only with archvow commands; write no file yourself.",
         "Never answer, decide, accept or remove: a person does.",
         "If something you need is missing, say what instead of guessing.",
         "End with what you added or proposed, one line each.")
IMPLEMENT_RULES = ("Respect the project's archvow mode and its approval by a person; never treat a proposal as accepted.",
                   "End with what you changed, and what a person must review.")
RUNS = ("draft-spec", "clarify", "analyze")  # the skills that change the spec only, through archvow


def on(data: dict[str, Any]) -> bool:
    return drafted.on(data, "ai_skills")


def allowed(data: dict[str, Any]) -> str | None:
    """None when archvow may run a skill here, else why not (the IDEs say it on the Run button)."""
    if not on(data):
        return ("AI skill runs are off for this project (ai_skills: no in project.vow) - an architect turns them "
                "on: archvow init <package> --force -a ai_skills=yes")
    if sandbox_required(data):
        return ("this project needs AI agents in a sandbox (ARCH051): a run started from here is not in one - copy "
                "the instructions to the agent you start in its sandbox")
    return None


def _skill_text(root: Path, skill: str, language: str) -> str:
    """The skill's procedure, as the project's agents read it (.agents/skills), else the templates' own copy."""
    rel = f"archvow-{skill}/SKILL.md"
    places = [root / agents.STANDARD_SKILLS / rel]
    for folder in available(root).values():
        places += [folder / f"files-{language}" / "skills" / rel, folder / "files" / "skills" / rel]
    for place in places:
        if place.is_file():
            text = place.read_text(encoding="utf-8")
            text = re.sub(r"\A---\n.*?\n---\n", "", text, flags=re.S).strip()
            # "What to give: ..." is for a person typing the skill's name: the target is given above it
            first = text.split("\n", 1)[0]
            return text.split("\n", 1)[1].strip() if re.match(r"^[^:\n]{1,20}:\s*<", first) else text
    return ""


def prompt(root: Path, skill: str, target: str, most: int | None = None) -> str:
    """What the AI assistant reads: the task, the target, the skill's procedure, and the rules of a run."""
    if skill not in SKILLS:
        raise SpecError(f"unknown skill '{skill}' (the skills: {', '.join(SKILLS)})")
    label, kind, takes_max = SKILLS[skill]
    if kind == "component":
        find_component(store.load(root), target)  # an unknown component says so here
    lang = project_language(root)
    lines = [tr(lang, "Archvow task: {label} (skill archvow-{skill}).", label=tr(lang, label), skill=skill),
             tr(lang, "Component: {target}" if kind == "component" else "Brief: {target}", target=target)]
    if takes_max:
        lines.append(tr(lang, "At most {most} questions, the riskiest first.", most=most or 5))
    body = _skill_text(root, skill, lang)
    if body:
        lines += ["", body]
    rules = IMPLEMENT_RULES if skill == "implement" else RULES
    lines += ["", tr(lang, "Rules:"), *[f"{i}. {tr(lang, rule)}" for i, rule in enumerate(rules, 1)]]
    return "\n".join(lines)


def _changed_files(root: Path) -> dict[str, str]:
    """Every changed or new file and its size and time: what the run may not touch outside .archvow/."""
    try:
        out = subprocess.run(["git", "status", "--porcelain=v1", "-z", "--untracked-files=all"], cwd=root,
                             capture_output=True, text=True, encoding="utf-8", errors="replace", check=False).stdout
    except OSError:
        return {}
    state: dict[str, str] = {}
    entries = out.split("\0")
    index = 0
    while index < len(entries):
        entry = entries[index]
        index += 1
        if len(entry) < 4:
            continue
        status, rel = entry[:2], entry[3:]
        if "R" in status or "C" in status:
            index += 1
        path = root / rel
        state[rel] = f"{path.stat().st_size}:{path.stat().st_mtime_ns}" if path.is_file() else "absent"
    return state


def _added(before: dict[str, Any], after: dict[str, Any]) -> tuple[dict[str, int], list[dict[str, Any]]]:
    """What the run changed in the spec: counts by section (questions 3, decisions 1...) and the changes."""
    changes = compare(before, after)
    counts: dict[str, int] = {}
    for change in changes:
        counts[change["section"]] = counts.get(change["section"], 0) + 1
    return counts, changes


def words(n: int, section: str) -> str:
    """'1 question', '3 hazards': what an AI adds to `decisions` are open questions (it decides nothing)."""
    one = {"decisions": "question", "assumptions": "assumption", "hazards": "hazard", "invariants": "invariant",
           "components": "component", "features": "feature", "rules": "rule"}.get(section, section.rstrip("s"))
    return f"{n} {one}" if n == 1 else f"{n} {one}s"


def _stop(process: subprocess.Popen[str]) -> None:
    """The assistant and what it started (its own process group)."""
    if process.poll() is not None:
        return
    try:
        if os.name == "posix":
            os.killpg(process.pid, signal.SIGTERM)
        else:
            process.terminate()
        process.wait(timeout=10)
    except (OSError, subprocess.TimeoutExpired):
        process.kill()


def _chosen(root: Path, data: dict[str, Any], skill: str, target: str, tool: str | None) -> dict[str, Any]:
    """Which of the project's assistants runs it: the one asked for, else the first installed here."""
    found = tools(root, data, "skill")
    if not found:
        raise SpecError("none of the project's AI assistants can run a skill without a person "
                        f"(ai_tools: {', '.join(data.get('ai_tools') or []) or 'none'})",
                        hint=f"copy the instructions instead: archvow skill {skill} {target} --prompt")
    chosen = next((t for t in found if t["name"] == tool), None) if tool else next((t for t in found if t["installed"]), None)
    if chosen is None:
        names = ", ".join(t["name"] for t in found)
        raise SpecError(f"'{tool}' cannot run skills here (the project's AI assistants that can: {names})" if tool
                        else f"none of the project's AI assistants is installed on this computer ({names})")
    if not chosen["installed"]:
        raise SpecError(f"{chosen['title']} is not installed on this computer: no '{chosen['program']}' command "
                        "(the IDE's own plugin is not enough - skills use the command)")
    return chosen


def _launch(root: Path, argv: list[str], env: dict[str, str], shown: str) -> tuple[str, int | None]:
    """Run the assistant, its output into the log; ("", exit code), or ("stopped" | "timeout", None)."""
    log = root / LOG
    log.parent.mkdir(parents=True, exist_ok=True)
    with open(log, "w", encoding="utf-8") as out:
        out.write(f"$ {shown}\n\n")
        out.flush()
        try:
            process = subprocess.Popen(argv, cwd=root, stdout=out, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                                       text=True, encoding="utf-8", env=env, start_new_session=os.name == "posix")
        except OSError as error:
            raise SpecError(f"{shown.split()[0]} could not start: {error}") from error

        def interrupted(*_: object) -> None:
            raise KeyboardInterrupt

        previous = signal.signal(signal.SIGTERM, interrupted)  # the IDE's Stop: the assistant stops too
        try:
            return "", process.wait(timeout=TIMEOUT)
        except subprocess.TimeoutExpired:
            return "timeout", None
        except KeyboardInterrupt:
            return "stopped", None
        finally:
            _stop(process)
            signal.signal(signal.SIGTERM, previous)


def run(root: Path, skill: str, target: str, tool: str | None, most: int | None = None) -> dict[str, Any]:
    """Run the skill with one of the project's AI assistants; what it changed, or why it failed."""
    if skill == "implement":
        raise SpecError("Implement writes code: it is your own agent's work, in its session and its sandbox. Give it "
                        f"the task: archvow skill implement {target} --prompt")
    if skill == "review":
        raise SpecError("a review is run by an approved reviewer: archvow review --base <branch> [--with <reviewer>]")
    if skill not in RUNS:
        raise SpecError(f"unknown skill '{skill}' (archvow runs: {', '.join(RUNS)})")
    data = store.load(root)
    why = allowed(data)
    if why:
        raise SpecError(why)
    chosen = _chosen(root, data, skill, target, tool)
    text = prompt(root, skill, target, most)
    command = str(agents.profiles(root)[chosen["name"]].skill["command"])
    argv = [text if word in (f"${PROMPT_VARIABLE}", f"${{{PROMPT_VARIABLE}}}") else word for word in shlex.split(command)]
    argv[0] = which(argv[0]) or argv[0]
    # the agent runs archvow itself: the archvow running now comes first on its PATH, and archvow knows it is an AI
    path = os.pathsep.join([str(Path(sys.executable).parent), *([os.environ["PATH"]] if "PATH" in os.environ else [])])
    env = {**os.environ, PROMPT_VARIABLE: text, "AI_AGENT": chosen["name"], "PATH": path}
    before_spec, before_files = store.load(root), _changed_files(root)
    started = time.monotonic()
    shown = " ".join(shlex.quote(a) if a != text else "$" + PROMPT_VARIABLE for a in argv)
    stopped, code = _launch(root, argv, env, shown)
    added, changes = _added(before_spec, store.load(root))
    after_files = _changed_files(root)
    touched = sorted(rel for rel in set(before_files) | set(after_files)
                     if before_files.get(rel) != after_files.get(rel) and not rel.startswith(".archvow/"))
    said = [line.strip() for line in (root / LOG).read_text(encoding="utf-8", errors="replace").splitlines()[1:]
            if line.strip()]
    outcome = {"skill": skill, "target": target, "tool": chosen["name"], "title": chosen["title"], "log": LOG,
               "seconds": round(time.monotonic() - started), "added": added, "changes": changes}
    return {**outcome, **_verdict(chosen["title"], touched, stopped, code, said, added)}


def _verdict(title: str, touched: list[str], stopped: str, code: int | None, said: list[str],
             added: dict[str, int]) -> dict[str, Any]:
    if touched:
        return {"status": "failed", "touched": touched,
                "message": f"{title} changed {', '.join(touched)}: a skill changes only the spec, through archvow. "
                           "Look at the change, then undo it (git checkout -- / git clean)"}
    if stopped:
        return {"status": "failed",
                "message": f"{title} was stopped" + (f" after {TIMEOUT // 60} minutes" if stopped == "timeout" else "")}
    if code != 0:
        return {"status": "failed", "message": f"{title} stopped (exit {code})" + (f": {' | '.join(said[-3:])}" if said else "")}
    if not added:
        return {"status": "done", "message": f"{title} added nothing" + (f": {said[-1]}" if said else "")}
    summary = ", ".join(words(n, section) for section, n in added.items())
    return {"status": "done", "message": f"{title} added {summary} - each the AI's, To review"}
