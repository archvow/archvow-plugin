"""An answer saved from an AI draft (3.2): `drafted_with <tool>` and `draft edited|unchanged` beside its `by` and `on`.

The answer is the person's - they read the draft and saved it (archvow draft, then --drafted-with). These two keys
only say where it came from, for the reader of show, doc and the merge request's spec changes.
"""

from __future__ import annotations

from typing import Any


def on(data: dict[str, Any], key: str = "ai_drafts") -> bool:
    """A yes/no AI answer of project.vow, set at init: `ai_drafts` (archvow draft) or `ai_skills` (archvow skill, 3.3).
    No by default in mode strict, yes in guided and free; an architect changes it with
    `archvow init <package> --force -a <key>=yes|no`."""
    answer = (data.get("init_answers") or {}).get(key)
    return str(data.get("mode") or "strict") != "strict" if answer is None else str(answer) == "yes"


def marks(data: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Every saved answer that came from an AI draft, by where it is ('sales.config decision 2'): the entry itself."""
    out: dict[str, dict[str, Any]] = {}
    for container in data.get("containers") or []:
        for comp in container.get("components") or []:
            for number, entry in enumerate(comp.get("decisions") or [], 1):
                if isinstance(entry, dict) and entry.get("drafted_with"):
                    out[f"{comp.get('id')} decision {number}"] = entry
            for key, entry in sorted((comp.get("answers") or {}).items()):
                if isinstance(entry, dict) and entry.get("drafted_with"):
                    out[f"{comp.get('id')} answer {key}"] = entry
    for entry in data.get("hazards") or []:
        if isinstance(entry, dict) and entry.get("drafted_with"):
            out[f"hazard {entry.get('id')}"] = entry
    return out


def mark(entry: dict[str, Any], tool: str | None, unchanged: bool = False) -> None:
    """Record on a saved answer that it came from an AI draft (or that it no longer does)."""
    entry.pop("drafted_with", None)
    entry.pop("draft", None)
    if tool:
        entry["drafted_with"] = tool
        entry["draft"] = "unchanged" if unchanged else "edited"


def note(entry: dict[str, Any]) -> str:
    """' (AI draft by claude-code, edited)', or '' for an answer a person wrote."""
    if not entry.get("drafted_with"):
        return ""
    return f" (AI draft by {entry['drafted_with']}, {entry.get('draft') or 'edited'})"


def view(entry: dict[str, Any]) -> dict[str, Any]:
    """What the IDEs read: {'drafted': {'tool': ..., 'edited': ...}} or {}."""
    if not entry.get("drafted_with"):
        return {}
    return {"drafted": {"tool": entry["drafted_with"], "edited": entry.get("draft") != "unchanged"}}
