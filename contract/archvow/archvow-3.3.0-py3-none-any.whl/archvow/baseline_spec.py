"""`check --base`: the guards the spec itself holds, beside the rule settings that baseline.py compares.

Each of these taken away or loosened since the base is ARCH020:

* a project rule (R1, R2...): removed, reworded, or given a scope that leaves out a component it applied to;
* a template project.vow records: removed, or another version or digest (its rules, questions, regimes and agent
  profiles may say less);
* AI drafts turned on (ai_drafts), or an answer saved from an AI draft while they are off;
* a column of a component: made less personal, untagged, no longer pseudonymised or removed, or taken out of
  the spec; a decision answered then removed;
* a rule parameter raised (compare_params, for baseline.py): a first override compares with the default that applied;
* a guard file changed (protected_files): a template's protected paths, the project's template copies, its own
  additions, the approved agents' files.
"""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path
from typing import Any

from archvow import agents
from archvow.checks.catalogue import DEFAULT_PARAMS
from archvow.checks.engine import Checker, number
from archvow.foundation import logs
from archvow.foundation.errors import GitError
from archvow.foundation.git import git
from archvow.model import drafted, store
from archvow.model.spec import to_accept
from archvow.templates import TemplateError, load_template, template_name
from archvow.templating.copies import recorded
from archvow.templating.store import OWN, PROJECT_TEMPLATES

log = logs.get(__name__)
RANK = {"none": 0, "personal": 1, "special": 2}


Weakened = Callable[..., None]  # weakened(message, file, line=0): a guard made weaker (baseline.compare)

def compare_params(code: str, base_rules: dict[str, Any], now_rules: dict[str, Any], template_rules: dict[str, Any],
                   keys: tuple[str, ...], weakened: Weakened, where: str) -> None:
    """Each parameter of rule `code` (keys: looser when higher) raised since the base. A first override compares with the
    default that applied - the template's value, else archvow's (2.6.2: it compared with the word "default", so a
    stricter first value was "relaxed"); an override taken out goes back to that default; a parameter with no known
    default (a template rule's) is a change whatever its value."""
    for key in keys:
        default = (template_rules.get(code) or {}).get(key, DEFAULT_PARAMS.get(code, {}).get(key))
        old = (base_rules.get(code) or {}).get(key)
        new = (now_rules.get(code) or {}).get(key, default if old is not None else None)
        before = old if old is not None else default
        if new is None or (before is not None and number(code, key, new) <= number(code, key, before)):
            continue
        was = old if old is not None else ("default" if before is None else f"{before} (default)")
        weakened(f"rule {code}: {key} relaxed from {was} to {new}", where)


def compare_spec(base: dict[str, Any], now: dict[str, Any], weakened: Weakened, where: str) -> None:
    _project_rules(base, now, weakened, where)
    _templates(base, now, weakened, where)
    _columns(base, now, weakened, where)
    _drafts(base, now, weakened, where)


def _drafts(base: dict[str, Any], now: dict[str, Any], weakened: Weakened, where: str) -> None:
    """AI drafts turned on, or an answer saved from an AI draft while they are off. Turning them on for an afternoon
    and back off before the commit still leaves the mark on each answer saved meanwhile."""
    if drafted.on(now, "ai_skills") and not drafted.on(base, "ai_skills"):
        weakened("AI skill runs turned on (ai_skills: yes): archvow may run the approved assistants on the spec in the "
                 "background", where)
    if drafted.on(now):
        if not drafted.on(base):
            weakened("AI drafts turned on (ai_drafts: yes): developers may ask the approved assistants for draft "
                     "answers", where)
        return
    before = drafted.marks(base)
    for place, entry in drafted.marks(now).items():
        if before.get(place) != entry:
            weakened(f"{place}: answer saved from an AI draft ({entry['drafted_with']}) while AI drafts are off "
                     "(ai_drafts: no in project.vow)", where)


def _scope_words(scope: dict[str, Any]) -> str:
    if scope.get("all"):
        return "every component"
    if scope.get("type"):
        return f"type {scope['type']}"
    return ", ".join(str(c) for c in scope.get("components") or []) or "no component"


def _covers(now: dict[str, Any], before: dict[str, Any]) -> bool:
    """Whether scope `now` applies to every component `before` applied to (a type is a type: kept or not)."""
    if now.get("all"):
        return True
    if before.get("components") is not None and now.get("components") is not None:
        return set(before["components"]) <= set(now["components"])
    return now == before


def _project_rules(base: dict[str, Any], now: dict[str, Any], weakened: Weakened, where: str) -> None:
    current = {str(r.get("id")): r for r in now.get("project_rules") or []}
    for rule in [r for r in base.get("project_rules") or [] if not to_accept(r)]:  # an AI's proposal guards nothing yet
        rid, after = str(rule.get("id")), current.get(str(rule.get("id")))
        if after is None:
            weakened(f"project rule {rid} removed ('{rule.get('text')}')", where)
        elif after.get("text") != rule.get("text"):
            weakened(f"project rule {rid} reworded from '{rule.get('text')}' to '{after.get('text')}'", where)
        elif not _covers(after.get("scope") or {}, rule.get("scope") or {}):
            weakened(f"project rule {rid} narrowed from {_scope_words(rule.get('scope') or {})} to "
                     f"{_scope_words(after.get('scope') or {})}", where)


def _templates(base: dict[str, Any], now: dict[str, Any], weakened: Weakened, where: str) -> None:
    after = recorded(now)
    for name, entry in sorted(recorded(base).items()):
        new = after.get(name)
        if new is None:
            weakened(f"template {name} removed (its rules, questions, regimes and agent profiles no longer apply)",
                     where)
        elif (new.get("version"), new.get("digest")) != (entry.get("version"), entry.get("digest")):
            weakened(f"template {name} changed from {entry.get('version')} ({entry.get('digest')}) to "
                     f"{new.get('version')} ({new.get('digest')}): its rules and questions may say less", where)


def _columns(base: dict[str, Any], now: dict[str, Any], weakened: Weakened, where: str) -> None:
    """A column made less personal (special -> personal -> none) or taken out of the spec, a tag removed (a
    regime no longer covers it), or a pseudonymisation or removal dropped, weakens the personal-data guards."""

    def components(data: dict[str, Any]) -> dict[str, Any]:
        return {c["id"]: c for ct in data.get("containers", []) or [] for c in ct.get("components", [])}

    old = components(base)
    for cid, comp in components(now).items():
        before = old.get(cid) or {}
        for name, kind in (before.get("columns") or {}).items():
            after = (comp.get("columns") or {}).get(name)
            if after is None and RANK.get(kind, 0):
                weakened(f"column {cid}.{name} taken out of the spec, was {kind}", where)
            elif after is not None and RANK.get(after, 0) < RANK.get(kind, 0):
                weakened(f"column {cid}.{name} classified {after}, was {kind}", where)
        for name, tags in (before.get("column_tags") or {}).items():
            lost = set(tags or []) - set((comp.get("column_tags") or {}).get(name) or [])
            if lost:
                weakened(f"column {cid}.{name} no longer tagged {', '.join(sorted(lost))}", where)
        for key in ("removes", "pseudonymises"):
            dropped = set((before.get("privacy") or {}).get(key) or []) - set((comp.get("privacy") or {}).get(key) or [])
            for name in sorted(dropped):
                weakened(f"{cid} no longer {key} {name}", where)
        now_questions = {d.get("question") for d in comp.get("decisions", []) or []}
        for decision in before.get("decisions", []) or []:  # `archvow question remove <component> <n>`: an answer is gone
            if (decision.get("answer") or "").strip() and decision.get("question") not in now_questions:
                weakened(f"{cid}: decision removed ('{decision.get('question')}' -> {decision.get('answer')})", where)


def protected_files(checker: Checker, root: Path, commit: str, weakened: Weakened) -> None:
    """The guard files changed since the base: the templates' protected paths, the project's copies (one finding per
    template), its own additions, the approved agents' files."""
    paths: list[str] = [PROJECT_TEMPLATES.as_posix(), OWN.as_posix()]  # the project's templates, whatever they say
    for container in checker.manifest.get("containers", []):
        try:
            data = load_template(template_name(container)[0], root).data
        except TemplateError:
            logs.swallowed(log, "protected_files: TemplateError")
            continue
        paths += data.get("protected_paths", [])
    known, language = agents.profiles(root), str(checker.manifest.get("language") or "en")  # approved agents' files
    paths += [r[:-3] if r.endswith(".j2") else r for t in store.instructed_tools(checker.manifest) for r in agents.profile(t, root, known).files(language)]
    try:
        changed = git(root, "diff", "--name-only", "-z", commit, "--", *sorted(set(paths))).split("\0")
        untracked = git(root, "ls-files", "-z", "--others", "--exclude-standard", "--", *sorted(set(paths))).split("\0")
    except GitError:
        logs.swallowed(log, "protected_files: GitError")
        return
    copies: dict[str, int] = {}  # a template's copy is one guard: one finding per template, not one per file
    for rel in sorted((set(changed) | set(untracked)) - {""}):  # -z: a name with a space is one name
        parts = rel.split("/")
        if rel.startswith(PROJECT_TEMPLATES.as_posix() + "/") and len(parts) > 3:
            copies["/".join(parts[:3])] = copies.get("/".join(parts[:3]), 0) + 1
        else:
            weakened("protected guard file changed; needs architect approval", rel)
    for folder, count in copies.items():
        weakened(f"the project's template {folder.rsplit('/', 1)[-1]} changed ({count} file(s) of its copy); "
                 "needs architect approval", folder)
