"""Typing in a terminal: line editing (arrows, Up for earlier answers, Tab for the suggestion; standard library
only) and the init questions `archvow init` and `archvow template new` ask one at a time.
"""

from __future__ import annotations

import atexit
import re
import sys
from collections.abc import Callable
from pathlib import Path

from archvow.cli.console import style as ui
from archvow.foundation import logs
from archvow.foundation.config import settings
from archvow.foundation.errors import SpecError
from archvow.foundation.paths import cache_dir
from archvow.spec.answers import (
    check_answer,
    dora_approvers_problem,
    question_default,
    resolved_choices,
)
from archvow.templates import Template

log = logs.get("ui")

# ---- typing an answer: line editing, history, Tab for the suggestion (standard library only)

_SUGGESTION: list[str] = []  # the suggestion of the question being asked (Tab puts it in the line)
_EDITING: list[bool] = []


def history_file() -> Path:
    """Where earlier answers are kept, so Up brings them back: the user's cache, never the project."""
    return Path(settings().history or cache_dir() / "history")


def setup_line_editing() -> bool:
    """In a terminal: arrows, Home/End, Up for earlier answers, Tab for the suggestion. Python's
    `readline` (GNU readline or macOS libedit); absent on Windows, whose console edits lines itself."""
    if _EDITING:
        return _EDITING[0]
    try:
        import readline
    except ImportError:
        logs.swallowed(log, "setup_line_editing: ImportError")
        _EDITING.append(False)
        return False
    readline.set_completer_delims("")
    readline.set_completer(_complete)
    if "libedit" in (readline.__doc__ or ""):
        readline.parse_and_bind("bind ^I rl_complete")
    else:
        readline.parse_and_bind("tab: complete")
    path = history_file()
    try:
        if path.is_file():
            readline.read_history_file(str(path))
        readline.set_history_length(500)
    except OSError:
        logs.swallowed(log, "setup_line_editing: OSError")
        pass

    def save() -> None:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            readline.write_history_file(str(path))
        except OSError:
            logs.swallowed(log, "save: OSError")
            pass  # a read-only home: no history, nothing else changes

    atexit.register(save)
    _EDITING.append(True)
    return True


def _complete(text: str, state: int) -> str | None:
    """Tab: the suggestion, when what is typed so far is its beginning (an empty line, or a start)."""
    if state == 0 and _SUGGESTION and _SUGGESTION[0] and _SUGGESTION[0].startswith(text):
        return _SUGGESTION[0]
    return None


ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")


def editable_prompt(prompt: str) -> str:
    """A prompt line editing can measure. Every colour code is wrapped in \\001 / \\002 (GNU
    readline then counts it as no width: moving in a long answer redraws it right). macOS libedit
    does not reliably understand those markers: there the prompt line has no colour at all, unless
    ARCHVOW_PROMPT_COLOURS=1 - the lines above it keep theirs. Without readline (Windows), the
    console edits the line itself and the prompt stays as it is."""
    if not ANSI_RE.search(prompt) or "readline" not in sys.modules:  # Windows: no readline, nothing to mark
        return prompt
    if _libedit() and not settings().prompt_colours:
        return ANSI_RE.sub("", prompt)
    return ANSI_RE.sub(lambda m: f"\001{m.group(0)}\002", prompt)


def _libedit() -> bool:
    module = sys.modules.get("readline")
    return module is not None and "libedit" in (module.__doc__ or "")


def ask(prompt: str, suggestion: str | None = None) -> str:
    """input() on an editable prompt, with Tab putting the suggestion into the line to edit it."""
    _SUGGESTION[:] = [suggestion or ""]
    try:
        return input(editable_prompt(prompt))
    finally:
        _SUGGESTION[:] = []


def ask_answers(template: Template, answers: dict, read: Callable[[str], str] | None = None) -> dict:
    """In a terminal, `init` asks the main questions (`ask: true`) that no `-a` answered.

    A list of choices is shown numbered: type a number, a value, or several separated by commas
    when more than one is allowed. Enter keeps the default. A wrong answer is asked again.
    """
    result = dict(answers)
    questions = {q["id"]: q for q in template.data.get("questions", [])}
    for question in template.data.get("questions", []):
        if question.get("ask") and question["id"] not in result:
            result[question["id"]] = _ask_one(template, question, read, known=result)
    while "architects" in questions and dora_approvers_problem(template, result):  # asked again, not refused
        print(f"\n  {dora_approvers_problem(template, result)}")
        result["architects"] = _ask_one(template, questions["architects"], read)
    return result


def ask_company_defaults(template: Template, read: Callable[[str], str] | None = None) -> dict:
    """`template new`: every init answer of the base, one at a time, as `init` asks them. Enter keeps
    the base's default (nothing written); an answer becomes the company's default."""
    chosen = {}
    for question in template.data.get("questions", []):
        value = _ask_one(template, question, read, keep=True)
        if value is not None:
            chosen[question["id"]] = value
    return chosen


def _ask_one(template: Template, question: dict, read: Callable[[str], str] | None,
             keep: bool = False, known: dict | None = None) -> str | None:
    """One init question in a terminal, until the answer is valid. `keep`: Enter answers None (the
    default stays the base's, for a company template). `known`: the answers so far."""
    qid = question["id"]
    choices = [str(c) for c in resolved_choices(template, question) or []]
    default = question_default(template, question, known)
    default = ",".join(default) if isinstance(default, list) else str(default or "")
    print("\n" + ui.question(question.get("prompt", qid)))
    titles = {c: template.family_title(c) for c in choices} if question.get("choices_from") == "rule_families" else {}
    width = max((len(c) for c in titles), default=0)
    for number, choice in enumerate(choices, 1):
        print(f"  {number}. {choice.ljust(width)}  {titles[choice]}".rstrip() if titles.get(choice)
              else f"  {number}. {choice}")
    hint = " (several: 1,3)" if question.get("multiple") and choices else ""
    while True:
        prompt = f"{qid}{hint} " + ui.hint(f"[{default}]") + ": "
        typed = (read(prompt) if read else ask(prompt, default)).strip()
        if keep and not typed:
            return None
        typed = typed or default
        items = [item.strip() for item in typed.split(",")] if question.get("multiple") else [typed]
        items = [choices[int(item) - 1] if item.isdigit() and 0 < int(item) <= len(choices) else item
                 for item in items]
        value = ",".join(items)
        try:
            check_answer(template, question, value)
        except SpecError as error:
            print(f"  {error}")
            continue
        return value
