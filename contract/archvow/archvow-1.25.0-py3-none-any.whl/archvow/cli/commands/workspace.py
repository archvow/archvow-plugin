"""`archvow workspace --json`: everything an editor shows of a project, in one process - the spec (`show --json`),
each component's view (`show <component> --json`), the build plan (`next --json`), the findings (`check --json`),
the briefs (`brief show --json`) and the templates (`catalog --json`), in the very shapes those commands print.
`--since <digest>`: when nothing changed since that answer, only `{"unchanged": true, "digest": ...}`.
"""

from __future__ import annotations

import argparse
from pathlib import Path

from archvow import __version__
from archvow.checks.engine import IGNORED_DIRS
from archvow.cli.args import Builder
from archvow.cli.commands.brief import brief_status
from archvow.cli.commands.plan import next_rows
from archvow.cli.commands.project import catalog_templates
from archvow.cli.console import style as ui
from archvow.cli.output import as_json, checked, project_root
from archvow.foundation.config import settings
from archvow.foundation.hashing import parts_digest, tree_state
from archvow.model import store
from archvow.views.component import component_view


def workspace_digest(root: Path) -> str:
    """What the answer depends on: archvow's version, the project's files (its vows, its code, its tests) and the
    company template folders (ARCHVOW_TEMPLATES). The same digest: the same answer."""
    parts = [("archvow", __version__.encode()), ("project", tree_state(root, IGNORED_DIRS).encode())]
    parts += [(f"templates {folder}", tree_state(Path(folder), IGNORED_DIRS).encode())
              for folder in settings().templates if Path(folder).is_dir()]
    return parts_digest(parts)


def workspace(args: argparse.Namespace, root: Path) -> dict:
    """The whole project as the editor reads it, the check run once for every component."""
    data = store.load(root)
    report = checked(args, root)
    ids = [c["id"] for container in data.get("containers", []) for c in container.get("components", [])]
    rows, _, _ = next_rows(root, None)
    return {"project": data,
            "components": {cid: component_view(root, data, cid, report) for cid in ids},
            "next": rows,
            "check": report.to_dict(),
            "briefs": brief_status(root, data),
            "catalog": {"templates": [template.summary() for template in catalog_templates(root)]}}


def cmd_workspace(args: argparse.Namespace) -> int:
    root = project_root(args)
    digest = workspace_digest(root)
    if args.since and args.since == digest:
        found: dict = {"unchanged": True, "digest": digest}
    else:
        found = {"digest": digest, **workspace(args, root)}
    if args.json:
        print(as_json(found))
        return 0
    if found.get("unchanged"):
        print(ui.ok("Nothing changed since that answer") + ui.dim(f"  (digest {digest})"))
        return 0
    errors = sum(v["severity"] == "error" for v in found["check"]["violations"])
    print(f"{len(found['components'])} components, {len(found['next'])} in the build plan, "
          f"{len(found['check']['violations'])} findings ({errors} errors)" + ui.dim(f"  (digest {digest})"))
    print(ui.dim("  for an editor or a script: archvow workspace --json (--since <digest>: only if something changed)"))
    return 0


def declare_workspace(b: Builder) -> None:
    """`archvow workspace`: its parser."""
    p = b.command("workspace", cmd_workspace, "everything an editor shows of the project, in one call (for tools)",
                  True, examples="""
        archvow workspace --json                  # the spec, every component, next, check, briefs, templates
        archvow workspace --json --since 4f2a9c0d1e3b   # only {"unchanged": true} when nothing changed
        """)
    p.add_argument("--since", metavar="DIGEST",
                   help="the digest of an earlier answer: when nothing changed since, print only "
                        "{\"unchanged\": true, \"digest\": ...}")
