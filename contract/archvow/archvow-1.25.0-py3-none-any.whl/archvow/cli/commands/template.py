"""`archvow template new`: a template that extends another one (replaced by packs in 1.26).
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from archvow.cli.args import (
    Builder,
)
from archvow.cli.console import style as ui
from archvow.cli.console.ask import ask, ask_company_defaults, setup_line_editing
from archvow.cli.output import project_root
from archvow.foundation import logs
from archvow.foundation.errors import SpecError
from archvow.model import store
from archvow.spec.answers import check_answer
from archvow.templates import (
    TemplateError,
    check_layer_names,
    load_template,
    scaffold_custom_template,
)

log = logs.get("cli")


def _split_list(text: str | None) -> list[str]:
    return [item.strip() for item in (text or "").replace(" ", ",").split(",") if item.strip()]


def _template_settings(args: argparse.Namespace, root: Path | None) -> dict:
    """What `template new` writes as settings: from the options, or asked in a terminal."""
    base = load_template(args.extends, root)
    given = args.description or args.answer or args.allowed_paths or args.verbatim_folders or args.layer
    if not given and not args.no_input and sys.stdin.isatty() and sys.stdout.isatty():
        setup_line_editing()
        print(ui.dim("Enter skips a question."))
        args.description = ask(f"  description [Custom variant of {args.extends}.]: ").strip() or None
        print(ui.dim(f"\nThe company's defaults for the init answers of {args.extends}, one at a time: Enter "
                     "keeps the base's default; a project can still change any of them (-a)."))
        args.answer = [f"{key}={value}" for key, value in ask_company_defaults(base).items()]
        print()
        args.allowed_paths = ask("  allowed_paths - top folders of Python files that are not "
                                    "components (e.g. devops,tools): ")
        args.verbatim_folders = ask("  verbatim_folders - folders of files/ copied as they are, .j2 "
                                       "included (e.g. templates): ")
        layers = " ".join(layer["name"] for layer in base.layers)
        args.layer = ask(f"  layer folders - Enter keeps {layers}; to rename, LAYER=FOLDER separated by "
                            "spaces (e.g. p1_domain=domain): ").split()
    questions = {q["id"]: q for q in base.data.get("questions", [])}
    defaults = {}
    for item in args.answer or []:
        key, sep, value = item.partition("=")
        if not sep:
            raise SpecError(f"-a {item}: write KEY=VALUE (e.g. -a ci=jenkins)")
        if key not in questions:
            raise SpecError(f"-a {key}: {args.extends} has no such init answer "
                            f"(archvow catalog lists them: {', '.join(questions)})")
        defaults[key] = check_answer(base, questions[key], value)
    allowed = [entry.strip("/") for entry in _split_list(args.allowed_paths)]
    deep = [entry for entry in allowed if "/" in entry]
    if deep:
        raise SpecError(f"allowed_paths: {', '.join(deep)} - only top folders (archvow looks at the "
                        "first folder of a file's path: devops covers devops/deploy/run.py)")
    verbatim = [entry.strip("/") for entry in _split_list(args.verbatim_folders)]
    layer_names = {}
    for item in args.layer or []:
        old, sep, new = item.partition("=")
        if not sep:
            raise SpecError(f"--layer {item}: write LAYER=FOLDER (e.g. --layer p1_domain=domain)")
        layer_names[old.strip()] = new.strip()
    try:
        check_layer_names(args.name, [layer["name"] for layer in base.layers], layer_names)
    except TemplateError as exc:
        raise SpecError(str(exc).replace("layer_names:", "--layer:")) from exc
    return {"description": args.description, "defaults": defaults, "allowed_paths": allowed,
            "verbatim_folders": verbatim, "layer_names": layer_names}


def cmd_template_new(args: argparse.Namespace) -> int:
    if args.dir:  # a company template, in the team's catalog: no project needed
        try:
            root: Path | None = project_root(args)
        except store.ManifestError:
            logs.swallowed(log, "cmd_template_new: store.ManifestError")
            root = None
        catalog = Path(args.dir).resolve()
        directory = scaffold_custom_template(root, args.name, args.extends, catalog=catalog,
                                             **_template_settings(args, root))
        print(ui.ok(f"Created {directory}") + "\n"
              f"Edit template.yaml and add your files in files/. To use it, on developer machines and in CI:\n"
              f"  export ARCHVOW_TEMPLATES={catalog}\n"
              f"  archvow init <package> -t {args.name} -a architects=@<group>")
        return 0
    try:
        root = project_root(args)
    except store.ManifestError as exc:
        raise SpecError("not in an archvow project: to create a company template, pass --dir "
                        "<catalog folder>") from exc
    directory = scaffold_custom_template(root, args.name, args.extends, **_template_settings(args, root))
    print(ui.ok(f"Created {directory.relative_to(root)}") + ". Edit template.yaml (a guard: the architects "
          "approve it); projects created from now on can use it with -t " + args.name + ".")
    return 0


def declare_template(b: Builder) -> None:
    """`archvow template`: its parser."""
    p = b.command("template", None, "create company or project-local templates",
                  examples="archvow template new acme-pyspark --extends pyspark-pipeline --dir ~/archvow-templates")
    tsub = p.add_subparsers(dest="template_command", required=True, metavar="new",
                            help="archvow template new --help: options and examples")
    tp = b.command("new", cmd_template_new, "create a template that extends another one", parent=tsub,
                   examples="""
        archvow template new acme-pyspark --extends pyspark-pipeline --dir ~/archvow-templates
            # a company template, in the team's catalog (then: export ARCHVOW_TEMPLATES=...)
        archvow template new my-variant --extends pyspark-pipeline
            # inside a project: .archvow/templates/my-variant
        archvow template new acme-pyspark --extends pyspark-pipeline --dir ~/archvow-templates -a ci=jenkins --allowed-paths devops,tools
            # with its settings (also -d, --verbatim-folders, --layer); without options, a terminal asks them
        """)
    tp.add_argument("name", help="name of the new template")
    tp.add_argument("--extends", required=True, metavar="TEMPLATE", help="template it builds on")
    tp.add_argument("--dir", metavar="FOLDER",
                    help="catalog folder to create it in (a company template; no project needed). "
                         "Default: the current project's .archvow/templates/")
    tp.add_argument("-d", "--description", metavar="TEXT", help="what the template is for (one line)")
    tp.add_argument("-a", "--answer", action="append", metavar="KEY=VALUE",
                    help="a company default for an init answer, repeatable (-a ci=jenkins -a sonar=yes); "
                         "a project can still override it")
    tp.add_argument("--allowed-paths", metavar="FOLDERS",
                    help="top folders of Python files that are not components, comma-separated "
                         "(devops,tools): no ARCH015 there; added to the base's")
    tp.add_argument("--verbatim-folders", metavar="FOLDERS", dest="verbatim_folders",
                    help="folders of files/ copied exactly as they are, .j2 included, comma-separated "
                         "(templates,deploy/ansible)")
    tp.add_argument("--layer", action="append", metavar="LAYER=FOLDER",
                    help="rename a layer's folder, repeatable (--layer p1_domain=domain): "
                         "src/<package>/domain/, tests/domain/; the others keep the base's")
    tp.add_argument("--no-input", action="store_true",
                    help="never ask: without options, the settings stay commented examples")
