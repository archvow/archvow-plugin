"""The pack commands that write: `pack new`, `pack template`, `pack add`, `pack update`, `pack remove`.
(`pack agent` and `pack rule`: spec/pack_parts.py; `pack check`: spec/pack_check.py.)

A pack is created in a folder (a company pack, `--dir`) or straight into the project (`.archvow/packs/<name>/`,
recorded). `pack add` copies a pack into the project and records its version, source and digest in project.vow;
`update` takes a new version from the same source; `remove` takes it out. Clones, the Git hook and the CI read
only the copy.
"""

from __future__ import annotations

import os
import shutil
from pathlib import Path
from typing import Any

import yaml

from archvow import __version__
from archvow.foundation import logs
from archvow.foundation.errors import PackError
from archvow.foundation.files import write_text
from archvow.model import store
from archvow.packs import regimes
from archvow.packs import rules as pack_rules
from archvow.packs import store as packs
from archvow.templates import TemplateError, check_layer_names, load_template, template_name

log = logs.get("spec.packs")


def pack_folder(target: str, root: Path | None) -> Path:
    """`<pack>` of a command: a folder with pack.yaml, or the name of one of the project's packs."""
    folder = Path(target).expanduser()
    if (folder / "pack.yaml").is_file():
        return folder.resolve()
    if root is not None and (root / packs.PROJECT_PACKS / target / "pack.yaml").is_file():
        return root / packs.PROJECT_PACKS / target
    raise PackError(f"'{target}' is neither a pack folder nor a pack of this project",
                    hint="give the pack's folder (archvow pack new <name> --dir <folder> makes one)")


def new_pack(root: Path | None, name: str, description: str, folder: Path | None, version: str = "1.0.0",
             languages: tuple[str, ...] = ("en", "fr")) -> Path:
    """A new pack: pack.yaml, README.md and commented examples. In `folder` (a company pack), else in the
    project, recorded at once."""
    if not packs.NAME_RE.match(name) or name == "archvow":
        raise PackError(f"'{name}': a pack's name is lowercase letters, digits and dashes (acme, acme-data), "
                        "never archvow")
    if not packs.VERSION_RE.match(version):
        raise PackError(f"--version {version}: MAJOR.MINOR.PATCH (1.0.0)")
    if folder is None and root is None:
        raise PackError("not in an archvow project: pass --dir <folder> to create a company pack there")
    target = (folder.expanduser().resolve() / name) if folder is not None else (root or Path()) / packs.PROJECT_PACKS / name
    if target.exists():
        raise PackError(f"{target} already exists")
    major, minor = (int(p) for p in __version__.split(".")[:2])
    meta = {"name": name, "version": version, "archvow": f">={major}.{minor},<{major + 1}",
            "description": description, "languages": [lang for lang in dict.fromkeys(("en", *languages))]}
    target.mkdir(parents=True)
    write_text(target / "pack.yaml", "# A pack (docs/packs.md of archvow): data only, never Python.\n"
               + yaml.safe_dump(meta, sort_keys=False, allow_unicode=True))
    write_text(target / "README.md", README.format(name=name, description=description))
    for rel, text in EXAMPLES.items():
        write_text(target / "examples" / rel, text)
    if folder is None and root is not None:
        _record(root, target, source=f"{packs.PROJECT_PACKS.as_posix()}/{name}")
    return target


def _record(root: Path, folder: Path, source: str) -> None:
    """Record a pack's copy in project.vow; before init, note its source beside the copy (init records it)."""
    pack = packs.read(folder)
    if not store.is_project(root):
        write_text(root / packs.PROJECT_PACKS / f"{pack.name}.source", source + "\n")
        return
    data = store.load(root)
    packs.record(data, pack, source)
    store.save(root, data)


def rerecord(root: Path | None, folder: Path) -> None:
    """After a command wrote into a pack of the project: its new digest recorded (no ARCH060 for archvow's
    own writes)."""
    if root is None or folder.parent.resolve() != (root / packs.PROJECT_PACKS).resolve():
        return
    entry = packs.recorded(store.load(root)).get(folder.name) if store.is_project(root) else None
    _record(root, folder, (entry or {}).get("source") or f"{packs.PROJECT_PACKS.as_posix()}/{folder.name}")


def _brings(folder: Path) -> set[str]:
    """What a pack brings that only one pack of a project may: its rule codes, its regimes (their ids, code
    prefixes and question letters) and its agents. A part it cannot read is left out (pack check says why)."""
    found = {f"agent {path.parent.name}" for path in folder.glob("agents/*/agent.yaml")}
    try:
        found |= {f"rule {code}" for code in pack_rules.pack_rules(folder)}
    except PackError:
        logs.swallowed(log, "_brings: rules")
    for path in sorted(folder.glob("regimes/*.yaml")):
        try:
            regime = regimes.read_file(path)
        except PackError:
            logs.swallowed(log, "_brings: regime")
            continue
        found |= {f"regime {regime.id}", f"regime prefix {regime.prefix}", f"regime letter {regime.letter}"}
    return found


def _refuse_clash(root: Path, folder: Path) -> None:
    """Before a copy: the pack in `folder` brings nothing another pack of the project brings (the later one would
    replace it without a word, and two regimes with one letter would share their question keys)."""
    name, new = packs.read(folder).name, _brings(folder)
    for other in packs.project_packs(root):
        clash = sorted(new & _brings(other.root)) if other.name != name else []
        if clash:
            raise PackError(f"pack {other.name} already brings {', '.join(clash)}: pack {name} cannot be added "
                            "beside it", hint=f"rename them in pack {name}, or take pack {other.name} out")


def add_pack(root: Path, source: str) -> packs.Pack:
    """`pack add <folder or package>`: copied into the project, recorded."""
    if not root.is_dir():
        raise PackError(f"{root} does not exist: create the project's folder first (or run init)")
    folder = packs.source_folder(source)
    _refuse_clash(root, folder)
    pack = packs.copy_in(root, folder)
    _record(root, pack.root, _recorded_source(root, source, folder))
    return pack


def _recorded_source(root: Path, source: str, folder: Path) -> str:
    """How project.vow names where a pack comes from: an installed package by its name; a folder by its path from
    the project's root - `packs/acme` inside it, `../company-packs/acme` beside it - the same on every clone laid out
    alike, and never a person's home path. Only a folder on another drive (Windows) keeps its absolute path."""
    if not Path(source).expanduser().is_dir():
        return source
    try:
        # the path as given first (a link the person went through stays in it: ../linked/acme, not where the link
        # points on this machine), when it leads from the root to the same folder; else the real one
        for rel in (os.path.relpath(os.path.abspath(Path(source).expanduser()), os.path.abspath(root)),
                    os.path.relpath(folder, root.resolve())):
            if (root / rel).resolve() == folder:
                return Path(rel).as_posix()
        return Path(os.path.relpath(folder, root.resolve())).as_posix()
    except ValueError:  # another drive: no path from the root leads there
        return str(folder)


def update_pack(root: Path, name: str, source: str | None = None) -> tuple[str, packs.Pack]:
    """`pack update <name>`: a new copy from its recorded source (or `source`); (the old version, the pack)."""
    entry = packs.recorded(store.load(root)).get(name)
    if entry is None:
        raise PackError(f"this project has no pack '{name}'", hint="archvow pack add <folder or package>")
    origin = source or entry.get("source") or ""
    if not origin or origin == f"{packs.PROJECT_PACKS.as_posix()}/{name}":
        raise PackError(f"pack {name} was made in this project: it has no other source to update from",
                        hint=f"archvow pack update {name} --from <folder or package>")
    given = origin
    if not source and not Path(origin).expanduser().is_absolute():  # recorded: a folder from the project's root
        from_root = root / origin
        if (from_root / "pack.yaml").is_file():
            given, folder = str(from_root), packs.source_folder(str(from_root))
        elif from_root.exists() or "/" in origin or "\\" in origin or origin.startswith("."):
            # never the same path from wherever archvow runs (2.6.0 recheck, ISSUE-030): another folder, another pack
            raise PackError(f"pack {name} comes from {origin} (from the project's root: {os.path.normpath(from_root)}), which holds no "
                            "pack.yaml", hint=f"lay the folders out as project.vow records them, or archvow pack update "
                            f"{name} --from <folder or package>")
        else:
            folder = packs.package_folder(origin)  # an installed package, by its name
    else:
        folder = packs.source_folder(origin)
    origin = _recorded_source(root, given, folder)  # an old absolute one: rewritten
    found = packs.read(folder).name  # checked before anything is copied
    if found != name:
        raise PackError(f"{origin} holds pack {found}, not {name}")
    _refuse_clash(root, folder)
    pack = packs.copy_in(root, folder)
    _record(root, pack.root, origin)
    return str(entry.get("version") or "?"), pack


def _in_use(root: Path, data: dict[str, Any], name: str) -> list[str]:
    """What of pack `name` the project uses: a template (its own or one it extends), a chosen regime, the profile
    of an approved AI tool (removing it would change how the agent gate recognises that tool)."""
    used = []
    for container in data.get("containers") or []:
        ref = template_name(container)[0]
        try:
            template = load_template(ref, root)
            chain = [template.qualified, *template.data.get("_extends_chain", [])]
        except TemplateError:
            chain = [ref]
        used += [f"container {container['id']} uses template {t}" for t in chain if t.split("/", 1)[0] == name]
    used += [f"regime {r.id} is chosen" for r in regimes.chosen(root, data) if r.pack == name]
    agents = root / packs.PROJECT_PACKS / name / "agents"
    tools = dict.fromkeys([*(data.get("ai_tools") or []), *(data.get("reviewers") or [])])
    return used + [f"the approved AI tool {t} has its profile there" for t in tools if (agents / t / "agent.yaml").is_file()]


def remove_pack(root: Path, name: str) -> None:
    """`pack remove <name>`: refused while the project uses something of it (_in_use)."""
    data = store.load(root)
    used = _in_use(root, data, name)
    if used:
        raise PackError(f"pack {name} stays: {'; '.join(used)}", hint=f"change these first, then archvow pack remove {name}")
    if name not in packs.recorded(data) and not (root / packs.PROJECT_PACKS / name).is_dir():
        raise PackError(f"this project has no pack '{name}'")
    shutil.rmtree(root / packs.PROJECT_PACKS / name, ignore_errors=True)
    data["packs"] = {k: v for k, v in packs.recorded(data).items() if k != name}
    if not data["packs"]:
        data.pop("packs")
    store.save(root, data)


def add_template(root: Path | None, folder: Path, name: str, extends: str, description: str | None = None,
                 defaults: dict[str, Any] | None = None, allowed_paths: list[str] | None = None,
                 verbatim_folders: list[str] | None = None, layer_names: dict[str, str] | None = None) -> Path:
    """`pack template`: a template of the pack that extends another one (of this pack, or any pack the project
    can use). What is given is written as settings; the rest stays as commented examples."""
    if not packs.NAME_RE.match(name):
        raise PackError(f"'{name}': a template's name is lowercase letters, digits and dashes (acme-pyspark)")
    pack = packs.read(folder)
    try:
        base = load_template(extends, root, extra=(folder,))
    except TemplateError as error:
        raise PackError(str(error), hint="archvow catalog lists the templates; a template of this pack too") from error
    directory = pack.templates / name
    if directory.exists():
        raise PackError(f"{directory} already exists")
    written = base.name if base.pack == pack.name else base.qualified
    text = TEMPLATE.format(name=name, extends=written, description=_flow(description or f"{pack.name}'s {base.name}."))
    if defaults:
        text = text.replace(DEFAULTS_EXAMPLE, "questions_defaults:\n" + "".join(
            f"  {key}: {_flow(value)}\n" for key, value in defaults.items()))
    if allowed_paths:
        text = text.replace(ALLOWED_EXAMPLE, f"allowed_paths: {_flow(allowed_paths)}\n")
    if verbatim_folders:
        text = text.replace(VERBATIM_EXAMPLE, f"verbatim_folders: {_flow(verbatim_folders)}\n")
    current = base.data.get("layer_names") or {}
    layers = {layer["name"]: current.get(layer["name"], layer["name"]) for layer in base.layers}
    if layers:  # every layer with its folder: the base's, unless renamed here
        check_layer_names(name, list(layers), layer_names or {})
        layers |= layer_names or {}
        text = text.replace(LAYERS_EXAMPLE, "layer_names:\n" + "".join(
            f"  {layer}: {where}\n" for layer, where in layers.items()))
    (directory / "files").mkdir(parents=True)
    write_text(directory / "template.yaml", text)
    raw = yaml.safe_load((folder / "pack.yaml").read_text(encoding="utf-8")) or {}
    for language in [str(lang) for lang in raw.get("languages") or []] or []:
        if language != "en":  # the texts this template adds, in the pack's other languages (the base's are already)
            write_text(directory / f"template.{language}.yaml",
                       f"# The texts of {name} in '{language}': only what template.yaml adds or changes (description,\n"
                       f"# questions, component types...); what it inherits from {written} is already translated.\n"
                       f"# French files go in files-{language}/.\n")
    rerecord(root, folder)
    return directory


def _flow(value: object) -> str:
    """A value as one line of YAML (a list in brackets, a string quoted only when it must be)."""
    dumped: str = yaml.safe_dump(value, default_flow_style=True, allow_unicode=True, width=10_000)
    return dumped.strip().removesuffix("\n...").strip()


README = """# Pack {name}

{description}

A pack of archvow: templates (templates/, each in English and in the pack's other languages: template.<lang>.yaml
and files-<lang>/), agent profiles (agents/), declarative rules (rules/) and privacy regimes (regimes/), data only. Add parts with `archvow pack template|agent|rule <folder> ...`, test the whole pack with
`archvow pack check <folder>`, and give it to projects with `archvow pack add <folder>` (or a pip package that
names this folder in its `archvow.packs` entry point). See docs/packs.md of archvow; examples/ holds commented
examples of each part.
"""

EXAMPLES = {
    "agent.yaml": """# agents/<name>/agent.yaml - only what differs from the standard (AGENTS.md, .agents/skills,
# AI_AGENT/AGENT=<name>); every key is optional. archvow pack agent writes it.
# title: ACME Assistant
# skills: .acme/skills                      # a copy of .agents/skills where it reads its skills
# detect: {processes: [acme-assistant], env: [ACME_ASSISTANT]}
# yolo: [--no-confirm]                      # options that let it act without asking: archvow refuses them
# fix: start ACME Assistant without --no-confirm
# review: {command: acme-assistant review "$ARCHVOW_REVIEW_PROMPT", secret: ACME_TOKEN}
# owns: [.acme]                             # its files: flagged while it is not approved
""",
    "ACME.yaml": """# rules/<FAMILY>.yaml - one entry per code; the family is the code's letters. archvow pack rule writes it.
# ACME001:
#   kind: forbid_import                      # forbid_import, forbid_call, forbid_pattern, forbid_file, only_in,
#   target: [legacy_billing]                 # require_keyword, require_question
#   in_layers: [p1_domain, p2_io]
#   severity: error
#   message: No direct use of the old billing API
#   message_fr: Pas d'appel direct à l'ancienne API de facturation
#   fix: use acme_billing.client instead
#   bad: "import legacy_billing"
#   good: "import acme_billing.client"
""",
    "regime.yaml": """# regimes/<id>.yaml - a privacy law as data (docs/packs.md, "A regime"); the file's name is its id.
# archvow's PRIV rules already check what every privacy law needs; a regime adds its questions and its register.
# Copy this file to regimes/hipaa.yaml and remove the # signs. Every text has its _fr twin when the pack is French.
# name: HIPAA                     # the file's name in capitals: -a rules=...,HIPAA
# prefix: HIPAA                   # its codes: HIPAA001...
# letter: H                       # its questions: H1, H2... (not O or C, nor P, U, G: archvow's regimes)
# default: false
# title: "HIPAA (US health information): minimum necessary, safeguards, business associates, breaches"
# law: "HIPAA Privacy, Security and Breach Notification Rules (45 CFR 160 and 164)"
# checked: "2026-11-11"           # the day its texts were checked against the law
# covers: [health]                # only the columns tagged health (archvow column set ... --tag health)
# rules:
#   HIPAA001: {title: "Protected health information used beyond the minimum necessary"}
#   HIPAA002: {title: "Protected health information stored without decided safeguards"}
# questions:                      # by role: purpose, store, share (the template says which types play them)
#   purpose:
#     - {id: minimum_necessary, rule: HIPAA001, text: "Minimum necessary: which health information does it need, and why no more - e.g. the diagnosis code only?"}
#   store:
#     - {id: safeguards, rule: HIPAA002, when: writes, text: "Safeguards: how is access limited and logged, and is it encrypted at rest and in transit - e.g. role-based access, audit log, AES-256?"}
# register:
#   file: PROTECTED_HEALTH_INFORMATION.md
#   title: "Protected health information"
#   intro: "Every column tagged health, and the components that read, change and write it."
#   answers: "Minimum necessary, safeguards"
""",
}

DEFAULTS_EXAMPLE = """\
# questions_defaults:
#   ci: jenkins
#   sonar: "yes"
"""
ALLOWED_EXAMPLE = "# allowed_paths: [devops, tools]\n"
VERBATIM_EXAMPLE = "# verbatim_folders: [templates]\n"
LAYERS_EXAMPLE = "# layer_names: {p1_domain: domain}\n"

TEMPLATE = """\
# Template '{name}'. Everything not declared here is inherited from '{extends}'.
# Mappings merge key by key, layers merge by name, any other value (a list) replaces the base's,
# except allowed_paths, which adds to the base's.
# Files: put them in ./files/ - rendered with Jinja2 when they end in .j2, copied as they are
# otherwise (or when their folder is in `verbatim_folders`). French versions go in ./files-fr/.
name: {name}
extends: {extends}
version: 0.1.0
description: {description}

# Your defaults for the init answers (a project can still override them with -a).
""" + DEFAULTS_EXAMPLE.replace("{", "{{").replace("}", "}}") + """
# Top folders of Python files that are not components (no ARCH015), added to the base's.
""" + ALLOWED_EXAMPLE + """
# Folders of ./files/ copied exactly as they are, even their .j2 files (another tool renders them).
""" + VERBATIM_EXAMPLE + """
# The folder of each layer (src/<package>/<folder>/, tests/<folder>/): change the right-hand side to
# rename one; archvow uses it everywhere (layers, component types, the files it writes).
""" + LAYERS_EXAMPLE.replace("{", "{{").replace("}", "}}") + """
# Example: add a new component type.
# component_types:
#   stream_reader:
#     layer: p2_io
#     description: Structured Streaming source.
#     module: "{{name}}_stream_reader"
#     name_pattern: "^[a-z][a-z0-9_]*$"
#     symbols:
#       - kind: function
#         name: "read_{{name}}_stream"
#         signature: "(spark: SparkSession, source: str) -> DataFrame"
#     guide_words: [missing, wrong]
#     edge_cases:
#       - "The source is unavailable: fail or wait (e.g. wait 10 min, then fail)?"
#       - question: "A record has no event time: drop it or fail (e.g. drop and count it)?"
#         suggested: "fail with the record's key in the error"   # `decision make <c> <n>` without text takes it

# Example: tune a rule for every project using this template.
# rules:
#   SPK009: {{severity: error, max_chain: 4}}
"""
