"""archvow's bootstrap: streams, completion, logs, the agent gate, dispatch, and ONE error handler that
turns every error into an exit code (2: archvow said no, 70: a bug).
"""

from __future__ import annotations

import argparse
import contextlib
import sys
import time
from collections.abc import Callable
from pathlib import Path
from typing import cast

from archvow import (
    __version__,
    agent,  # agent.gate through the module: a wrapper put on it (the tests' recorder) is used
)
from archvow.cli.commands.project import cmd_completion, cmd_doctor, cmd_version
from archvow.cli.console import completion
from archvow.cli.console import style as ui
from archvow.cli.output import as_json, project_root
from archvow.cli.parser import build_parser
from archvow.foundation import logs, once
from archvow.foundation.config import settings
from archvow.foundation.errors import ArchvowError, FileAccessError
from archvow.model import store

log = logs.get("cli")


INTERNAL_ERROR = 70  # an error archvow did not expect: a bug (sysexits EX_SOFTWARE)
# the commands that only read the project: each file is read once (foundation/once.py)
READS = frozenset({"show", "catalog", "next", "check", "audit", "changes", "diff", "prompt", "workspace"})


def gate_name(func: Callable[[argparse.Namespace], int]) -> str:
    """The command as the agent gate names it, from its handler: cmd_decision_make -> "decision make"."""
    return func.__name__.removeprefix("cmd_").replace("_", " ")


def _agent_gate(args: argparse.Namespace) -> list[str]:
    """Inside an AI agent in YOLO mode, or outside a sandbox when the project asks for one, archvow
    refuses to run (ARCH052, ARCH051): the lines it printed, with the fix (none: go on). `doctor` still says
    what archvow sees."""
    func = getattr(args, "func", None)
    if func in (cmd_doctor, cmd_version, None) or (func is cmd_completion and not args.install):
        return []
    command = "completion --install" if func is cmd_completion else gate_name(func)  # it writes the shell's rc
    try:
        root = project_root(args)
        data = store.load(root)
    except store.ManifestError:  # not in a project yet (init): only a person creates one
        logs.swallowed(log, "_agent_gate: store.ManifestError")
        lines = agent.gate_outside(Path(getattr(args, "dir", None) or Path.cwd()), command)
    else:
        lines = agent.gate(root, data, command)
    for line in lines:
        print(ui.error(line) if line.startswith("ARCH") else line, file=sys.stderr)
    log.info("agent gate: %s", "refused" if lines else "allowed")
    return lines


VERBOSE = {"-v": 1, "-vv": 2, "-vvv": 2, "--verbose": 1}


def _verbosity(argv: list[str]) -> tuple[list[str], int]:
    """-v / -vv / --verbose may come anywhere on the line (archvow next -v): taken out before parsing."""
    words, level, rest = [], 0, False
    for word in argv:
        if word == "--":
            rest = True
        if not rest and word in VERBOSE:
            level += VERBOSE[word]
            continue
        words.append(word)
    return words, min(level, 2)


def _command_words(parser: argparse.ArgumentParser) -> set[str]:
    """Every command and verb name (`decision`, `make`...): what a log may show of a command line."""
    words: set[str] = set()
    for action in parser._actions:
        if isinstance(action, argparse._SubParsersAction):
            for name, sub in action.choices.items():
                words |= {name, *_command_words(sub)}
    return words


def _error_envelope(argv: list[str], kind: str, message: str, hint: str | None, code: int) -> None:
    """With --json, an error is also an object on stdout, so a tool never parses the red text."""
    if "--json" in argv:
        print(as_json({"error": {"type": kind, "message": message, "hint": hint, "exit": code}}))


def _explained(argv: list[str], exc: ArchvowError) -> int:
    print(ui.error(f"archvow: error: {exc}"), file=sys.stderr)
    if exc.hint:
        print(f"  {exc.hint}", file=sys.stderr)
    _error_envelope(argv, exc.kind, str(exc), exc.hint, exc.exit_code)
    return exc.exit_code


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    for stream in (sys.stdout, sys.stderr):  # a character the console can't show is replaced, never a crash
        try:
            stream.reconfigure(errors="replace")  # type: ignore[union-attr]
        except (AttributeError, ValueError):  # not a text stream (tests, pipes of some IDEs): left as it is
            continue
    if argv[:1] == ["__complete"]:  # what Tab asks: `archvow __complete <shell> <line>` (completion.py)
        return completion.run(argv[1] if len(argv) > 1 else "zsh", argv[2] if len(argv) > 2 else "archvow ",
                              build_parser())
    argv, verbosity = _verbosity(argv)
    env = settings()
    parser = build_parser()
    logs.COMMAND_WORDS.update(_command_words(parser))
    logs.setup(argv, verbosity, env.log, env.log_file)
    if not argv:  # `archvow` alone: the icon, the version and the commands
        print(ui.logo(f"archvow {__version__}") + "\n")
        parser.print_help()
        return 0
    args = parser.parse_args(argv)
    start = time.perf_counter()
    log.info("start %s (archvow %s, Python %s, %s)", " ".join(logs.masked_command(argv)), __version__,
             sys.version.split()[0], Path.cwd())
    code = _run(args, argv)
    log.info("done exit %d (%d ms)", code, round((time.perf_counter() - start) * 1000))
    return code


def _run(args: argparse.Namespace, argv: list[str]) -> int:
    """The command, and the one place where errors become a message and an exit code."""
    try:
        # a command that only reads reads each file once (foundation/once.py), the gate's spec included
        with once.reading() if getattr(args, "command", None) in READS else contextlib.nullcontext():
            refused = _agent_gate(args)
            if refused:  # exit 1 as before; with --json the usual error object too (a tool must not read findings)
                arch = [line for line in refused if line.startswith("ARCH")] or refused
                _error_envelope(argv, "AgentRefused", " ".join(arch),
                                " ".join(r for r in refused if r not in arch) or None, 1)
                return 1
            return cast(int, args.func(args))
    except BrokenPipeError:  # output piped into `head` and the like: not an error
        import os

        os.dup2(os.open(os.devnull, os.O_WRONLY), sys.stdout.fileno())
        return 0
    except PermissionError as exc:  # a file the system does not let archvow use: an error to explain, not a bug
        where = exc.filename or "a file"
        return _explained(argv, FileAccessError(f"permission denied: {where}", hint="give your user the right to "
                                                "read it (and write it, if archvow writes there), or move it away"))
    except ArchvowError as exc:
        return _explained(argv, exc)
    except (KeyboardInterrupt, EOFError):  # Ctrl+C or Ctrl+D during a question: no traceback
        print("\n" + ui.error("stopped"), file=sys.stderr)
        return 130
    except Exception as exc:  # noqa: BLE001 - anything else is a bug: a short message and a crash report
        report = logs.crash_report(exc, __version__, argv)
        print(ui.error(f"archvow {__version__} internal error (a bug): {type(exc).__name__}: {exc}"), file=sys.stderr)
        print(f"  report: {report}" if report else "  (no crash report: the cache folder cannot be written)",
              file=sys.stderr)
        _error_envelope(argv, "InternalError", f"{type(exc).__name__}: {exc}",
                        f"report: {report}" if report else None, INTERNAL_ERROR)
        return INTERNAL_ERROR
