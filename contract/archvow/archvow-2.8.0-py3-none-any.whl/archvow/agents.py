"""AI agents (layer 1): the standard every project gets, and a profile only where an agent differs.

Every project has the standard files whatever its agents: AGENTS.md (the rules) and `.agents/skills/archvow-*/`
(the procedures). Any name can be approved (`-a ai_tools=claude-code,newagent`): an agent with no profile gets the
standard one - it reads AGENTS.md and .agents/skills, archvow recognises it by AI_AGENT or AGENT=<name>, and knows
nothing more about it. A profile is a pack's `agents/<name>/agent.yaml`, every key optional:

    title: Claude Code                       how AGENTS.md names it
    skills: .claude/skills                   a copy of .agents/skills where the agent reads its skills
    detect: {processes: [claude], env: [CLAUDECODE]}   how archvow sees it running (the agent gate)
    yolo: [--dangerously-skip-permissions]   options that let it act without asking (ARCH052)
    unseen: "in the IDE plugin"              where archvow cannot see it
    fix: "start it in its sandbox"           how to start it again, protected
    review: {command: ..., secret: ...}      how `archvow review` runs it without a person
    permissions: "~/.x/allow.json"           where a person lists the auto-approved commands, when its own
                                             permission file is not in the project
    owns: [CLAUDE.md, .claude]               its files: present while it is not approved -> ARCH040
    when: {.cursor/cli.json: "auto_approve == 'yes'"}   conditions of its own files
    withdrawn: [.cursor/cli.json]            its files deleted at init --force once their condition is false

and its own files in `files/` (and `files-<lang>/`), rendered like a template's when it is approved. A profile of a
project's pack replaces archvow's for the same name.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any

import yaml

from archvow.foundation import logs
from archvow.foundation.errors import PackError
from archvow.foundation.files import parse_yaml
from archvow.packs import store as packs

log = logs.get("agents")

NAME_RE = re.compile(r"^[a-z][a-z0-9]*([_-][a-z0-9]+)*$")
STANDARD_SKILLS = ".agents/skills"


@dataclass(frozen=True)
class Profile:
    """What archvow knows of one agent: the standard, plus what its profile says."""

    name: str
    title: str = ""
    pack: str = ""  # "" for the standard profile
    folder: Path | None = None
    skills: str = ""
    processes: tuple[str, ...] = ()
    env: tuple[str, ...] = ()
    yolo: tuple[str, ...] = ()
    unseen: str = ""
    fix: str = ""
    review: dict[str, Any] = field(default_factory=dict)
    permissions: str = ""
    owns: tuple[str, ...] = ()
    when: dict[str, Any] = field(default_factory=dict)
    withdrawn: tuple[str, ...] = ()

    @property
    def standard(self) -> bool:
        return not self.pack

    def detect(self) -> dict[str, Any]:
        """How the agent gate recognises it (agent.py): its processes and its own variables. Every agent, with a
        profile or not, is also recognised by the standard variables AI_AGENT and AGENT naming it (agent.py)."""
        return {"processes": list(self.processes), "env": list(self.env), "yolo": list(self.yolo),
                "unseen": self.unseen, "fix": self.fix}

    def files(self, language: str) -> dict[str, Path]:
        """Its own files, relative path -> source (the language's version over the English one)."""
        if self.folder is None:
            return {}
        found: dict[str, Path] = {}
        for base in (self.folder / "files", self.folder / f"files-{language}"):
            if base.is_dir():
                found |= {p.relative_to(base).as_posix(): p for p in sorted(base.rglob("*"))
                          if p.is_file() and packs.kept(p, base)}
        return found

    def summary(self) -> dict[str, Any]:
        """What `catalog --json`, `workspace --json` and doctor say of it."""
        return {"name": self.name, "title": self.title or self.name, "pack": self.pack, "standard": self.standard,
                "skills": [STANDARD_SKILLS, *([self.skills] if self.skills else [])],
                "files": sorted(self.files("en")) if self.folder else [], "owns": list(self.owns),
                "detect": self.detect(), "review": bool(self.review.get("command")),
                "seen": bool(self.processes or self.env), "unseen": self.unseen}


def read(folder: Path, pack: str) -> Profile:
    """The profile in `folder` (agents/<name>/agent.yaml of a pack)."""
    path = folder / "agent.yaml"
    try:
        raw = parse_yaml(path.read_text(encoding="utf-8")) or {}
    except (OSError, yaml.YAMLError) as error:
        raise PackError(f"{path}: cannot be read ({error})") from error
    if not isinstance(raw, dict):
        raise PackError(f"{path}: expected a mapping (title, skills, detect, owns...)")
    name = folder.name
    if not NAME_RE.match(name):
        raise PackError(f"{path}: '{name}' is not an agent name (lowercase letters, digits, - and _)")
    skills = Path(str(raw.get("skills") or ""))
    if skills.is_absolute() or ".." in skills.parts:  # init writes the skills there (paths.inside refuses it too)
        raise PackError(f"{path}: skills '{skills}' leaves the project: give a folder inside it (.acme/skills)")
    detect = raw.get("detect") or {}

    def words(key: str, source: dict[str, Any] = raw) -> tuple[str, ...]:
        return tuple(str(v) for v in (source.get(key) or []))

    return Profile(name=name, title=str(raw.get("title") or ""), pack=pack, folder=folder,
                   skills=str(raw.get("skills") or ""), processes=words("processes", detect), env=words("env", detect),
                   yolo=words("yolo"), unseen=str(raw.get("unseen") or ""), fix=str(raw.get("fix") or ""),
                   review=dict(raw.get("review") or {}), permissions=str(raw.get("permissions") or ""),
                   owns=words("owns"), when={str(k): str(v) for k, v in (raw.get("when") or {}).items()},
                   withdrawn=words("withdrawn"))


SIGNALS = ("processes", "env", "yolo", "owns")  # what the gate reads: a pack may add to them, never remove


def profiles(root: Path | None) -> dict[str, Profile]:
    """Every agent the project's packs describe, by name (a project's pack after archvow's: its texts win, its
    signals join the earlier ones). A copy in .archvow/packs/ that project.vow does not record (never `pack add`ed,
    ARCH060) is not one of them. Read again only when a profile file changed."""
    recorded = packs.recorded_names(root)
    files = [(pack.name, path) for pack in packs.all_packs(root) for path in sorted(pack.agents.glob("*/agent.yaml"))
             if packs.kept(path, pack.root) and (pack.name == "archvow" or recorded is None or pack.name in recorded)]
    key = tuple((str(path), path.stat().st_mtime_ns) for _, path in files)
    if key in _CACHE:
        return dict(_CACHE[key])
    found: dict[str, Profile] = {}
    for pack, path in files:
        try:
            new, before = read(path.parent, pack), found.get(path.parent.name)
            if before is not None:  # a later pack's profile adds to how the agent is recognised, never takes away
                joined: dict[str, Any] = {k: tuple(dict.fromkeys((*getattr(before, k), *getattr(new, k)))) for k in SIGNALS}
                new = replace(new, **joined)
            found[path.parent.name] = new
        except PackError:
            logs.swallowed(log, "profiles: PackError")  # pack check and check report it
    _CACHE.clear()
    _CACHE[key] = found
    return dict(found)


_CACHE: dict[tuple[Any, ...], dict[str, Profile]] = {}


def profile(name: str, root: Path | None, known: dict[str, Profile] | None = None) -> Profile:
    """The agent's profile, or the standard one for a name no pack describes."""
    known = profiles(root) if known is None else known
    return known.get(name) or Profile(name=name)


def detect_table(root: Path | None, approved: list[str] | None = None) -> dict[str, dict[str, Any]]:
    """name -> how the agent gate recognises it: every profile, and the approved agents without one."""
    known = profiles(root)
    names = [*known, *[a for a in approved or [] if a not in known and a != "none"]]
    return {name: profile(name, root, known).detect() for name in names}


def owned_files(root: Path | None) -> dict[str, list[str]]:
    """name -> the files that configure the agent (ARCH040 while it is not approved)."""
    return {name: list(p.owns) for name, p in profiles(root).items() if p.owns}
