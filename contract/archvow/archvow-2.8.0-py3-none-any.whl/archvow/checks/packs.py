"""The packs of a project, checked (layer 2): ARCH060, a copy that differs from what `pack add` / `pack update`
recorded; ARCH009, a pack this archvow cannot use (its archvow range, a rule, an agent profile or a regime it cannot read), and a
regime the project chose (`compliance`) that no pack holds or that cannot be read.
"""

from __future__ import annotations

from archvow import agents
from archvow.checks.catalogue import all_rules, override_problem
from archvow.checks.engine import Checker
from archvow.foundation.errors import PackError
from archvow.foundation.paths import PROJECT_REL
from archvow.packs import regimes
from archvow.packs import rules as pack_rules
from archvow.packs import store as packs
from archvow.templates import Template


def run_packs(checker: Checker) -> None:
    for name, why in packs.changed_by_hand(checker.root, checker.manifest):
        checker.add("ARCH060", f"pack {name}: {why} - an architect runs `archvow pack update {name}` (or "
                    f"`pack add`), never edits the copy", (packs.PROJECT_PACKS / name).as_posix())
    for pack in packs.project_packs(checker.root):
        where = (packs.PROJECT_PACKS / pack.name / "pack.yaml").as_posix()
        try:
            packs.require_fit(pack)
            pack_rules.pack_rules(pack.root)
            for profile in sorted(pack.agents.glob("*/agent.yaml")):
                agents.read(profile.parent, pack.name)
            for regime in sorted((pack.root / "regimes").glob("*.yaml")):  # skipped by regimes.available: say so
                regimes.read_file(regime, pack=pack.name)
        except PackError as error:
            checker.add("ARCH009", f"pack {pack.name}: {error}", where)
    every_rule = all_rules(list(checker.templates.values()))  # every container's rules, not the first's only
    for code, value in (checker.manifest.get("rules") or {}).items():  # an override is applied or reported
        problem = override_problem(code, value, every_rule)
        if problem:
            checker.add("ARCH009", f"rules: {problem} - archvow ignores it", PROJECT_REL.as_posix())
    for template in {t.qualified: t for t in checker.templates.values()}.values():  # a template's own `rules:` too
        where = _template_file(checker, template)
        for code, value in (template.rules or {}).items():
            problem = override_problem(code, value, all_rules([template]))
            if problem:
                checker.add("ARCH009", f"template {template.qualified}: rules: {problem} - archvow ignores it", where)
    known = {*regimes.available(checker.root), "tst", "priv", "none"}
    for name in [str(n) for n in checker.manifest.get("compliance") or [] if str(n) not in known]:
        checker.add("ARCH009", f"compliance names '{name}', a regime archvow cannot find or read: its questions and "
                    "rules do not run - add the pack that holds it, fix its file, or take the name out "
                    "(archvow init <package> --force -a rules=...)", PROJECT_REL.as_posix())


def _template_file(checker: Checker, template: Template) -> str:
    """Where a finding about a template goes: its template.yaml in the project's pack copy, else project.vow."""
    home = checker.root.resolve()
    for folder in reversed(template.dirs):
        if folder.resolve().is_relative_to(home):
            return (folder.resolve() / "template.yaml").relative_to(home).as_posix()
    return PROJECT_REL.as_posix()
