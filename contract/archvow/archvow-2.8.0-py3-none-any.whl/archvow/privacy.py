"""Personal data, for every privacy regime: every column classified in the spec, then the code checked against it.

* A component type that declares columns (`columns: structfield` for a PySpark schema, `columns:
  fields` for a Pydantic model) holds the classification: `columns: {email: personal, ...}`, and the tags a
  regime may cover (`column_tags: {card_number: [financial]}`: GLBA's nonpublic personal information).
* Where the data goes is read from the manifest: a component handles the personal columns of what
  it `uses`; a type marked `orchestrates` (a job) hands them to every component it wires; a type
  marked `writes_data` writes them, minus what a component of the same job `removes` or
  `pseudonymises` (`privacy: {removes: [...], pseudonymises: [...]}`).
* The checks (PRIV001-006, on with any privacy regime) read only the code's syntax, like every archvow check.
  What one law asks on top - its questions, its register - is the regime's file (packs/regimes.py).
"""

from __future__ import annotations

import ast
import re
from pathlib import Path
from typing import Any

from archvow.checks.engine import Checker
from archvow.foundation import logs, once
from archvow.foundation.errors import SpecError
from archvow.foundation.files import parse_python, walked
from archvow.model import store
from archvow.model.spec import find_component
from archvow.packs.regimes import TAGS
from archvow.templates import Template, templates_of

log = logs.get("privacy")

CLASSES = ("personal", "special", "none")
PERSONAL = ("personal", "special")
NAME_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
SHOWN = {"show", "display", "explain"}
COLLECTED = {"collect", "take", "head", "first", "tail", "toPandas", "toJSON", "toLocalIterator"}
LOG_METHODS = {"debug", "info", "warning", "warn", "error", "exception", "critical", "log"}
HTTP_METHODS = {"get", "post", "put", "patch", "delete", "head", "options"}
SIMPLE_TYPES = {"str", "int", "float", "EmailStr", "UUID", "date", "datetime"}


# ------------------------------------------------------------------ the spec


def classify(root: Path, component_id: str, names: list[str], kind: str | None,
             removes: bool = False, pseudonymises: bool = False, tags: list[str] | None = None) -> dict[str, Any]:
    """`archvow column set`: classify columns of a schema/model (with `tags`, what a regime covers; `none` as the
    only tag removes them), or say a component removes or pseudonymises personal columns before they are
    written."""
    data = store.load(root)
    container, comp = find_component(data, component_id)
    names = [n.strip() for n in names if n.strip()]
    bad = [n for n in names if not NAME_RE.match(n)]
    if not names or bad:
        raise SpecError(f"column names are identifiers, separated by commas (got: {', '.join(bad) or 'none'})")
    if removes or pseudonymises:
        if kind:
            raise SpecError("--removes / --pseudonymises take no class: archvow column set <component> email "
                            "--removes")
        privacy = comp.setdefault("privacy", {})
        key = "removes" if removes else "pseudonymises"
        privacy[key] = sorted(set(privacy.get(key) or []) | set(names))
        store.save(root, data)
        return {"component": component_id, key: privacy[key]}
    template = templates_of(root, data).get(container["id"])
    ctype = template.type_of(comp) if template else {}
    if not ctype.get("columns"):
        holders = sorted(t for t, d in (template.component_types if template else {}).items() if d.get("columns"))
        raise SpecError(f"'{component_id}' ({comp['type']}) declares no columns: classify them on a "
                        f"{' or '.join(holders) or 'schema'} component; here use --removes or --pseudonymises")
    if kind not in CLASSES:
        raise SpecError("say the class: personal, special (health, religion, biometrics...: GDPR art. 9 special "
                        "categories, US sensitive personal information) or none")
    tags = sorted({t.strip() for t in tags or [] if t.strip()})
    unknown = [t for t in tags if t not in (*TAGS, "none")]
    if unknown:
        raise SpecError(f"tag '{unknown[0]}': one of {', '.join(TAGS)} (or none, to remove them)")
    if tags and tags != ["none"] and kind == "none":
        raise SpecError("a column that is not personal has no tag: classify it personal or special")
    columns = comp.setdefault("columns", {})
    for name in names:
        columns[name] = kind
    comp["columns"] = dict(sorted(columns.items()))
    known = dict(comp.get("column_tags") or {})
    for name in names:
        if kind == "none" or tags == ["none"]:
            known.pop(name, None)
        elif tags:
            known[name] = tags
    if known:
        comp["column_tags"] = dict(sorted(known.items()))
    else:
        comp.pop("column_tags", None)
    store.save(root, data)
    return {"component": component_id, "columns": {n: kind for n in names},
            **({"tags": {n: known[n] for n in names if n in known}} if any(n in known for n in names) else {})}


def personal_flow(root: Path, data: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Component id -> {handles, writes: {column: class}, removed, pseudonymised: [columns]}."""
    templates = templates_of(root, data)
    comps: dict[str, dict[str, Any]] = {}
    types: dict[str, dict[str, Any]] = {}
    for container in data.get("containers", []):
        template = templates.get(container["id"])
        for comp in container.get("components", []):
            comps[comp["id"]] = comp
            types[comp["id"]] = template.type_of(comp) if template else {}
    handles = {cid: {n: k for n, k in (c.get("columns") or {}).items() if k in PERSONAL} for cid, c in comps.items()}
    changed = True
    while changed:
        changed = False
        for cid, comp in comps.items():
            uses = [u for u in comp.get("uses") or [] if u in comps]
            for used in uses:  # what a component uses, it handles
                if not handles[used].items() <= handles[cid].items():
                    handles[cid].update(handles[used])
                    changed = True
            if types[cid].get("orchestrates"):  # a job hands its data to every step it wires
                for used in uses:
                    if types[used].get("columns") or comps[used].get("type") == "foundation":
                        continue
                    if not handles[cid].items() <= handles[used].items():
                        handles[used].update(handles[cid])
                        changed = True
    flows = {}
    for cid, comp in comps.items():
        privacy = comp.get("privacy") or {}
        removed = set(privacy.get("removes") or [])
        pseudo = set(privacy.get("pseudonymises") or [])
        for other in comps.values():  # a step of the same job removes it before the write
            if types[other["id"]].get("orchestrates") and cid in (other.get("uses") or []):
                for sibling in other.get("uses") or []:
                    removed |= set(((comps.get(sibling) or {}).get("privacy") or {}).get("removes") or [])
                    pseudo |= set(((comps.get(sibling) or {}).get("privacy") or {}).get("pseudonymises") or [])
        writes = {n: k for n, k in handles[cid].items() if n not in removed} if types[cid].get("writes_data") else {}
        flows[cid] = {"handles": dict(sorted(handles[cid].items())), "writes": dict(sorted(writes.items())),
                      "removed": sorted(removed & set(handles[cid])), "pseudonymised": sorted(pseudo & set(writes))}
    return flows


def column_tags(data: dict[str, Any]) -> dict[str, set[str]]:
    """Every tagged column of the spec, by name: what a regime covers (`covers`) or leaves out (`leaves_out`).
    Once per spec while a command only reads: each component's questions ask for it (ISSUE-032). Kept by the
    containers' id: the value holds them, so no other list takes that id meanwhile. Shared: read only."""
    containers = data.get("containers", [])
    return once.remember(("column tags", id(containers)), lambda: (containers, _column_tags(containers)))[1]


def _column_tags(containers: list[Any]) -> dict[str, set[str]]:
    found: dict[str, set[str]] = {}
    for container in containers:
        for comp in container.get("components", []):
            for name, tags in (comp.get("column_tags") or {}).items():
                found.setdefault(name, set()).update(tags or [])
    return found


def personal_names(data: dict[str, Any]) -> set[str]:
    return {n for ct in data.get("containers", []) for c in ct.get("components", [])
            for n, k in (c.get("columns") or {}).items() if k in PERSONAL}


def known_columns(root: Path, container: dict[str, Any], comp: dict[str, Any], template: Template | None,
                  code: bool = True) -> list[tuple[str, list[str]]]:
    """The columns archvow knows for a component and the schemas or models it uses: (component, names),
    classified ones (archvow column set) first, then those its file defines (`code`; never in a committed
    card, which depends only on the vows). What its questions are about, so they are answered with its own
    names rather than the template's example."""
    if template is None:
        return []
    by_id = {c["id"]: c for c in container.get("components", [])}
    found = []
    for other in [comp, *[by_id[u] for u in comp.get("uses") or [] if u in by_id]]:
        ctype = template.type_of(other)
        names = list(other.get("columns") or {})
        if code and ctype.get("columns"):
            names += [n for n, _ in code_columns(root / store.source_path(container, other), ctype["columns"])
                      if n not in names]
        if names:
            found.append((other["id"], names))
    return found


def columns_line(found: list[tuple[str, list[str]]], own: str) -> str:
    """'Known columns: sale_id, quantity (sales_schema: sale_id, product)', or ''."""
    parts = [", ".join(names) if cid == own else f"{cid}: {', '.join(names)}" for cid, names in found]
    return ("Known columns: " + "; ".join(parts)) if parts else ""


# ------------------------------------------------------------------ the code


def code_columns(path: Path, mode: str) -> list[tuple[str, int]]:
    """The columns a schema/model file defines: StructField("name", ...) or class fields."""
    try:
        tree = parse_python(path.read_text(encoding="utf-8"))
    except (OSError, SyntaxError, UnicodeDecodeError):
        logs.swallowed(log, "code_columns: OSError, SyntaxError, UnicodeDecodeError")
        return []
    found: list[tuple[str, int]] = []
    if mode == "structfield":
        for node in walked(tree):
            if isinstance(node, ast.Call) and _name(node.func) == "StructField" and node.args \
                    and isinstance(node.args[0], ast.Constant) and isinstance(node.args[0].value, str):
                found.append((node.args[0].value, node.lineno))
    elif mode == "fields":
        for node in tree.body:
            if isinstance(node, ast.ClassDef):
                for item in node.body:
                    if isinstance(item, ast.AnnAssign) and isinstance(item.target, ast.Name) \
                            and not item.target.id.startswith("_") and item.target.id != "model_config":
                        found.append((item.target.id, item.lineno))
    return found


def _name(node: ast.expr) -> str:
    if isinstance(node, ast.Attribute):
        return node.attr
    if isinstance(node, ast.Name):
        return node.id
    return ""


def _root_name(node: ast.expr) -> str:
    while isinstance(node, (ast.Attribute, ast.Call)):
        node = node.value if isinstance(node, ast.Attribute) else node.func
    return node.id if isinstance(node, ast.Name) else ""


def _has_collected(node: ast.AST) -> bool:
    return any(isinstance(n, ast.Call) and _name(n.func) in COLLECTED for n in ast.walk(node))


def _imported(tree: ast.AST) -> set[str]:
    """The names a module's imports bind (plt, pyplot, np...)."""
    return {(a.asname or a.name).split(".")[0] for n in walked(tree) if isinstance(n, ast.Import | ast.ImportFrom)
            for a in n.names}


def _is_module(node: ast.expr, modules: set[str]) -> bool:
    """Whether a receiver is an imported module itself (plt, matplotlib.pyplot), not data it returned."""
    while isinstance(node, ast.Attribute):
        node = node.value
    return isinstance(node, ast.Name) and node.id in modules


def _personal_field(node: ast.AST, handled: set[str]) -> str | None:
    """A personal column a log or print argument holds: `user.email`, `row["email"]`, `email`."""
    for item in ast.walk(node):
        if isinstance(item, ast.Attribute) and item.attr in handled:
            return item.attr
        if isinstance(item, ast.Subscript) and isinstance(item.slice, ast.Constant) and item.slice.value in handled:
            return str(item.slice.value)
        if isinstance(item, ast.Name) and item.id in handled:
            return item.id
    return None


def _is_logging(func: ast.expr) -> bool:
    if isinstance(func, ast.Name):
        return func.id == "print"
    return isinstance(func, ast.Attribute) and func.attr in LOG_METHODS and "log" in _root_name(func).lower()


def run_privacy(checker: Checker, implemented: set[str], blocked: set[str]) -> None:
    """PRIV001-006 (each regime's own questions are checked with the question sets, questions.py)."""
    root, data = checker.root, checker.manifest
    templates = templates_of(root, data)
    flows = personal_flow(root, data)
    names = personal_names(data)
    for container in data.get("containers", []):
        template = templates.get(container["id"])
        if template is None:
            continue
        for comp in container.get("components", []):
            cid = comp["id"]
            ctype = template.type_of(comp)
            path = root / store.source_path(container, comp)
            rel = store.source_path(container, comp)
            if ctype.get("columns") and cid in implemented:
                classified = comp.get("columns") or {}
                in_code = code_columns(path, ctype["columns"])
                for name, line in in_code:
                    if name not in classified:
                        blocked.add(cid)
                        checker.add("PRIV001", f"column '{name}' of {cid} is not classified -> archvow "
                                    f"column set {cid} {name} personal|special|none", rel, line)
                for name in sorted(set(classified) - {n for n, _ in in_code}):
                    checker.add("PRIV006", f"column '{name}' is classified in the spec of {cid} but not "
                                "defined in its code (renamed?)", rel)
            flow = flows.get(cid, {})
            if flow.get("handles") and cid in implemented and path.is_file():
                if _check_code(checker, path, rel, set(flow["handles"]), names):
                    blocked.add(cid)
            special = [n for n, k in flow.get("writes", {}).items() if k == "special"
                       and n not in flow.get("pseudonymised", [])]
            if special:
                _check_special(checker, data, cid, special)


def _check_code(checker: Checker, path: Path, rel: str, handled: set[str], everywhere: set[str]) -> bool:
    try:
        tree = parse_python(path.read_text(encoding="utf-8"))
    except (OSError, SyntaxError, UnicodeDecodeError):
        logs.swallowed(log, "_check_code: OSError, SyntaxError, UnicodeDecodeError")
        return False
    before, modules = len(checker.report.errors), _imported(tree)
    for node in walked(tree):
        if isinstance(node, ast.Call):
            name = _name(node.func)
            if name in SHOWN and isinstance(node.func, ast.Attribute) and not _is_module(node.func.value, modules):
                checker.add("PRIV002", f".{name}() prints rows of personal data ({', '.join(sorted(handled))}); "
                            "remove it (count or check in a test instead)", rel, node.lineno)
            elif _is_logging(node.func) and any(_has_collected(a) for a in [*node.args, *node.keywords]):
                checker.add("PRIV002", "personal data collected and printed or logged; log counts, never "
                            f"rows ({', '.join(sorted(handled))})", rel, node.lineno)
            elif _is_logging(node.func) and isinstance(node.func, ast.Attribute) and (field := next(filter(None, (
                    _personal_field(a, handled) for a in [*node.args, *node.keywords])), None)):  # a print is output
                checker.add("PRIV002", f"the personal field '{field}' logged; log an id or a count, never the value",
                            rel, node.lineno)
            elif name in ("partitionBy", "bucketBy") and _root_name(node.func) not in ("W", "Window"):
                for arg in node.args:
                    if isinstance(arg, ast.Constant) and arg.value in handled:
                        checker.add("PRIV004", f"{name}('{arg.value}'): personal values become folder "
                                    "names; partition by a non-personal column", rel, node.lineno)
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            _check_route(checker, node, rel, everywhere)
    return len(checker.report.errors) > before


def _check_route(checker: Checker, node: ast.FunctionDef | ast.AsyncFunctionDef, rel: str,
                 personal: set[str]) -> None:
    """PRIV005: a route keeps personal data out of its URL (path and query parameters)."""
    for deco in node.decorator_list:
        if not (isinstance(deco, ast.Call) and _name(deco.func) in HTTP_METHODS and deco.args
                and isinstance(deco.args[0], ast.Constant) and isinstance(deco.args[0].value, str)):
            continue
        for placeholder in re.findall(r"{(\w+)}", deco.args[0].value):
            if placeholder in personal:
                checker.add("PRIV005", f"'{deco.args[0].value}': {placeholder} is personal data in the URL "
                            "(access logs keep it); use an id, or send it in the body", rel, deco.lineno)
        for arg in node.args.args + node.args.kwonlyargs:
            annotation = ast.unparse(arg.annotation) if arg.annotation else ""
            simple = annotation.split("[")[0].split(".")[-1] in SIMPLE_TYPES or "Query(" in annotation
            if arg.arg in personal and simple and f"{{{arg.arg}}}" not in deco.args[0].value:
                checker.add("PRIV005", f"{node.name}({arg.arg}): personal data as a query parameter ends "
                            "up in access logs; send it in the body", rel, arg.lineno)


def _check_special(checker: Checker, data: dict[str, Any], cid: str, columns: list[str]) -> None:
    """PRIV003: special (sensitive) data reaches a writer unpseudonymised -> a critical `exposed`
    hazard with its invariant (tested by a property test: ARCH030, ARCH031, ARCH037)."""
    where = store.PROJECT_REL.as_posix()
    hazards = [h for h in store.hazards(data) if h.get("component") == cid and h.get("guide_word") == "exposed"
               and h.get("severity") == "critical"]
    prevented = {h for inv in data.get("invariants", []) or [] for h in inv.get("mitigates", []) or []}
    if any(d.get("component") == cid and d.get("guide_word") == "exposed" for d in store.dismissals(data)):
        checker.add("PRIV003", f"'{cid}' writes special (sensitive) data ({', '.join(columns)}): its `exposed` "
                    "safety question cannot be 'not applicable'", where)
    if not any(h["id"] in prevented for h in hazards):
        checker.add("PRIV003", f"'{cid}' writes special (sensitive) data ({', '.join(columns)}) that no step "
                    f"pseudonymises -> archvow hazard add {cid} exposed critical \"special data "
                    f"is written in clear\", then archvow invariant add {cid} \"{', '.join(columns)} "
                    "are pseudonymised or encrypted before the write\" (or archvow column set <step> "
                    f"{','.join(columns)} --pseudonymises)", where)


# ------------------------------------------------------------------ the view
