"""A company's own rules, declared as data in its pack (`rules/<FAMILY>.yaml`, packs/rules.py), no Python needed.

The kinds: forbid_import, forbid_call, forbid_pattern, forbid_file, only_in, require_keyword (matched here, on the
Python files of the containers) and require_question (asked as C1, C2... of those component types, questions.py).
The family of a rule is the letters of its code (ACME): its section in `archvow doc`'s project.md.
`catches()` runs one rule on one example: `archvow pack rule` and `pack check` prove each rule catches its bad
example and passes its good one.
"""

from __future__ import annotations

import ast
import fnmatch
import re
from pathlib import PurePosixPath
from typing import Any

from archvow.checks.catalogue import custom_rules
from archvow.checks.engine import Checker
from archvow.foundation import logs, walk
from archvow.foundation.files import parse_python, walked
from archvow.imports import Names

log = logs.get("custom")


def run_custom(checker: Checker) -> None:
    """Each container's code against the rules of its own template, with that template's settings (its families, its
    `rules:`, the project's overrides): a rule of the second container's template is not one of the first's. A
    forbid_file rule looks at the project's files once per template that brings it. The project-wide settings (the
    first container's template) come back after."""
    containers = checker.manifest.get("containers", [])
    globbed: set[tuple[str, str]] = set()
    try:
        for container in containers:
            template = checker.templates[container["id"]]
            rules = custom_rules([template])
            if not rules:
                continue
            checker._configure(template)
            files = _component_files(checker, [container])
            for code, rule in rules.items():
                if rule["kind"] == "require_question":
                    continue  # asked as a C question, checked with the other question sets
                if rule["kind"] == "forbid_file":
                    if (template.qualified, code) not in globbed:
                        globbed.add((template.qualified, code))
                        _forbidden_files(checker, code, rule)
                    continue
                for rel, layer, ctype, source in files:
                    for line, found in matches(rule, source, _inside(rule, layer, ctype)):
                        checker.add(code, _message(rule, found), rel, line)
    finally:
        if containers:
            checker._configure(checker.templates.get(containers[0]["id"]))


def _forbidden_files(checker: Checker, code: str, rule: dict[str, Any]) -> None:
    unread = walk.of_project(checker.root, checker.manifest)
    for pattern in rule["targets"]:
        for path in sorted(checker.root.glob(pattern)):
            rel = path.relative_to(checker.root).as_posix()
            if path.is_file() and file_matches(pattern, rel, unread):
                checker.add(code, _message(rule, rel), rel)


def _message(rule: dict[str, Any], found: str) -> str:
    fix = f" -> {rule['fix']}" if rule.get("fix") else ""
    return f"{rule['title']}: {found}{fix}"


def file_matches(pattern: str, rel: str, unread: walk.Folders | None = None) -> bool:
    """Whether a file (its path from the project's root) is one a forbid_file glob names, as `Path.glob` reads it:
    `*`, `?` and `[...]` within one name, `**` any number of folders. A file in a folder archvow does not read
    (`unread`: Git ignores it, a virtualenv, a hidden one - foundation/walk.py) does not count; the proof of `bad`
    and `good`, with no project, leaves out the hidden folders only. `check` and the proof both ask here."""
    names = PurePosixPath(rel).parts
    folder = PurePosixPath(*names[:-1]) if len(names) > 1 else PurePosixPath(".")
    skipped = unread.skips(folder) if unread is not None else any(p.startswith(".") for p in names[:-1])
    return not skipped and _names_match(PurePosixPath(pattern).parts, names)


def _names_match(globs: tuple[str, ...], names: tuple[str, ...]) -> bool:
    if not globs:
        return not names
    if globs[0] == "**":
        return any(_names_match(globs[1:], names[start:]) for start in range(len(names) + 1))
    return bool(names) and fnmatch.fnmatchcase(names[0], globs[0]) and _names_match(globs[1:], names[1:])


def _inside(rule: dict[str, Any], layer: str, ctype: str) -> bool:
    """Whether a file is where the rule looks (no in_types / in_layers: everywhere)."""
    if not rule["types"] and not rule["layers"]:
        return True
    return ctype in rule["types"] or layer in rule["layers"]


def _component_files(checker: Checker, containers: list[dict[str, Any]]) -> list[tuple[str, str, str, str]]:
    """(path, layer, component type, source) of every Python file of these containers."""
    found = []
    for container in containers:
        base = checker.root / container["path"]
        if not base.is_dir():
            continue
        types = {str(c.get("module", "")): str(c.get("type", "")) for c in container.get("components", [])}
        package, template = str(container.get("package", "")), checker.templates[container["id"]]
        for path in walk.python_files(base):
            rel = path.relative_to(base)  # every folder of a container is code: the engine checks it all
            module, where = ".".join([package, *rel.with_suffix("").parts]), path.relative_to(checker.root).as_posix()
            layer = checker.file_layer(container, template, where, module) or ""  # layer_paths first, as ARCH001
            found.append((where, layer, types.get(module, ""), path.read_text(encoding="utf-8", errors="replace")))
    return found


def matches(rule: dict[str, Any], source: str, inside: bool = True) -> list[tuple[int, str]]:
    """Where a rule finds something in one file: (line, what). `inside`: the file is where the rule looks."""
    kind, targets = rule["kind"], rule["targets"]
    if kind == "forbid_pattern":
        if not inside:
            return []
        pattern = re.compile(targets[0])
        return [(n, line.strip()) for n, line in enumerate(source.splitlines(), 1) if pattern.search(line)]
    if kind == "require_keyword":
        if not inside or re.search(targets[0], source, re.MULTILINE):
            return []
        return [(0, f"no {targets[0]}")]
    try:
        tree = parse_python(source)
    except SyntaxError:
        logs.swallowed(log, "matches: SyntaxError")
        return []
    if kind == "only_in" and inside:
        return []  # where the import is allowed
    if kind in ("forbid_import", "forbid_call") and not inside:
        return []
    out = []
    names = Names(tree)
    for node in walked(tree):
        if kind in ("forbid_import", "only_in") and isinstance(node, (ast.Import, ast.ImportFrom)):
            modules = [a.name for a in node.names] if isinstance(node, ast.Import) else [node.module or ""]
            if isinstance(node, ast.ImportFrom) and node.module:  # from legacy import billing: legacy.billing too
                modules += [f"{node.module}.{a.name}" for a in node.names]
            for module in modules:
                if any(module == p or module.startswith(p + ".") for p in targets):
                    out.append((node.lineno, f"import {module}"))
                    if isinstance(node, ast.ImportFrom):
                        break  # one finding per `from` statement, as before
        elif kind == "forbid_call" and isinstance(node, ast.Call):
            called = ast.unparse(node.func)
            full = names.full_name(node.func)  # an alias is resolved: `nap` -> time.sleep
            short = node.func.attr if isinstance(node.func, ast.Attribute) else called
            candidates = {called, f"*.{short}"} | ({full, f"*.{full.rsplit('.', 1)[-1]}"} if full else set())
            for pattern in targets:
                if any(fnmatch.fnmatch(c, pattern) or c == pattern for c in candidates):
                    out.append((node.lineno, f"{called}()" + (f" ({full})" if full and full != called else "")))
                    break
    return out


def catches(rule: dict[str, Any], example: str) -> bool:
    """Whether the rule finds something in an example: Python source, or a file path for forbid_file (the example
    is read as a file of the types and layers the rule looks in)."""
    if rule["kind"] == "forbid_file":
        return any(file_matches(pattern, example) for pattern in rule["targets"])
    if rule["kind"] == "only_in":
        return bool(matches(rule, example, inside=False))  # an import outside where it is allowed
    return bool(matches(rule, example, inside=True))
