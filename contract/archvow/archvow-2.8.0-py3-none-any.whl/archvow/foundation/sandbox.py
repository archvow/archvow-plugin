"""Jinja's sandbox, the one way archvow renders a template's text (its files, names, expressions, doctor entries).

Templates are data: they render in the sandbox, so a changed template file in a merge request cannot run Python on
the architect's machine. A mistake in that text - a syntax error, an unknown name, what the sandbox refuses - is a
TemplateError that quotes the template's line, never an internal error.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

import jinja2
from jinja2.sandbox import SandboxedEnvironment

from archvow.foundation.errors import TemplateError


def _told(error: jinja2.TemplateError, source: str) -> TemplateError:
    """The template's mistake, with the line it is on (Jinja's own frames for a template are named <template>)."""
    line = getattr(error, "lineno", None)
    trace = error.__traceback__
    while trace is not None:
        if trace.tb_frame.f_code.co_filename == "<template>":
            line = trace.tb_lineno
        trace = trace.tb_next
    lines = source.splitlines()
    where = f" (line {line}: {lines[line - 1].strip()[:80]})" if line and 0 < line <= len(lines) else ""
    return TemplateError(f"a template's text cannot be rendered: {type(error).__name__}: {error.message}{where}",
                         hint="fix it in the template's pack (archvow pack check <pack> finds what else is wrong)")


class _Template(jinja2.Template):
    source = ""

    def render(self, *args: Any, **kwargs: Any) -> str:
        try:
            return super().render(*args, **kwargs)
        except jinja2.TemplateError as error:
            raise _told(error, self.source) from None


class Sandbox(SandboxedEnvironment):
    """SandboxedEnvironment whose templates and expressions raise archvow's TemplateError."""

    template_class = _Template

    def from_string(self, source: Any, *args: Any, **kwargs: Any) -> jinja2.Template:
        try:
            template = super().from_string(source, *args, **kwargs)
        except jinja2.TemplateError as error:
            raise _told(error, str(source)) from None
        template.source = str(source)  # type: ignore[attr-defined]
        return template

    def compile_expression(self, source: str, undefined_to_none: bool = True) -> Callable[..., Any]:  # type: ignore[override]
        try:
            expression = super().compile_expression(source, undefined_to_none)
        except jinja2.TemplateError as error:
            raise _told(error, f"expression {source}") from None

        def run(*args: Any, **kwargs: Any) -> Any:
            try:
                return expression(*args, **kwargs)
            except jinja2.TemplateError as error:
                raise _told(error, f"expression {source}") from None

        return run
