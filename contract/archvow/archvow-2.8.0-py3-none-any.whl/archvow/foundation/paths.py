"""Every file and folder archvow owns, in one map. Paths are relative to the project's root unless the
name says otherwise; `Path` values join with a root, `str` values are compared with Git's paths."""

from __future__ import annotations

import os
from pathlib import Path

from archvow.foundation.errors import TemplateError

ARCHVOW_DIR = Path(".archvow")
PROJECT_REL = ARCHVOW_DIR / "project.vow"         # the project's vow
FEATURES_REL = ARCHVOW_DIR / "features"          # features/<feature>/<feature>.vow, its components/<id>.vow
SHARED = "shared"                                # the feature init creates: what every feature uses
COMPONENTS_DIR = "components"                    # a feature's components, one vow each
PROPOSALS_FILE = "proposals.vow"                 # a feature's proposals by the AI, waiting for a person
DOC_REL = ARCHVOW_DIR / "doc"                    # archvow doc writes there; ignored by Git (.archvow/.gitignore)
FROZEN_REL = ".archvow/frozen.json"              # violations accepted by `archvow freeze`
STATUS_REL = ".archvow/doc/status.md"            # the local status report (gitignored, with the docs)
AGENTS_STATE_REL = ARCHVOW_DIR / "agents.local"   # each agent's last state, one line per agent (local)
TRAILER_REL = ARCHVOW_DIR / "trailer.local"       # what the commit-msg hook adds to the next commit (local)
WRITE_LOCK_REL = ARCHVOW_DIR / "write.local"      # held while a command writes the spec (local)
REVIEWS_DIR = "reviews"                          # AI review reports (gitignored)


def feature_dir(feature: str) -> Path:
    """.archvow/features/<feature>/"""
    return FEATURES_REL / feature


def feature_vow(feature: str) -> Path:
    """.archvow/features/<feature>/<feature>.vow - named after it, so a search for the feature finds it."""
    return FEATURES_REL / feature / f"{feature}.vow"


def component_vow(feature: str, component: str) -> Path:
    """.archvow/features/<feature>/components/<component>.vow"""
    return FEATURES_REL / feature / COMPONENTS_DIR / f"{component}.vow"


def proposals_vow(feature: str) -> Path:
    """.archvow/features/<feature>/proposals.vow"""
    return FEATURES_REL / feature / PROPOSALS_FILE


def inside(root: Path, rel: str | Path) -> Path:
    """root / rel, for a path a template or a pack names (a rendered file name, an agent's skills folder): refused
    when it leaves the project (`..`, an absolute path), or when a symbolic link in the project leads it out (a cloned
    repository can carry one). A link that stays inside the project is followed. What counts is where the path
    really is, links followed: a link inside the project followed by `..` leaves it as surely as a link to elsewhere."""
    target = root / rel
    if not Path(os.path.normpath(target.absolute())).is_relative_to(os.path.normpath(root.absolute())):
        raise TemplateError(f"'{rel}' would be written outside the project ({root}): the template or agent profile "
                            "that names it is wrong")
    home = root.resolve()
    real = target.resolve()
    if not real.is_relative_to(home):
        step = root
        for part in Path(rel).parts:
            step = step / part
            if step.is_symlink() and not step.resolve().is_relative_to(home):
                raise TemplateError(f"'{rel}' would be written outside the project through the symbolic link "
                                    f"{step.relative_to(root).as_posix()} (to {step.resolve()})",
                                    hint="make it a real folder of the project, or point it inside the project")
        raise TemplateError(f"'{rel}' would be written outside the project ({root}): through a symbolic link it "
                            f"leads to {real}", hint="name the path without `..` after a link")
    return target


def cache_dir() -> Path:
    """archvow's folder in the user's cache (history, crash reports): never inside a project (ARCH050)."""
    base = os.environ.get("XDG_CACHE_HOME") or str(Path.home() / ".cache")
    return Path(base) / "archvow"


OWNERS_BEGIN = "# --- Component owners: written by archvow (archvow component edit <component> --owners ...)"


OWNERS_END = "# --- end of component owners"
