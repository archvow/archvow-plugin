"""Which folders of a project archvow reads. Every folder holds the project's code, whatever its name (a team's own
`build/` scripts, an `env/` package): a folder is never skipped for its name. Skipped are only the folders that hold
no code of the project - the ones Git ignores (`git ls-files --ignored --directory`), the virtualenvs (a folder
holding pyvenv.cfg) and the hidden ones (.git, .tox, .mypy_cache...). Inside a container nothing at all is skipped:
the engine checks all of its code. `check`, its pack rules and the digest of `workspace --since` ask here, so what
the digest watches is what check reads.
"""

from __future__ import annotations

import os
from pathlib import Path, PurePosixPath
from typing import Any

from archvow.foundation import once
from archvow.foundation.git import git_or_none


class Folders:
    """The folders of one project archvow does not read; paths are relative to its root."""

    def __init__(self, root: Path, containers: tuple[str, ...] = ()) -> None:
        self.root = root
        self.containers = tuple(PurePosixPath(c.strip("/")) for c in containers if c.strip("/"))
        listed = git_or_none(root, "ls-files", "--others", "--ignored", "--exclude-standard", "--directory", "-z")
        self.ignored = {entry.rstrip("/") for entry in (listed or "").split("\0") if entry.endswith("/")}
        self._venvs: dict[PurePosixPath, bool] = {}
        self._skipped: dict[str, bool] = {}

    def skips(self, folder: str | PurePosixPath) -> bool:
        """Whether archvow leaves a folder (a path from the root) and all it holds unread."""
        key = str(folder)
        if key not in self._skipped:
            rel = PurePosixPath(folder)
            self._skipped[key] = not any(rel.is_relative_to(c) for c in self.containers) and any(
                step.name.startswith(".") or self.holds_no_code(step)
                for step in (PurePosixPath(*rel.parts[:depth]) for depth in range(1, len(rel.parts) + 1)))
        return self._skipped[key]

    def holds_no_code(self, folder: str | PurePosixPath) -> bool:
        """A folder Git ignores, or a virtualenv (the hidden ones aside: the digest of `workspace` watches .archvow)."""
        rel = PurePosixPath(folder)
        return rel.as_posix() in self.ignored or self._venv(rel)

    def reads(self, path: Path) -> bool:
        """Whether a file of the project is read: its folder is not skipped."""
        return not self.skips(os.path.dirname(os.path.relpath(path, self.root)).replace(os.sep, "/") or ".")

    def _venv(self, step: PurePosixPath) -> bool:
        if step not in self._venvs:
            self._venvs[step] = (self.root / step / "pyvenv.cfg").is_file()
        return self._venvs[step]


def folders(root: Path, containers: tuple[str, ...] = ()) -> Folders:
    """The project's unread folders (one `git ls-files` per reading command)."""
    return once.remember(("unread folders", str(root.resolve()), containers), lambda: Folders(root, containers))


def of_project(root: Path, data: dict[str, Any]) -> Folders:
    """The unread folders of a project whose spec is `data` (its containers are read whole)."""
    return folders(root, tuple(str(c.get("path") or "") for c in data.get("containers") or []))


def files(root: Path, base: Path, pattern: str = "*", containers: tuple[str, ...] = ()) -> list[Path]:
    """The files of `base` (a folder of the project) matching `pattern` that archvow reads, in order."""
    def found() -> list[Path]:
        if not base.is_dir():
            return []
        unread = folders(root, containers)
        return [p for p in sorted(base.rglob(pattern)) if p.is_file() and unread.reads(p)]

    return list(once.remember(("read files", str(root.resolve()), str(base), pattern, containers), found))


def python_files(folder: Path) -> list[Path]:
    """Every .py file under a folder, sorted: listed once per reading command, where check's families walk the same
    folders (ISSUE-032). Shared: no caller changes the list."""
    return once.remember(("python files", str(folder)),
                         lambda: sorted(p for p in folder.rglob("*.py") if p.is_file()))
