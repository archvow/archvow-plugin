"""The regular expressions a pack's rules may hold (forbid_pattern, require_keyword): `check` runs them on every line
of the project, so one that can take exponential time on a line it almost matches is refused when the pack is read.

Two shapes do: a repeat inside a repeat that runs it many times (`(a+)+`, `(\\w+\\s?)*`, and since 2.6.1 with a
bound as well: `(\\w+){1,60}`, `(a{1,3})+`, `(?:a{1,30}){1,30}`), and a repeat of an alternation whose branches can start
with the same character (`(a|aa)+`, `(a|a)*`) - each makes the engine try every way of splitting the same text. A
third takes polynomial time (2.6.0): two unbounded repeats in a row that the same characters can feed, with nothing
required between them (`\\w*\\w*x`, `\\d+\\.?\\d+`) - every split point between them is tried, on every start.
Python's parser already merges a common start (`(ab|ac)+` is `a[bc]`, `(a|aa)` is `a(|a)`), so a branch that can
match nothing counts too. The pattern is read as `re.compile` reads it (re._parser), never run.
"""

from __future__ import annotations

import math
import re._parser as _parser  # what re.compile reads: to see a pattern's repeats and branches
from typing import Any

REPEATS = {getattr(_parser, name) for name in ("MAX_REPEAT", "MIN_REPEAT", "POSSESSIVE_REPEAT") if hasattr(_parser, name)}
ANY = ("any",)  # a first character that may be anything
CATEGORIES = {  # a category (\d, \w, \s...) and the characters it holds
    _parser.CATEGORY_DIGIT: str.isdigit, _parser.CATEGORY_WORD: lambda c: c.isalnum() or c == "_",
    _parser.CATEGORY_SPACE: str.isspace}
NEGATED = {_parser.CATEGORY_NOT_DIGIT: _parser.CATEGORY_DIGIT, _parser.CATEGORY_NOT_WORD: _parser.CATEGORY_WORD,
           _parser.CATEGORY_NOT_SPACE: _parser.CATEGORY_SPACE}  # \D, \W, \S: every character but those
POSSESSIVE = getattr(_parser, "POSSESSIVE_REPEAT", None)
ATOMIC = getattr(_parser, "ATOMIC_GROUP", None)
SPLITS = 4096  # the most ways a bounded repeat of a repeat may split a text: (\\d{1,3}\\.){3} has 27
SAMPLE = range(0x300)  # the characters two first sets are compared on, beside their own literals and ranges


def problem(pattern: str) -> str:
    """Why a pack's pattern is refused, or ""."""
    items = _parser.parse(pattern).data
    if _repeats_a_repeat(items):
        return (f"target {pattern!r} repeats a repeat (as in (a+)+, (\\w+ ?)*, (\\w+){{1,60}} or (a{{1,3}})+): on a line "
                "it almost matches, it takes exponential time - repeat the group once ((a|b)+), give the inner repeat "
                "a fixed count (\\d{3}), or make it possessive (\\w++)")
    if _repeats_an_ambiguous_branch(items):
        return (f"target {pattern!r} repeats an alternation whose branches can start with the same character (as in "
                "(a|aa)+ or (a|a)*): on a line it almost matches, it takes exponential time - make each branch start "
                "with its own character (a+ for (a|aa)+), or bound the repeat")
    if _overlapping_repeats_in_a_row(items):
        return (f"target {pattern!r} has two unbounded repeats in a row that the same characters can match (as in "
                "\\w*\\w*x or \\d+\\.?\\d+): on a long line it almost matches, it takes quadratic time or worse - "
                "keep one repeat (\\w*x), or make what is between them required (\\d+(\\.\\d+)?)")
    return ""


def _overlapping_repeats_in_a_row(items: list[Any]) -> bool:
    """Whether a sequence holds an unbounded repeat followed - with only parts that can match nothing between - by
    another unbounded repeat whose characters overlap its own: the engine tries every split between the two."""
    for index, (op, arg) in enumerate(items):
        if op in REPEATS and arg[1] == _parser.MAXREPEAT:
            mine = _first(arg[2])
            for later_op, later_arg in items[index + 1:]:
                if later_op in REPEATS and later_arg[1] == _parser.MAXREPEAT and _overlap(mine, _first(later_arg[2])):
                    return True
                if not _nullable([(later_op, later_arg)]):
                    break
    return any(_overlapping_repeats_in_a_row(child) for op, arg in items for child in _children(op, arg))


def _children(op: object, arg: object) -> list[list[Any]]:
    if op in REPEATS:
        return [arg[2]]  # type: ignore[index]
    if op == _parser.SUBPATTERN:
        return [arg[3]]  # type: ignore[index]
    if op == _parser.BRANCH:
        return list(arg[1])  # type: ignore[index]
    if op in (_parser.ASSERT, _parser.ASSERT_NOT):
        return [arg[1]]  # type: ignore[index]
    if op == getattr(_parser, "ATOMIC_GROUP", None):
        return [arg]  # type: ignore[list-item]
    return []


def _repeats_a_repeat(items: list[Any], turns: float = 1) -> bool:
    """Whether a parsed pattern has a repeat of variable length inside a repeat that runs it more than once (`turns`:
    how many times at most the enclosing repeats run what is here, math.inf for unbounded): every way of splitting
    the same text among the turns is tried. Unbounded on either side is refused; a bounded case only when it splits a
    text more than SPLITS ways ((\\d{1,3}\\.){3} is kept, (a{1,30}){1,30} is not). A possessive repeat never gives
    back what it took, and starts a count of its own; an atomic group too. An optional part (x?) is no repeat here."""
    for op, arg in items:
        if op == ATOMIC and ATOMIC is not None:
            if _repeats_a_repeat(arg, 1):
                return True
            continue
        if op in REPEATS:
            low, high, child = arg
            unbounded = high == _parser.MAXREPEAT
            variable = low != high and (unbounded or high >= 2)
            possessive = op == POSSESSIVE and POSSESSIVE is not None
            if turns > 1 and variable and not possessive and (
                    unbounded or math.isinf(turns) or (high - low + 1) ** turns > SPLITS):
                return True
            runs = math.inf if unbounded else high
            if _repeats_a_repeat(child, runs if possessive else turns * runs if runs > 1 else turns):
                return True
            continue
        if any(_repeats_a_repeat(child, turns) for child in _children(op, arg)):
            return True
    return False


def _repeats_an_ambiguous_branch(items: list[Any], inside: bool = False) -> bool:
    """Whether a branch inside an unbounded repeat has two alternatives that can start alike, or one that can
    match nothing."""
    for op, arg in items:
        if inside and op == _parser.BRANCH:
            alternatives = list(arg[1])
            if any(_nullable(a) for a in alternatives):
                return True
            firsts = [_first(a) for a in alternatives]
            if any(_overlap(x, y) for i, x in enumerate(firsts) for y in firsts[i + 1:]):
                return True
        unbounded = op in REPEATS and arg[1] == _parser.MAXREPEAT
        if any(_repeats_an_ambiguous_branch(child, inside or unbounded) for child in _children(op, arg)):
            return True
    return False


def _nullable(items: list[Any]) -> bool:
    """Whether a parsed sequence can match nothing."""
    for op, arg in items:
        if op in REPEATS:
            if arg[0] > 0 and not _nullable(arg[2]):
                return False
        elif op == _parser.SUBPATTERN:
            if not _nullable(arg[3]):
                return False
        elif op == _parser.BRANCH:
            if not any(_nullable(a) for a in arg[1]):
                return False
        elif op == getattr(_parser, "ATOMIC_GROUP", None):
            if not _nullable(arg):
                return False
        elif op not in (_parser.AT, _parser.ASSERT, _parser.ASSERT_NOT, _parser.GROUPREF,
                        getattr(_parser, "GROUPREF_EXISTS", None)):
            return False  # a character
    return True


def _first(items: list[Any]) -> set[tuple[Any, ...]]:
    """The characters a parsed sequence can start with: ('c', char), ('range', lo, hi), ('cat', category) or ANY."""
    found: set[tuple[Any, ...]] = set()
    for op, arg in items:
        if op == _parser.LITERAL:
            found.add(("c", chr(arg)))
        elif op == _parser.IN:
            if any(o == _parser.NEGATE for o, _ in arg):
                found.add(ANY)
            for o, a in arg:
                if o == _parser.LITERAL:
                    found.add(("c", chr(a)))
                elif o == _parser.RANGE:
                    found.add(("range", *a))
                elif o == _parser.CATEGORY and a in CATEGORIES:
                    found.add(("cat", a))
                elif o == _parser.CATEGORY and a in NEGATED:
                    found.add(("not", NEGATED[a]))
                else:
                    found.add(ANY)  # another category (\D, \W...), a negation
        elif op in REPEATS:
            found |= _first(arg[2])
        elif op == _parser.SUBPATTERN:
            found |= _first(arg[3])
        elif op == _parser.BRANCH:
            for alternative in arg[1]:
                found |= _first(alternative)
        elif op == getattr(_parser, "ATOMIC_GROUP", None):
            found |= _first(arg)
        elif op not in (_parser.AT, _parser.ASSERT, _parser.ASSERT_NOT):
            found.add(ANY)  # ., [^x], a back reference...
        if not _nullable([(op, arg)]):
            break
    return found


def _holds(atom: tuple[Any, ...], char: int) -> bool:
    """Whether a first-set atom matches this character."""
    if atom[0] == "c":
        return ord(atom[1]) == char
    if atom[0] == "range":
        return bool(atom[1] <= char <= atom[2])
    holds = bool(CATEGORIES[atom[1]](chr(char)))
    return holds if atom[0] == "cat" else not holds


def _overlap(left: set[tuple[Any, ...]], right: set[tuple[Any, ...]]) -> bool:
    """Whether a character can start both: compared on their own literals and ranges, and on SAMPLE."""
    if (ANY in left and right) or (ANY in right and left):
        return True
    chars = set(SAMPLE)
    for atom in left | right:
        if atom[0] == "c":
            chars.add(ord(atom[1]))
        elif atom[0] == "range":
            chars.update(range(atom[1], min(atom[2], atom[1] + 1024) + 1))
    return any(any(_holds(a, c) for a in left) and any(_holds(b, c) for b in right) for c in chars)
