"""Assembles archvow's parser: each commands module declares its own commands (`declare_<command>`); this module
calls them in the order `archvow --help` lists them, after the options every command has.
"""

from __future__ import annotations

import argparse
from functools import cache

from archvow import __version__
from archvow.cli.args import DESCRIPTION, FLOW, Builder, Parser
from archvow.cli.commands import (
    assumption,
    brief,
    column,
    component,
    decision,
    dependency,
    example,
    feature,
    hazard,
    invariant,
    pack,
    plan,
    project,
    question,
    rule,
    show,
    specify,
    tryout,
    verify,
    workspace,
)
from archvow.views.guidance import grammar_of


def build_parser() -> argparse.ArgumentParser:
    parser = Parser(prog="archvow", description=DESCRIPTION, epilog=FLOW)
    parser.add_argument("--version", action="version", version=f"archvow {__version__}")
    parser.add_argument("-v", "--verbose", action="count", default=0,
                        help="say what archvow does and how long it takes, on stderr (-vv: every file, git call "
                             "and error it went on from); anywhere on the line; also ARCHVOW_LOG=info|debug")
    parser.add_argument("--root", help="project root (default: search upwards from the current folder)")
    sub = parser.add_subparsers(dest="command", required=True, metavar="command",
                                help="archvow <command> --help: its options and examples")
    b = Builder(sub)
    # every command gets this parser's commands and parameters: what a finding's guide may suggest (checked())
    parser.set_defaults(grammar=cache(lambda: grammar_of(parser)))
    for declare in (
        project.declare_init,
        project.declare_catalog,
        feature.declare_feature,
        component.declare_component,
        show.declare_show,
        specify.declare_specify,
        question.declare_question,
        decision.declare_decision,
        rule.declare_rule,
        assumption.declare_assumption,
        brief.declare_brief,
        hazard.declare_hazard,
        invariant.declare_invariant,
        column.declare_column,
        dependency.declare_dependency,
        example.declare_example,
        plan.declare_prompt,
        plan.declare_next,
        workspace.declare_workspace,
        verify.declare_check,
        verify.declare_review,
        project.declare_version,
        verify.declare_freeze,
        verify.declare_audit,
        verify.declare_changes,
        verify.declare_diff,
        project.declare_doctor,
        project.declare_completion,
        project.declare_doc,
        tryout.declare_try,
        pack.declare_pack,
    ):
        declare(b)
    return parser
