"""Project commands: init, catalog, version, doctor, completion, docs, template.
"""

from __future__ import annotations

import argparse
import sys
import textwrap
from pathlib import Path

from archvow import __version__, adopt, agents
from archvow.agent import tool_data, unseen
from archvow.checks.families.dora import unregistered
from archvow.cli.args import (
    DEFAULT_TEMPLATE,
    Builder,
    TemplateAction,
    answers_help,
    init_details,
)
from archvow.cli.console import style as ui
from archvow.cli.console.ask import ask_answers, setup_line_editing
from archvow.cli.console.completion import install, script
from archvow.cli.output import as_json, print_result, project_root
from archvow.foundation import logs
from archvow.model import store
from archvow.packs import regimes
from archvow.packs import store as packs
from archvow.spec.answers import auto_approve_notes
from archvow.spec.init import init_project, spec_committed
from archvow.spec.project_files import enable_git_hooks, init_git, next_steps
from archvow.templates import (
    Template,
    discover,
    load_template,
    template_name,
)
from archvow.views import project_doc
from archvow.views.doctor import SET_UP_ONCE, as_dicts, render, run_doctor

log = logs.get("cli")


def catalog_templates(root: Path | None) -> list[Template]:
    """The templates a project (or, outside one, this machine) can use: what `archvow catalog` lists. A shared base is
    extended, never used directly: it is left out."""
    return [t for t in (load_template(name, root) for name in sorted(discover(root))) if not t.data.get("abstract")]


def catalog_parts(root: Path | None, templates: list[dict]) -> dict:
    """What `catalog --json` and `workspace --json` say of the packs: the templates, the packs, the agents, the
    privacy regimes (1.27)."""
    return {"templates": templates, "packs": [p.summary() for p in packs.all_packs(root)],
            "agents": [p.summary() for p in agents.profiles(root).values()],
            "regimes": [r.summary() for r in regimes.available(root).values()]}


def cmd_catalog(args: argparse.Namespace) -> int:
    try:
        root = project_root(args)
    except store.ManifestError:
        logs.swallowed(log, "cmd_catalog: store.ManifestError")
        here = Path(getattr(args, "root", None) or ".").resolve()  # before init: the packs `pack add` copied here
        root = here if (here / packs.PROJECT_PACKS).is_dir() else None
    loaded = catalog_templates(root)
    templates = [template.summary() for template in loaded]
    if args.json:
        print(as_json(catalog_parts(root, templates)))
        return 0
    for pack in packs.all_packs(root):
        print(ui.title(f"pack {pack.name} {pack.version}") + ui.dim(f"  {pack.description}"))
    print(ui.dim("  agents with a profile (any other name gets the standard one): "
                 + ", ".join(sorted(agents.profiles(root)))))
    print(ui.dim("  regimes, the laws (-a rules=...): " + ", ".join(
        f"{r.name} ({r.letter}1...)" for r in regimes.available(root).values())) + "\n")
    for template, t in zip(loaded, templates, strict=True):
        chain = f" (extends {' -> '.join(t['extends'])})" if t["extends"] else ""
        print(ui.title(f"{t['name']}@{t['version']}") + f"  [{t['language']} / {t['kind']} / {t['style']}]{chain}")
        print(f"    {t['description']}")
        print("  component types (archvow component add TYPE NAME):")
        for key, ct in t["component_types"].items():
            if ct["addable"]:
                print(f"    - {key:<15} -> {ct['layer']:<15} {ct['description']}")
        print(f"  init answers (archvow init NAME -t {t['name']} -a KEY=VALUE):")
        print(textwrap.indent(answers_help(template), "  "))
    return 0


def _component_ids(root: Path) -> set[str]:
    return {c["id"] for k in store.load(root).get("containers") or [] for c in k.get("components") or []}


def cmd_init(args: argparse.Namespace) -> int:
    answers = dict(item.split("=", 1) for item in args.answer or [])
    root = Path(args.dir or ".").resolve()
    keep = args.force and store.is_project(root) and spec_committed(root)
    if not keep and not args.no_input and sys.stdin.isatty() and sys.stdout.isatty():
        setup_line_editing()
        answers = ask_answers(load_template(args.template or DEFAULT_TEMPLATE, root), answers)
    before = _component_ids(root) if keep else set()
    written = init_project(root, args.template, args.package, args.description, answers,
                                 src=args.src, force=args.force)
    if args.adopt:
        _adopt(root)
    project_doc.write_owners(root)
    template = template_name(store.load(root)["containers"][0])[0]
    if keep:
        print(ui.ok(f"Rewrote the generated files of {root} from template {template}")
              + ui.dim(f"  ({len(written)} files)"))
        print(ui.ok("Kept the committed spec: components, decisions, hazards and invariants are unchanged"))
        added = sorted(_component_ids(root) - before)
        if added:
            print(ui.ok(f"Added the template's new starting component(s), planned: {', '.join(added)}")
                  + ui.dim(f"  -> archvow specify {added[0]}"))
        print(ui.dim(f"  to change an answer: archvow init {args.package} --force -a <question>=<answer>"))
        print(ui.warn("Review with `git diff` before committing: changed guard files need the architects' "
                      "approval (archvow check --base)"))
        _auto_approve_reminder(root)
        _register_reminder(root)
        _unseen_reminder(root)
        return 0
    print(ui.logo(f"archvow {__version__} - {template}") + "\n")
    data = store.load(root)
    print(ui.ok(f"archvow initialised: {len(written)} files, mode {data.get('mode')}, language {data.get('language')}")
          + ui.dim("  (no source folders created)"))
    results = [] if args.no_git else [init_git(root)]
    results.append(enable_git_hooks(root))
    for level, message in results:
        if message:
            print(ui.ok(message) if level == "ok" else ui.warn(message))
    for line in next_steps(template, root, answers).splitlines():  # what needs attention now; the rest: doctor
        if line.strip().startswith("! "):
            print(ui.warn(line.strip()[2:]))
    _auto_approve_reminder(root)
    _register_reminder(root)
    _unseen_reminder(root)
    print("\n" + ui.title("Next:") + " " + ui.code("archvow next")
          + ui.dim("        Git host and CI settings to make once: archvow doctor"))
    return 0


def _adopt(root: Path) -> None:
    """init --adopt: propose `layer_paths` for the existing code, write it, show it."""
    data = store.load(root)
    template = load_template(template_name(data["containers"][0])[0], root)
    proposal, unmapped = adopt.propose(root, data, template)
    adopt.write(root, proposal, list(template.layer_names))
    print(ui.title("Adopting the existing code") + ui.dim("  - files stay where they are"))
    if proposal:
        print(ui.ok("layer_paths proposed from folder and file names - review it in .archvow/project.vow "
                    "(the architects approve it in the merge request):"))
        width = max(len(layer) for layer in proposal)
        for layer in template.layer_names:
            for path in proposal.get(layer, []):
                print(f"  {ui.code(layer.ljust(width))}  {path}")
    else:
        print(ui.dim("  no file to map: every Python file is in a layer folder or mapped already"))
    if unmapped:
        folders: dict[str, int] = {}
        for rel in unmapped:
            folders[rel.rsplit("/", 1)[0]] = folders.get(rel.rsplit("/", 1)[0], 0) + 1
        names = [f"{rel.rsplit('/', 1)[0]}/ ({folders[rel.rsplit('/', 1)[0]]} files)"
                 if folders[rel.rsplit("/", 1)[0]] > 1 else rel for rel in unmapped]
        names = list(dict.fromkeys(names))
        shown = ", ".join(names[:12]) + (f" and {len(names) - 12} more" if len(names) > 12 else "")
        print(ui.warn(f"Not mapped (no name archvow knows): {shown} - an architect maps them in `layer_paths` "
                      "of .archvow/project.vow, or leaves them out of the layers"))
    print(ui.dim("  then: archvow check (the code rules run on every file), archvow freeze (today's violations "
                 "are accepted, new ones fail), and one module at a time:"))
    print("  " + ui.code(f'archvow component add <type> <name> -d "..." --file {store.load(root)["containers"][0]["path"]}/<module>.py'))


def _auto_approve_reminder(root: Path) -> None:
    """auto_approve yes: the approved assistants that keep their permissions outside the project."""
    lines = auto_approve_notes(root)
    if lines:
        print(ui.warn("AI auto-approval: these assistants read their permissions outside the project; each "
                      "developer adds the safe commands once:"))
        for line in lines:
            print("  " + ui.dim(line))


def _unseen_reminder(root: Path) -> None:
    """The approved assistants archvow cannot always see: it cannot check their sandbox or YOLO mode."""
    data = store.load(root)
    for tool, where in unseen(tool_data(root, data), list(data.get("ai_tools") or [])):
        print(ui.warn(f"archvow cannot see {tool} {where}: its sandbox and YOLO mode are not checked "
                      "(docs: agent security)"))


def _register_reminder(root: Path) -> None:
    """After init, with DORA on: what to record before the first commit passes (DORA003)."""
    names = unregistered(root, store.load(root))
    if names:
        print(ui.warn("DORA: before the first commit, record who supplies these packages and their licence "
                      "(the third-party register, DORA003):"))
        for name in names:
            print("  " + ui.code(f'archvow dependency add {name} --supplier "..." --licence "..." '
                                 "--criticality critical|important|minor"))


def cmd_completion(args: argparse.Namespace) -> int:
    """archvow completion zsh|bash|powershell: the script that makes Tab complete archvow; with --install,
    written to ~/.archvow-completion.<ext> and loaded by one line in the shell's startup file."""
    if not args.install:
        print(script(args.shell), end="")
        return 0
    for line in install(args.shell):
        print(ui.ok(line))
    print(ui.dim("  open a new terminal, then: archvow sp<Tab>"))
    return 0


def cmd_version(args: argparse.Namespace) -> int:
    import platform

    print_result(args, {"archvow": __version__, "python": platform.python_version()}, f"archvow {__version__}")
    return 0


def cmd_doctor(args: argparse.Namespace) -> int:
    start = Path(args.root) if args.root else Path.cwd()
    findings = run_doctor(start)
    if args.json:
        print(as_json(as_dicts(findings)))
    else:
        try:
            store.find_root(start)
            known = True
        except store.ManifestError:
            logs.swallowed(log, "cmd_doctor: store.ManifestError")
            known = False
        print(render(findings, known))
        for f in findings:
            if f.check == SET_UP_ONCE:
                print("\n" + ui.title("Set up once (Git host and CI)") + "\n" + ui.steps(f.detail))
    return 1 if any(f.status == "fail" for f in findings) else 0


def cmd_doc(args: argparse.Namespace) -> int:
    root = project_root(args)
    for path in project_doc.generate(root, args.feature, args.base):
        print(f"wrote {path.relative_to(root)}")
    return 0


def declare_init(b: Builder) -> None:
    """`archvow init`: its parser."""
    # ---- project
    p = b.command("init", cmd_init, "add archvow specs and guards to a repository (no source folders)",
                  details=init_details, examples="""
        archvow init my_pipeline -a architects=@my-team
        archvow init "$NAME" -t pyspark-pipeline -d "PySpark pipeline for $NAME" \\
            -a architects=@my-team -a ai_tools="$AI_TOOL"
        archvow init "$NAME" -d "Daily orders report" -a architects="@alice @data/architects" \\
            -a ai_tools=copilot,claude-code -a platform=github -a python_version=3.12 \\
            -a ci_image=registry.example.local/python-spark:3.12 \\
            -a pip_index_url=https://nexus.example.local/repository/pypi/simple
        archvow init "$NAME" --force -a architects=@my-team -a ci_image=registry.example.local/py:3.12
            # an existing project: rewrites the generated files, keeps the committed spec

        Run init once, to create the project. Developers clone the repository instead.
        """)
    p.add_argument("package", help="snake_case Python package the code will live in (also the project name)")
    p.add_argument("-t", "--template", action=TemplateAction, metavar="TEMPLATE",
                   help=f"architecture template: <pack>/<template>, or its short name when one pack only has it "
                        f"(default: {DEFAULT_TEMPLATE}; list: archvow catalog); a company template comes in a "
                        "pack: archvow pack add <folder> first")
    p.add_argument("-d", "--description", metavar="TEXT",
                   help="what the system does, in one line: goes into the vow, the README and "
                        "every doc (default: the package name)")
    p.add_argument("-a", "--answer", action="append", metavar="KEY=VALUE",
                   help="answer one of the template's questions (repeatable); the keys are listed below")
    p.add_argument("--dir", help="repository root (default: current folder)")
    p.add_argument("--src", default="src", help="source root (default: src)")
    p.add_argument("--force", action="store_true",
                   help="in a folder that is already a project: rewrite the generated files from the template "
                        "(AGENTS.md, CI, hooks...). A committed spec is always kept; to start over, "
                        "git rm -r .archvow and commit")
    p.add_argument("--no-git", action="store_true",
                   help="do not create a Git repository (default: one is created, branch main)")
    p.add_argument("--no-input", action="store_true",
                   help="never ask: in a terminal, init asks the main questions no -a answered "
                        "(scripts and CI are never asked)")
    p.add_argument("--adopt", action="store_true",
                   help="existing code: propose `layer_paths` from folder and file names (core, models, crud, "
                        "services, api...) so the files stay where they are; written into .archvow/project.vow "
                        "and printed for the architects to review (with --force in a project: adds the "
                        "files not mapped yet)")


def declare_catalog(b: Builder) -> None:
    """`archvow catalog`: its parser."""
    b.command("catalog", cmd_catalog, "list templates, their init answers and component types", True,
              examples="archvow catalog\narchvow catalog --json")


def declare_version(b: Builder) -> None:
    """`archvow version`: its parser."""
    # ---- maintenance
    b.command("version", cmd_version, "archvow's version, and the version of its --json output (contract)", True,
              examples="archvow version\narchvow version --json      # {\"contract\": \"MAJOR.MINOR\", \"archvow\": ...}")


def declare_doctor(b: Builder) -> None:
    """`archvow doctor`: its parser."""
    b.command("doctor", cmd_doctor, "check this machine's setup for the project, with the fix for each problem",
              True, examples="""
        archvow doctor          # Python, archvow (command and version), Git hook, the template's tools
        """)


def declare_completion(b: Builder) -> None:
    """`archvow completion`: its parser."""
    p = b.command("completion", cmd_completion, "Tab completion for your shell (zsh, bash or powershell)",
                  examples="""
        archvow completion zsh --install          # zsh, the macOS default: ~/.archvow-completion.zsh + one line in ~/.zshrc
        archvow completion bash --install         # bash: ~/.archvow-completion.bash + one line in ~/.bashrc (~/.bash_profile on macOS)
        archvow completion powershell --install   # PowerShell: ~/.archvow-completion.ps1 + one line in $PROFILE
        archvow completion zsh                    # only print the script
        Run it once, open a new terminal. Then Tab completes commands, options and the project's own names: archvow sp<Tab> -> specify,
        archvow show <Tab> -> its components and rules R1..., then archvow show clean_orders <Tab> -> H1, INV1...
        """)
    p.add_argument("shell", choices=["zsh", "bash", "powershell"], help="the shell to complete in")
    p.add_argument("--install", action="store_true",
                   help="write the script to ~/.archvow-completion.<ext> and load it from the shell's startup file "
                        "(once); it works even when archvow is not on the PATH yet when the shell starts")


def declare_doc(b: Builder) -> None:
    """`archvow doc`: its parser."""
    p = b.command("doc", cmd_doc, "write the spec to read: the project, each feature, the status (.archvow/doc/, "
                  "never committed)",
                  examples="archvow doc\narchvow doc orders\narchvow doc orders --base develop   # what the branch "
                           "changed comes first (for a merge request)")
    p.add_argument("feature", nargs="?", help="only this feature (default: the project and every feature)")
    p.add_argument("--base", metavar="BRANCH", help="mark what changed since this branch (archvow diff --base)")
