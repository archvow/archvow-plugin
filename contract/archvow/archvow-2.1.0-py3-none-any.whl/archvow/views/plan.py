"""The build plan (`archvow next`): the planned components in build order - what each one waits for - and the
next task that fits an AI session's budget.
"""

from __future__ import annotations

from pathlib import Path

from archvow.checks.run import run_check
from archvow.model import store
from archvow.model.spec import mode
from archvow.privacy import personal_flow
from archvow.questions import component_questions
from archvow.tasks import next_task, tasks_for
from archvow.templates import templates_of
from archvow.toreview import pending
from archvow.views.runline import left_to_do, run_lines


def _dependency_order(comps: dict[str, dict]) -> list[str]:
    """The components, each after the ones it uses (a cycle is cut where it closes)."""
    order: list[str] = []
    visiting: set[str] = set()

    def visit(cid: str) -> None:
        if cid in order or cid in visiting or cid not in comps:
            return
        visiting.add(cid)
        for dep in comps[cid].get("uses", []) or []:
            visit(dep)
        visiting.discard(cid)
        order.append(cid)

    for cid in comps:
        visit(cid)
    return order


def plan_next(root: Path, base: str | None = None) -> list[dict]:
    """Planned components in dependency order with their readiness (see `plan_with_budget`)."""
    return plan_with_budget(root, base)[0]


def plan_with_budget(root: Path, base: str | None = None) -> tuple[list[dict], dict | None, list[str]]:
    """Planned components in dependency order with their readiness. With `base` (the branch the
    merge request targets), nothing is ready once the change has no room left in its review budget
    (ARCH022): the work goes on in the next merge request. Last: the run line of each entry point
    (`runline.run_lines`)."""
    data = store.load(root)
    report = run_check(root, base=base)
    full = bool(report.budget and report.budget["full"])
    status = {c.component: c for c in report.components}
    rows: list[dict] = []
    templates = templates_of(root, data)
    flows = personal_flow(root, data)
    guided_or_free = mode(data) != "strict"
    for container in data.get("containers", []):
        template = templates.get(container["id"])
        comps = {c["id"]: c for c in container.get("components", [])}
        for cid in _dependency_order(comps):
            st = status.get(cid)
            tasks = tasks_for(root, data, comps[cid], template, report,
                              component_questions(root, data, comps[cid], template, flows)) if template else []
            todo = next_task(tasks)
            if st is None or (st.status != "planned" and todo is None):
                continue
            waiting = [d for d in comps[cid].get("uses", []) or []
                       if status.get(d) is not None and status[d].status == "planned"]
            plural = "" if st.open_questions == 1 else "s"
            due = pending(data, comps[cid])
            if due:  # the component changed after these were recorded: a person looks at them first (ARCH057)
                readiness = f"blocked: {len(due)} item{'' if len(due) == 1 else 's'} to review after its change"
            elif st.open_questions and not guided_or_free:
                readiness = f"blocked: {st.open_questions} decision{plural} to make"
            elif waiting:
                readiness = f"waiting for {', '.join(waiting)}"
            elif full:
                readiness = "next merge request (change budget reached)"
            elif st.open_questions:  # mode guided or free: the AI proposes the answers, then builds
                readiness = f"ready - {st.open_questions} decision{plural} to propose first"
            else:
                readiness = "ready"
            if todo is not None and readiness == "ready":
                readiness = f"ready - task {todo.number} of {len(tasks)}"
            left = left_to_do(report, container["id"], cid)
            row = {"component": cid, "type": comps[cid]["type"], "readiness": readiness,
                   "invariants": st.invariants_total}
            if st.open_questions and template:  # how many of them `specify` offers an answer for (contract 2.1)
                offered = template.suggested_answers(comps[cid])
                row["suggested"] = sum(1 for d in comps[cid].get("decisions", []) or []
                                       if not (d.get("answer") or "").strip() and offered.get(d["question"]))
            if tasks:
                row["tasks"] = {"total": len(tasks), "done": sum(1 for t in tasks if t.done),
                                "next": f"T{todo.number}" if todo else None}
            if left:  # the file exists but is not finished: say what remains
                row["started"] = left
            rows.append(row)
    return rows, report.budget, run_lines(data, templates, report)
