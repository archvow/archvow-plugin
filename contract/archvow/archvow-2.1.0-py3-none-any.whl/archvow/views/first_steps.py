"""The first steps of a new project (`workspace --json` "first_steps", contract 2.1): five steps, each read from
the spec, the check and Git - never stored - so every editor shows the same card and it goes once all five are done.

1. foundations: the shared components have no open decision
2. feature: a feature besides `shared` exists
3. component: a component of a feature has no open decision
4. build: a component of a feature is tested or verified
5. commit: the spec, a feature's vows and code are in Git (once done, it stays done while the work goes on)
"""

from __future__ import annotations

from pathlib import Path

from archvow.checks.engine import Report
from archvow.foundation.git import git_or_none, succeeds
from archvow.foundation.paths import SHARED
from archvow.model import features as feats
from archvow.model import store

STEPS = ("foundations", "feature", "component", "build", "commit")


def _decisions(n: int) -> str:
    return f"{n} decision{'' if n == 1 else 's'}"


def first_steps(root: Path, data: dict, report: Report, rows: list[dict]) -> list[dict]:
    """The five steps, in order, each `{step, title, detail, command, done}`."""
    status = {c.component: c for c in report.components}
    suggested = {r["component"]: r.get("suggested", 0) for r in rows}
    shared = [c["id"] for c in feats.components_of(data, SHARED)]
    open_shared = [cid for cid in shared if cid in status and status[cid].open_questions]
    asked = sum(status[cid].open_questions for cid in open_shared)
    offered = sum(suggested.get(cid, 0) for cid in open_shared)
    named = [f["name"] for f in feats.features(data) if f["name"] != SHARED]
    own = [c["id"] for c in feats.all_components(data) if feats.feature_of(c) != SHARED and c["id"] in status]
    answered = [cid for cid in own if not status[cid].open_questions]
    built = [cid for cid in own if status[cid].status in ("tested", "verified")]
    tracked = git_or_none(root, "ls-files", "--", *((store.PROJECT_REL.parent / "features" / n).as_posix() for n in named), "src")
    files = (tracked or "").splitlines()
    committed = bool(named and succeeds(root, "ls-files", "--error-unmatch", store.PROJECT_REL.as_posix())
                     and any(not f.startswith("src") for f in files) and any(f.startswith("src") for f in files))
    first_open = next((cid for cid in own if status[cid].open_questions), None)
    return [
        {"step": "foundations", "title": "Answer the foundations",
         "detail": (f"{', '.join(open_shared)}: {_decisions(asked)}" + (f", {offered} with a suggestion" if offered else ""))
         if open_shared else "Their decisions are made",
         "command": f"archvow specify {open_shared[0]}" if open_shared else "archvow specify", "done": not open_shared},
        {"step": "feature", "title": "Add a feature", "detail": "What the product does",
         "command": 'archvow feature add <name> -d "what the product does"', "done": bool(named)},
        {"step": "component", "title": "Add its first component and answer its decisions",
         "detail": "Next then shows it ready to build",
         "command": f"archvow specify {first_open}" if first_open else
         f'archvow component add <type> <name> -d "what it must do" --feature {named[0] if named else "<feature>"}',
         "done": bool(answered)},
        {"step": "build", "title": "Build it, then Check", "detail": "Its code and tests, checked against the spec",
         "command": "archvow check", "done": bool(built)},
        {"step": "commit", "title": "Commit",
         "detail": "The hooks run the same checks as CI; then open a merge request",
         "command": "git add -A && git commit", "done": committed},
    ]
