# airport-assistant

<!-- archvow:begin -->
<!-- Added by archvow init: `archvow init --force` rewrites only what is between these two markers; write your own text outside them. -->

Answers employees' questions from the travel policies, and books flights with their approval

An **AI assistant on LangGraph**, specified and guarded with [archvow](.archvow/README.md)
(template `archvow/langgraph-agent@2.1.0`).

## For developers

Everything you need every day, on one page. The spec of each component is written and
approved by the architects (@acme/architects); you write the code from it.

**Once, after cloning** - Python 3.12 or newer, LangGraph 1:

```bash
pip install -r requirements.txt            # LangGraph, LangChain core, FastAPI, archvow, ruff, pytest...
git config core.hooksPath .githooks        # the checks before every commit
archvow doctor                             # checks your setup, with the fix for each problem
make run                                   # the assistant's API on http://127.0.0.1:8000/docs
```

**Every day**

| Step | Do |
|---|---|
| What to build | `archvow next` - the planned components in build order, *ready* or what each waits for |
| Your task | `archvow prompt <component>` (the whole feature: `archvow prompt --feature <feature>`): the file, its public names and routes, the decisions made, the tests, what must never happen |
| Write it | yourself, starting the file with the task's header (`@assisted none`) - or with the AI assistant, one line in its chat: `implement <component>` |
| Something is unclear | do not guess: `archvow question add <component> "<question>"`, an architect decides |
| Commit | `git commit` - the Git hook runs ruff and `archvow check`; `make test` runs the tests |

**Good to know**

- A model comes only from the `models` foundation: `models.chat("reasoner")`,
  `models.embeddings()`. Never import a provider or write a model's name anywhere else
  (`AGT001`, `AGT002`); the tests get fake models from it, never a real one.
- Tools take the user's identity from the access scope the runtime injects, never from an argument
  the model fills (`AGT010`); only a retriever searches the index, filtered by that scope (`AGT007`).
- A model's answer is read through a structured output (a `schema` component), never with
  `json.loads` (`AGT006`). Text the model reads - a page, an e-mail, a document - is data, never
  instructions.
- A graph is compiled with the memory's checkpointer and a recursion limit (`AGT003`, `AGT004`);
  a tool that acts waits for a person's approval when its vow says so (`AGT005`).
- One test per component: `tests/<layer>/test_<component>.py`; whole graphs go in
  `tests/integration/`.
- Every error says how to fix it; the rules are in the project's doc (`archvow doc`, Checks)
  and explained in [`.archvow/README.md`](.archvow/README.md).
- `.archvow/` changes only through archvow commands, approved by the architects - never
  by hand.
- AI assistants approved for this project: claude-code. Their rules: [`AGENTS.md`](AGENTS.md).

The rest of this README is for the architects and for reference: how the assistant is
specified, step by step, and how it runs.

## Architecture

Code lives in `src/airport_assistant/`, in five layers. A layer may only import the layers listed
next to it: the shapes and prompts never call a model, the agents never touch data except through
tools, and what runs - graphs, the API, the indexing jobs - sits on top.

| Layer | Responsibility | May import |
|---|---|---|
| `p0_common` | Foundations - settings, the models, logging, the access scope, documents, the memory | - |
| `p1_domain` | The assistant's own shapes and pure logic - state, structured outputs, prompts, chunking; no I/O, no model call | p0_common |
| `p2_tools` | Tools, retrievers and clients - the only place that reads or changes the company's data and other systems | p0_common, p1_domain |
| `p3_agents` | Agents, routers and nodes - one step of thinking each, calling models and tools | p0_common, p1_domain, p2_tools |
| `p4_app` | The graphs, the API, the MCP server and the indexing jobs - what runs | p0_common, p1_domain, p2_tools, p3_agents |

The full specification - every component, its public functions and routes, the decided edge
cases and what must never happen - is in [`.archvow/`](.archvow/README.md):

- The project's doc - `archvow doc` writes it into `.archvow/doc/` (never committed): the whole project on one page - diagram, features, components, rules, hazards, invariants, personal data, checks - and one page per feature
- [The spec](.archvow/) - `project.vow`, then `features/<feature>/<feature>.vow` and one vow per component in `features/<feature>/components/`; a component's task: `archvow prompt <component>`

## Project layout

Right after `archvow init` - the spec and the guards, no code yet:

```
airport-assistant/
├── .archvow/                           the spec: project.vow, features/<feature>/, README.md
├── AGENTS.md                           rules for every AI assistant
├── .gitlab-ci.yml                      CI: guards and tests
├── .gitlab/CODEOWNERS                  the architects approve the spec and the guards
├── .githooks/pre-commit                checks before every commit
├── Makefile                            make run, make check, make test... (make help)
├── pyproject.toml                      the package, what it needs at run time, the test settings
├── README.md
├── requirements.txt                    development tools
├── ruff.toml                           style, security, logging and FastAPI rules
└── .gitignore
```

When development is done - every component written from its task, with its test:

```
airport-assistant/
├── .archvow/
│   ├── project.vow                     the project's vow
│   └── features/<feature>/             <feature>.vow + components/<component>.vow (one vow each)
├── src/
│   └── airport_assistant/
│       ├── p0_common/                  settings, models, logging_setup, access, documents, memory
│       ├── p1_domain/                  assistant_state.py, answer_schema.py, answer_prompt.py, ...
│       ├── p2_tools/                   policies_retriever.py, book_ticket_tool.py, ...
│       ├── p3_agents/                  question_router.py, answer_node.py, booking_agent.py
│       └── p4_app/                     assistant_graph.py, chat_api.py, policies_index_job.py
├── tests/
│   ├── <layer>/test_<component>.py     one test per component, fake models
│   └── integration/                    whole graphs, the API
└── ...                                 the files of the first tree
```

## Building the assistant, step by step

Each step below shows **one example**; do the same for every component. People write the spec
(steps 1-4); then the code is written from it, by a person or an AI assistant (step 5); the same
checks judge it (step 6). Every command and option, with examples: `archvow --help`; a complete
assistant, from the empty project to a run: archvow's documentation, *LangGraph template*.

**1. Create the project** - this one was created with:

```bash
archvow init airport_assistant -t archvow/langgraph-agent -d 'Answers employees'"'"' questions from the travel policies, and books flights with their approval' \
    -a language=en -a python_version=3.12 -a line_length=88 -a platform=gitlab -a ci=auto -a architects=@acme/architects -a sonar=no -a auto_approve=yes -a sandbox=yes -a briefs=briefs -a git_hooks=githooks -a branch_naming=gitflow -a langgraph_version=1 -a ai_tools=claude-code -a dependencies=numpy -a mode=strict -a rules=ARCH,STYLE,AGENT,FASTAPI,GDPR,TST
pip install -r requirements.txt
git add -A && git commit -m "archvow init"          # the only commit on main
git switch -c develop                            # once, from main
git switch -c feature/US-001-policies develop # one branch per change, from develop
```

`init` writes the spec folder `.archvow/`, the guards (AGENTS.md, ruff.toml, the test settings,
CI, CODEOWNERS, the Git hook) and six starting components: `settings`, `models` (the only place
that creates models), `logging_setup`, `access` (who asks), `documents` (the shape of the company's
data) and `memory` (the conversations). It never writes source code, and runs once: developers
clone the repository instead.

**2. Declare the components** - each one's type, a name, and what it must do; here a small
assistant that answers from the company's policies:

```bash
archvow component add schema answer -d "An answer: text str, citations list[str] (the passages' ids), ai_generated bool = True" -s US-001
archvow component add retriever policies -d "The HR policy passages the user may read that answer the question, best first" -s US-001
archvow component add node answer -d "Answers the question from the retrieved passages with the reasoner role, citing them" -u policies_retriever,answer_schema -s US-001
archvow component add graph assistant -d "Retrieve the passages, answer, end" -u answer_node -s US-001
archvow component add api chat -d "POST /chat for the signed-in user; GET /health" -u assistant_graph -r "chat: POST /chat" -r "health: GET /health" -s US-001
```

The type fixes the structure: the file, the public function or class, the layer, the test file; it
turns the name into the component id (`policies` -> `policies_retriever`). **The description (`-d`)
is what the AI assistant - or the developer - implements.** Types (state, schema, prompt, chunker,
tool, retriever, mcp_client, client, router, node, agent, graph, api, mcp_server, index_job):
`archvow component add --help`. The AI assistant can propose these commands for a whole feature:
`/archvow-draft-spec <the feature in plain words>`.

**3. Answer its questions** - each type asks what must not be guessed:

```bash
archvow show policies_retriever
archvow decision make policies_retriever 1 "The source's groups are copied on every chunk; the search filters by the user's groups"
archvow rule add answer_node "Given no passage above the threshold, when it answers, then it says it does not know"
```

`show` lists everything about the component: its numbered questions (red ✖ open, green ✔
answered), its rules and its safety questions S1, S2... `decision make` answers question 1 (with no
answer, it takes the one `show` suggests); `rule add` adds a rule the questions do not cover. In a
terminal, `archvow specify policies_retriever` asks what is open, one question at a time. Nothing is
decided silently - not where the access rights come from, not which model a step uses, not who
approves before a tool acts: code written while a question is open fails the build.

**4. Say what must never happen, then commit the spec**

```bash
archvow hazard add policies_retriever S1 critical
git add .archvow && git commit -m "US-001: specify the policies assistant"
```

The safety questions speak of what an assistant can get wrong: an answer that shows what the user
may not see (`leak`), text that carries instructions (`injection`), a loop that spends without limit
(`runaway`), an action without approval (`acts`)... Each ends as a hazard, given by its number, or a
dismissal with its reason. With no text, `hazard add` takes the suggested hazard and, for critical
or high, its invariant - what is always true, proven by a test.

**5. Write the code** - `archvow next` gives the order, and what each component waits for:

```bash
archvow next
```

```
  component                    type            status
✖ access                       foundation      blocked: 1 decision to make (1 suggested)  -> archvow specify access
✖ documents                    foundation      blocked: 1 decision to make (1 suggested)  -> archvow specify documents
✖ logging_setup                foundation      blocked: 2 decisions to make (2 suggested)  -> archvow specify logging_setup
✖ memory                       foundation      blocked: 3 decisions to make (2 suggested)  -> archvow specify memory
✖ models                       foundation      blocked: 5 decisions to make (1 suggested)  -> archvow specify models
✖ settings                     foundation      blocked: 2 decisions to make  -> archvow specify settings
✖ answer_schema                schema          blocked: 3 decisions to make (1 suggested)  -> archvow specify answer_schema
✖ policies_retriever           retriever       blocked: 3 decisions to make (2 suggested)  -> archvow specify policies_retriever
✖ answer_node                  node            blocked: 3 decisions to make (1 suggested)  -> archvow specify answer_node
✖ assistant_graph              graph           blocked: 3 decisions to make (2 suggested)  -> archvow specify assistant_graph
✖ chat_api                     api             blocked: 4 decisions to make (2 suggested)  -> archvow specify chat_api

Safety: 1 of 16 questions answered  -> archvow specify

! Not ready to run yet: chat_api needs access (planned), documents (planned), logging_setup (planned), memory (planned), models (planned), settings (planned), policies_retriever (planned), answer_schema (planned), answer_node (planned), assistant_graph (planned), chat_api (planned)
```

*blocked*: questions are still open; answer them as in step 3 and the component becomes
*ready*. Then, in the AI assistant's chat (agent mode, in the project folder):

```
implement models
implement everything archvow next lists as ready
```

`AGENTS.md` tells every approved assistant (claude-code) what "implement" means:
read its task, write the file with its header and its tests, run the checks, fix, and
report anything it had to assume.

*Yourself*: `archvow prompt <component>` is your task; start the file with
its header, `@assisted none`. Commit each component; the Git hook runs the checks first.

**6. Verify and run**

```bash
archvow check --complete                             # release gate: everything planned is built
pytest --cov=src --cov-report=term-missing           # every test, with coverage (as CI does)
make run                                             # http://127.0.0.1:8000/docs
```

## One example per command

| To... | For example |
|---|---|
| give the agents a tool | `archvow component add tool book_ticket -d "Books a ticket for the current user, after their approval"`; its questions say whether it reads untrusted content, private data, and whether it acts |
| let an agent choose among tools | `archvow component add agent booking -d "Finds flights and books one, with the user's approval" -u find_flights_tool,book_ticket_tool` |
| send each request to the right model | `archvow component add router question -d "Simple questions to the fast role, the others to the reasoner"` |
| copy a source into the index | `archvow component add index_job policies -d "Copies the HR policies from SharePoint, only what changed" -u policies_chunker` |
| cut documents into passages | `archvow component add chunker policies -d "Cuts a policy by its headings, then into 500-token chunks"` |
| use an MCP server's tools | `archvow component add mcp_client tickets -d "The tools of the internal tickets server"` |
| serve tools over MCP | `archvow component add mcp_server policies -d "search_policies for the company's assistants"` |
| change a component | `archvow component edit answer_node -d "..."` |
| remove a hazard, an invariant or a rule | `archvow hazard remove policies_retriever.H1`, `archvow invariant remove policies_retriever.INV1`, `archvow rule remove R1` |
| ask a question, as a developer | `archvow question add answer_node "May it answer in English to a French question?"` |
| let the AI find what is unclear | `archvow prompt answer_node --clarify` (in the chat: `/archvow-clarify answer_node`) |
| record a business example (an evaluation: a question in, what the answer must hold out) | `archvow example add chat_api US-001-leave-days -s US-001`; its test checks properties (the cited ids, "I don't know"), never the exact words |
| find a name everywhere | `archvow show <name>` |
| answer what is open, one question at a time | `archvow specify policies_retriever` (in a terminal) |
| let the AI propose the risks of a component | in the chat: `/archvow-analyze book_ticket_tool` |
| classify fields (personal data) | `archvow column set assistant_state messages personal` |
| approve a model provider | `archvow init airport_assistant --force -a dependencies=langchain_anthropic` (an architect) |
| check my setup | `archvow doctor` |
| see every command and option | `archvow --help`, then `archvow <command> --help` |

## Company data

A **Document** is one piece of content from any source - a file, an e-mail, a database row, a
dashboard's description, a page - in one shape (`documents` foundation): `source_id`,
`source_kind`, `text`, `url`, `modified_at`, `allowed` (who may read it, copied from the source).
The flow is always: source -> Documents -> passages (a `chunker`) -> embeddings (the `models`
foundation) -> the index (an `index_job`) -> search (a `retriever`, filtered by the user's access
scope) -> the answer, which cites its passages. A source asked live - a database through an SQL tool,
a mailbox through its search API - makes no Documents: a `tool` answers directly. Which to copy and
which to ask live, per source: archvow's documentation, *LangGraph template*.

## Tests

Every component has its test, `tests/<layer>/test_<component>.py`; an implemented component
without it fails the build. Its task says which kind and what to cover.

- **Unit** (states, schemas, prompts, chunkers, routers, nodes, agents): fake models from the `models`
  foundation (`models.fake([...])` answers the messages it is given, in turn), no network.
- **Integration** (tools, retrievers, graphs, the API, indexing jobs): a whole graph with an in-memory
  checkpointer, an in-memory index, FastAPI's `TestClient`; marked `@pytest.mark.integration`.

The answers of real models are checked apart, on the business examples (`archvow example add`), by
their properties: the cited passages, "I don't know" when nothing is relevant - never word for word.

## Running the assistant

```bash
make run                                   # uvicorn with reload, the API of the `chat` component
```

Settings and keys come from the environment (`get_settings()`), never from code; a local `.env` file
is gitignored. The interactive API documentation is at `/docs`.

## Committing spec changes

The same rules apply to everyone, people and AI assistants alike:

1. **Commit `.archvow/` with the change.** Every command above updates the vows (`.vow` files) in
   `.archvow/`; commit the whole folder (`doc/`, what `archvow doc` writes, is ignored). Never edit a vow
   by hand: `archvow check` sees it (`ARCH014`).
2. **The spec and the code that follows it travel together.** Code without its spec change fails
   (`ARCH001`, `ARCH002`); a spec change without its code is simply *planned*.
3. **Spec changes are approved by the architects** (@acme/architects), through
   `.gitlab/CODEOWNERS`.

## Rules for contributors and AI assistants

[`AGENTS.md`](AGENTS.md) - read it before contributing. Approved AI assistants: claude-code.

Changes to the specification and its guards are approved by @acme/architects
(`.gitlab/CODEOWNERS`).

<!-- archvow:end -->
