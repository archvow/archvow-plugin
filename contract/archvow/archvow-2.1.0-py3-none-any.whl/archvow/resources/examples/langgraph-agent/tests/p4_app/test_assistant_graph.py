"""The question is routed, answered or booked, with the memory and a step limit."""

import uuid
from collections.abc import Callable
from pathlib import Path

import pytest
from hypothesis import HealthCheck, given, settings
from hypothesis import strategies as st
from langchain_core.messages import AIMessage, HumanMessage
from langgraph.types import Command

from airport_assistant.p0_common.access import AccessScope
from airport_assistant.p0_common.settings import get_settings
from airport_assistant.p4_app.assistant_graph import build_assistant_graph
from airport_assistant.p4_app.policies_index_job import index_policies

_SCOPE = AccessScope("ann", frozenset({"employees"}))


def _turn(text: str) -> dict:
    return {"messages": [HumanMessage(content=text)], "scope": _SCOPE}


@pytest.mark.integration
@pytest.mark.decision(1)
def test_a_policy_question_is_answered_from_the_policies(
    script: Callable[..., None],
) -> None:
    index_policies()
    script(
        fast=['{"route": "policies"}'],
        reasoner=['{"text": "Up to 35 euros a day.", "citations": ["travel.md#3.0"]}'],
    )
    result = build_assistant_graph().invoke(
        _turn("meals paid a day"), {"configurable": {"thread_id": "g1"}}
    )
    assert result["route"] == "policies" and result["answer"].citations == [
        "travel.md#3.0"
    ]


@pytest.mark.integration
@pytest.mark.decision(3)
def test_the_graph_has_a_step_limit() -> None:
    assert build_assistant_graph().config["recursion_limit"] == 25


@pytest.mark.integration
@pytest.mark.decision(1)
def test_a_new_turn_keeps_the_conversation(script: Callable[..., None]) -> None:
    script(fast=['{"route": "policies"}', '{"route": "policies"}'], reasoner=[])
    graph, config = build_assistant_graph(), {"configurable": {"thread_id": "g3"}}
    graph.invoke(_turn("first question"), config)
    result = graph.invoke(_turn("second question"), config)
    assert [m.content for m in result["messages"] if isinstance(m, HumanMessage)] == [
        "first question",
        "second question",
    ]


@pytest.mark.integration
@pytest.mark.decision(2)
@settings(
    max_examples=6,
    deadline=None,
    suppress_health_check=[HealthCheck.function_scoped_fixture],
)
@given(approve=st.booleans())
def test_nothing_is_booked_unless_the_user_approves(
    approve: bool, script: Callable[..., None], tool_call: Callable[..., AIMessage]
) -> None:
    Path(get_settings().bookings_path).unlink(missing_ok=True)
    script(
        fast=['{"route": "booking"}'],
        reasoner=[tool_call("book_ticket", flight="AF1234", day="2026-12-01"), "Done."],
    )
    graph = build_assistant_graph()
    config = {"configurable": {"thread_id": f"approve-{approve}-{uuid.uuid4().hex}"}}
    waiting = graph.invoke(_turn("Book AF1234 on 1 December"), config)
    assert waiting["__interrupt__"][0].value["action"] == "book_ticket"
    graph.invoke(Command(resume=approve), config)
    path = Path(get_settings().bookings_path)
    booked = path.read_text(encoding="utf-8").splitlines() if path.exists() else []
    assert len(booked) == (1 if approve else 0)
