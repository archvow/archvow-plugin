"""Messages are appended between steps; the other fields are replaced."""

from collections.abc import Callable
from typing import get_type_hints

import pytest
from langchain_core.messages import AIMessage, HumanMessage
from langgraph.graph.message import add_messages

from airport_assistant.p0_common.access import AccessScope
from airport_assistant.p1_domain.assistant_state import AssistantState
from airport_assistant.p4_app.assistant_graph import build_assistant_graph


@pytest.mark.decision(1)
def test_messages_are_appended() -> None:
    hints = get_type_hints(AssistantState, include_extras=True)
    reducer = hints["messages"].__metadata__[0]
    assert reducer is add_messages
    merged = reducer(
        [HumanMessage(content="hi", id="1")], [AIMessage(content="hello", id="2")]
    )
    assert [m.content for m in merged] == ["hi", "hello"]


@pytest.mark.decision(3)
def test_the_personal_data_is_in_messages_and_scope() -> None:
    hints = get_type_hints(AssistantState, include_extras=True)
    assert set(hints) == {"messages", "scope", "route", "passages", "answer", "version"}


@pytest.mark.decision(2)
def test_a_conversation_of_an_older_version_starts_again(
    script: Callable[..., None],
) -> None:
    script(fast=['{"route": "policies"}'], reasoner=[])
    graph, config = build_assistant_graph(), {"configurable": {"thread_id": "old"}}
    old = [HumanMessage(content="asked last year", id="1")]
    graph.update_state(config, {"messages": old, "version": 0})
    scope = AccessScope("ann", frozenset({"employees"}))
    result = graph.invoke(
        {"messages": [HumanMessage(content="new")], "scope": scope}, config
    )
    assert [m.content for m in result["messages"] if isinstance(m, HumanMessage)] == [
        "new"
    ]
