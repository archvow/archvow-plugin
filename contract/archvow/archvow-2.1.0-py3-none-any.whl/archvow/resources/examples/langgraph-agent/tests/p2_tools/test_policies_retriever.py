"""Only the passages the user's groups may read are found, best first."""

from pathlib import Path

import pytest
from hypothesis import HealthCheck, given, settings
from hypothesis import strategies as st

from airport_assistant.p0_common.access import AccessScope
from airport_assistant.p0_common.settings import get_settings
from airport_assistant.p2_tools.policies_retriever import retrieve_policies
from airport_assistant.p4_app.policies_index_job import index_policies


def _indexed() -> None:
    if not Path(get_settings().index_path).exists():
        index_policies()


@pytest.mark.integration
@pytest.mark.decision(2, 4)
def test_a_question_finds_its_policy_best_first() -> None:
    _indexed()
    found = retrieve_policies(
        "hotel night paid in Paris", AccessScope("ann", frozenset({"employees"}))
    )
    assert found and found[0].text.startswith("Hotels")
    assert [p.score for p in found] == sorted((p.score for p in found), reverse=True)


@pytest.mark.integration
@pytest.mark.decision(3)
def test_nothing_relevant_finds_nothing() -> None:
    _indexed()
    assert (
        retrieve_policies(
            "quarterly revenue forecast", AccessScope("ann", frozenset({"employees"}))
        )
        == []
    )


@pytest.mark.integration
@pytest.mark.decision(3)
def test_no_index_finds_nothing() -> None:
    assert (
        retrieve_policies(
            "hotel in Paris", AccessScope("ann", frozenset({"employees"}))
        )
        == []
    )


_groups = st.frozensets(st.sampled_from(["employees", "executives", "contractors"]))


@pytest.mark.integration
@pytest.mark.decision(1)
@settings(
    max_examples=20,
    deadline=None,
    suppress_health_check=[HealthCheck.function_scoped_fixture],
)
@given(
    groups=_groups,
    question=st.sampled_from(
        ["business class flights", "hotel night in Paris", "meals"]
    ),
)
def test_a_user_only_finds_what_their_groups_may_read(
    groups: frozenset[str], question: str
) -> None:
    _indexed()
    for passage in retrieve_policies(question, AccessScope("ann", groups)):
        assert passage.allowed & groups
