"""The index follows the policy files: what changed, stable ids, deletions."""

import json
from pathlib import Path

import pytest

from airport_assistant.p0_common.settings import get_settings
from airport_assistant.p4_app.policies_index_job import index_policies


def _ids() -> set[str]:
    return set(json.loads(Path(get_settings().index_path).read_text(encoding="utf-8")))


@pytest.mark.integration
@pytest.mark.decision(1, 2)
def test_a_rerun_changes_nothing() -> None:
    assert index_policies() > 0
    before = _ids()
    assert index_policies() == 0 and _ids() == before


@pytest.mark.integration
@pytest.mark.decision(2)
def test_a_changed_file_is_indexed_again(workspace: Path) -> None:
    index_policies()
    policy = workspace / "policies/travel.md"
    policy.write_text(
        policy.read_text(encoding="utf-8") + "\n## Taxis\n\nTaxis are paid at night.\n",
        encoding="utf-8",
    )
    assert index_policies() == 5  # the title, then four sections


@pytest.mark.integration
@pytest.mark.decision(3)
def test_a_deleted_file_leaves_the_index(workspace: Path) -> None:
    index_policies()
    (workspace / "policies/executive-travel.md").unlink()
    index_policies()
    assert not any(i.startswith("executive-travel.md") for i in _ids())


@pytest.mark.integration
@pytest.mark.decision(1, 4)
def test_a_failing_run_leaves_the_index_as_it_was(workspace: Path) -> None:
    index_policies()
    before = Path(get_settings().index_path).read_bytes()
    (workspace / "policies/open.md").write_text(
        "## Anyone\nNo groups line.\n", encoding="utf-8"
    )
    with pytest.raises(ValueError, match="allowed"):
        index_policies()
    assert Path(get_settings().index_path).read_bytes() == before
