"""The booking agent finds flights with its tools, and stops after its step limit."""

from collections.abc import Callable

import pytest
from langchain_core.messages import AIMessage, HumanMessage

from airport_assistant.p0_common import models
from airport_assistant.p0_common.access import AccessScope
from airport_assistant.p3_agents.booking_agent import build_booking_agent

_ASK = {
    "messages": [HumanMessage(content="Flights CDG to JFK on 1 December?")],
    "scope": AccessScope("ann", frozenset({"employees"})),
}


@pytest.mark.decision(1, 3, 4)
def test_it_finds_the_flights_then_answers(
    script: Callable[..., None], tool_call: Callable[..., AIMessage]
) -> None:
    script(
        reasoner=[
            tool_call(
                "find_flights", origin="CDG", destination="JFK", day="2026-12-01"
            ),
            "AF1234 at 10:30 or AF1236 at 16:05.",
        ]
    )
    result = build_booking_agent().invoke(_ASK)
    assert "AF1234" in result["messages"][2].content
    assert result["messages"][-1].content == "AF1234 at 10:30 or AF1236 at 16:05."


@pytest.mark.decision(2)
def test_it_stops_after_eight_tool_calls(
    monkeypatch: pytest.MonkeyPatch, tool_call: Callable[..., AIMessage]
) -> None:
    search = {"origin": "CDG", "destination": "JFK", "day": "2026-12-01"}
    looping_model = models.fake([tool_call("find_flights", **search) for _ in range(8)])
    monkeypatch.setattr(models, "chat", lambda role: looping_model)
    result = build_booking_agent().invoke(_ASK, {"recursion_limit": 50})
    assert isinstance(result["messages"][-1], AIMessage)
    assert result["messages"][-1].content.startswith("I stopped after 8 steps")
