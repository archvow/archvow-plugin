"""The answer comes from the passages the user may read, and cites them."""

from collections.abc import Callable

import pytest
from langchain_core.messages import HumanMessage

from airport_assistant.p0_common.access import AccessScope
from airport_assistant.p3_agents.answer_node import answer_node
from airport_assistant.p4_app.policies_index_job import index_policies

_EMPLOYEE = AccessScope("ann", frozenset({"employees"}))


def _state(question: str) -> dict:
    return {"messages": [HumanMessage(content=question)], "scope": _EMPLOYEE}


@pytest.mark.decision(1, 2)
@pytest.mark.invariant("answer_node.INV1")
def test_the_answer_cites_the_passages_it_found(script: Callable[..., None]) -> None:
    index_policies()
    script(
        reasoner=[
            '{"text": "Up to 150 euros a night.", '
            '"citations": ["travel.md#1.0", "made-up#9"]}'
        ]
    )
    result = answer_node(_state("hotel night paid in Paris"))
    assert result["answer"].text == "Up to 150 euros a night."
    assert result["answer"].citations == ["travel.md#1.0"]
    assert result["messages"][0].content == "Up to 150 euros a night."


@pytest.mark.rule("R1")
def test_no_passage_means_it_does_not_know(script: Callable[..., None]) -> None:
    script(reasoner=[])
    result = answer_node(_state("hotel night paid in Paris"))
    assert (
        result["answer"].text.startswith("I do not know")
        and result["answer"].citations == []
    )


@pytest.mark.decision(3)
def test_an_answer_that_never_fits_gives_a_fixed_message(
    script: Callable[..., None],
) -> None:
    index_policies()
    script(reasoner=["not json", "still not json"])
    result = answer_node(_state("hotel night paid in Paris"))
    assert result["answer"].text.startswith("I could not write an answer")
