"""A route is one of a fixed list."""

import pytest
from pydantic import ValidationError

from airport_assistant.p1_domain.route_schema import Route


@pytest.mark.decision(1)
def test_a_route_of_the_list_fits() -> None:
    assert Route(route="booking").route == "booking"


@pytest.mark.decision(1, 2)
def test_a_route_outside_the_list_does_not_fit() -> None:
    with pytest.raises(ValidationError):
        Route.model_validate({"route": "delete_everything"})


@pytest.mark.decision(3)
def test_a_route_is_not_an_answer() -> None:
    assert set(Route.model_fields) == {"route"}
