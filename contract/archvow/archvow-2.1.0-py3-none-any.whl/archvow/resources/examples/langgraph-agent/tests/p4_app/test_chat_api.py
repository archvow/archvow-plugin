"""POST /chat for the signed-in user: an AI's answer; approvals resume."""

import uuid
from collections.abc import Callable

import pytest
from fastapi.testclient import TestClient
from hypothesis import given, settings
from hypothesis import strategies as st
from langchain_core.messages import AIMessage

from airport_assistant.p4_app.chat_api import create_app
from airport_assistant.p4_app.policies_index_job import index_policies

client = TestClient(create_app())
_ANN = {"X-User": "ann", "X-Groups": "employees"}


@pytest.mark.integration
@pytest.mark.decision(2, 4)
def test_the_first_answer_says_it_comes_from_an_ai(script: Callable[..., None]) -> None:
    index_policies()
    script(
        fast=['{"route": "policies"}', '{"route": "policies"}'],
        reasoner=[
            '{"text": "Up to 150 euros.", "citations": ["travel.md#1.0"]}',
            '{"text": "Up to 35 euros.", "citations": []}',
        ],
    )
    first = client.post(
        "/chat",
        json={"thread_id": "a1", "message": "hotel night in Paris"},
        headers=_ANN,
    ).json()
    assert (
        first["ai_generated"] is True
        and first["notice"]
        and first["citations"] == ["travel.md#1.0"]
    )
    second = client.post(
        "/chat", json={"thread_id": "a1", "message": "meals"}, headers=_ANN
    ).json()
    assert second["ai_generated"] is True and second["notice"] is None


@pytest.mark.integration
@pytest.mark.decision(1, 3)
def test_no_signed_in_user_is_refused() -> None:
    assert (
        client.post("/chat", json={"thread_id": "a2", "message": "hi"}).status_code
        == 401
    )


@pytest.mark.integration
@pytest.mark.decision(1, "P1", "P2")
def test_the_groups_come_from_the_gateway_never_from_the_body(
    script: Callable[..., None],
) -> None:
    index_policies()
    cited = '{"text": "Business class.", "citations": ["executive-travel.md#1.0"]}'
    script(fast=['{"route": "policies"}'], reasoner=[cited])
    body = {
        "thread_id": "a3",
        "message": "business class flights for executives",
        "groups": ["executives"],
    }
    reply = client.post("/chat", json=body, headers=_ANN).json()
    assert reply["citations"] == []  # an executives' passage is never found for ann


@pytest.mark.integration
@pytest.mark.decision(1)
def test_a_reply_to_an_approval_resumes_the_conversation(
    script: Callable[..., None], tool_call: Callable[..., AIMessage]
) -> None:
    script(
        fast=['{"route": "booking"}'],
        reasoner=[
            tool_call("book_ticket", flight="AF1234", day="2026-12-01"),
            "Booked AF1234.",
        ],
    )
    asked = client.post(
        "/chat", json={"thread_id": "a4", "message": "Book AF1234"}, headers=_ANN
    ).json()
    assert asked["pending_approval"] == {
        "action": "book_ticket",
        "flight": "AF1234",
        "day": "2026-12-01",
    }
    stranger = client.post(
        "/chat", json={"thread_id": "a4", "approve": True}, headers={"X-User": "eve"}
    )
    assert stranger.status_code == 409
    done = client.post(
        "/chat", json={"thread_id": "a4", "approve": True}, headers=_ANN
    ).json()
    assert done["text"] == "Booked AF1234."


@pytest.mark.integration
def test_health() -> None:
    assert client.get("/health").json() == {"status": "ok"}


_users = st.sampled_from(["ann", "bob", "eve"])


@pytest.mark.integration
@pytest.mark.invariant("chat_api.INV1")
@settings(max_examples=15, deadline=None)
@given(owner=_users, other=_users, thread=st.text("abc123", min_size=1, max_size=8))
def test_a_conversation_belongs_to_the_user_who_started_it(
    owner: str, other: str, thread: str
) -> None:
    thread = f"{thread}-{uuid.uuid4().hex}"
    started = client.post(
        "/chat",
        json={"thread_id": thread, "message": "hotel"},
        headers={"X-User": owner, "X-Groups": "employees"},
    )
    assert started.status_code == 200 and started.json()["notice"]
    again = client.post(
        "/chat",
        json={"thread_id": thread, "message": "meals"},
        headers={"X-User": other, "X-Groups": "executives"},
    )
    assert (again.json()["notice"] is None) == (other == owner)
