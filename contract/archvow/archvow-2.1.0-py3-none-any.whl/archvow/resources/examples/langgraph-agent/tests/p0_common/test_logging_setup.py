"""One line per event, with the request and thread ids of the run it belongs to."""

import logging
import sys

import pytest
from langchain_core.runnables import RunnableLambda

from airport_assistant.p0_common.logging_setup import setup_logging


@pytest.mark.decision(1)
def test_a_line_carries_the_ids_of_its_run(capsys: pytest.CaptureFixture[str]) -> None:
    setup_logging("INFO")
    log = logging.getLogger("airport_assistant.tests")
    run = {"metadata": {"request_id": "r1", "thread": "t1"}}
    RunnableLambda(lambda _: log.info("inside a run")).invoke(None, run)
    log.info("outside")
    inside, outside = capsys.readouterr().err.splitlines()
    assert "INFO request=r1 thread=t1 airport_assistant.tests inside a run" in inside
    assert "request=- thread=-" in outside


@pytest.mark.decision(2)
def test_logs_only_go_to_stderr_nothing_leaves_the_process() -> None:
    setup_logging("INFO")
    (handler,) = logging.getLogger().handlers
    assert type(handler) is logging.StreamHandler
    assert handler.stream is sys.stderr
