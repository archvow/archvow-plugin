## Hotels

A night is paid up to 150 euros in Paris and up to 110 euros elsewhere.

## Meals

Meals are paid up to 35 euros a day.
