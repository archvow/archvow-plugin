"""An answer says it was written by an AI and cites passages."""

import pytest
from pydantic import ValidationError

from airport_assistant.p1_domain.answer_schema import Answer


@pytest.mark.decision(1, 3)
def test_an_answer_is_marked_as_written_by_an_ai() -> None:
    answer = Answer(text="Up to 150 euros.")
    assert answer.ai_generated is True and answer.citations == []


@pytest.mark.decision(1, 2)
def test_an_answer_without_text_does_not_fit() -> None:
    with pytest.raises(ValidationError):
        Answer.model_validate({"citations": ["travel.md#1.0"]})
