"""A booking waits for the user's approval, and the same booking is never made twice."""

import json
from pathlib import Path

import pytest
from hypothesis import HealthCheck, given, settings
from hypothesis import strategies as st
from langchain_core.messages import AIMessage
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import START, StateGraph
from langgraph.prebuilt import ToolNode
from langgraph.types import Command

from airport_assistant.p0_common.access import AccessScope
from airport_assistant.p0_common.settings import get_settings
from airport_assistant.p1_domain.assistant_state import AssistantState
from airport_assistant.p2_tools.book_ticket_tool import book_ticket

_CALL = AIMessage(
    content="",
    tool_calls=[
        {
            "name": "book_ticket",
            "args": {"flight": "AF1234", "day": "2026-12-01"},
            "id": "c1",
        }
    ],
)


def _book(user: str, approve: bool, thread: str) -> str:
    """One call of the tool in a graph, then the user's reply to its approval."""
    graph = StateGraph(AssistantState)
    graph.add_node("tools", ToolNode([book_ticket]))
    graph.add_edge(START, "tools")
    app = graph.compile(checkpointer=InMemorySaver())
    config = {"configurable": {"thread_id": thread}}
    waiting = app.invoke(
        {"messages": [_CALL], "scope": AccessScope(user, frozenset())}, config
    )
    assert waiting["__interrupt__"][0].value == {
        "action": "book_ticket",
        "flight": "AF1234",
        "day": "2026-12-01",
    }
    return str(app.invoke(Command(resume=approve), config)["messages"][-1].content)


def _lines() -> list[str]:
    path = Path(get_settings().bookings_path)
    return path.read_text(encoding="utf-8").splitlines() if path.exists() else []


@pytest.mark.integration
@pytest.mark.decision(3)
def test_an_approved_booking_is_recorded_for_the_signed_in_user() -> None:
    assert _book("ann", approve=True, thread="t1").startswith("Booked")
    (line,) = _lines()
    record = json.loads(line)
    assert (record["user"], record["approved_by"], record["flight"]) == (
        "ann",
        "ann",
        "AF1234",
    )


@pytest.mark.integration
@pytest.mark.decision(2, 5)
def test_a_refused_booking_is_not_made() -> None:
    assert _book("ann", approve=False, thread="t1").startswith("Not booked")
    assert _lines() == []


@pytest.mark.integration
@pytest.mark.decision(1)
def test_another_user_books_their_own_seat() -> None:
    _book("ann", approve=True, thread="t1")
    assert _book("bob", approve=True, thread="t2").startswith("Booked")
    assert len(_lines()) == 2


@pytest.mark.integration
@pytest.mark.decision(4)
@settings(
    max_examples=10,
    deadline=None,
    suppress_health_check=[HealthCheck.function_scoped_fixture],
)
@given(tries=st.integers(min_value=1, max_value=3), approve=st.booleans())
def test_nothing_is_booked_without_approval_and_never_twice(
    tries: int, approve: bool
) -> None:
    Path(get_settings().bookings_path).unlink(missing_ok=True)
    for number in range(tries):
        _book("carol", approve=approve, thread=f"t{number}")
    assert len(_lines()) == (1 if approve else 0)
