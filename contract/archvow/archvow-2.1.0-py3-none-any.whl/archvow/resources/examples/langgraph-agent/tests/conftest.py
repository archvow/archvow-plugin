"""Shared fixtures: logging put back, a temporary workspace, scripted models."""

from __future__ import annotations

import logging
import shutil
from collections.abc import Callable, Iterator
from pathlib import Path

import pytest
from langchain_core.messages import AIMessage

from airport_assistant.p0_common import models

EXAMPLE = Path(__file__).resolve().parents[1]

Script = Callable[..., None]


@pytest.fixture(autouse=True)
def _logging_put_back() -> Iterator[None]:
    root = logging.getLogger()
    handlers, level = root.handlers[:], root.level
    yield
    root.handlers[:] = handlers
    root.setLevel(level)


@pytest.fixture(autouse=True)
def workspace(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """The policies and flights, copied; the index and bookings written there."""
    shutil.copytree(EXAMPLE / "policies", tmp_path / "policies")
    shutil.copytree(EXAMPLE / "data", tmp_path / "data")
    monkeypatch.setenv("ASSISTANT_POLICIES_DIR", str(tmp_path / "policies"))
    monkeypatch.setenv(
        "ASSISTANT_INDEX_PATH", str(tmp_path / "index" / "policies.json")
    )
    monkeypatch.setenv(
        "ASSISTANT_FLIGHTS_PATH", str(tmp_path / "data" / "flights.json")
    )
    monkeypatch.setenv(
        "ASSISTANT_BOOKINGS_PATH", str(tmp_path / "data" / "bookings.jsonl")
    )
    return tmp_path


@pytest.fixture
def script(monkeypatch: pytest.MonkeyPatch) -> Script:
    """script(fast=[...], reasoner=[...]): each role answers these messages in turn."""

    def scripted(**roles: list[AIMessage | str]) -> None:
        fakes = {role: models.fake(messages) for role, messages in roles.items()}
        monkeypatch.setattr(models, "chat", lambda role: fakes[role])

    return scripted


@pytest.fixture
def tool_call() -> Callable[..., AIMessage]:
    """tool_call(name, **args): the reasoner's message asking for one tool."""

    def call(name: str, **args: str) -> AIMessage:
        return AIMessage(
            content="", tool_calls=[{"name": name, "args": args, "id": f"call_{name}"}]
        )

    return call
