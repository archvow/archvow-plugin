"""The flights of one day between two airports, from the schedule."""

import pytest

from airport_assistant.p2_tools.find_flights_tool import find_flights


@pytest.mark.integration
@pytest.mark.decision(1, 2, 3)
def test_the_days_flights_between_two_airports() -> None:
    flights = find_flights.invoke(
        {"origin": "cdg", "destination": "JFK", "day": "2026-12-01"}
    )
    assert [f["flight"] for f in flights] == ["AF1234", "AF1236"]


@pytest.mark.integration
@pytest.mark.decision(4, 5)
def test_another_day_has_no_flight() -> None:
    assert (
        find_flights.invoke(
            {"origin": "CDG", "destination": "JFK", "day": "2026-12-02"}
        )
        == []
    )
