Feature: cut a travel policy
  Scenario: one chunk per section, each starting with its heading
    Given the travel team's hotel limits, with two sections
    When the policy is cut
    Then there is one chunk per section, its heading first
