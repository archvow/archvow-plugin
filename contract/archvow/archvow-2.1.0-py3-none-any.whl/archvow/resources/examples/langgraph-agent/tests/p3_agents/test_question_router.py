"""The fast model names the route; an answer that does not fit: policies."""

from collections.abc import Callable

import pytest
from langchain_core.messages import HumanMessage

from airport_assistant.p3_agents.question_router import route_question


@pytest.mark.decision(1, 2)
def test_the_fast_model_names_the_route(script: Callable[..., None]) -> None:
    script(fast=['{"route": "booking"}'])
    assert route_question(
        {"messages": [HumanMessage(content="Book me a flight to New York")]}
    ) == {"route": "booking"}


@pytest.mark.decision(3)
def test_an_answer_that_does_not_fit_takes_the_policies_route(
    script: Callable[..., None],
) -> None:
    script(fast=['{"route": "delete_everything"}'])
    assert route_question({"messages": [HumanMessage(content="???")]}) == {
        "route": "policies"
    }
