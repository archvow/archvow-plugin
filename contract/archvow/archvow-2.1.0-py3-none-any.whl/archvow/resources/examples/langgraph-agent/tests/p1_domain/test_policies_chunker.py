"""A policy is cut at its headings, then into overlapping chunks."""

import json
from datetime import UTC, datetime
from pathlib import Path

import pytest

from airport_assistant.p0_common.documents import Document
from airport_assistant.p1_domain.policies_chunker import chunk_policies


def _document(text: str) -> Document:
    return Document(
        source_id="travel.md",
        source_kind="file",
        text=text,
        url="file:///travel.md",
        modified_at=datetime(2026, 11, 1, tzinfo=UTC),
        allowed=frozenset({"employees"}),
    )


@pytest.mark.decision(1, 3)
def test_each_heading_starts_a_chunk_that_keeps_its_document() -> None:
    chunks = chunk_policies(
        _document("## Hotels\nUp to 150 euros.\n## Meals\nUp to 35 euros.")
    )
    assert [c.text.splitlines()[0] for c in chunks] == ["Hotels", "Meals"]
    assert {(c.source_id, c.url, c.allowed) for c in chunks} == {
        ("travel.md", "file:///travel.md", frozenset({"employees"}))
    }


@pytest.mark.decision(2)
def test_a_long_section_is_cut_into_chunks_that_overlap() -> None:
    words = [f"w{i}" for i in range(250)]
    chunks = chunk_policies(_document("## Long\n" + " ".join(words)))
    bodies = [c.text.split("\n", 1)[1].split() for c in chunks]
    assert all(len(body) <= 120 for body in bodies)
    assert bodies[0][-20:] == bodies[1][:20]
    assert {w for body in bodies for w in body} == set(words)
    assert len({c.chunk_id for c in chunks}) == len(chunks)


@pytest.mark.example("US-002-hotel-limits")
def test_example_hotel_limits() -> None:
    case = Path(__file__).parents[1] / "examples/policies_chunker/US-002-hotel-limits"
    text = (case / "input/policy.md").read_text(encoding="utf-8")
    document = _document(text).model_copy(update={"source_id": "hotels.md"})
    got = [{"chunk_id": c.chunk_id, "text": c.text} for c in chunk_policies(document)]
    (case / "actual").mkdir(
        exist_ok=True
    )  # what it gave, for archvow show (not committed)
    (case / "actual/chunks.json").write_text(
        json.dumps(got, indent=2), encoding="utf-8"
    )
    expected = json.loads((case / "expected/chunks.json").read_text(encoding="utf-8"))
    assert got == expected
