allowed: employees
# Travel policy

## Hotels

A night in a hotel is paid up to 150 euros in Paris and up to 110 euros in other cities,
breakfast included. Book the hotel through the travel desk; a hotel booked elsewhere is not
paid back unless the travel desk had no room under the limit.

## Flights

Flights of less than six hours are booked in economy class. Longer flights may be booked in
premium economy with the manager's approval. Book at least 14 days ahead when you can.

## Meals

Meals on a business trip are paid up to 35 euros a day, with the receipts.
