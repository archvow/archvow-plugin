allowed: executives
# Executive travel

## Flights

Executives may fly business class on flights of more than four hours, and use the airport
lounges of the company's partner airlines.
