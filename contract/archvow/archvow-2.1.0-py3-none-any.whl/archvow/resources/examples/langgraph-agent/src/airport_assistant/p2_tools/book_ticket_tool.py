"""Books a seat for the signed-in user once they approved it; never twice.

@component  book_ticket_tool (tool, p2_tools)
@spec       US-003
@project    airport_assistant
@author     A. Developer
@assisted   claude-code
@date       2026-11-08
"""

from __future__ import annotations

import hashlib
import json
import logging
from datetime import UTC, datetime
from pathlib import Path
from typing import Annotated

from langchain_core.tools import tool
from langgraph.prebuilt import InjectedState
from langgraph.types import interrupt

from airport_assistant.p0_common.access import AccessScope
from airport_assistant.p0_common.settings import get_settings

logger = logging.getLogger(__name__)


def _booking_key(scope: AccessScope, flight: str, day: str) -> str:
    """The same user, flight and day give the same key: a second booking is refused."""
    return hashlib.sha256(
        f"{scope.tenant}|{scope.user_id}|{flight}|{day}".encode()
    ).hexdigest()


def _booked(path: Path) -> set[str]:
    if not path.exists():
        return set()
    lines = path.read_text(encoding="utf-8").splitlines()
    return {json.loads(line)["key"] for line in lines if line.strip()}


@tool
def book_ticket(
    flight: str,
    day: str,
    scope: Annotated[AccessScope, InjectedState("scope")],
) -> str:
    """Book a seat on flight (e.g. AF1234) on day (YYYY-MM-DD) for the user."""
    approved = interrupt({"action": "book_ticket", "flight": flight, "day": day})
    if approved is not True:
        logger.info("booking refused by the user")
        return f"Not booked: the user did not approve flight {flight} on {day}."
    path = Path(get_settings().bookings_path)
    key = _booking_key(scope, flight, day)
    if key in _booked(path):
        logger.info("booking %s already recorded", key[:12])
        return f"Already booked: flight {flight} on {day}."
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as bookings:
        # The audit line: who, what, when, approved by whom.
        line = {
            "key": key,
            "user": scope.user_id,
            "flight": flight,
            "day": day,
            "at": datetime.now(tz=UTC).isoformat(),
            "approved_by": scope.user_id,
        }
        bookings.write(json.dumps(line) + "\n")
    logger.info("booking %s recorded", key[:12])
    return f"Booked: flight {flight} on {day}."
