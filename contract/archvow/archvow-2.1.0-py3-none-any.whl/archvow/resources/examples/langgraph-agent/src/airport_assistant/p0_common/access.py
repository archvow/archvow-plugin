"""Who asks: the user, their groups, the tenant.

@component  access (foundation, p0_common)
@spec       -
@project    airport_assistant
@author     A. Developer
@assisted   claude-code
@date       2026-11-08
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass, field


@dataclass(frozen=True)
class AccessScope:
    """Built by the API from the signed-in user; never filled by a model."""

    user_id: str
    groups: frozenset[str] = field(default_factory=frozenset)
    tenant: str = "default"

    def may_read(self, allowed: Iterable[str]) -> bool:
        """Whether one of the user's groups is among the groups allowed to read."""
        return not self.groups.isdisjoint(allowed)
