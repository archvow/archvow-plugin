"""The route the router chose.

@component  route_schema (schema, p1_domain)
@spec       US-003
@project    airport_assistant
@author     A. Developer
@assisted   claude-code
@date       2026-11-08
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel


class Route(BaseModel):
    """One route of a fixed list: the policies answer or the booking agent."""

    route: Literal["policies", "booking"]
