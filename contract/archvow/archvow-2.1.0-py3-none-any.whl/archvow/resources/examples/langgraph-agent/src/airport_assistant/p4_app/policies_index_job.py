"""Copies the policy files into the index: only what changed, with stable ids.

@component  policies_index_job (index_job, p4_app)
@spec       US-002
@project    airport_assistant
@author     A. Developer
@assisted   claude-code
@date       2026-11-08
"""

from __future__ import annotations

import hashlib
import logging
import os
from datetime import UTC, datetime
from pathlib import Path

from langchain_core.documents import Document as StoredChunk
from langchain_core.vectorstores import InMemoryVectorStore

from airport_assistant.p0_common import models
from airport_assistant.p0_common.documents import Document
from airport_assistant.p0_common.settings import get_settings
from airport_assistant.p1_domain.policies_chunker import chunk_policies

logger = logging.getLogger(__name__)


def _read(path: Path, root: Path) -> Document:
    """A policy file: an 'allowed: group, group' first line, then Markdown."""
    first, _, text = path.read_text(encoding="utf-8").partition("\n")
    if not first.startswith("allowed:"):
        message = f"{path.name}: the first line must be 'allowed: <groups>'"
        raise ValueError(message)
    groups = frozenset(
        g.strip() for g in first.removeprefix("allowed:").split(",") if g.strip()
    )
    return Document(
        source_id=path.relative_to(root).as_posix(),
        source_kind="file",
        text=text,
        url=path.resolve().as_uri(),
        modified_at=datetime.fromtimestamp(path.stat().st_mtime, tz=UTC),
        allowed=groups,
    )


def _hash(document: Document) -> str:
    content = document.text + "|" + ",".join(sorted(document.allowed))
    return hashlib.sha256(content.encode()).hexdigest()


def index_policies() -> int:
    """Brings the index up to date with policies_dir; returns the chunks written."""
    settings = get_settings()
    root, index = Path(settings.policies_dir), Path(settings.index_path)
    store = (
        InMemoryVectorStore.load(str(index), models.embeddings())
        if index.exists()
        else InMemoryVectorStore(models.embeddings())
    )
    indexed: dict[str, set[str]] = {}
    hashes: dict[str, str] = {}
    for chunk_id, chunk in store.store.items():
        source = chunk["metadata"]["source_id"]
        indexed.setdefault(source, set()).add(chunk_id)
        hashes[source] = chunk["metadata"]["content_hash"]
    documents = [_read(path, root) for path in sorted(root.rglob("*.md"))]
    written = 0
    for document in documents:
        content_hash = _hash(document)
        if hashes.get(document.source_id) == content_hash:
            continue
        if document.source_id in indexed:
            store.delete(ids=list(indexed[document.source_id]))
        passages = chunk_policies(document)
        chunks = [
            StoredChunk(
                page_content=p.text,
                metadata={
                    "source_id": p.source_id,
                    "url": p.url,
                    "allowed": sorted(p.allowed),
                    "content_hash": content_hash,
                },
            )
            for p in passages
        ]
        store.add_documents(chunks, ids=[p.chunk_id for p in passages])
        written += len(chunks)
    for gone in set(indexed) - {d.source_id for d in documents}:
        store.delete(ids=list(indexed[gone]))
        logger.info("removed the chunks of %s", gone)
    index.parent.mkdir(parents=True, exist_ok=True)
    partial = index.with_suffix(".partial")
    store.dump(str(partial))
    os.replace(partial, index)
    logger.info("%d document(s), %d chunk(s) written", len(documents), written)
    return written
