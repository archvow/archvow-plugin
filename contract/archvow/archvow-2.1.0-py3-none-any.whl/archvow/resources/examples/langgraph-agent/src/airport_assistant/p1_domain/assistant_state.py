"""The conversation, saved between steps and between requests.

@component  assistant_state (state, p1_domain)
@spec       US-001
@project    airport_assistant
@author     A. Developer
@assisted   claude-code
@date       2026-11-08
"""

from __future__ import annotations

from typing import Annotated, TypedDict

from langchain_core.messages import AnyMessage
from langgraph.graph.message import add_messages

from airport_assistant.p0_common.access import AccessScope
from airport_assistant.p0_common.documents import Passage
from airport_assistant.p1_domain.answer_schema import Answer


class AssistantState(TypedDict, total=False):
    """messages are appended; every other field is replaced."""

    messages: Annotated[list[AnyMessage], add_messages]
    scope: AccessScope
    route: str
    passages: list[Passage]
    answer: Answer | None
    version: int
