"""Answers from the passages the user may read, citing them.

@component  answer_node (node, p3_agents)
@spec       US-001
@project    airport_assistant
@author     A. Developer
@assisted   claude-code
@date       2026-11-08
"""

from __future__ import annotations

import logging

from langchain_core.messages import AIMessage, HumanMessage

from airport_assistant.p0_common import models
from airport_assistant.p0_common.documents import Passage
from airport_assistant.p1_domain.answer_prompt import build_answer_prompt
from airport_assistant.p1_domain.answer_schema import Answer
from airport_assistant.p1_domain.assistant_state import AssistantState
from airport_assistant.p2_tools.policies_retriever import retrieve_policies

logger = logging.getLogger(__name__)

_NOT_FOUND = "I do not know: no travel policy you may read answers this question."
_NOT_ANSWERED = "I could not write an answer this time; please ask again."


def _ask(question: str, passages: list[Passage]) -> Answer:
    """The reasoner's answer; asked again once with the error when it does not fit."""
    reasoner = models.chat("reasoner").with_structured_output(Answer)
    messages = build_answer_prompt(question, passages)
    try:
        return reasoner.invoke(messages)
    except ValueError as error:
        logger.warning("the answer did not fit the schema: asked again once")
        retry = [*messages, HumanMessage(content=f"Your answer did not fit: {error}")]
        try:
            return reasoner.invoke(retry)
        except ValueError:
            logger.warning("the answer did not fit the schema twice")
            return Answer(text=_NOT_ANSWERED)


def answer_node(state: AssistantState) -> dict[str, object]:
    """Reads the last message and the scope; writes the passages and the answer."""
    question = str(state["messages"][-1].content)
    passages = retrieve_policies(question, state["scope"])
    if not passages:
        answer = Answer(text=_NOT_FOUND)
    else:
        answer = _ask(question, passages)
        found = {passage.chunk_id for passage in passages}
        answer = answer.model_copy(
            update={"citations": [c for c in answer.citations if c in found]}
        )
    return {
        "passages": passages,
        "answer": answer,
        "messages": [AIMessage(content=answer.text)],
    }
