"""Cuts a policy document at its headings, then into overlapping chunks.

@component  policies_chunker (chunker, p1_domain)
@spec       US-002
@project    airport_assistant
@author     A. Developer
@assisted   claude-code
@date       2026-11-08
"""

from __future__ import annotations

import re

from airport_assistant.p0_common.documents import Document, Passage

_CHUNK_WORDS = 120
_OVERLAP_WORDS = 20
_HEADING = re.compile(r"^## +(.+)$", re.MULTILINE)


def _sections(text: str) -> list[tuple[str, str]]:
    """The (heading, body) of each '## ' section; the text before has no heading."""
    parts = _HEADING.split(text)
    sections = [("", parts[0])]
    sections += [(parts[i].strip(), parts[i + 1]) for i in range(1, len(parts), 2)]
    return [(heading, body) for heading, body in sections if body.strip()]


def _pieces(words: list[str]) -> list[list[str]]:
    """At most _CHUNK_WORDS words each, the next one starting _OVERLAP_WORDS earlier."""
    step = _CHUNK_WORDS - _OVERLAP_WORDS
    starts = range(0, max(len(words) - _OVERLAP_WORDS, 1), step)
    return [words[start : start + _CHUNK_WORDS] for start in starts]


def chunk_policies(document: Document) -> list[Passage]:
    """The passages, each keeping its source, url, heading and allowed groups."""
    passages: list[Passage] = []
    for number, (heading, body) in enumerate(_sections(document.text)):
        for part, words in enumerate(_pieces(body.split())):
            prefix = f"{heading}\n" if heading else ""
            passages.append(
                Passage(
                    source_id=document.source_id,
                    chunk_id=f"{document.source_id}#{number}.{part}",
                    text=prefix + " ".join(words),
                    url=document.url,
                    allowed=document.allowed,
                )
            )
    return passages
