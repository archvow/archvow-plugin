"""The conversations' memory: the checkpointer every graph is compiled with.

@component  memory (foundation, p0_common)
@spec       -
@project    airport_assistant
@author     A. Developer
@assisted   claude-code
@date       2026-11-08
"""

from __future__ import annotations

from langgraph.checkpoint.base import BaseCheckpointSaver
from langgraph.checkpoint.memory import InMemorySaver

_SAVER = InMemorySaver()


def get_checkpointer() -> BaseCheckpointSaver:
    """The conversations' store: in memory here; Postgres in production."""
    return _SAVER
