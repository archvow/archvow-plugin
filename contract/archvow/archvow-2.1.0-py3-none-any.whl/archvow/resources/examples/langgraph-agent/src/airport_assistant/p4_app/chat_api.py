"""POST /chat for the signed-in user; a reply to an approval resumes the conversation.

@component  chat_api (api, p4_app)
@spec       US-001
@project    airport_assistant
@author     A. Developer
@assisted   claude-code
@date       2026-11-08
"""

from __future__ import annotations

import logging
import uuid
from functools import cache
from typing import Annotated

from fastapi import APIRouter, FastAPI, Header, HTTPException
from langchain_core.messages import AIMessage, HumanMessage
from langgraph.graph.state import CompiledStateGraph
from langgraph.types import Command
from pydantic import BaseModel, Field

from airport_assistant.p0_common.access import AccessScope
from airport_assistant.p0_common.logging_setup import setup_logging
from airport_assistant.p0_common.settings import get_settings
from airport_assistant.p1_domain.answer_schema import Answer
from airport_assistant.p4_app.assistant_graph import build_assistant_graph

logger = logging.getLogger(__name__)

_AI_NOTICE = (
    "You are talking to an AI assistant: check its answers in the cited policies."
)

router: APIRouter = APIRouter()


class _ChatRequest(BaseModel):
    """A message, or the reply to an approval (approve), in one conversation."""

    thread_id: str = Field(min_length=1, max_length=64)
    message: str | None = Field(default=None, max_length=4000)
    approve: bool | None = None


class _ChatResponse(BaseModel):
    """The reply; pending_approval holds what waits for the user's yes or no."""

    thread_id: str
    text: str
    citations: list[str] = Field(default_factory=list)
    ai_generated: bool = True
    notice: str | None = None
    pending_approval: dict[str, str] | None = None


def _scope(x_user: str, x_groups: str) -> AccessScope:
    """Built from the gateway's headers, never from the body."""
    if not x_user.strip():
        raise HTTPException(status_code=401, detail="not signed in")
    groups = frozenset(group.strip() for group in x_groups.split(",") if group.strip())
    return AccessScope(user_id=x_user.strip(), groups=groups)


@cache
def _assistant() -> CompiledStateGraph:
    return build_assistant_graph()


@router.post("/chat")
def chat(
    request: _ChatRequest,
    x_user: Annotated[str, Header()] = "",
    x_groups: Annotated[str, Header()] = "",
) -> _ChatResponse:
    """One turn of the conversation, for the signed-in user."""
    scope = _scope(x_user, x_groups)
    # A thread belongs to its user: another user's thread id is another conversation.
    config = {
        "configurable": {
            "thread_id": f"{scope.tenant}|{scope.user_id}|{request.thread_id}"
        }
    }
    assistant = _assistant()
    saved = assistant.get_state(config)
    first = not saved.values
    if request.approve is not None:
        if not saved.interrupts:
            raise HTTPException(status_code=409, detail="nothing waits for an approval")
        turn: object = Command(resume=request.approve)
    elif request.message:
        turn = {"messages": [HumanMessage(content=request.message)], "scope": scope}
    else:
        raise HTTPException(status_code=422, detail="give a message or approve")
    ids = {"request_id": uuid.uuid4().hex[:12], "thread_id": request.thread_id}
    logger.info("turn started", extra=ids)
    run = {
        **config,
        "metadata": {"request_id": ids["request_id"], "thread": request.thread_id},
    }
    result = assistant.invoke(
        turn, config=run
    )  # the steps' log lines carry the same ids
    logger.info("turn ended", extra=ids)
    waiting = result.get("__interrupt__")
    if waiting:
        pending = {key: str(value) for key, value in waiting[0].value.items()}
        text = f"Do you approve {pending['action']} for flight {pending['flight']}?"
        return _ChatResponse(
            thread_id=request.thread_id, text=text, pending_approval=pending
        )
    answer = result.get("answer") or Answer(text=_last_text(result["messages"]))
    return _ChatResponse(
        thread_id=request.thread_id,
        text=answer.text,
        citations=answer.citations,
        notice=_AI_NOTICE if first else None,
    )


def _last_text(messages: list[object]) -> str:
    replies = [m for m in messages if isinstance(m, AIMessage) and m.content]
    return str(replies[-1].content) if replies else ""


@router.get("/health")
def health() -> dict[str, str]:
    """Whether the assistant is up."""
    return {"status": "ok"}


def create_app() -> FastAPI:
    """The assistant's web application."""
    setup_logging(get_settings().log_level)
    app = FastAPI(title="Airport assistant")
    app.include_router(router)
    return app
