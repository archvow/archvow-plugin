"""The policy passages the user may read that answer a question, best first.

@component  policies_retriever (retriever, p2_tools)
@spec       US-001
@project    airport_assistant
@author     A. Developer
@assisted   claude-code
@date       2026-11-08
"""

from __future__ import annotations

import logging
from pathlib import Path

from langchain_core.documents import Document as StoredChunk
from langchain_core.vectorstores import InMemoryVectorStore

from airport_assistant.p0_common import models
from airport_assistant.p0_common.access import AccessScope
from airport_assistant.p0_common.documents import Passage
from airport_assistant.p0_common.settings import get_settings

logger = logging.getLogger(__name__)

_TOP_K = 4
_MIN_SCORE = 0.30


def retrieve_policies(query: str, scope: AccessScope) -> list[Passage]:
    """The best passages above the threshold, only those the user may read."""
    path = Path(get_settings().index_path)
    if not path.exists():
        logger.warning("no index at %s: nothing can be found", path)
        return []
    store = InMemoryVectorStore.load(str(path), models.embeddings())

    def readable(chunk: StoredChunk) -> bool:
        return scope.may_read(chunk.metadata.get("allowed", []))

    found = store.similarity_search_with_score(query, k=_TOP_K, filter=readable)
    passages = [
        Passage(
            source_id=chunk.metadata["source_id"],
            chunk_id=str(chunk.id),
            text=chunk.page_content,
            url=chunk.metadata["url"],
            allowed=frozenset(chunk.metadata["allowed"]),
            score=score,
        )
        for chunk, score in found
        if score >= _MIN_SCORE
    ]
    logger.info(
        "%d passage(s) found, %d above the threshold", len(found), len(passages)
    )
    return passages
