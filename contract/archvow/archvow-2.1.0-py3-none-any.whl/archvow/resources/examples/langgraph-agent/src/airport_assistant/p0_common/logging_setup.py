"""Configures logging once, at startup; modules only log.

@component  logging_setup (foundation, p0_common)
@spec       -
@project    airport_assistant
@author     A. Developer
@assisted   claude-code
@date       2026-11-08
"""

from __future__ import annotations

import logging

from langchain_core.runnables.config import var_child_runnable_config

_FORMAT = (
    "%(asctime)s %(levelname)s request=%(request_id)s thread=%(thread_id)s "
    "%(name)s %(message)s"
)


def _run_metadata() -> dict[str, object]:
    """The metadata of the graph run this line is logged in (the API gives the ids)."""
    config = var_child_runnable_config.get() or {}
    return dict(config.get("metadata") or {})


class _Ids(logging.Filter):
    """Every line gets the request and thread ids: its own, its run's, or '-'."""

    def filter(self, record: logging.LogRecord) -> bool:
        """Never drops a line."""
        metadata = _run_metadata()
        for name, key in (("request_id", "request_id"), ("thread_id", "thread")):
            if not hasattr(record, name):
                setattr(record, name, metadata.get(key, "-"))
        return True


def setup_logging(level: str = "INFO") -> None:
    """Logs to stderr, one line per event: time, level, ids and message."""
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter(_FORMAT))
    handler.addFilter(_Ids())
    logging.basicConfig(level=level.upper(), handlers=[handler], force=True)
