"""Routes the question, then answers from the policies or runs the booking agent.

@component  assistant_graph (graph, p4_app)
@spec       US-001
@project    airport_assistant
@author     A. Developer
@assisted   claude-code
@date       2026-11-08
"""

from __future__ import annotations

from langchain_core.messages import RemoveMessage
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import REMOVE_ALL_MESSAGES
from langgraph.graph.state import CompiledStateGraph

from airport_assistant.p0_common.memory import get_checkpointer
from airport_assistant.p1_domain.assistant_state import AssistantState
from airport_assistant.p3_agents.answer_node import answer_node
from airport_assistant.p3_agents.booking_agent import build_booking_agent
from airport_assistant.p3_agents.question_router import route_question

_RECURSION_LIMIT = 25
_STATE_VERSION = (
    1  # raised when AssistantState changes: older conversations start again
)


def _start(state: AssistantState) -> dict[str, object]:
    """A new turn: last turn's results cleared; an older conversation starts again."""
    turn: dict[str, object] = {"route": "", "passages": [], "answer": None}
    if state.get("version") != _STATE_VERSION:
        last = state["messages"][-1]
        turn["messages"] = [RemoveMessage(id=REMOVE_ALL_MESSAGES), last]
        turn["version"] = _STATE_VERSION
    return turn


def _chosen(state: AssistantState) -> str:
    return state["route"]


def build_assistant_graph() -> CompiledStateGraph:
    """The assistant, with the memory's checkpointer and a step limit."""
    graph = StateGraph(AssistantState)
    graph.add_node("start", _start)
    graph.add_node("route", route_question)
    graph.add_node("answer", answer_node)
    graph.add_node("booking", build_booking_agent())
    graph.add_edge(START, "start")
    graph.add_edge("start", "route")
    graph.add_conditional_edges(
        "route", _chosen, {"policies": "answer", "booking": "booking"}
    )
    graph.add_edge("answer", END)
    graph.add_edge("booking", END)
    compiled = graph.compile(checkpointer=get_checkpointer())
    return compiled.with_config(recursion_limit=_RECURSION_LIMIT)
