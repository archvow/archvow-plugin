"""The only place that knows the models: one per role, created here.

@component  models (foundation, p0_common)
@spec       -
@project    airport_assistant
@author     A. Developer
@assisted   claude-code
@date       2026-11-08
"""

from __future__ import annotations

import itertools
import json
import math
import re
import zlib
from collections.abc import Sequence

from langchain_core.embeddings import Embeddings
from langchain_core.language_models import BaseChatModel
from langchain_core.language_models.fake_chat_models import GenericFakeChatModel
from langchain_core.messages import AIMessage, BaseMessage
from langchain_core.runnables import Runnable, RunnableLambda
from pydantic import BaseModel

from airport_assistant.p0_common.settings import get_settings

# What each role answers while no provider is approved (settings: models = fake).
_CANNED: dict[str, dict[str, object]] = {
    "fast": {"route": "policies"},
    "reasoner": {
        "text": "No model is set up yet: this is a fake answer.",
        "citations": [],
    },
}
_EMBEDDING_SIZE = 256
_WORD = re.compile(r"[a-z0-9]{4,}")


class _FakeModel(GenericFakeChatModel):
    """A model that gives its messages in turn: the tests, and runs with no provider."""

    def bind_tools(self, tools: Sequence[object], **kwargs: object) -> _FakeModel:
        """Tools are written in its messages already."""
        del tools, kwargs
        return self

    def with_structured_output(
        self, schema: type[BaseModel], **kwargs: object
    ) -> Runnable[object, BaseModel]:
        """Reads each message as the JSON of the schema."""
        del kwargs

        def parse(message: BaseMessage) -> BaseModel:
            return schema.model_validate_json(str(message.content))

        return self | RunnableLambda(parse)


class _WordsEmbedding(Embeddings):
    """Counts the words of 4 letters or more: texts sharing words are near."""

    def embed_query(self, text: str) -> list[float]:
        """The text's vector, of length 1."""
        vector = [0.0] * _EMBEDDING_SIZE
        for word in _WORD.findall(text.lower()):
            vector[zlib.crc32(word.encode()) % _EMBEDDING_SIZE] += 1.0
        norm = math.sqrt(sum(value * value for value in vector)) or 1.0
        return [value / norm for value in vector]

    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        """One vector per text."""
        return [self.embed_query(text) for text in texts]


def fake(messages: Sequence[AIMessage | str]) -> BaseChatModel:
    """A fake chat model that answers these messages in turn (for the tests)."""
    return _FakeModel(messages=iter(list(messages)))


def chat(role: str) -> BaseChatModel:
    """The chat model of a role: fast or reasoner."""
    if role not in _CANNED:
        message = f"unknown model role {role!r}: the roles are {', '.join(_CANNED)}"
        raise ValueError(message)
    settings = get_settings()
    if settings.models != "fake":
        message = (
            f"models={settings.models}: no provider is approved yet - an architect "
            "approves one (-a dependencies=...), then it is created here, by role"
        )
        raise RuntimeError(message)
    answer = AIMessage(content=json.dumps(_CANNED[role]))
    return _FakeModel(messages=itertools.repeat(answer))


def embeddings() -> Embeddings:
    """The one embedding model: it indexes and it searches."""
    if get_settings().models != "fake":
        message = "no embedding model is approved yet"
        raise RuntimeError(message)
    return _WordsEmbedding()
