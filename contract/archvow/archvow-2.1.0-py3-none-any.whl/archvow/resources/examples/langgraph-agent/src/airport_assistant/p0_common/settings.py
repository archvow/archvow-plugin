"""The assistant's settings, read from the environment, never from code.

@component  settings (foundation, p0_common)
@spec       -
@project    airport_assistant
@author     A. Developer
@assisted   claude-code
@date       2026-11-08
"""

from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """The settings, from environment variables named ASSISTANT_<SETTING>."""

    model_config = SettingsConfigDict(env_prefix="ASSISTANT_")

    log_level: str = "INFO"
    models: str = "fake"
    index_path: str = "data/policies_index.json"
    policies_dir: str = "policies"
    flights_path: str = "data/flights.json"
    bookings_path: str = "data/bookings.jsonl"


def get_settings() -> Settings:
    """The settings of this process, read from the environment."""
    return Settings()
