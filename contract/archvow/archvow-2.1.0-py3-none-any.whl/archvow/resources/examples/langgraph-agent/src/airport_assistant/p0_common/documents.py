"""The shapes of the company's data: Document and Passage.

@component  documents (foundation, p0_common)
@spec       -
@project    airport_assistant
@author     A. Developer
@assisted   claude-code
@date       2026-11-08
"""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict


class Document(BaseModel):
    """One piece of content from any source: a file, an e-mail, a row, a page."""

    model_config = ConfigDict(frozen=True)

    source_id: str
    source_kind: str
    text: str
    url: str
    modified_at: datetime
    allowed: frozenset[str]


class Passage(BaseModel):
    """A piece of a Document that is indexed, found and cited."""

    model_config = ConfigDict(frozen=True)

    source_id: str
    chunk_id: str
    text: str
    url: str
    allowed: frozenset[str]
    score: float = 0.0
