"""Flights from one airport to another on one day, from the schedule.

@component  find_flights_tool (tool, p2_tools)
@spec       US-003
@project    airport_assistant
@author     A. Developer
@assisted   claude-code
@date       2026-11-08
"""

from __future__ import annotations

import json
from pathlib import Path

from langchain_core.tools import tool

from airport_assistant.p0_common.settings import get_settings


@tool
def find_flights(origin: str, destination: str, day: str) -> list[dict[str, str]]:
    """The flights from origin to destination (IATA codes) on day (YYYY-MM-DD)."""
    schedule = json.loads(Path(get_settings().flights_path).read_text(encoding="utf-8"))
    return [
        flight
        for flight in schedule
        if flight["origin"] == origin.upper()
        and flight["destination"] == destination.upper()
        and flight["day"] == day
    ]
