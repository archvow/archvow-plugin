"""An answer shown to the user: its text, the passages it cites, written by an AI.

@component  answer_schema (schema, p1_domain)
@spec       US-001
@project    airport_assistant
@author     A. Developer
@assisted   claude-code
@date       2026-11-08
"""

from __future__ import annotations

from pydantic import BaseModel, Field


class Answer(BaseModel):
    """What the reasoner answers: the text, the ids of the passages it relies on."""

    text: str
    citations: list[str] = Field(default_factory=list)
    ai_generated: bool = True
