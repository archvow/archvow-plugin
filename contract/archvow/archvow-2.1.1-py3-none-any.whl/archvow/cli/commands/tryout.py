"""`archvow try`: see archvow catch a mistake, in a minute, without a project of your own.

It copies a finished example (its spec, code and tests: every check green) into a scratch folder, makes there
the change an AI assistant often makes - a helper module nobody declared, and a shortcut import across layers -
and runs `check`. Nothing outside the scratch folder is written; no network, no AI.
"""

from __future__ import annotations

import argparse
import shutil
import tempfile
from dataclasses import asdict
from pathlib import Path

from archvow.cli.args import Builder
from archvow.cli.console import style as ui
from archvow.cli.output import as_json, checked
from archvow.foundation.errors import SpecError
from archvow.model import store
from archvow.templates import load_template, template_name

EXAMPLES = ("pyspark-pipeline", "fastapi-service", "python-app", "langgraph-agent")
SKIP = shutil.ignore_patterns("__pycache__", ".pytest_cache", ".ruff_cache", ".mypy_cache", ".hypothesis",
                              "actual", "doc", "test-results.xml", ".git")


def examples_folder() -> Path:
    """The finished examples: inside the installed package, else archvow's own repository (an editable install)."""
    here = Path(__file__).resolve()
    for folder in (here.parents[2] / "resources" / "examples", here.parents[4] / "examples"):
        if (folder / EXAMPLES[0] / ".archvow").is_dir():
            return folder
    raise SpecError("the finished examples are not installed with this archvow: reinstall it from its wheel")


def _module(path: Path) -> str:
    parts = path.with_suffix("").parts
    return ".".join(parts[1:] if parts[0] == "src" else parts)


def ai_like_change(root: Path) -> list[dict]:
    """The change: a helper module next to a domain component, which also imports a higher layer's module.

    Chosen from the spec, so it is the same on every run: the first component of the second layer, and the
    first component of the next layer up that has a file.
    """
    data = store.load(root)
    container = data["containers"][0]
    layers = load_template(template_name(container)[0], root).layer_names
    files: dict[int, list[Path]] = {}
    for comp in container.get("components", []):
        path = Path(store.source_path(container, comp))
        layer = comp.get("layer")
        if layer in layers and (root / path).is_file():
            files.setdefault(layers.index(layer), []).append(path)
    lower = (files.get(1) or [None])[0]
    upper = next((files[i][0] for i in sorted(files) if i > 1), None)
    if lower is None or upper is None:
        raise SpecError("this example has no domain component with a component of a higher layer to import")
    helper = lower.parent / "helpers.py"
    (root / helper).write_text('"""Helpers."""\n\n\ndef rounded(value: float) -> float:\n    """Two decimals."""\n'
                               "    return round(value, 2)\n", encoding="utf-8")
    shortcut = f"import {_module(upper)}  # a shortcut to the code of another layer\n"
    with (root / lower).open("a", encoding="utf-8") as file:
        file.write("\n" + shortcut)
    return [{"file": str(helper), "change": "new module", "lines": ["def rounded(value: float) -> float: ..."]},
            {"file": str(lower), "change": "one import added", "lines": [shortcut.strip()]}]


def cmd_try(args: argparse.Namespace) -> int:
    source = examples_folder() / args.example
    folder = Path(args.dir).resolve() if args.dir else Path(tempfile.mkdtemp(prefix="archvow-try-"))
    root = folder / args.example
    if root.exists():
        raise SpecError(f"{root} already exists: choose another --dir")
    shutil.copytree(source, root, ignore=SKIP)
    before = checked(args, root)
    changes = ai_like_change(root)
    after = checked(args, root)
    caught = [v for v in after.violations if v.severity == "error"]
    if args.json:
        print(as_json({"example": args.example, "folder": str(root),
                       "before": {"errors": len(before.errors), "warnings": len(before.violations) - len(before.errors)},
                       "changes": changes, "errors": len(caught), "violations": [asdict(v) for v in caught]}))
        return 0
    print(ui.ok(f"Copied the finished example {args.example}: {len(before.errors)} errors, its checks green")
          + ui.dim(f"  ({root})"))
    print(ui.ok("Made the change an AI assistant often makes:"))
    for c in changes:
        print(f"  {c['file']}: {c['change']}" + ui.dim(f"  {c['lines'][0]}"))
    if not caught:
        print(ui.warn("check found nothing: this example's layers allow the change"))
        return 0
    print(ui.error(f"check stops it: {len(caught)} error(s) - the commit and the CI would fail here"))
    for v in caught:
        where = f"{v.file}:{v.line}" if v.line else v.file
        print(f"  {ui.title(v.title or v.code)}" + ui.dim(f"  {v.code} · {where}"))
        print(f"    {v.message}")
        if v.guide:
            print(ui.dim(f"    what to do: {v.guide['fix']}"))
    print(ui.dim(f"\nNothing outside {folder} was written. Read the example's spec: archvow --root {root} doc"))
    print(ui.dim("Your own project: archvow init <package> -t <template>, then archvow next"))
    return 0


def declare_try(b: Builder) -> None:
    """`archvow try`: its parser."""
    p = b.command("try", cmd_try, "see archvow catch a mistake on a finished example, in a scratch folder", True,
                  examples="""
        archvow try                       # the PySpark pipeline
        archvow try fastapi-service       # the FastAPI service (python-app, langgraph-agent too)
        archvow try --dir /tmp/demo       # keep the copy where you choose
        """)
    p.add_argument("example", nargs="?", default=EXAMPLES[0], choices=EXAMPLES,
                   help=f"the finished example to copy ({EXAMPLES[0]} if none is named)")  # the IDEs show it raw
    p.add_argument("--dir", metavar="FOLDER", help="the folder to copy it into, as <folder>/<example> (default: a new temporary folder; the path is printed)")
