"""A save of the spec in one step. `store.save` writes up to dozens of files - project.vow, feature vows, component
vows - and removes stale ones. The system replaces one file at a time, never several: a save stopped half-way left a
spec nobody wrote (a component's new decision beside its old hazards). So a save has a commit point, as a database's:

1. every new text is written beside its file, as `.<name>.saving` (stopped here: the spec is untouched);
2. the journal `.archvow/save.journal` lists the renames, removals and emptied folders - written whole, it is the
   commit point: from then on the save counts as done;
3. the steps are done;
4. the journal is removed.

`finish`, under the write lock, completes a journal a stopped save left (never rolls it back) and removes the
`.saving` files of a save stopped before its journal. `save` runs it first. The journal is never committed (ARCH050
names one left).

A reader takes no lock, so it is told about saves as a sequence lock does (`read`): the generation in
`.archvow/save.local` turns odd when a save starts renaming and even when it is done. A read that starts on an odd
generation, or ends on another one than it started on, may hold some vows new and some old: it is done again (and
after a few tries, under the lock).
"""

from __future__ import annotations

import json
import os
import time
from collections.abc import Callable
from pathlib import Path, PurePosixPath
from typing import TypeVar

from archvow.foundation import logs
from archvow.foundation.errors import ManifestError
from archvow.foundation.files import spec_lock, write_text
from archvow.foundation.paths import ARCHVOW_DIR, COMPONENTS_DIR, FEATURES_REL

log = logs.get("journal")
T = TypeVar("T")

JOURNAL_REL = ARCHVOW_DIR / "save.journal"
GENERATION_REL = ARCHVOW_DIR / "save.local"  # local, gitignored (.archvow/*.local): odd while a save renames
TRIES = 5
STAGED = ".saving"  # .<name>.saving: a new text waiting for its rename


class Save:
    """The steps of one save, done in one go by `commit`."""

    def __init__(self, root: Path) -> None:
        self.root = root
        self.steps: list[list[str]] = []

    def _rel(self, path: Path) -> str:
        return path.relative_to(self.root).as_posix()

    def write(self, path: Path, text: str) -> None:
        """Stage a file's new text (nothing when it is unchanged)."""
        try:
            if path.read_text(encoding="utf-8") == text:
                return
        except OSError:
            logs.swallowed(log, "write: OSError")
        staged = path.with_name(f".{path.name}{STAGED}")
        write_text(staged, text)
        self.steps.append(["rename", self._rel(staged), self._rel(path)])

    def delete(self, path: Path) -> None:
        self.steps.append(["delete", self._rel(path)])

    def prune(self, folder: Path) -> None:
        """A feature folder whose vow goes: its empty components/ and then the folder itself, if empty."""
        self.steps.append(["prune", self._rel(folder)])

    def commit(self) -> None:
        if not self.steps:
            return
        journal = self.root / JOURNAL_REL
        _bump(self.root, odd=True)  # readers from now on read again
        write_text(journal, json.dumps({"steps": self.steps}, indent=1) + "\n")  # the commit point
        _apply(self.root, self.steps)
        journal.unlink()
        _bump(self.root, odd=False)


def generation(root: Path) -> int:
    """How many times a save started or ended renaming (odd: one is renaming now, or was stopped doing it)."""
    try:
        return int((root / GENERATION_REL).read_text(encoding="utf-8").split()[0])
    except (OSError, ValueError, IndexError):
        return 0


def _bump(root: Path, odd: bool) -> None:
    now = generation(root)
    write_text(root / GENERATION_REL, f"{now + 1 if (now % 2 == 1) != odd else now + 2}\n")


def read(root: Path, reader: Callable[[], T]) -> T:
    """What `reader` reads of the vows, as one save left them - never some new and some old: read again while a
    save renames, and under the lock (finishing a stopped save first) when it keeps changing."""
    for _ in range(TRIES):
        before = generation(root)
        if before % 2 == 0 and not (root / JOURNAL_REL).is_file():
            found = reader()
            if generation(root) == before:
                return found
        time.sleep(0.02)
    with spec_lock(root):
        finish(root)
        return reader()


def finish(root: Path) -> None:
    """Under the write lock: finish the save a journal describes; remove what a save stopped earlier staged."""
    journal = root / JOURNAL_REL
    if journal.is_file():
        try:
            steps = json.loads(journal.read_text(encoding="utf-8"))["steps"]
        except (ValueError, KeyError, TypeError):
            raise ManifestError(f"{JOURNAL_REL.as_posix()} cannot be read: archvow did not write it, or a stop cut it "
                                "- check the vows (git diff .archvow/), then delete it") from None
        for step in steps:
            _check(root, step)
        _apply(root, steps)
        journal.unlink()
        log.info("a save stopped after its commit point: finished (%d steps)", len(steps))
    if generation(root) % 2:
        _bump(root, odd=False)  # a save stopped while renaming: finished above, or never begun
    folder = root / ARCHVOW_DIR
    for staged in sorted(folder.rglob(f".*{STAGED}")) if folder.is_dir() else []:
        staged.unlink(missing_ok=True)  # a save stopped before its journal: the spec was never touched


def _check(root: Path, step: object) -> None:
    """A journal is archvow's: each step names a file of .archvow/, of the kind that step handles. A journal made by
    hand or carried by a clone must never move or remove anything else."""
    kind, *paths = step if isinstance(step, list) and step and all(isinstance(p, str) for p in step) else ["?"]
    shapes = {"rename": 2, "delete": 1, "prune": 1}
    good = kind in shapes and len(paths) == shapes[kind] and all(
        not PurePosixPath(p).is_absolute() and ".." not in PurePosixPath(p).parts
        and PurePosixPath(p).parts[:1] == (ARCHVOW_DIR.name,) and (root / p).resolve().is_relative_to(
            (root / ARCHVOW_DIR).resolve()) for p in paths)
    if good and kind == "rename":
        staged, target = (PurePosixPath(p) for p in paths)
        good = staged.parent == target.parent and staged.name == f".{target.name}{STAGED}" and target.suffix == ".vow"
    elif good and kind == "delete":
        good = PurePosixPath(paths[0]).suffix == ".vow"
    elif good:
        good = PurePosixPath(paths[0]).parent == PurePosixPath(FEATURES_REL.as_posix())
    if not good:
        raise ManifestError(f"{JOURNAL_REL.as_posix()}: the step {step!r} is not one archvow writes - delete the "
                            "journal after checking the vows (git diff .archvow/)")


def _apply(root: Path, steps: list[list[str]]) -> None:
    """Do the steps; each may already be done (a finish after a stop), so each is done only if still needed."""
    for kind, *paths in steps:
        if kind == "rename":
            staged, target = root / paths[0], root / paths[1]
            if staged.is_file():
                target.parent.mkdir(parents=True, exist_ok=True)
                os.replace(staged, target)
        elif kind == "delete":
            (root / paths[0]).unlink(missing_ok=True)
        else:
            folder = root / paths[0]
            components = folder / COMPONENTS_DIR
            if components.is_dir() and not any(components.iterdir()):
                components.rmdir()
            if folder.is_dir() and not any(folder.iterdir()):
                folder.rmdir()
