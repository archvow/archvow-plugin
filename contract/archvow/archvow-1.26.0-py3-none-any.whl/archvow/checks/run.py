"""The check run (`archvow check`): the engine checks the code against the spec, then each family in turn, in a
fixed order; frozen findings are set aside and, with --base, the guards are compared with the base branch.

The engine (checks/engine.py) never imports a family: the families import the engine. This module is the one place
that knows them all.
"""

from __future__ import annotations

from pathlib import Path

from archvow import agentcheck
from archvow.agent import run_agents
from archvow.baseline import compare
from archvow.briefs import run_briefs
from archvow.checks.engine import Checker, Report
from archvow.checks.packs import run_packs
from archvow.compliance import run_compliance
from archvow.evidence import run_evidence
from archvow.examples import run_examples
from archvow.freeze import apply
from archvow.limits import run_limits
from archvow.proposals import run_proposals
from archvow.safety import run_safety
from archvow.toreview import run_review

# after the code and the project files, in this order (each one's time goes to the log)
FAMILIES = (("packs", run_packs), ("safety", run_safety), ("evidence", run_evidence), ("examples", run_examples),
            ("compliance", run_compliance), ("briefs", run_briefs), ("proposals", run_proposals),
            ("limits", run_limits), ("review", run_review))


def run_all(checker: Checker) -> Report:
    """Every check on one checker: the code (with the families that read each file), then the families."""
    checker.file_checks.append(agentcheck.check_file)
    if not checker.check_code():
        return checker.report  # without its template nothing else can be judged: one clear error (ARCH009)
    for name, step in FAMILIES:
        checker.timed(name, step, checker)
    checker.timed("tasks", checker.check_task_size)
    checker.timed("archvow folder", checker.check_archvow_folder)
    checker.timed("agents", run_agents, checker)
    return checker.finish()


def run_check(root: Path, only_file: Path | None = None, content: str | None = None,
              base: str | None = None, accept_weakening: bool = False,
              complete: bool = False, raw: bool = False, test_report: Path | None = None) -> Report:
    """Run every check for the project at `root`.

    `content` replaces the on-disk text of `only_file` (unsaved editor buffer).
    `base` compares guards with that git reference (see archvow.baseline).
    `raw` ignores .archvow/frozen.json (used by `archvow freeze`).
    """
    overrides = {only_file: content} if only_file is not None and content is not None else None
    checker = Checker(root, overrides, complete, test_report)
    report = run_all(checker)
    if not raw:
        apply(root, report)
    if base:
        compare(checker, base, accept_weakening)
        report.violations.sort(key=lambda v: (v.file, v.line, v.code))
    if only_file is not None:
        rel = only_file.resolve().relative_to(root.resolve()).as_posix()
        report.violations = [v for v in report.violations if v.file == rel]
    return report
