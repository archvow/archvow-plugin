"""The .vow format: how archvow writes a vow on disk, and reads it back.

A vow is written by archvow commands only, in one canonical layout, so a reviewer, a developer or an
AI reads every vow the same way. One fact per line, every value with its keyword:

    vow 1 component clean_orders
    # comment lines (archvow writes them; they are not part of the vow)
    type transformation                        keyword value
    uses [orders_schema, compute_vat]          a list of values
    columns                                    a group: its lines are indented by two spaces
      order_id none
    decision 1                                 an item of a list (decisions, hazards...): its keyword
      question "Which rows are kept?"            and its number or id, then its lines
      answer "Rows with an order_id"

Keywords: letters, digits and _ . / - (a folder path is a keyword: `src/acme/p2_io [acme_io]`);
any other key is written in double quotes.
Values: a word (letters, digits and _ @ . / : + -), "text in double quotes" (JSON escapes),
an integer or decimal number, true, false, null, [] (empty list), {} (empty group), or [a, "b c", 1].
A value the format has no shape for is written `key = <JSON>` (archvow itself never needs it).

The first line says what the file is: `vow 1 project`, `vow 1 component <id>` or `vow 1 proposals`
(1 is the version of the format). Indentation is two spaces, never tabs; a line ends after its value.

`dumps` and `loads` are exact inverses: `loads(dumps(kind, data)) == (kind, data)` for any value
built from dicts, lists, strings, numbers, booleans and None.
"""

from __future__ import annotations

import json
import math
import re

from archvow.foundation.errors import VowError

FORMAT_VERSION = 1
KINDS = ("project", "component", "proposals")
EXTENSION = ".vow"

# List keys of a file's top level whose items are written as blocks: list key -> (item keyword,
# the item's field shown after the keyword, or POSITION: its number in the list, starting at 1).
POSITION = "#"
_SAFETY = {"hazards": ("hazard", "id"), "invariants": ("invariant", "id"),
           "dismissed": ("not_applicable", "guide_word")}
ITEM_LISTS = {
    "component": {"symbols": ("symbol", "name"), "decisions": ("decision", POSITION),
                  "assumptions": ("assumption", POSITION), "examples": ("example", "name"), **_SAFETY},
    "project": {"containers": ("container", "id"), "project_rules": ("rule", "id"),
                "type_answers": ("type_answer", "type"),
                "third_parties": ("third_party", "name"), **_SAFETY},
    "proposals": {"proposals": ("proposal", None)},
}
SECTIONS = {"dismissed": "not applicable", "project_rules": "rules",
            "type_answers": "answered once for every component of a type"}  # the comment above a list's items
# Words that read better than the stored field names: (where) -> {stored name: keyword}.
RENAMES = {
    "component": {"spec": "ticket"},
    "hazard": {"description": "never"},
    "invariant": {"statement": "always", "mitigates": "prevents", "verify": "verified_by"},
    "not_applicable": {"rationale": "because"},
}

# Values of these keys are text a person wrote: always in quotes, even when one word.
TEXT_KEYS = {"description", "question", "answer", "text", "rationale", "statement", "signature", "never",
             "always", "because"}
KEY_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_./\-]*")
WORD_RE = re.compile(r"[A-Za-z0-9_@][A-Za-z0-9_@./:+\-]*")
NUMBER_RE = re.compile(r"-?(?:0|[1-9][0-9]*)(?P<frac>\.[0-9]+)?(?P<exp>[eE][+-]?[0-9]+)?")
LITERALS = {"null": None, "true": True, "false": False}


# ------------------------------------------------------------------ write


def dumps(kind: str, data: dict, *, name: str | None = None, comment: str = "") -> str:
    """`data` as the text of a .vow file of this kind. `name` goes on the first line (a component's
    id); `comment` (lines starting with #) goes right under it."""
    if kind not in KINDS:
        raise ValueError(f"unknown kind of vow {kind!r}")
    lines = [" ".join(["vow", str(FORMAT_VERSION), kind, *([name] if name else [])])]
    lines += [line for line in comment.splitlines() if line.strip()]
    renames = RENAMES.get(kind, {})
    items = ITEM_LISTS[kind]
    sections_seen = False
    for key, value in data.items():
        if key in items and isinstance(value, list) and value and all(isinstance(v, dict) for v in value):
            keyword, field = items[key]
            lines.append("")
            lines.append(f"# --- {SECTIONS.get(key, key.replace('_', ' '))}")
            for number, item in enumerate(value, 1):
                if number > 1:
                    lines.append("")
                lines += _item(keyword, field, number, item, 0)
            sections_seen = True
            continue
        if sections_seen:  # a plain line after a list of items: keep it apart from the last item
            lines.append("")
            sections_seen = False
        reserved = {i[0] for i in items.values()} | set(renames.values())
        lines += _entry(renames.get(key, key), value, 0, reserved=reserved, renamed=key in renames)
    return "\n".join(lines) + "\n"


def _item(keyword: str, field: str | None, number: int, item: dict, indent: int) -> list[str]:
    head = keyword
    rest = dict(item)
    if field == POSITION:
        head += f" {number}"
    elif field and isinstance(rest.get(field), str) and _bare(rest[field]):
        head += f" {rest.pop(field)}"
    lines = [" " * indent + head]
    renames = RENAMES.get(keyword, {})
    for key, value in rest.items():
        lines += _entry(renames.get(key, key), value, indent + 2, reserved=set(renames.values()),
                        renamed=key in renames)
    return lines


def _entry(key: str, value: object, indent: int, *, reserved: set[str], renamed: bool) -> list[str]:
    pad = " " * indent
    # a stored key spelled like a keyword of this level is written in quotes: it reads back as itself
    shown = key if (renamed or (KEY_RE.fullmatch(key) and key not in reserved)) else json.dumps(key)
    if isinstance(value, dict):
        if not value:
            return [f"{pad}{shown} {{}}"]
        lines = [f"{pad}{shown}"]
        for k, v in value.items():
            lines += _entry(str(k), v, indent + 2, reserved=set(), renamed=False)
        return lines
    if isinstance(value, list):
        if not value:
            return [f"{pad}{shown} []"]
        if all(_is_scalar(v) for v in value):
            return [f"{pad}{shown} [" + ", ".join(_scalar(v) for v in value) + "]"]
        return [f"{pad}{shown} = " + json.dumps(value, ensure_ascii=False)]
    if not _is_scalar(value) or (isinstance(value, float) and not math.isfinite(value)):
        return [f"{pad}{shown} = " + json.dumps(value, ensure_ascii=False, default=str)]
    if isinstance(value, str) and key in TEXT_KEYS:
        return [f"{pad}{shown} {json.dumps(value, ensure_ascii=False)}"]
    return [f"{pad}{shown} {_scalar(value)}"]


def _is_scalar(value: object) -> bool:
    return value is None or isinstance(value, (str, bool, int, float))


def _bare(text: str) -> bool:
    """A string written without quotes reads back as the same string."""
    return bool(WORD_RE.fullmatch(text)) and text not in LITERALS and not NUMBER_RE.fullmatch(text)


def _scalar(value: object) -> str:
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        text = repr(value)
        return text if NUMBER_RE.fullmatch(text) else json.dumps(value)
    text = str(value)
    return text if _bare(text) else json.dumps(text, ensure_ascii=False)


# ------------------------------------------------------------------ read


def loads(text: str, label: str = "<vow>") -> tuple[str, str | None, dict]:
    """The text of a .vow file -> (kind, the name on its first line or None, data)."""
    lines = text.replace("\r\n", "\n").split("\n")
    first = next((i for i, line in enumerate(lines) if line.strip() and not line.lstrip().startswith("#")), None)
    if first is None:
        raise VowError(f"{label}: empty - a vow starts with `vow {FORMAT_VERSION} project|component|proposals`")
    words = lines[first].split()
    if len(words) < 3 or words[0] != "vow" or words[2] not in KINDS or len(words) > 4:
        raise VowError(f"{label}:{first + 1}: not a vow - the first line is `vow {FORMAT_VERSION} "
                       "project`, `vow 1 component <id>` or `vow 1 proposals`")
    if words[1] != str(FORMAT_VERSION):
        raise VowError(f"{label}:{first + 1}: format version {words[1]} - this archvow reads version "
                       f"{FORMAT_VERSION} (a newer archvow wrote it: upgrade archvow)")
    kind, name = words[2], (words[3] if len(words) == 4 else None)
    parsed = []
    for number, raw in enumerate(lines[first + 1:], first + 2):
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        if "\t" in raw[: len(raw) - len(raw.lstrip())]:
            raise VowError(f"{label}:{number}: a tab in the indentation - two spaces per level")
        indent = len(raw) - len(raw.lstrip(" "))
        if indent % 2:
            raise VowError(f"{label}:{number}: indented by {indent} spaces - two spaces per level")
        parsed.append(_Line(number, indent, raw.strip(), label))
    reader = _Reader(parsed, label)
    data = reader.block(0, kind)
    return kind, name, data


class _Line:
    def __init__(self, number: int, indent: int, text: str, label: str) -> None:
        self.number, self.indent, self.label = number, indent, label
        if text.startswith('"'):
            end = _string_end(text, 0)
            if end is None:
                raise self.error("a key in quotes with no closing quote")
            self.key, self.quoted = json.loads(text[: end + 1]), True
            rest = text[end + 1:]
        else:
            match = KEY_RE.match(text)
            if not match:
                raise self.error(f"`{text.split()[0]}` is not a keyword")
            self.key, self.quoted = match.group(0), False
            rest = text[match.end():]
        if rest and not rest.startswith(" "):
            raise self.error(f"a space is needed after `{self.key}`")
        self.value = rest.strip() or None

    def error(self, message: str) -> VowError:
        return VowError(f"{self.label}:{self.number}: {message}")


class _Reader:
    def __init__(self, lines: list[_Line], label: str) -> None:
        self.lines, self.pos, self.label = lines, 0, label

    def block(self, indent: int, where: str) -> dict:
        """The lines at `indent` (and their children) as one dict. `where`: the file's kind at the top
        level, an item keyword inside an item, or "" in a plain group."""
        result: dict = {}
        items = ITEM_LISTS.get(where, {})
        keywords = {keyword: (key, field) for key, (keyword, field) in items.items()}
        renames = {word: stored for stored, word in RENAMES.get(where, {}).items()}
        while self.pos < len(self.lines):
            line = self.lines[self.pos]
            if line.indent < indent:
                break
            if line.indent > indent:
                raise line.error("indented more than the line above allows")
            self.pos += 1
            if not line.quoted and line.key in keywords:
                key, field = keywords[line.key]
                current = result.setdefault(key, [])
                if not isinstance(current, list) or (current and not isinstance(current[-1], dict)):
                    raise line.error(f"`{line.key}` items and a `{key}` line in the same vow")
                item = self.block(indent + 2, line.key) if self._children(indent) else {}
                if field == POSITION:
                    if line.value != str(len(current) + 1):
                        raise line.error(f"`{line.key} {line.value}`: expected `{line.key} {len(current) + 1}` "
                                         "(numbered in order from 1)")
                elif line.value is not None:
                    if field is None or field in item:
                        raise line.error(f"`{line.key}` takes no value on its own line here")
                    item = {field: self._scalar(line, line.value), **item}
                current.append(item)
                continue
            key = renames.get(line.key, line.key) if not line.quoted else line.key
            if key in result:
                raise line.error(f"`{line.key}` appears twice")
            if line.value is None:
                if not self._children(indent):
                    raise line.error(f"`{line.key}` needs a value (or lines under it, indented by two spaces)")
                result[key] = self.block(indent + 2, "")
            else:
                result[key] = self._value(line)
                if self._children(indent):
                    raise self.lines[self.pos].error(f"`{line.key}` has a value: nothing may be indented under it")
        return result

    def _children(self, indent: int) -> bool:
        return self.pos < len(self.lines) and self.lines[self.pos].indent > indent

    def _value(self, line: _Line) -> object:
        text = line.value or ""
        if text.startswith("= "):
            try:
                return json.loads(text[2:])
            except json.JSONDecodeError as exc:
                raise line.error(f"`{line.key} = ...` is not valid JSON ({exc.msg})") from None
        if text == "[]":
            return []
        if text == "{}":
            return {}
        if text.startswith("["):
            if not text.endswith("]"):
                raise line.error("a list starts with [ and ends with ]")
            return [self._scalar(line, part) for part in _split_list(text[1:-1], line)]
        return self._scalar(line, text)

    def _scalar(self, line: _Line, text: str) -> object:
        if text.startswith('"'):
            end = _string_end(text, 0)
            if end is None or end != len(text) - 1:
                raise line.error("text in quotes must be the whole value (one closing quote, at the end)")
            return json.loads(text)
        if text in LITERALS:
            return LITERALS[text]
        number = NUMBER_RE.fullmatch(text)
        if number:
            return float(text) if number.group("frac") or number.group("exp") else int(text)
        if WORD_RE.fullmatch(text):
            return text
        raise line.error(f"`{text}`: put text with spaces or signs in double quotes")


def _string_end(text: str, start: int) -> int | None:
    """Index of the quote closing the string that opens at `start`."""
    i = start + 1
    while i < len(text):
        if text[i] == "\\":
            i += 2
            continue
        if text[i] == '"':
            return i
        i += 1
    return None


def _split_list(text: str, line: _Line) -> list[str]:
    parts, i, n = [], 0, len(text)
    while i < n:
        while i < n and text[i] == " ":
            i += 1
        if i >= n:
            break
        if text[i] == '"':
            end = _string_end(text, i)
            if end is None:
                raise line.error("text in quotes with no closing quote")
            parts.append(text[i:end + 1])
            i = end + 1
        else:
            j = i
            while j < n and text[j] not in ", ":
                j += 1
            parts.append(text[i:j])
            i = j
        while i < n and text[i] == " ":
            i += 1
        if i < n:
            if text[i] != ",":
                raise line.error("list values are separated by commas")
            i += 1
            if not text[i:].strip():
                raise line.error("a comma with no value after it")
    return parts
