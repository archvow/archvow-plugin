"""The shapes of the spec in memory, as `store.load` gives them and `store.save` takes them: the vow's keywords
(docs/vow-format.md) after loading. Types for people and mypy only - a vow stays plain dicts and lists at run
time, so nothing here changes what archvow reads or writes. Every key is optional unless the comment says it
is always there (total=False): a vow written by an older archvow, or by hand, may lack any of them.
"""

from __future__ import annotations

from typing import TypedDict


class Stamp(TypedDict, total=False):
    """Who recorded an item and when (`by`: the Git e-mail or the user name, `on`: an ISO 8601 time in UTC)."""

    by: str
    on: str


class Origin(Stamp, total=False):
    """An item an AI agent added: which agent and why, then `accepted` once a person keeps it."""

    added_by: str
    why: str
    accepted: Stamp


class Source(TypedDict, total=False):
    """The brief an item was drawn from (`--from`): the file, its section and the section's digest then."""

    file: str
    section: str
    hash: str


class Decision(Origin, total=False):
    question: str  # the question (a template question not answered yet keeps only its key)
    answer: str
    origin: str  # "ai": accepted from an AI proposal
    source: Source
    review: str  # why a person must look at it again (the component changed after it was recorded)


class Symbol(TypedDict, total=False):
    name: str  # always there
    kind: str  # function, class, constant, route
    signature: str
    annotation: str
    method: str
    path: str


class Example(Stamp, total=False):
    name: str  # always there
    ticket: str
    rule: str
    source: Source
    fingerprint: str


class Assumption(Stamp, total=False):
    text: str
    status: str  # proposed, accepted, rejected
    reviewed_by: str
    reviewed_on: str


class Component(Origin, total=False):
    id: str  # always there: <name>_<type suffix>, e.g. orders_reader
    name: str
    type: str
    kind: str
    layer: str
    group: str
    module: str
    adopted: bool
    container: str
    spec: str  # the ticket (-s)
    description: str
    uses: list[str]
    owners: list[str]
    source: Source
    symbols: list[Symbol]
    decisions: list[Decision]
    examples: list[Example]
    assumptions: list[Assumption]
    answers: dict[str, dict[str, str]]  # the P and O questions' answers, by the template's question id
    columns: dict[str, str]  # column -> none, personal, special
    privacy: dict[str, list[str]]  # removes, pseudonymises


class Container(TypedDict, total=False):
    id: str  # always there
    template: str  # name@version
    package: str
    path: str
    components: list[Component]


class Hazard(Origin, total=False):
    id: str  # always there: <component>.H<n>, or system.H<n>
    component: str
    guide_word: str
    severity: str  # critical, high, medium, low
    description: str  # what must never happen
    review: str


class Invariant(Origin, total=False):
    id: str  # always there: <component>.INV<n>
    component: str
    statement: str
    from_decision: int  # instead of a statement: it says what that decision answers
    mitigates: list[str]  # hazard ids
    verify: str  # example_test, property_test, runtime_assertion, static_rule, model_check


class RuleScope(TypedDict, total=False):
    """Who a rule applies to: every component, every one of a type, or the ones named."""

    all: bool
    type: str
    components: list[str]


class Rule(Origin, total=False):
    id: str  # always there: R<n>
    text: str
    scope: RuleScope
    source: Source


class Spec(TypedDict, total=False):
    """The project: `.archvow/spec.vow` and every component's vow, assembled."""

    schema_version: int
    system: dict[str, str]  # name, description
    language: str
    mode: str  # strict, guided, free
    families: list[str]
    compliance: list[str]
    ai_tools: list[str]
    reviewers: list[str]
    dependencies: list[str]
    rules: dict[str, dict[str, object]]  # check settings by code
    init_answers: dict[str, str]
    containers: list[Container]  # always there
    hazards: list[Hazard]
    invariants: list[Invariant]
    dismissed: list[dict[str, object]]  # safety questions answered "not applicable"
    project_rules: list[Rule]
    third_parties: list[dict[str, str]]
    type_answers: list[dict[str, str]]
