"""What archvow writes for people and agents (layer 3): the cards (cards.py, an AI's task), the project spec
(project_spec.py), the build plan (plan.py), the run line, a finding's guide (guidance.py), the search, a file's
place (locate.py), the release report (changes.py), the spec diff, the audit, the doctor. Imports layers 0-2.
"""
