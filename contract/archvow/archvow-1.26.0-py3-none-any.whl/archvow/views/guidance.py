"""What to do about a check finding, in plain words, for the person who reads it.

Every violation `archvow check` finds gets a guide (`check --json`: the field `guide`; `check` prints its
"what to do" line once per rule): what it means and what to do (the rule's row in rules.md, packaged in
`archvow/rulebook/`), who does it (an architect, a person - never an AI agent -, whoever writes the code),
whether it blocks the commit, what happens next, the archvow command the message names - its words for a
form, the parts left to a person (<component>, "...", a choice a|b) - and the file to open.

The texts follow the project's language (rules.fr.md in French); the messages themselves stay English.
The IDE plugins show the same guide (their guidance.ts and ArchvowGuidance follow these rules).
"""

from __future__ import annotations

import argparse
import re
from dataclasses import dataclass, field
from functools import lru_cache
from importlib import resources

from archvow.agent import person_only
from archvow.foundation import logs
from archvow.foundation.i18n import tr

log = logs.get("guidance")

READ_ONLY = {"show", "catalog", "next", "check", "audit", "doctor", "changes", "diff", "prompt"}
ARCHITECT_CODES = {"ARCH012", "ARCH020", "ARCH023", "ARCH024", "ARCH040", "ARCH041"}
PERSON_CODES = {"ARCH009", "ARCH014", "ARCH033", "ARCH034", "ARCH035", "ARCH036", "ARCH039", "ARCH043", "ARCH051",
                "ARCH052", "ARCH054", "ARCH057"}  # decisions, assumptions, safety and the spec are a person's
VOW_CODES = {"ARCH009", "ARCH014", "ARCH036", "ARCH050"}  # about what a vow says: its file is worth opening
STOP_WORDS = {"or", "and", "then", "to", "after", "before", "if", "when", "with",
              "ou", "et", "puis", "pour", "après", "avant", "si", "quand", "avec"}
STOP_TOKENS = {"->", "→", "|", ";", "—", "-", "–"}
PLACEHOLDER = re.compile(r"<[^>]*>|\{[^}]*\}|^(\.\.\.|…)$")
ARCHVOW = re.compile(r"(`?)\barchvow\s+")


# ------------------------------------------------------------------ the rules table


@lru_cache(maxsize=2)
def rulebook(language: str) -> str:
    """archvow's rules page (docs/rules.md, rules.fr.md in French), packaged with archvow."""
    name = "rules.fr.md" if language == "fr" else "rules.md"
    try:
        return resources.files("archvow").joinpath("rulebook", name).read_text(encoding="utf-8")
    except (FileNotFoundError, OSError):
        logs.swallowed(log, "rulebook: FileNotFoundError, OSError")
        return ""


def _clean(cell: str) -> str:
    cell = re.sub(r"\[([^\]]+)\]\([^)]*\)", r"\1", cell)
    for pattern in (r"^\s*\((?:a )?warning[^)]*\)\s*", r"^\s*\((?:un )?avertissement[^)]*\)\s*",
                    r"^\s*\(always on\)\s*", r"^\s*\(toujours actif\)\s*"):
        cell = re.sub(pattern, "", cell, flags=re.IGNORECASE)
    return cell.strip()


def rule_row(markdown: str, code: str) -> tuple[str, str]:
    """The cells of a code's row (Code | Fails when | Fix), ("", "") when absent."""
    row = re.compile(r"^\s*\|\s*" + re.escape(code) + r"\s*\|(.*)\|\s*$")
    for line in (markdown or "").split("\n"):
        m = row.match(line)
        if m:
            cells = [_clean(c.replace("\\|", "|")) for c in re.split(r"(?<!\\)\|", m.group(1))]
            return cells[0] if cells else "", " ".join(cells[1:]).strip()
    return "", ""


# ------------------------------------------------------------------ the commands a message names


@dataclass
class Command:
    """A command a message names, as its form: the words given, the parts left to a person."""

    name: str
    values: dict = field(default_factory=dict)
    text: str = ""
    missing: list = field(default_factory=list)
    read_only: bool = False

    def as_dict(self) -> dict:
        return {"name": self.name, "values": self.values, "text": self.text, "missing": self.missing,
                "readOnly": self.read_only}


@dataclass
class _Param:
    name: str
    flags: list
    required: bool
    boolean: bool
    append: bool
    multi: bool
    choices: list


def grammar_of(parser: argparse.ArgumentParser) -> dict[tuple[str, ...], list[_Param]]:
    """Every archvow command and its parameters, read from archvow's own parser (the console hands it:
    `archvow.cli.parser.grammar()`; this module never imports the console)."""
    found: dict[tuple[str, ...], list[_Param]] = {}

    def walk(parser: argparse.ArgumentParser, path: tuple[str, ...]) -> None:
        for action in parser._actions:
            if isinstance(action, argparse._SubParsersAction):
                for name, nested in action.choices.items():
                    walk(nested, (*path, name))
                return
        if path:
            found[path] = [
                _Param(a.dest, list(a.option_strings), bool(a.required),
                       isinstance(a, (argparse._StoreTrueAction, argparse._StoreFalseAction)),
                       isinstance(a, argparse._AppendAction), a.nargs in ("+", "*"),
                       [str(c) for c in a.choices] if a.choices else [])
                for a in parser._actions
                if not isinstance(a, (argparse._HelpAction, argparse._SubParsersAction))
                and a.dest not in {"func", "help", "json"}]

    walk(parser, ())
    return found


def command_tokens(text: str, whole: bool = False) -> list[tuple[str, bool]]:
    """The words of a command written in a sentence, up to where the sentence goes on: (word, quoted)."""
    tokens: list[tuple[str, bool]] = []
    i = 0
    while i < len(text):
        while i < len(text) and text[i].isspace():
            i += 1
        if i >= len(text):
            break
        if text[i] == '"':
            j, value = i + 1, []
            while j < len(text) and text[j] != '"':
                if text[j] == "\\" and j + 1 < len(text):
                    j += 1
                value.append(text[j])
                j += 1
            tokens.append(("".join(value), True))
            i = j + 1
            if not whole and i < len(text) and text[i] in ",;:)":
                break
            if not whole and i < len(text) and text[i] == "." and (i + 1 >= len(text) or text[i + 1].isspace()):
                break
            continue
        j = i
        while j < len(text) and not text[j].isspace():
            j += 1
        raw, i = text[i:j], j
        if whole:
            tokens.append((raw, False))
            continue
        if raw.startswith("(") or raw in STOP_TOKENS or raw.lower() in STOP_WORDS:
            break
        end = False
        if raw and raw[-1] in ",;:)" or raw.endswith(".") and not raw.endswith("...") and len(raw) > 1:
            raw, end = raw[:-1], True
        if raw:
            tokens.append((raw, False))
        if end:
            break
    return tokens


def commands_in(message: str, commands: dict[tuple[str, ...], list[_Param]]) -> list[Command]:
    """The archvow commands a message names, in order, as forms (`commands`: `grammar_of` archvow's parser)."""
    found = []
    text = message or ""
    for m in ARCHVOW.finditer(text):
        after = text[m.end():]
        close = after.find("`") if m.group(1) == "`" else -1
        tokens = command_tokens(after[:close], True) if m.group(1) == "`" and close >= 0 else command_tokens(after)
        words = [t for t, _ in tokens]
        path = tuple(words[:2]) if tuple(words[:2]) in commands else tuple(words[:1])
        if path not in commands or any(quoted for _, quoted in tokens[:len(path)]):
            continue
        found.append(_form(path, commands[path], tokens[len(path):]))
    return found


def _form(path: tuple[str, ...], params: list[_Param], args: list[tuple[str, bool]]) -> Command:
    values: dict[str, str] = {}
    missing: list[str] = []
    positional = [p for p in params if not p.flags]

    def put(param: _Param, word: str, quoted: bool) -> None:
        choice = (not quoted and "|" in word) or (param.choices and word not in param.choices)
        if PLACEHOLDER.search(word) or choice:
            if param.name not in missing:
                missing.append(param.name)
            return
        listed = param.append or param.multi
        values[param.name] = values[param.name] + "\n" + word if listed and param.name in values else word

    k, nxt = 0, 0
    while k < len(args):
        word, quoted = args[k]
        flag = next((p for p in params if word.split("=")[0] in p.flags), None) \
            if not quoted and word.startswith("-") else None
        if flag:
            if flag.boolean:
                values[flag.name] = "true"
            elif "=" in word:
                put(flag, word.split("=", 1)[1], False)
            elif k + 1 < len(args):
                k += 1
                put(flag, *args[k])
        elif not (not quoted and word.startswith("-")) and nxt < len(positional):
            put(positional[nxt], word, quoted)
            if not positional[nxt].multi:
                nxt += 1
        k += 1
    for p in params:
        if p.required and p.name not in values and p.name not in missing:
            missing.append(p.name)
    shown = ["archvow", *path, *(f'"{w}"' if q or re.search(r"\s", w) else w for w, q in args)]
    return Command(" ".join(path), values, " ".join(shown), missing, path[0] in READ_ONLY)


def main_command(found: list[Command]) -> Command | None:
    """The command to offer first: one that changes something (the fix), else the first."""
    return next((c for c in found if not c.read_only), found[0] if found else None)


# ------------------------------------------------------------------ who does it


def _person_only(name: str) -> bool:
    return name in ("assumption accept", "assumption reject") or person_only(name) is not None


def _who(code: str, command: Command | None) -> str:
    if code in ARCHITECT_CODES:
        return "architect"
    if command:
        if command.name == "init":
            return "architect"
        if command.read_only:  # a command to look first: who acts depends on the rule
            return "person" if code in PERSON_CODES else "developer"
        return "person" if _person_only(command.name) else "you"
    return "person" if code in PERSON_CODES else "developer"


def _who_text(who: str, lang: str) -> str:
    return tr(lang, {
        "architect": "An architect: it changes the guards of the whole project.",
        "person": "A person, here or in their own terminal - not an AI agent: it decides or changes the spec.",
        "you": "You (or the AI, with your review).",
    }.get(who, "Whoever writes the code: you, or the AI with your review."))


# ------------------------------------------------------------------ the guide


def file_of(code: str, file: str, line: int) -> dict | None:
    """The file to open: "a.py (and 3 more)" is a.py; a vow only for the codes about a vow's content."""
    path = re.sub(r"\s+\(and \d+ more\)\s*$", "", file or "").strip()
    if not path or (path.startswith(".archvow/") and path.endswith(".vow") and code not in VOW_CODES):
        return None
    return {"path": path, "line": max(0, line or 0)}


def guide(code: str, severity: str, message: str, file: str = "", line: int = 0, language: str = "en", *,
          commands: dict[tuple[str, ...], list[_Param]]) -> dict:
    """What to do about one finding: meaning, fix, who, blocking, then, command, file."""
    lang = "fr" if language == "fr" else "en"
    code = (code or "").upper()
    when, fix = rule_row(rulebook(lang), code)
    command = _personal(code, main_command(commands_in(message, commands)))
    where = file_of(code, file, line)
    found = {
        "meaning": when or tr(lang, "archvow found this while checking the project (see the message above)."),
        "fix": fix or tr(lang, "Run the command the message gives." if command
                         else "Open the file and fix what the message says." if where
                         else "Do what the message says."),
        "who": _who_text(_who(code, command), lang),
        "blocking": tr(lang, "Does not block: a warning - the commit and CI pass. Some warnings become errors in mode "
                             "strict or with check --complete." if severity == "warning"
                       else "Blocks: archvow check fails until it is fixed - the Git hook refuses the commit and CI "
                            "fails."),
        "then": tr(lang, "Then run archvow check again: the finding disappears once it is fixed."),
    }
    found.update(_specific(code, message, lang, command))
    return {"language": lang, **found, "command": command.as_dict() if command else None, "file": where}


def _personal(code: str, command: Command | None) -> Command | None:
    """A person treats it: the decision the AI would propose (ARCH033), the person makes."""
    if code != "ARCH033" or command is None or command.name != "decision propose":
        return command
    return Command("decision make", command.values, command.text.replace("archvow decision propose",
                                                                         "archvow decision make"),
                   command.missing, command.read_only)


def _specific(code: str, message: str, lang: str, command: Command | None) -> dict:
    """Where the rules table is not enough: the codes that confused people, by message variant."""
    def t(english: str, **values: object) -> str:
        return tr(lang, english, **values)

    if code == "ARCH012":
        m = re.search(r"says ([\w.-]+)@([\d.]+), installed is [\w.-]+@([\d.]+)", message)
        template, old, now = m.groups() if m else ("the template", "an older version", "a newer one")
        prepared = f" ({command.text})" if command else ""
        return {
            "meaning": t("The project was set up with {template} {old}; the archvow installed here brings {now}. "
                         "archvow's own files in the project (CI job, Git hooks, AGENTS.md, ruff and test settings) are "
                         "still those of {old}.", template=template, old=old, now=now),
            "fix": t("Upgrade the project to {now}: run the prepared command{prepared}. It rewrites archvow's files "
                     "with the new template and keeps your spec and your answers. Then review git diff - keep your own "
                     "lines if you had edited a generated file such as the README - and commit.",
                     now=now, prepared=prepared),
            "then": t("Then commit: the warning disappears."),
        }
    if code == "ARCH053":
        m = re.search(r"written by ([\w.-]+)", message) or re.search(r"écrit par ([\w.-]+)", message)
        tool = m.group(1) if m else t("the AI tool")
        base = t("{tool} wrote these files (their header says @assisted {tool}). Before an agent's code is committed, "
                 "archvow checks that the agent ran protected: in its sandbox, without an option that lets it act "
                 "without asking (YOLO).", tool=tool)
        if re.search(r"cannot see|ne peut pas voir", message):
            w = re.search(r"cannot see (in [^:]+?)(?: \(|:)", message)
            where = f" {w.group(1)}" if w else ""
            return {
                "meaning": base + " " + t("archvow cannot see {tool}{where}, so nobody checked how it ran.",
                                          tool=tool, where=where),
                "fix": t("Review what {tool} wrote, then commit it. This warning only concerns files not committed "
                         "yet: it disappears with the commit, and it never blocks. ", tool=tool)
                + (t("For archvow to check the agent next time, use {tool} where archvow sees it (archvow doctor "
                     "says where).", tool=tool) if where
                   else t("archvow cannot check {tool} anywhere: review its code with care before each commit.",
                          tool=tool)),
                "who": t("You, who commit the code."),
                "then": t("Then commit: the warning disappears."),
            }
        if re.search(r"never ran archvow|n'a jamais lancé archvow", message):
            return {
                "meaning": base + " " + t("{tool} never ran archvow in this project, so nobody checked how it ran.",
                                          tool=tool),
                "fix": t("Ask {tool} to run archvow check here, in its sandbox; then commit again. The commit message "
                         "then records how it ran (an Archvow-Agent line).", tool=tool),
                "who": t("You, then {tool}.", tool=tool),
                "then": t("Then commit again."),
            }
        if re.search(r"refused to run inside it|a refusé de tourner", message):
            return {
                "meaning": base + " " + t("The last time {tool} ran archvow here, it was not protected, and archvow "
                                          "stopped it.", tool=tool),
                "fix": t("Start {tool} protected - its sandbox on, without the option that lets it act without asking "
                         "- let it run archvow check, then commit again. archvow doctor says what archvow sees.",
                         tool=tool),
                "who": t("You, who start {tool}.", tool=tool),
                "then": t("Then commit again."),
            }
        if re.search(r"no Archvow-Agent line|aucune ligne Archvow-Agent|pas de ligne Archvow-Agent", message):
            return {
                "meaning": t("A commit of this branch changes code {tool} wrote, and its message has no Archvow-Agent "
                             "line: it was made without the Git hooks (git commit --no-verify?), so nobody checked how "
                             "{tool} ran.", tool=tool),
                "fix": t("Redo the commit with the hooks on: git reset --soft HEAD~1, then git commit. If the hooks "
                         "never run on your machine: git config core.hooksPath .githooks."),
                "who": t("You, who made the commit."),
                "then": t("Then push again: CI checks the branch again."),
            }
        if re.search(r"YOLO|outside a sandbox|hors bac à sable", message):
            return {
                "meaning": t("A commit of this branch changes code {tool} wrote while it was not protected (outside its "
                             "sandbox, or in YOLO mode).", tool=tool),
                "fix": t("Have that code reviewed closely, or redo it with {tool} protected; the architects decide "
                         "whether the branch can be merged.", tool=tool),
                "who": t("You, then the architects."),
            }
    if code == "ARCH050" and "is left out of the spec" in message:
        return {"meaning": t("A component folder lost its spec.vow: archvow reads the spec without that component, "
                             "so next, show and the spec cards leave it out."),
                "fix": t("Restore the file from Git (the command in the message). If the component was removed on "
                         "purpose, delete its folder.")}
    if code == "ARCH014":
        return {"fix": t("This entry of a vow was edited by hand, and archvow writes it. Undo the hand edit (git "
                         "checkout -- the file), then make the change with the archvow commands (component edit, "
                         "question add, rule add...).")}
    return {}


def attach(report, language: str, commands: dict[tuple[str, ...], list[_Param]]) -> None:
    """Give every finding of a check report its guide (`commands`: `grammar_of` archvow's parser)."""
    for v in report.violations:
        v.guide = guide(v.code, v.severity, v.message, v.file, v.line, language, commands=commands)
