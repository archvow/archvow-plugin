"""The files of a project that are not the spec: .gitignore and .gitattributes merged with the team's,
the Git repository and its hooks, the skill files, the next steps init prints.
"""

from __future__ import annotations

import os
from pathlib import Path

from jinja2 import Environment

from archvow.agents import STANDARD_SKILLS, Profile
from archvow.foundation.files import write_text
from archvow.foundation.git import available, git, git_or_none, succeeds
from archvow.foundation.i18n import tr
from archvow.model import store
from archvow.spec.answers import (
    _env,
    answers_with_defaults,
    derive,
    split_rules,
)
from archvow.templates import (
    Template,
    load_template,
    template_name,
)


def _write_skill(root: Path, rel: str, source: Path, instructed: list, context: dict, env, template: Template,
                 force: bool) -> list[Path]:
    """skills/<name>/<file> into .agents/skills/<name>/<file> (the standard folder, every project), and into the
    skills folder of each approved agent that reads its skills elsewhere (its profile's `skills`): the review skill
    for the approved reviewers, the others for the assistants that write code."""
    name = rel.split("/")[1]
    tools = [t for t in (context.get("reviewers") if name == "archvow-review" else context.get("ai_tools")) or []
             if t != "none"]
    if not tools:
        return []
    folders = [STANDARD_SKILLS, *dict.fromkeys(p.skills for p in instructed if p.skills and p.name in (tools or []))]
    written = []
    for folder in folders:
        target = root / folder / rel.removeprefix("skills/").removesuffix(".j2")
        if target.exists() and not force:
            continue
        content = source.read_text(encoding="utf-8")
        if rel.endswith(".j2"):
            content = template.rename_layers(env.from_string(content).render(**context))
        target.parent.mkdir(parents=True, exist_ok=True)
        write_text(target, content)
        written.append(target)
    return written


def write_agent_files(root: Path, profile: Profile, context: dict, env, template: Template, language: str,
                       force: bool) -> list[Path]:
    """An approved agent's own files (agents/<name>/files/ of its pack), rendered with the project's context, each
    under its condition (`when`); a withdrawn file whose condition turned false goes at init --force."""
    written = []
    for rel, source in profile.files(language).items():
        target_rel = rel.removesuffix(".j2")
        rule = profile.when.get(target_rel)
        if rule is not None and not env.compile_expression(rule)(**context):
            if force and target_rel in profile.withdrawn:
                (root / target_rel).unlink(missing_ok=True)  # it granted something: a stale copy would keep granting it
            continue
        target = root / target_rel
        if target.exists() and not force:
            continue  # never overwrite a file the team already owns
        content = source.read_text(encoding="utf-8")
        if rel.endswith(".j2"):
            content = template.rename_layers(env.from_string(content).render(**context))
        target.parent.mkdir(parents=True, exist_ok=True)
        write_text(target, content)
        written.append(target)
    return written


# Only with AI reviewers: their reports stay local (a project without reviewers is left as it was,
# including a `reviews/` folder of its own).
REVIEW_GITIGNORE = ["# archvow: AI review reports (local; CI keeps them with the merge request)", "reviews/"]


# Each AI agent's last run in this project and the next commit's Archvow-Agent line (agent.py).
AGENT_GITIGNORE = ["# archvow: how each AI agent last ran here, for the commit check (local)", ".archvow/*.local"]


GITATTRIBUTES = ["# the scripts run on Linux (cluster, container, CI): they keep LF line endings, even from Windows",
                 "*.sh text eol=lf", ".githooks/* text eol=lf",
                 "# business examples keep their bytes on every system (archvow compares their fingerprint)",
                 "tests/examples/** text eol=lf"]


def merge_gitignore(root: Path, lines: list[str], name: str = ".gitignore") -> Path | None:
    """Create .gitignore (or .gitattributes) or append the missing archvow lines; never remove the
    team's own."""
    if not lines:
        return None
    path = root / name
    existing = path.read_text(encoding="utf-8").splitlines() if path.is_file() else []
    present = {line.strip() for line in existing}
    missing = [line for line in lines if line.startswith("#") or line.strip() not in present]
    if not [line for line in missing if not line.startswith("#")]:
        return None
    block = []
    for index, line in enumerate(missing):
        if line.startswith("#"):
            nxt = missing[index + 1] if index + 1 < len(missing) else "#"
            if nxt.startswith("#"):
                continue  # drop a comment whose entries are all already present
            if block:
                block.append("")
        block.append(line)
    text = "\n".join(existing).rstrip("\n")
    if text:
        text += "\n\n# --- added by archvow init ---\n"
    write_text(path, text + "\n".join(block) + "\n")
    return path


def merge_marked(path: Path, content: str, language: str, *, force: bool, ours: bool) -> str | None:
    """A file shared with the team (README.md): archvow owns only the part between its markers.

    New file: its title, then the rest inside the markers. The team's file: the part added at its
    end, once.
    `--force` replaces only that part; in a project archvow made, a file without markers is
    replaced whole. None: nothing to write.
    """
    note = tr(language, "<!-- Added by archvow init: `archvow init --force` rewrites only what is between "
              "these two markers; write your own text outside them. -->")
    title = ""
    if content.startswith("# "):  # the title belongs to the team: it stays outside the markers
        title, _, content = content.partition("\n")
    block = f"{BEGIN_MARK}\n{note}\n\n{content.strip()}\n\n{END_MARK}\n"
    text = path.read_text(encoding="utf-8") if path.is_file() else ""
    if BEGIN_MARK in text and END_MARK in text.split(BEGIN_MARK, 1)[1]:
        if not force:
            return None
        before, rest = text.split(BEGIN_MARK, 1)
        after = rest.split(END_MARK, 1)[1]
        return before + block + after.removeprefix("\n")
    if not text.strip() or (force and ours):
        return f"{title}\n\n{block}" if title else block
    return text.rstrip("\n") + "\n\n" + block


def _existing_tooling(root: Path, src: str) -> dict:
    """What the repository already has: archvow uses it instead of adding its own."""
    def theirs(name: str, *generated_marks: str) -> bool:  # the team's file, not one archvow wrote
        path = root / name
        text = path.read_text(encoding="utf-8", errors="replace") if path.is_file() else ""
        return path.is_file() and not any(mark in text for mark in generated_marks)

    existing = next((name for name in ("requirements.txt", "requirements", "requirements-dev.txt")
                     if theirs(name, "archvow==")), None)
    pyproject = theirs("pyproject.toml", "./entrypoint.sh --package", "(generated by archvow")
    if existing:
        install = f"pip install -r {existing}"
    elif pyproject:
        install = 'pip install -e ".[dev]"'
    else:
        install = "pip install -r requirements.txt"
    return {
        "makefile_exists": any((root / name).is_file() for name in ("Makefile", "makefile", "GNUmakefile")),
        "requirements_file_exists": bool(existing) or pyproject,
        "requirements_name": existing or ("pyproject.toml" if pyproject else "requirements.txt"),
        "pyproject_exists": pyproject,
        "install_command": install,
        "cov_option": "--cov" if (root / ".coveragerc").is_file() else f"--cov={src}",
    }


def _pytest_configured(root: Path) -> bool:
    """True when the repository already configures pytest (archvow then writes no pytest.ini)."""
    markers = {"pytest.ini": "", "pyproject.toml": "[tool.pytest", "setup.cfg": "[tool:pytest]",
               "tox.ini": "[pytest]"}
    for name, marker in markers.items():
        path = root / name
        if path.is_file() and marker in path.read_text(encoding="utf-8", errors="ignore"):
            return True
    return False


def init_git(root: Path) -> tuple[str, str]:
    """Create a Git repository (branch main) unless the folder is already inside one."""
    if not available():
        return "warn", "Git is not installed: run `git init`, then `git config core.hooksPath .githooks`"
    parent = None
    if succeeds(root, "rev-parse", "--is-inside-work-tree"):
        top = (git_or_none(root, "rev-parse", "--show-toplevel") or "").strip()
        if not top or Path(top).resolve() == root.resolve():
            return "", ""  # already its own repository
        parent = Path(top)  # CI files, CODEOWNERS and hooks only work at a repository root
    git(root, "init", "-q")
    git(root, "symbolic-ref", "HEAD", "refs/heads/main")
    if parent is not None:
        rel = root.resolve().relative_to(parent.resolve()).as_posix()
        return "warn", (f"Git repository created (branch main) inside the repository {parent}: "
                        f"add '{rel}/' to its .gitignore so the two stay separate")
    return "ok", "Git repository created (branch main)"


def enable_git_hooks(root: Path) -> tuple[str, str]:
    """Point Git at .githooks when this is a Git repository (local setting, this clone only)."""
    if not (root / ".githooks").is_dir():
        return "", ""
    if not available():
        return "warn", "Local checks not enabled (git not found): later run `git config core.hooksPath .githooks`"
    inside = git_or_none(root, "rev-parse", "--show-toplevel")
    if inside is None:
        return ("warn", "Local checks not enabled (not a Git repository): after `git init`, "
                "run `git config core.hooksPath .githooks`")
    top = Path(inside.strip()).resolve()
    if top != root.resolve():
        rel = root.resolve().relative_to(top).as_posix()
        return ("warn", f"Local checks not enabled: the repository root is {top}. If this is its only "
                f"project, run `git -C {top} config core.hooksPath {rel}/.githooks`")
    git_or_none(root, "config", "core.hooksPath", ".githooks")
    if os.name == "nt":  # Windows has no executable bit: Git records it, so Linux (CI, cluster) can run them
        scripts = [p.relative_to(root).as_posix() for p in [*(root / ".githooks").iterdir(), *root.glob("*.sh")]
                   if p.is_file()]
        git_or_none(root, "add", "--chmod=+x", "--", *scripts)
        return "ok", "Local checks enabled for this clone (.githooks); the scripts staged as executable"
    return "ok", "Local checks enabled for this clone (.githooks)"


def next_steps(template_name: str, root: Path, answers: dict | None = None) -> str:
    """Platform setup steps printed after `init`."""
    template = load_template(template_name, root)
    text = template.data.get("next_steps")
    if not text:
        return ""
    answers = answers or {}
    context = {**template.data.get("context", {}), **answers_with_defaults(template, answers)}
    context["families"], context["compliance"] = split_rules(template, context.get("rules") or ["all"])
    context["agents_approved"] = [t for t in context.get("ai_tools") or [] if t != "none"]
    context.update(derive(template, context))
    return _env().from_string(text).render(**context).strip()


def _render(env: Environment, value: object, context: dict) -> object:
    if isinstance(value, str):
        return env.from_string(value).render(**context)
    if isinstance(value, list):
        return [_render(env, item, context) for item in value]
    if isinstance(value, dict):
        return {k: _render(env, v, context) for k, v in value.items()}
    return value


def _load(root: Path, container_id: str | None) -> tuple[dict, dict, Template]:
    data = store.load(root)
    container = store.container(data, container_id)
    return data, container, load_template(template_name(container)[0], root)


BEGIN_MARK, END_MARK = "<!-- archvow:begin -->", "<!-- archvow:end -->"
