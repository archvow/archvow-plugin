"""Every file and folder archvow owns, in one map. Paths are relative to the project's root unless the
name says otherwise; `Path` values join with a root, `str` values are compared with Git's paths."""

from __future__ import annotations

import os
from pathlib import Path

ARCHVOW_DIR = Path(".archvow")
PROJECT_REL = ARCHVOW_DIR / "spec.vow"            # the project's vow
COMPONENTS_REL = ARCHVOW_DIR / "components"      # components/<id>/spec.vow and spec.md
COMPONENT_FILE = "spec.vow"                      # a component's vow, in its folder
CARD_FILE = "spec.md"                            # the spec card generated next to each spec.vow
PROPOSALS_REL = ARCHVOW_DIR / "proposals.vow"     # the AI's proposals waiting for a person (guided, free)
FROZEN_REL = ".archvow/frozen.json"              # violations accepted by `archvow freeze`
STATUS_REL = ".archvow/status.md"                # the local status report (gitignored)
AGENTS_STATE_REL = ARCHVOW_DIR / "agents.local"   # each agent's last state, one line per agent (local)
TRAILER_REL = ARCHVOW_DIR / "trailer.local"       # what the commit-msg hook adds to the next commit (local)
WRITE_LOCK_REL = ARCHVOW_DIR / "write.local"      # held while a command writes the spec (local)
REVIEWS_DIR = "reviews"                          # AI review reports (gitignored)


def cache_dir() -> Path:
    """archvow's folder in the user's cache (history, crash reports): never inside a project (ARCH050)."""
    base = os.environ.get("XDG_CACHE_HOME") or str(Path.home() / ".cache")
    return Path(base) / "archvow"


OWNERS_BEGIN = "# --- Component owners: written by archvow (archvow component edit <component> --owners ...)"


OWNERS_END = "# --- end of component owners"
