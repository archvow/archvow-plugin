"""`archvow rule add|edit|accept|remove`: rules in plain words.
"""

from __future__ import annotations

import argparse

from archvow.cli.args import Builder
from archvow.cli.items import ai_author, kept_by_a_person, remove_item
from archvow.cli.output import after_change, print_result, project_root, source_of, to_change
from archvow.foundation.errors import SpecError
from archvow.model.spec import rule_scope
from archvow.spec.acceptance import accept_rule
from archvow.spec.rules import add_rule, edit_rule


def cmd_rule_remove(args: argparse.Namespace) -> int:
    return remove_item(args, "rule")


def cmd_rule_add(args: argparse.Namespace) -> int:
    """archvow rule add <components> "text" | --type T "text" | --all "text"."""
    root = project_root(args)
    words = args.words
    if args.type or args.all:
        if len(words) != 1:
            raise SpecError('with --type or --all, give only the rule: archvow rule add --all "..."')
        rule = add_rule(root, words[0], type_name=args.type, all_components=args.all,
                              source=source_of(root, args), added_by=ai_author(root), why=args.why)
    else:
        if len(words) != 2:
            raise SpecError('usage: archvow rule add <component>[,<component>...] "the rule" '
                            '(or --type <type> / --all)')
        components = [c.strip() for c in words[0].split(",") if c.strip()]
        rule = add_rule(root, words[1], components=components, source=source_of(root, args),
                              added_by=ai_author(root), why=args.why)
    after_change(args, root)
    print_result(args, rule, f"Recorded {rule['id']} ({rule_scope(rule)}): {rule['text']}\n"
                       "Each component it applies to implements it, with a test."
           + kept_by_a_person(rule, f"archvow rule accept {rule['id']}")
           + to_change(f"archvow rule edit {rule['id']} \"...\""), success=True)
    return 0


def cmd_rule_edit(args: argparse.Namespace) -> int:
    root = project_root(args)
    rule = edit_rule(root, args.id, args.text)
    after_change(args, root)
    print_result(args, rule, f"Changed {rule['id']} ({rule_scope(rule)}): {rule['text']}"
           + to_change(f"archvow rule edit {rule['id']} \"...\""), success=True)
    return 0


def cmd_rule_accept(args: argparse.Namespace) -> int:
    root = project_root(args)
    rule = accept_rule(root, args.id)
    after_change(args, root)
    print_result(args, rule, f"Kept {rule['id']} (added by {rule['added_by']}): {rule['text']}", success=True)
    return 0


def declare_rule(b: Builder) -> None:
    """`archvow rule`: its parser."""
    rsub = b.noun("rule", "a rule of what components do, in plain words (R1, R2... for the project)",
                  "add|edit|accept|remove", examples="""
        archvow rule add <component> "<a rule in your own words>"
        archvow rule edit R3 "<the new text>"
        archvow rule accept R3          # a person keeps a rule the AI added
        archvow rule remove R3
        """)
    p = b.command("add", cmd_rule_add, "record a rule for one or more components, a type, or all", True,
                  parent=rsub, examples="""
        archvow rule add <component> "<a rule in your own words>"
        archvow rule add <component>,<component> "Given <situation>, when <action>, then <result>"
        archvow rule add <component> "When <trigger>, <component> <response>"
        archvow rule add --type reader "<a rule for every reader, today and later>"
        archvow rule add --all "<a rule for every component>"
        """)
    p.add_argument("words", nargs="+", metavar="ARG",
                   help='<component>[,<component>...] "rule", or only "rule" with --type/--all')
    scope = p.add_mutually_exclusive_group()
    scope.add_argument("--type", metavar="TYPE", help="every component of this type, including later ones")
    scope.add_argument("--all", action="store_true", help="every component")
    p.add_argument("--from", dest="source", metavar="BRIEF",
                   help="the brief it is drawn from: briefs/<file>.md, or briefs/<file>.md#<section> (a heading); "
                        "archvow check warns when that text changes (ARCH039)")
    p.add_argument("--why", metavar="REASON",
                   help="why it is added, in a few words (what in the card or the brief leaves it open) - "
                        "shown to the person who keeps it")
    p = b.command("edit", cmd_rule_edit, "change a rule's text (its scope stays)", True, parent=rsub,
                  examples='archvow rule edit R3 "<the new text>"')
    p.add_argument("id", metavar="RULE", help="the rule's id, e.g. R3")
    p.add_argument("text", help="the new text")
    p = b.command("accept", cmd_rule_accept, "keep a rule the AI added (a person, never the AI)", True, parent=rsub,
                  examples="archvow rule accept R3")
    p.add_argument("id", metavar="RULE", help="the rule's id, e.g. R3")
    p = b.command("remove", cmd_rule_remove, "remove a rule (asks first)", True, parent=rsub,
                  examples="archvow rule remove R3")
    p.add_argument("id", metavar="RULE", help="the rule's id, e.g. R3")
    p.add_argument("--yes", action="store_true", help="do not ask for confirmation (scripts)")
