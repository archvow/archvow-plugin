"""`archvow column set`: personal data in columns.
"""

from __future__ import annotations

import argparse

from archvow.cli.args import Builder
from archvow.cli.output import after_change, print_result, project_root, to_change
from archvow.privacy import classify


def cmd_column_set(args: argparse.Namespace) -> int:
    """archvow column set <component> <names> personal|special|none, or --removes / --pseudonymises."""
    root = project_root(args)
    result = classify(root, args.component, args.names.split(","), args.kind, removes=args.removes,
                      pseudonymises=args.pseudonymises)
    after_change(args, root)
    if "columns" in result:
        text = "\n".join(f"{args.component}.{n}: {k}" for n, k in result["columns"].items()) + to_change(
            f"archvow column set {args.component} {','.join(result['columns'])} personal|special|none")
    else:
        key = "removes" if args.removes else "pseudonymises"
        text = f"{args.component} {key} {', '.join(result[key])} before the data is written"
    print_result(args, result, text, success=True)
    return 0


def declare_column(b: Builder) -> None:
    """`archvow column`: its parser."""
    # ---- personal data and third parties
    ksub = b.noun("column", "personal data: classify columns, or say a component removes or pseudonymises them",
                  "set", examples='archvow column set <schema> <column,...> personal|special|none')
    p = b.command("set", cmd_column_set, "classify columns: personal, special (GDPR art. 9) or none", True,
                  parent=ksub, examples="""
        archvow column set <schema> customer_email,phone personal
        archvow column set <schema> diagnosis special             # health, religion, biometrics... (art. 9)
        archvow column set <schema> order_id,amount none
        archvow column set <transformation> phone --removes        # dropped before the data is written
        archvow column set <transformation> customer_email --pseudonymises
        """)
    p.add_argument("component", help="a schema or model component (classes); any component for --removes / "
                   "--pseudonymises")
    p.add_argument("names", help="column names, separated by commas")
    p.add_argument("kind", nargs="?", choices=["personal", "special", "none"], help="personal | special | none")
    flow = p.add_mutually_exclusive_group()
    flow.add_argument("--removes", action="store_true", help="this component drops these columns")
    flow.add_argument("--pseudonymises", action="store_true", help="this component pseudonymises or encrypts them")
