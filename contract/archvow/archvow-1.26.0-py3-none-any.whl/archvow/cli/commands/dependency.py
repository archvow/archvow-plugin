"""`archvow dependency add|remove`: the third-party register.
"""

from __future__ import annotations

import argparse

from archvow import dora
from archvow.cli.args import Builder
from archvow.cli.output import after_change, print_result, project_root, to_change


def cmd_dependency_add(args: argparse.Namespace) -> int:
    root = project_root(args)
    entry = dora.add_dependency(root, args.name, args.supplier, args.licence, args.criticality)
    after_change(args, root)
    print_result(args, entry, f"Registered {entry['name']}: {entry['supplier']}, {entry['licence']}, "
                        f"{entry['criticality']}"
           + to_change(f"archvow dependency remove {entry['name']}, then dependency add again"), success=True)
    return 0


def cmd_dependency_remove(args: argparse.Namespace) -> int:
    root = project_root(args)
    entry = dora.remove_dependency(root, args.name)
    after_change(args, root)
    print_result(args, entry, f"Removed {entry['name']} from the register", success=True)
    return 0


def declare_dependency(b: Builder) -> None:
    """`archvow dependency`: its parser."""
    p = b.command("dependency", None, "the third-party register (DORA): supplier, licence, criticality", examples="""
        archvow dependency add pyspark --supplier "Apache Software Foundation" --licence Apache-2.0 --criticality critical
        archvow dependency remove pyspark
        """)
    dsub = p.add_subparsers(dest="dependency_command", required=True, metavar="add|remove",
                            help="archvow dependency add|remove --help: options and examples")
    dp = b.command("add", cmd_dependency_add, "record a package of requirements.txt in the register", True,
                   parent=dsub, examples='archvow dependency add fastapi --supplier "Sebastián Ramírez (tiangolo)" '
                                         '--licence MIT --criticality critical')
    dp.add_argument("name", help="the package, as requirements.txt names it")
    dp.add_argument("--supplier", required=True, metavar="WHO", help="who provides and maintains it")
    dp.add_argument("--licence", required=True, metavar="SPDX", help="its licence (SPDX name, e.g. Apache-2.0, MIT)")
    dp.add_argument("--criticality", required=True, choices=["critical", "important", "minor"], metavar="LEVEL",
                    help="critical (the service stops without it; pinned with ==) | important | minor")
    dp = b.command("remove", cmd_dependency_remove, "remove a package from the register", True, parent=dsub,
                   examples="archvow dependency remove requests")
    dp.add_argument("name", help="the package")
