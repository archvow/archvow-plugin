"""`archvow pack new|template|agent|rule|add|update|remove|check`: packs, the one way to extend archvow.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from archvow.cli.args import Builder
from archvow.cli.commands.template_settings import template_settings
from archvow.cli.console import style as ui
from archvow.cli.output import as_json, print_result, project_root
from archvow.foundation import logs
from archvow.model import store
from archvow.packs import rules as pack_rules
from archvow.spec.pack_check import check_pack
from archvow.spec.pack_parts import add_agent, add_rule
from archvow.spec.packs import (
    add_pack,
    add_template,
    new_pack,
    pack_folder,
    remove_pack,
    update_pack,
)

log = logs.get("cli")


def _project(args: argparse.Namespace) -> Path | None:
    """The project the command is in, or None (a company pack is written outside any project)."""
    try:
        return project_root(args)
    except store.ManifestError:
        logs.swallowed(log, "_project: store.ManifestError")
        return None


def _folder(args: argparse.Namespace) -> tuple[Path | None, Path]:
    root = _project(args)
    return root, pack_folder(args.pack, root)


def _words(text: str | None) -> list[str]:
    return [w.strip() for w in (text or "").replace(" ", ",").split(",") if w.strip()]


def _shown(root: Path | None, path: Path) -> str:
    try:
        return path.relative_to(root).as_posix() if root is not None else str(path)
    except ValueError:
        return str(path)


def cmd_pack_new(args: argparse.Namespace) -> int:
    root = _project(args) if args.dir is None else None  # without --dir: a pack of this project
    folder = new_pack(root, args.name, args.description,
                      Path(args.dir) if args.dir else None, args.version, tuple(_words(args.languages)) or ("en",))
    where = _shown(root, folder)
    print_result(args, {"pack": args.name, "folder": str(folder)},
                 ui.ok(f"Created pack {args.name} in {where}") + "\n"
                 f"Next: archvow pack template {where} <name> --extends <template> (agents: pack agent, rules: "
                 f"pack rule), then archvow pack check {where}")
    return 0


def cmd_pack_template(args: argparse.Namespace) -> int:
    root, folder = _folder(args)
    directory = add_template(root, folder, args.name, args.extends, **template_settings(args, root, folder))
    print_result(args, {"template": args.name, "folder": str(directory)},
                 ui.ok(f"Created {_shown(root, directory)}") + " - edit template.yaml, add files in files/ "
                 f"(and files-fr/), then: archvow pack check {_shown(root, folder)}")
    return 0


def cmd_pack_agent(args: argparse.Namespace) -> int:
    root, folder = _folder(args)
    target = add_agent(root, folder, args.name, extends=args.extends, title=args.title, env=_words(args.detect_env),
                       processes=_words(args.detect_process), instructions=args.instructions, skills=args.skills,
                       unsafe=args.unsafe_flag, fix=args.fix, review_command=args.review_command,
                       review_secret=args.review_secret, owns=_words(args.owns), permissions=args.permissions)
    print_result(args, {"agent": args.name, "folder": str(target)},
                 ui.ok(f"Created {_shown(root, target)}/agent.yaml") + f" - a project approves it with "
                 f"-a ai_tools=...,{args.name}")
    return 0


def cmd_pack_rule(args: argparse.Namespace) -> int:
    root, folder = _folder(args)
    rule = {"kind": args.kind, "target": _words(args.target) if args.kind in ("forbid_import", "forbid_call",
                                                                                 "forbid_file", "only_in")
            else args.target, "in_types": _words(args.in_types), "in_layers": _words(args.in_layers),
            "severity": args.severity, "message": args.message, "message_fr": args.message_fr, "fix": args.fix,
            "fix_fr": args.fix_fr, "why": args.why, "why_fr": args.why_fr, "bad": args.bad, "good": args.good}
    path = add_rule(root, folder, args.code, rule)
    print_result(args, {"rule": args.code, "file": str(path)},
                 ui.ok(f"Recorded {args.code} in {_shown(root, path)}") + ": it catches its bad example and passes "
                 "its good one")
    return 0


def cmd_pack_add(args: argparse.Namespace) -> int:
    root = _project(args) or Path(args.project or ".").resolve()
    pack = add_pack(root, args.source)
    later = "" if store.is_project(root) else " (recorded in spec.vow by init)"
    print_result(args, pack.summary(), ui.ok(f"Added pack {pack.name} {pack.version}") + f" into "
                 f".archvow/packs/{pack.name}/{later}. Commit it: clones, the Git hook and the CI read that copy.")
    return 0


def cmd_pack_update(args: argparse.Namespace) -> int:
    root = project_root(args)
    old, pack = update_pack(root, args.name, args.source)
    print_result(args, pack.summary(), ui.ok(f"Updated pack {pack.name}: {old} -> {pack.version}") +
                 "; archvow diff shows what changed for the project")
    return 0


def cmd_pack_remove(args: argparse.Namespace) -> int:
    root = project_root(args)
    remove_pack(root, args.name)
    print_result(args, {"removed": args.name}, ui.ok(f"Removed pack {args.name}"))
    return 0


def cmd_pack_check(args: argparse.Namespace) -> int:
    root = _project(args)
    folder = pack_folder(args.pack, root)
    pack, problems, proved = check_pack(folder)
    if args.json:
        print(as_json({"pack": pack.summary() if pack else None, "problems": problems, "proved": proved}))
        return 1 if problems else 0
    for line in proved:
        print(ui.ok(line))
    for line in problems:
        print(ui.error(line), file=sys.stderr)
    print(f"\n{len(problems)} problem(s)" if problems else "\n" + ui.ok("The pack is ready to share"))
    return 1 if problems else 0


def declare_pack(b: Builder) -> None:
    """`archvow pack`: its parsers."""
    sub = b.noun("pack", "packs: a company's templates, agents and rules, in one folder (data only)",
                 "new|template|agent|rule|add|update|remove|check", examples="""
        archvow pack new acme -d "ACME's templates and rules" --dir ~/packs
        archvow pack template ~/packs/acme acme-pyspark --extends pyspark-pipeline -a ci=jenkins
        archvow pack check ~/packs/acme
        archvow pack add ~/packs/acme                 # in a project: copied into .archvow/packs/acme/
        """)
    _declare_new(b, sub)
    _declare_template(b, sub)
    _declare_agent(b, sub)
    _declare_rule(b, sub)
    p = b.command("add", cmd_pack_add, "copy a pack into the project and record it (version, source, digest)",
                  True, parent=sub, examples="""
        archvow pack add ~/packs/acme                 # a folder
        archvow pack add acme-archvow-pack            # a pip package that names its pack (entry point archvow.packs)
        """)
    p.add_argument("source", help="the pack's folder, or an installed package that carries one")
    p.add_argument("--project", metavar="FOLDER", help="the project's folder before init (default: here)")
    p = b.command("update", cmd_pack_update, "a new version of a pack, from the source it was added from", True,
                  parent=sub, examples="archvow pack update acme")
    p.add_argument("name", help="the pack's name")
    p.add_argument("--from", dest="source", metavar="SOURCE", help="another folder or package to take it from")
    p = b.command("remove", cmd_pack_remove, "take a pack out of the project", True, parent=sub,
                  examples="archvow pack remove acme")
    p.add_argument("name", help="the pack's name")
    p = b.command("check", cmd_pack_check, "test a whole pack before sharing it (every part, every language)", True,
                  parent=sub, examples="archvow pack check ~/packs/acme")
    p.add_argument("pack", help="the pack's folder, or the name of a pack of this project")


def _declare_new(b: Builder, sub: argparse._SubParsersAction) -> None:
    p = b.command("new", cmd_pack_new, "create a pack: pack.yaml, README.md, commented examples", True, parent=sub,
                  examples="""
        archvow pack new acme -d "ACME's templates and rules" --dir ~/packs    # a company pack
        archvow pack new team -d "This team's rules"                           # in this project, recorded
        """)
    p.add_argument("name", help="the pack's name: lowercase letters, digits and dashes (acme)")
    p.add_argument("-d", "--description", required=True, metavar="TEXT", help="what the pack brings, in one line")
    p.add_argument("--dir", metavar="FOLDER", help="create it in this folder (a company pack; no project needed); "
                   "default: inside this project")
    p.add_argument("--version", default="1.0.0", help="its version (default: 1.0.0)")
    p.add_argument("--languages", default="en,fr", help="its languages, English always (default: en,fr)")


def _declare_template(b: Builder, sub: argparse._SubParsersAction) -> None:
    p = b.command("template", cmd_pack_template, "add a template to a pack, extending another one", True,
                  parent=sub, usage="archvow pack template PACK NAME --extends TEMPLATE [options]", examples="""
        archvow pack template ~/packs/acme acme-pyspark --extends pyspark-pipeline -a ci=jenkins --allowed-paths devops
            # without options, a terminal asks them
        """)
    p.add_argument("pack", help="the pack's folder, or the name of a pack of this project")
    p.add_argument("name", help="the template's name (acme-pyspark)")
    p.add_argument("--extends", required=True, metavar="TEMPLATE",
                   help="the template it builds on: <pack>/<template>, or a short name (one of this pack too)")
    p.add_argument("-d", "--description", metavar="TEXT", help="what the template is for (one line)")
    p.add_argument("-a", "--answer", action="append", metavar="KEY=VALUE",
                   help="a company default for an init answer, repeatable (-a ci=jenkins); a project can override it")
    p.add_argument("--allowed-paths", metavar="FOLDERS",
                   help="top folders of Python files that are not components (devops,tools): no ARCH015 there")
    p.add_argument("--verbatim-folders", metavar="FOLDERS", dest="verbatim_folders",
                   help="folders of files/ copied exactly as they are, .j2 included (templates,deploy/ansible)")
    p.add_argument("--layer", action="append", metavar="LAYER=FOLDER",
                   help="rename a layer's folder, repeatable (--layer p1_domain=domain)")
    p.add_argument("--no-input", action="store_true", help="never ask: without options, settings stay examples")


def _declare_agent(b: Builder, sub: argparse._SubParsersAction) -> None:
    p = b.command("agent", cmd_pack_agent, "add an agent profile to a pack (only what differs from the standard)",
                  True, parent=sub, usage="archvow pack agent PACK NAME [options]", examples="""
        archvow pack agent ~/packs/acme acme-assistant --title "ACME Assistant" --detect-env ACME_ASSISTANT \\
            --instructions .acme/instructions.md:rules --unsafe-flag=--no-confirm --owns .acme
        archvow pack agent ~/packs/acme claude-code --extends claude-code --review-command "claude -p ..."
        """)
    p.add_argument("pack", help="the pack's folder, or the name of a pack of this project")
    p.add_argument("name", help="the agent's name, as a project approves it (acme-assistant)")
    p.add_argument("--extends", metavar="AGENT", help="start from a known agent's profile and files")
    p.add_argument("--title", help="how AGENTS.md names it (ACME Assistant)")
    p.add_argument("--detect-env", metavar="VARIABLES", help="variables it sets where it runs commands (NAME or "
                   "NAME=start), comma-separated")
    p.add_argument("--detect-process", metavar="PROGRAMS", help="the programs it runs, comma-separated")
    p.add_argument("--instructions", metavar="FILE:KIND", help="its own instructions file: KIND import (a pointer "
                   "to AGENTS.md) or rules (AGENTS.md's rules copied there)")
    p.add_argument("--skills", metavar="FOLDER", help="where it reads skills, when not .agents/skills (a copy)")
    p.add_argument("--unsafe-flag", action="append", metavar="FLAG", help="an option that lets it act without "
                   "asking, repeatable (archvow refuses to run under it)")
    p.add_argument("--fix", metavar="TEXT", help="how to start it again, protected")
    p.add_argument("--review-command", metavar="COMMAND", help="how `archvow review` runs it without a person "
                   "(the task is in $ARCHVOW_REVIEW_PROMPT)")
    p.add_argument("--review-secret", metavar="NAME", help="the CI secret its review command needs")
    p.add_argument("--owns", metavar="FILES", help="its files, comma-separated: flagged while it is not approved")
    p.add_argument("--permissions", metavar="TEXT", help="where a person lists its auto-approved commands, when "
                   "that is outside the project")


def _declare_rule(b: Builder, sub: argparse._SubParsersAction) -> None:
    p = b.command("rule", cmd_pack_rule, "add a declarative rule to a pack (refused unless it catches its bad "
                  "example and passes its good one)", True, parent=sub,
                  usage="archvow pack rule PACK CODE --kind KIND --target TARGET --message TEXT [options]", examples="""
        archvow pack rule ~/packs/acme ACME001 --kind forbid_import --target legacy_billing --in-layers p2_io \\
            --message "No direct use of the old billing API" --fix "use acme_billing.client" \\
            --bad "import legacy_billing" --good "import acme_billing.client"
        """)
    p.add_argument("pack", help="the pack's folder, or the name of a pack of this project")
    p.add_argument("code", help="its code: the company's letters and 3 digits (ACME001)")
    p.add_argument("--kind", required=True, choices=list(pack_rules.KINDS), help="what it checks")
    p.add_argument("--target", required=True, help="what the kind looks for (modules, calls or files: "
                   "comma-separated; a pattern, a keyword or a question: as it is)")
    p.add_argument("--in-types", metavar="TYPES", help="only in these component types, comma-separated")
    p.add_argument("--in-layers", metavar="LAYERS", help="only in these layers, comma-separated")
    p.add_argument("--severity", default="error", choices=["error", "warning"], help="error (default) or warning")
    p.add_argument("--message", required=True, metavar="TEXT", help="what the finding says")
    p.add_argument("--message-fr", metavar="TEXT", help="the same, in French")
    p.add_argument("--fix", metavar="TEXT", help="how to fix it")
    p.add_argument("--fix-fr", metavar="TEXT", help="the same, in French")
    p.add_argument("--why", metavar="TEXT", help="why the rule exists")
    p.add_argument("--why-fr", metavar="TEXT", help="the same, in French")
    p.add_argument("--bad", metavar="CODE", help="an example it must catch (a file path for forbid_file)")
    p.add_argument("--good", metavar="CODE", help="an example it must pass")
