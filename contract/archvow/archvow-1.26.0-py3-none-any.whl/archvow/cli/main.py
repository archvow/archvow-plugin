"""archvow's bootstrap: streams, completion, logs, the agent gate, dispatch, and ONE error handler that
turns every error into an exit code (2: archvow said no, 70: a bug).
"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

from archvow import __version__
from archvow.agent import gate, gate_outside
from archvow.cli.commands.project import cmd_completion, cmd_doctor, cmd_version
from archvow.cli.console import completion
from archvow.cli.console import style as ui
from archvow.cli.output import as_json, project_root, spec_state
from archvow.cli.parser import build_parser
from archvow.foundation import logs
from archvow.foundation.config import settings
from archvow.foundation.errors import ArchvowError
from archvow.model import store

log = logs.get("cli")


INTERNAL_ERROR = 70  # an error archvow did not expect: a bug (sysexits EX_SOFTWARE)


def _agent_gate(args: argparse.Namespace) -> int:
    """Inside an AI agent in YOLO mode, or outside a sandbox when the project asks for one, archvow
    refuses to run (ARCH052, ARCH051): exit 1 with the fix. `doctor` still says what archvow sees."""
    if getattr(args, "func", None) in (cmd_doctor, cmd_completion, cmd_version, None):
        return 0
    command = args.func.__name__.removeprefix("cmd_").replace("_", " ")
    try:
        root = project_root(args)
        data = store.load(root)
    except store.ManifestError:  # not in a project yet (init): only a person creates one
        logs.swallowed(log, "_agent_gate: store.ManifestError")
        lines = gate_outside(Path(getattr(args, "dir", None) or Path.cwd()), command)
    else:
        lines = gate(root, data, command)
    for line in lines:
        print(ui.error(line) if line.startswith("ARCH") else line, file=sys.stderr)
    log.info("agent gate: %s", "refused" if lines else "allowed")
    return 1 if lines else 0


VERBOSE = {"-v": 1, "-vv": 2, "-vvv": 2, "--verbose": 1}


def _verbosity(argv: list[str]) -> tuple[list[str], int]:
    """-v / -vv / --verbose may come anywhere on the line (archvow next -v): taken out before parsing."""
    words, level, rest = [], 0, False
    for word in argv:
        if word == "--":
            rest = True
        if not rest and word in VERBOSE:
            level += VERBOSE[word]
            continue
        words.append(word)
    return words, min(level, 2)


def _command_words(parser: argparse.ArgumentParser) -> set[str]:
    """Every command and verb name (`decision`, `make`...): what a log may show of a command line."""
    words: set[str] = set()
    for action in parser._actions:
        if isinstance(action, argparse._SubParsersAction):
            for name, sub in action.choices.items():
                words |= {name, *_command_words(sub)}
    return words


def _error_envelope(argv: list[str], kind: str, message: str, hint: str | None, code: int) -> None:
    """With --json, an error is also an object on stdout, so a tool never parses the red text."""
    if "--json" in argv:
        print(as_json({"error": {"type": kind, "message": message, "hint": hint, "exit": code}}))


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    for stream in (sys.stdout, sys.stderr):  # a character the console can't show is replaced, never a crash
        try:
            stream.reconfigure(errors="replace")  # type: ignore[union-attr]
        except (AttributeError, ValueError):  # not a text stream (tests, pipes of some IDEs): left as it is
            continue
    if argv[:1] == ["__complete"]:  # what Tab asks: `archvow __complete <shell> <line>` (completion.py)
        return completion.run(argv[1] if len(argv) > 1 else "zsh", argv[2] if len(argv) > 2 else "archvow ",
                              build_parser())
    argv, verbosity = _verbosity(argv)
    env = settings()
    parser = build_parser()
    logs.COMMAND_WORDS.update(_command_words(parser))
    logs.setup(argv, verbosity, env.log, env.log_file)
    if not argv:  # `archvow` alone: the icon, the version and the commands
        print(ui.logo(f"archvow {__version__}") + "\n")
        parser.print_help()
        return 0
    args = parser.parse_args(argv)
    start = time.perf_counter()
    log.info("start %s (archvow %s, Python %s, %s)", " ".join(logs.masked_command(argv)), __version__,
             sys.version.split()[0], Path.cwd())
    code = _run(args, argv)
    log.info("done exit %d (%d ms)", code, round((time.perf_counter() - start) * 1000))
    return code


def _run(args: argparse.Namespace, argv: list[str]) -> int:
    """The command, and the one place where errors become a message and an exit code."""
    try:
        refused = _agent_gate(args)
        if refused:
            return refused
        args.before = spec_state(args)  # what the vows say before the command: after_change compares
        return args.func(args)
    except BrokenPipeError:  # output piped into `head` and the like: not an error
        import os

        os.dup2(os.open(os.devnull, os.O_WRONLY), sys.stdout.fileno())
        return 0
    except ArchvowError as exc:
        print(ui.error(f"archvow: error: {exc}"), file=sys.stderr)
        if exc.hint:
            print(f"  {exc.hint}", file=sys.stderr)
        _error_envelope(argv, exc.kind, str(exc), exc.hint, exc.exit_code)
        return exc.exit_code
    except (KeyboardInterrupt, EOFError):  # Ctrl+C or Ctrl+D during a question: no traceback
        print("\n" + ui.error("stopped"), file=sys.stderr)
        return 130
    except Exception as exc:  # noqa: BLE001 - anything else is a bug: a short message and a crash report
        report = logs.crash_report(exc, __version__, argv)
        print(ui.error(f"archvow {__version__} internal error (a bug): {type(exc).__name__}: {exc}"), file=sys.stderr)
        print(f"  report: {report}" if report else "  (no crash report: the cache folder cannot be written)",
              file=sys.stderr)
        _error_envelope(argv, "InternalError", f"{type(exc).__name__}: {exc}",
                        f"report: {report}" if report else None, INTERNAL_ERROR)
        return INTERNAL_ERROR
