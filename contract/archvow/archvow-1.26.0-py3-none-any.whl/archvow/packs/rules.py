"""Declarative rules: a pack's `rules/<FAMILY>.yaml`, one entry per code (the family is the code's letters).

    ACME001:
      kind: forbid_import          one of KINDS
      target: [legacy_billing]     what the kind looks for (module prefixes, calls, a pattern, files, a keyword...)
      in_types: [writer]           optional: only in files of these component types
      in_layers: [p2_io]           optional: only in these layers
      severity: error              error (default) or warning
      message: No direct use of the old billing API      message_fr: ...   (the finding, per language)
      fix: use acme_billing.client instead                fix_fr: ...
      why: the old API bypasses the audit log             why_fr: ...
      bad: "import legacy_billing"                        an example it must catch (a file path for forbid_file)
      good: "import acme_billing.client"                  an example it must pass

The rules of a pack apply to the projects whose template comes from that pack, or extends one of its templates.
No Python runs: the kinds are matched by archvow (checks/custom.py).
"""

from __future__ import annotations

import re
from pathlib import Path

import yaml

from archvow.foundation.errors import PackError

KINDS = {
    "forbid_import": "a module the code must not import (prefixes: legacy_billing covers legacy_billing.client)",
    "forbid_call": "a function or method the code must not call (time.sleep, *.toPandas)",
    "forbid_pattern": "a text the code must not contain (a regular expression: s3://acme-prod)",
    "forbid_file": "files the repository must not hold (globs: **/*.ipynb)",
    "only_in": "a module imported only in the given component types or layers (requests only in clients)",
    "require_keyword": "a text every file of the given types or layers must contain (a regular expression)",
    "require_question": "a question every component of the given types must answer (asked as C1, C2...)",
}
CODE_RE = re.compile(r"^([A-Z]{2,8})(\d{3})$")
RESERVED = ("ARCH", "STY", "SPK", "FAPI", "AGT", "GDPR", "TST", "DORA", "PRIV")  # archvow's own families


def family(code: str) -> str:
    match = CODE_RE.match(code)
    return match.group(1) if match else ""


def read_file(path: Path) -> dict[str, dict]:
    """The rules of one family file, checked: code -> rule."""
    try:
        raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except (OSError, yaml.YAMLError) as error:
        raise PackError(f"{path}: cannot be read ({error})") from error
    if not isinstance(raw, dict):
        raise PackError(f"{path}: expected a mapping, one entry per rule code (ACME001: ...)")
    rules = {}
    for code, rule in raw.items():
        code = str(code)
        problem = problem_of(code, rule, path.stem)
        if problem:
            raise PackError(f"{path}: {code}: {problem}")
        rules[code] = dict(rule)
    return rules


def problem_of(code: str, rule: object, family_name: str | None = None) -> str:
    """What is wrong with a rule's declaration ('' when nothing)."""
    if not CODE_RE.match(code):
        return "a code is 2 to 8 capital letters and 3 digits (ACME001)"
    if family(code) in RESERVED:
        return f"{family(code)} is one of archvow's own families: choose your company's letters"
    if family_name is not None and family(code) != family_name:
        return f"belongs in rules/{family(code)}.yaml, not rules/{family_name}.yaml"
    if not isinstance(rule, dict):
        return "expected a mapping (kind, target, message...)"
    if rule.get("kind") not in KINDS:
        return f"kind must be one of {', '.join(KINDS)}"
    if not rule.get("target"):
        return "give its target (what the kind looks for)"
    if not str(rule.get("message") or "").strip():
        return "give its message (what the finding says)"
    if str(rule.get("severity", "error")) not in ("error", "warning"):
        return "severity is error or warning"
    if rule["kind"] in ("only_in", "require_keyword", "require_question") and not (
            rule.get("in_types") or rule.get("in_layers")):
        return f"{rule['kind']} needs in_types or in_layers (where it applies)"
    if rule["kind"] == "require_question" and not rule.get("in_types"):
        return "require_question needs in_types (the component types that answer it)"
    if rule["kind"] != "require_question" and (rule.get("bad") is None or rule.get("good") is None):
        return "give a bad example (it must be caught) and a good one (it must pass)"
    return ""


def pack_rules(pack_root: Path) -> dict[str, dict]:
    """Every rule of a pack: code -> rule."""
    found: dict[str, dict] = {}
    for path in sorted((pack_root / "rules").glob("*.yaml")):
        found |= read_file(path)
    return found


def template_rules(template: object) -> dict[str, dict]:
    """The rules a template brings: those of its pack and of the packs of the templates it extends, in the
    template's language (message_<lang>, fix_<lang>, why_<lang> when given). A rule file that cannot be read is
    left out here; `check` reports it (ARCH009)."""
    language = str(getattr(template, "language", "en"))
    found: dict[str, dict] = {}
    for folder in getattr(template, "dirs", []):
        pack_root = Path(folder).parent.parent  # <pack>/templates/<template>
        if not (pack_root / "pack.yaml").is_file():
            continue
        try:
            rules = pack_rules(pack_root)
        except PackError:
            continue
        for code, rule in rules.items():
            found[code] = localized(rule, language)
    return found


def localized(rule: dict, language: str) -> dict:
    """The rule's texts in a language, and the shape the matchers read (checks/custom.py)."""
    texts = {k: str(rule.get(f"{k}_{language}") or rule.get(k) or "") for k in ("message", "fix", "why")}
    target = rule["target"]
    return {**rule, "title": texts["message"], "fix": texts["fix"], "why": texts["why"],
            "severity": str(rule.get("severity", "error")),
            "targets": [str(t) for t in target] if isinstance(target, list) else [str(target)],
            "types": [str(t) for t in rule.get("in_types") or []],
            "layers": [str(t) for t in rule.get("in_layers") or []]}
