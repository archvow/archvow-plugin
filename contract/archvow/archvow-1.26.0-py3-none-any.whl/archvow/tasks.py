"""Tasks: a big spec card cut into parts an implementer can do one at a time.

Nothing is stored and there is no task command. The tasks are computed from the manifest, the same
way every time:

* An **item** is something to implement with its own test: a decision (3, or P1 for personal data
  and operations), a rule (R2), a business example (FATTRIB-012-paid) or an invariant (clean_orders.INV4).
* A card with at most `task_items` items (template key, default 6) is one task: nothing is shown.
* Otherwise the items are cut by meaning, in this order, and packed up to `task_items` per task:
  the core (the file, its signature and description, and the type's `core_questions`, e.g. what a
  transformation computes), the other decisions, the rules, the business examples, the invariants, then
  personal data and operations. The core is never cut in two.
* A task is done when the component's code exists (not a placeholder) and every item of it has a
  marked test: ``@pytest.mark.decision(3)``, ``@pytest.mark.rule("R2")``,
  ``@pytest.mark.example("FATTRIB-012-paid")``, or the invariant's own evidence (``@pytest.mark.invariant("clean_orders.INV4")``...).
"""

from __future__ import annotations

import ast
from dataclasses import dataclass, field
from pathlib import Path

from archvow import proposals as ai
from archvow.foundation import i18n, logs
from archvow.model import store
from archvow.model.spec import mode, rules_for

log = logs.get("tasks")

DEFAULT_TASK_ITEMS = 6
SPLIT_HINT = 3  # more tasks than this: the component itself is probably too big


@dataclass
class Item:
    kind: str  # decision | rule | example | invariant | question
    key: str  # "3", "R2", "clean_orders.INV4", "P1"
    text: str
    answer: str | None = None
    done: bool | None = None  # None: not known (no status asked)

    @property
    def label(self) -> str:
        return {"decision": f"decision {self.key}", "question": f"decision {self.key}",
                "rule": f"rule {self.key}", "example": f"example {self.key}", "invariant": self.key}[self.kind]

    def as_dict(self) -> dict:
        return {"kind": self.kind, "key": self.key, "text": self.text, "answer": self.answer, "done": self.done}


@dataclass
class Task:
    number: int
    items: list[Item] = field(default_factory=list)
    core: bool = False
    done: bool | None = None

    def as_dict(self) -> dict:
        return {"task": f"T{self.number}", "core": self.core, "done": self.done,
                "items": [i.as_dict() for i in self.items]}


def task_items(template) -> int:
    try:
        return max(1, int(template.data.get("task_items") or DEFAULT_TASK_ITEMS))
    except (TypeError, ValueError):
        logs.swallowed(log, "task_items: TypeError, ValueError")
        return DEFAULT_TASK_ITEMS


def items_of(data: dict, comp: dict, extra: list[dict] | None = None) -> list[list[Item]]:
    """The component's items in groups: decisions, rules, business examples, invariants, P/O questions."""
    decisions = [Item("decision", str(n), d["question"], d.get("answer") or None)
                 for n, d in enumerate(comp.get("decisions", []) or [], 1)]
    rules = [Item("rule", r["id"], r["text"]) for r in rules_for(data, comp)]
    examples = [Item("example", e["name"], e.get("ticket") or e["name"]) for e in comp.get("examples") or []]
    invariants = [Item("invariant", i["id"], i.get("statement", ""))
                  for i in data.get("invariants", []) or [] if i.get("component") == comp["id"]]
    questions = [Item("question", q["key"], q["question"], q.get("answer")) for q in extra or []]
    return [decisions, rules, examples, invariants, questions]


def split(template, comp: dict, groups: list[list[Item]]) -> list[Task]:
    """The tasks of a component, or [] when its card is small enough to be one."""
    budget = task_items(template)
    if sum(len(g) for g in groups) <= budget:
        return []
    ctype = template.type_of(comp)
    core_n = int(ctype.get("core_questions") or 0)
    decisions, *others = groups
    units = [decisions[:core_n]]  # the core is one unit, whatever its size
    for group in [decisions[core_n:], *others]:
        units += [group[i:i + budget] for i in range(0, len(group), budget)]
    tasks = [Task(1, list(units[0]), core=True)]
    for unit in units[1:]:
        if not unit:
            continue
        if len(tasks[-1].items) + len(unit) > budget and tasks[-1].items:
            tasks.append(Task(len(tasks) + 1))
        tasks[-1].items += unit
    return tasks


def collect_marks(test_file: Path) -> dict[str, set[str]]:
    """The decisions, rules and examples a test file marks: {"decision": {"3", "P1"}, "rule": {"R2"},
    "example": {"FATTRIB-012-PAID"}} (upper case). `example` counts only as `pytest.mark.example(...)`:
    a bare `@example(...)` is Hypothesis's."""
    marks: dict[str, set[str]] = {"decision": set(), "rule": set(), "example": set()}
    if not test_file.is_file():
        return marks
    try:
        tree = ast.parse(test_file.read_text(encoding="utf-8"))
    except (SyntaxError, UnicodeDecodeError):
        logs.swallowed(log, "collect_marks: SyntaxError, UnicodeDecodeError")
        return marks
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            continue
        for deco in node.decorator_list:
            if not isinstance(deco, ast.Call):
                continue
            target = deco.func
            name = target.attr if isinstance(target, ast.Attribute) else getattr(target, "id", "")
            if name in marks and (name != "example" or isinstance(target, ast.Attribute)):
                for arg in deco.args:
                    if isinstance(arg, ast.Constant) and isinstance(arg.value, (int, str)):
                        marks[name].add(str(arg.value).strip().upper())
    return marks


def mark_done(tasks: list[Task], groups: list[list[Item]], marks: dict[str, set[str]],
              verified: dict[str, bool], coded: bool) -> None:
    """Fill in `done` for every item and task."""
    for item in (i for g in groups for i in g):
        if item.kind in ("decision", "question"):
            item.done = bool(item.answer) and item.key.upper() in marks["decision"]
        elif item.kind == "rule":
            item.done = item.key.upper() in marks["rule"]
        elif item.kind == "example":
            item.done = item.key.upper() in marks.get("example", set())
        else:
            item.done = bool(verified.get(item.key))
    for task in tasks:  # nothing is done before the code exists
        task.done = coded and all(i.done for i in task.items)


def tasks_for(root: Path, data: dict, comp: dict, template, report=None,
              extra: list[dict] | None = None) -> list[Task]:
    """The tasks of one component; with a check report, each one says whether it is done."""
    groups = items_of(data, comp, extra)
    if mode(data) != "strict":  # what the AI proposed counts as answered for its task
        proposed = ai.by_question(root)
        for item in groups[0]:
            if not item.answer and (comp["id"], int(item.key)) in proposed:
                item.answer = proposed[(comp["id"], int(item.key))]["answer"]
    tasks = split(template, comp, groups)
    if tasks and report is not None:
        status = next((c for c in report.components if c.component == comp["id"]), None)
        coded = bool(status) and status.status != "planned"
        verified = {i["id"]: bool(i.get("verified")) for i in report.invariants}
        mark_done(tasks, groups, collect_marks(root / store.test_path(comp)), verified, coded)
    return tasks


def next_task(tasks: list[Task]) -> Task | None:
    return next((t for t in tasks if not t.done), None)


# The words of a task summary in English; other languages: `words: tasks:` in their locale file.
WORDS = {"decision": ("decision", "decisions"), "rule": ("rule", "rules"), "example": ("example", "examples"),
         "core": "the file and its public API"}


def summary(task: Task, lang: str = "en") -> str:
    """'the file and its public API, decisions 1-4, rule R2, clean_orders.INV4': what a task covers."""
    words = i18n.words(lang, "tasks") or WORDS
    parts: list[str] = [words["core"]] if task.core else []
    decisions = [i.key for i in task.items if i.kind in ("decision", "question")]
    rules = [i.key for i in task.items if i.kind == "rule"]
    invariants = [i.key for i in task.items if i.kind == "invariant"]
    if decisions:
        one, many = words["decision"]
        digits = [k for k in decisions if k.isdigit()]
        if len(digits) == len(decisions) > 2 and int(digits[-1]) - int(digits[0]) == len(digits) - 1:
            parts.append(f"{many} {digits[0]}-{digits[-1]}")
        else:
            parts.append(f"{one if len(decisions) == 1 else many} {', '.join(decisions)}")
    if rules:
        one, many = words["rule"]
        parts.append(f"{one if len(rules) == 1 else many} {', '.join(rules)}")
    examples = [i.key for i in task.items if i.kind == "example"]
    if examples:
        one, many = words["example"]
        parts.append(f"{one if len(examples) == 1 else many} {', '.join(examples)}")
    if invariants:
        parts.append(", ".join(invariants))
    return ", ".join(parts)
