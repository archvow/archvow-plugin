"""File header: who wrote a component file, with which AI assistant, for which spec.

The template defines the header lines (`file_header`). archvow fills what it knows
(component, type, layer, spec, project) in the spec card; the implementer fills the rest
(author, the AI assistant used or `none`, date). `archvow check` verifies it (ARCH018):
present, filled in, about the right component and spec, and naming only an approved assistant.
"""

from __future__ import annotations

import re
from datetime import date

from archvow.foundation import logs

log = logs.get("header")

TAG_RE = re.compile(r"^\s*@(\w+)\s+(.*?)\s*$")
PLACEHOLDER_RE = re.compile(r"<[^>]*>")


def _assistants(manifest: dict) -> list[str]:
    return [*(manifest.get("ai_tools") or []), "none"] if manifest.get("ai_tools") is not None else []


def render(lines: list[str], manifest: dict, comp: dict) -> list[str]:
    """Header lines as the spec card shows them."""
    values = {"id": comp["id"], "type": comp.get("type", ""), "layer": comp.get("layer", ""),
              "spec": comp.get("spec") or "-", "project": manifest.get("system", {}).get("name", ""),
              "assistants": " | ".join(t for t in _assistants(manifest) if t != "none") + " | none"
              if _assistants(manifest) else "AI assistant used, or none"}
    return [line.format(**values) for line in lines]


def problems(docstring: str | None, lines: list[str], manifest: dict, comp: dict) -> list[str]:
    """What is wrong with a file's header (empty list: it is fine)."""
    required = [m.group(1) for m in (TAG_RE.match(line) for line in lines) if m]
    if not required:
        return []
    found = {m.group(1): m.group(2) for m in (TAG_RE.match(line) for line in (docstring or "").splitlines()) if m}
    missing = [tag for tag in required if tag not in found]
    if len(missing) == len(required):
        return ["no file header: copy it from its spec (.archvow/components/"
                f"{comp['id']}/spec.md, section 'File header')"]
    issues = [f"@{tag} is missing" for tag in missing]
    for tag, value in found.items():
        if tag in required and PLACEHOLDER_RE.search(value):
            issues.append(f"@{tag} is not filled in ({value})")
        elif tag in required and not value:
            issues.append(f"@{tag} is empty: fill it in as the spec card shows")
    if "component" in found and found["component"].split()[:1] != [comp["id"]]:
        issues.append(f"@component says '{found['component'].split()[0]}', this file is '{comp['id']}'")
    if "spec" in found and found["spec"] != (comp.get("spec") or "-"):
        issues.append(f"@spec says '{found['spec']}', the spec says '{comp.get('spec') or '-'}'")
    project = manifest.get("system", {}).get("name")
    if "project" in found and project and found["project"] != project:
        issues.append(f"@project says '{found['project']}', the project is '{project}'")
    allowed = _assistants(manifest)
    if "assisted" in found and allowed and not PLACEHOLDER_RE.search(found["assisted"]):
        named = [t.strip().lower() for t in found["assisted"].split(",") if t.strip()]
        unapproved = [t for t in named if t not in allowed]
        if unapproved:
            issues.append(f"@assisted names {', '.join(unapproved)}, approved: {', '.join(allowed)}")
    if "date" in found and not PLACEHOLDER_RE.search(found["date"]):
        try:
            date.fromisoformat(found["date"])
        except ValueError:
            logs.swallowed(log, "problems: ValueError")
            issues.append(f"@date '{found['date']}' is not a date (YYYY-MM-DD)")
    return issues
