"""What `show`, `next` and `specify` read about a component: plain data built from the spec (no
printing).
"""

from __future__ import annotations

from pathlib import Path

from archvow import examples
from archvow import proposals as ai
from archvow.checks.engine import Report
from archvow.checks.families.arch_spec import missing_contracts
from archvow.checks.run import run_check
from archvow.examples import REPORT
from archvow.foundation import logs
from archvow.foundation.errors import SpecError
from archvow.model import store
from archvow.model.spec import find_component, rule_applies, rule_scope, rules_for, to_accept
from archvow.privacy import code_columns, known_columns, personal_flow
from archvow.questions import component_questions
from archvow.spec.hazards import safety_questions, safety_suggestion
from archvow.spec.items import find_item, template_question_count
from archvow.tasks import summary, tasks_for
from archvow.templates import (
    TemplateError,
    load_template,
    template_name,
    templates_of,
)
from archvow.toreview import pending
from archvow.views import locate
from archvow.views.runline import run_lines

log = logs.get("cli")


def origin_view(item: dict) -> dict:
    """Where an item came from, for show --json: the brief (`source`), the AI agent that added it (`added_by`,
    `why`), whether a person still has to keep it (`to_accept`) and who did (`accepted`)."""
    out: dict = {}
    if isinstance(item.get("source"), dict):
        out["source"] = {k: item["source"][k] for k in ("file", "section") if item["source"].get(k)}
    if item.get("added_by"):
        out["added_by"] = item["added_by"]
        out["to_accept"] = to_accept(item)
    if item.get("why"):
        out["why"] = item["why"]
    if isinstance(item.get("accepted"), dict):
        out["accepted"] = {"by": item["accepted"].get("by"), "on": str(item["accepted"].get("on") or "")[:10]}
    return out


def safety_worksheet(root: Path, only: str | None = None) -> list[dict]:
    """Every safety question of every component (or of one), numbered, with its answer if any:
    the hazards (and the invariants that prevent them) or the dismissal; open ones carry the
    template's suggestion."""
    data = store.load(root)
    if only:
        find_component(data, only)
    hazards: dict[tuple, list[dict]] = {}
    for h in store.hazards(data):
        hazards.setdefault((h.get("component"), h.get("guide_word")), []).append(h)
    dismissed = {(d.get("component"), d.get("guide_word")): d for d in store.dismissals(data)}
    prevented: dict[str, list[dict]] = {}
    for inv in data.get("invariants", []) or []:
        for hid in inv.get("mitigates", []) or []:
            prevented.setdefault(hid, []).append({**{k: inv.get(k) for k in ("id", "statement", "verify", "from_decision")
                                                     if k != "from_decision" or inv.get(k)}, **origin_view(inv)})
    sheet = []
    for container in data["containers"]:
        template = load_template(template_name(container)[0], root)
        words = template.data.get("guide_words", {}) or {}
        for comp in container.get("components", []):
            if only and comp["id"] != only:
                continue
            questions = []
            for number, word in enumerate(safety_questions(template, comp), 1):
                key = (comp["id"], word)
                item = {"number": number, "guide_word": word, "question": words.get(word, word),
                        "status": "answered" if key in hazards or key in dismissed else "open"}
                suggestion = safety_suggestion(template, data, comp, word)
                if key in hazards:  # the template's words, or the team's own (compared, nothing stored)
                    item["hazards"] = [{**{k: h.get(k) for k in ("id", "severity", "description")},
                                        "suggested": h.get("description") == suggestion.get("hazard"),
                                        "prevented_by": prevented.get(h["id"], []), **origin_view(h)}
                                       for h in hazards[key]]
                    if any(h["severity"] in ("critical", "high") and not h["prevented_by"] for h in item["hazards"]):
                        item["suggestion"] = suggestion  # its invariant is still to write: what to write
                elif key in dismissed:
                    item["dismissed"] = dismissed[key].get("rationale", "")
                else:
                    item["suggestion"] = suggestion
                questions.append(item)
            if questions:
                sheet.append({"component": comp["id"], "type": comp["type"], "questions": questions})
    return sheet


def component_view(root: Path, data: dict, cid: str, report: Report, flows: dict | None = None) -> dict:
    """Everything about one component: decisions, rules, columns and personal data,
    P/O/C questions, safety, assumptions, status."""
    container, comp = find_component(data, cid)
    flows = personal_flow(root, data) if flows is None else flows
    template = templates_of(root, data).get(container["id"])
    ctype = template.type_of(comp) if template else {}
    classified = comp.get("columns") or {}
    in_code = [n for n, _ in code_columns(root / store.source_path(container, comp), ctype["columns"])] \
        if ctype.get("columns") else []
    columns = [{"name": n, "class": classified.get(n), "in_code": n in in_code}
               for n in [*classified, *[c for c in in_code if c not in classified]]]
    status = next((c for c in report.components if c.component == cid), None)
    suggested = template.suggested_answers(comp) if template else {}
    choices = template.choices(comp) if template else {}
    by_id = {c["id"]: c for c in container.get("components", [])}
    missing = missing_contracts(comp, ctype, by_id)
    proposed = ai.by_question(root)
    try:  # the first ones come from the template: they stay (question remove refuses them); an IDE lists the others
        from_template = template_question_count(root, data, cid) if template else 0
    except (SpecError, TemplateError):
        logs.swallowed(log, "_component_view: SpecError, TemplateError")
        from_template = 0
    decisions = [{"number": n, "question": d["question"], "answer": d.get("answer") or None,
                  "template": n <= from_template, **({"review": d["review"]} if d.get("review") else {}),
                  "suggested": suggested.get(d["question"]),
                  **({"choices": choices[d["question"]]} if d["question"] in choices else {}),
                  **({"by": d.get("by"), "on": str(d.get("on"))[:10]} if d.get("answer") and d.get("by") else {}),
                  "proposed": None if d.get("answer") else (proposed.get((cid, n)) or {}).get("answer"),
                  **({"origin": d["origin"]} if d.get("origin") else {}), **origin_view(d)}
                 for n, d in enumerate(comp.get("decisions", []) or [], 1)]
    rules = [{"id": r["id"], "text": r["text"], "scope": rule_scope(r), **origin_view(r)}
             for r in rules_for(data, comp)]
    tested = {i["id"]: i.get("verified") for i in report.invariants}
    sheet = safety_worksheet(root, cid)
    safety = sheet[0]["questions"] if sheet else []
    for q in safety:
        for h in q.get("hazards", []):
            for inv in h["prevented_by"]:
                inv["tested"] = bool(tested.get(inv["id"]))
    questions = component_questions(root, data, comp, template, flows) if template else []
    tasks = tasks_for(root, data, comp, template, report, questions) if template else []
    run = next((r for r in run_lines(data, templates_of(root, data), report) if r["component"] == cid), None)
    known = [{"component": c, "columns": names} for c, names in known_columns(root, container, comp, template)]
    return {"component": cid, "type": comp["type"], **({"kind": comp["kind"]} if comp.get("kind") else {}),
            "layer": comp.get("layer"), "known_columns": known,
            "description": comp.get("description", ""), **({"owners": comp["owners"]} if comp.get("owners") else {}),
            **({"source": comp["source"]} if comp.get("source") else {}),
            **({"origin": "ai", "created_by": comp.get("created_by")} if comp.get("origin") == "ai" else {}),
            "uses": list(comp.get("uses") or []), "used_by": locate.used_by(data, cid),
            "evidence": locate.evidence(root, data, comp), "examples": examples_view(root, comp, template), "rule_texts": rule_texts(data, comp),
            "status": status.status if status else "planned", "decisions": decisions, "rules": rules,
            "missing": missing,
            "columns": columns, "declares_columns": bool(ctype.get("columns")), "personal": flows.get(cid, {}),
            "questions": questions,
            "safety": safety, "assumptions": [{"number": n, **a} for n, a in enumerate(comp.get("assumptions", []) or [], 1)],
            "tasks": [{**t.as_dict(), "summary": summary(t)} for t in tasks], **({"run": run} if run else {}),
            "to_review": [{"item": label, "why": why} for label, why in pending(data, comp)]}


def examples_view(root: Path, comp: dict, template) -> list[dict]:
    if not comp.get("examples"):
        return []
    return examples.view(root, comp, template, examples.marked(root), examples.verdicts(root))


def rule_texts(data: dict, comp: dict) -> dict[str, str]:
    """The words of each rule an example of this component names: an invariant's statement, a rule's text."""
    named = {e.get("rule") for e in comp.get("examples") or [] if e.get("rule")}
    texts = {str(i.get("id")): str(i.get("statement", "")) for i in data.get("invariants") or [] if i.get("id") in named}
    texts.update({str(r.get("id")): str(r.get("text", "")) for r in data.get("project_rules") or [] if r.get("id") in named})
    return texts


def item_view(root: Path, data: dict, item_id: str, report: Report) -> dict:
    """One hazard, invariant or rule, with what it is linked to."""
    kind, item = find_item(data, item_id)
    view = {"kind": kind, **item}
    tested = {i["id"]: i.get("verified") for i in report.invariants}
    if kind == "hazard":
        view["prevented_by"] = [{"id": i["id"], "statement": i.get("statement"), "tested": bool(tested.get(i["id"]))}
                                for i in data.get("invariants", []) or [] if item["id"] in (i.get("mitigates") or [])]
    elif kind == "invariant":
        by_id = {h["id"]: h for h in data.get("hazards", []) or []}
        view["prevents"] = [{"id": h, "severity": by_id[h].get("severity"), "description": by_id[h].get("description")}
                            for h in item.get("mitigates") or [] if h in by_id]
        view["tested"] = bool(tested.get(item["id"]))
    else:
        view["applies_to"] = [c["id"] for container in data["containers"] for c in container.get("components", [])
                              if rule_applies(item, c)]
    return view


def report_name() -> str:
    return REPORT


def open_items(root: Path, only: str | None) -> list[dict]:
    """Everything still to specify, in order: decisions to make, then safety questions."""
    data = store.load(root)
    if only:
        find_component(data, only)
    items = []
    for container in data["containers"]:
        template = load_template(template_name(container)[0], root)
        for comp in container.get("components", []):
            if only and comp["id"] != only:
                continue
            suggested = template.suggested_answers(comp)
            choices = template.choices(comp)
            proposed = ai.by_question(root)
            for n, d in enumerate(comp.get("decisions", []) or [], 1):
                if not (d.get("answer") or "").strip():
                    items.append({"kind": "decision", "component": comp["id"], "number": n,
                                  "question": d["question"], "suggested": suggested.get(d["question"]),
                                  "choices": choices.get(d["question"], []),
                                  "proposed": (proposed.get((comp["id"], n)) or {}).get("answer"),
                                  "command": f'archvow decision make {comp["id"]} {n} "..."'})
    report = run_check(root)
    flows = personal_flow(root, data)
    for container in data["containers"]:
        for comp in container.get("components", []):
            if only and comp["id"] != only:
                continue
            view = component_view(root, data, comp["id"], report, flows)
            for c in view["columns"]:
                if not c["class"]:
                    items.append({"kind": "column", "component": comp["id"], "column": c["name"],
                                  "label": c["name"], "question": "personal, special (sensitive) or none?",
                                  "command": f"archvow column set {comp['id']} {c['name']} personal|special|none"})
            for q in view["questions"]:
                if not q["answer"]:
                    items.append({"kind": "question", "component": comp["id"], "key": q["key"],
                                  "label": q["key"], "question": q["question"],
                                  "command": f'archvow decision make {comp["id"]} {q["key"]} "..."'})
    for sheet in safety_worksheet(root, only):
        for q in sheet["questions"]:
            if q["status"] == "open":
                items.append({"kind": "safety", "component": sheet["component"], **q,
                              "command": f"archvow hazard add {sheet['component']} S{q['number']} <severity>  "
                                         f"|  archvow hazard dismiss {sheet['component']} S{q['number']} \"why\""})
    return items
