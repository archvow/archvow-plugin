"""`archvow pack check <folder>`: the architect's test of a whole pack before sharing it.

It reads every part as archvow will (pack.yaml and the archvow range, each template with what it extends, each
agent profile, each rule), creates a throwaway project from each template in each of the pack's languages (so every
file renders and every answer rule holds), checks that every language has every template's texts and files, and
proves each rule catches its bad example and passes its good one. Nothing is written in the pack.
"""

from __future__ import annotations

import tempfile
from pathlib import Path

import yaml

from archvow import agents
from archvow.foundation import logs
from archvow.foundation.errors import ArchvowError, PackError
from archvow.packs import regimes
from archvow.packs import rules as pack_rules
from archvow.packs import store as packs
from archvow.spec.answers import question_default
from archvow.spec.init import init_project
from archvow.spec.pack_parts import example_problem
from archvow.templates import load_template

log = logs.get("spec.pack_check")
SAMPLE_ANSWERS = {"architects": "@pack-check/architects"}  # a required answer a throwaway project needs


def check_pack(folder: Path) -> tuple[packs.Pack | None, list[str], list[str]]:
    """(the pack, what is wrong, what was proved)."""
    problems: list[str] = []
    proved: list[str] = []
    try:
        pack = packs.read(folder)
        packs.require_fit(pack)
    except PackError as error:
        return None, [str(error)], proved
    raw = yaml.safe_load((folder / "pack.yaml").read_text(encoding="utf-8")) or {}
    languages = [str(lang) for lang in raw.get("languages") or ["en"]]
    proved.append(f"pack.yaml: {pack.name} {pack.version}, archvow {pack.archvow or 'any'}, "
                  f"languages {', '.join(languages)}")
    for template in sorted(pack.templates.glob("*/template.yaml")):
        _check_template(folder, pack, template.parent, languages, problems, proved)
    for path in sorted(pack.agents.glob("*/agent.yaml")):
        try:
            agents.read(path.parent, pack.name)
            proved.append(f"agent {path.parent.name}: profile read")
        except PackError as error:
            problems.append(str(error))
    for path in sorted(pack.rules.glob("*.yaml")):
        try:
            rules = pack_rules.read_file(path)
        except PackError as error:
            problems.append(str(error))
            continue
        for code, rule in rules.items():
            verdict = example_problem(code, rule)
            missing = [lang for lang in languages if lang != "en" and not rule.get(f"message_{lang}")]
            if verdict:
                problems.append(verdict)
            elif missing:
                problems.append(f"{code}: no message in {', '.join(missing)} (message_{missing[0]})")
            else:
                proved.append(f"rule {code}: catches its bad example, passes its good one")
    for path in sorted((folder / "regimes").glob("*.yaml")):
        _check_regime(path, pack, languages, problems, proved)
    if not any(proved[1:]) and not problems:
        problems.append("the pack holds nothing yet: add a template, an agent, a rule or a regime (archvow pack "
                        "template|agent|rule; a regime: examples/regime.yaml)")
    return pack, problems, proved


def _check_regime(path: Path, pack: packs.Pack, languages: list[str], problems: list[str], proved: list[str]) -> None:
    """A privacy regime: its file as archvow reads it, a letter and a prefix no other regime has, every text in
    each of the pack's languages."""
    try:
        regime = regimes.read_file(path, pack=pack.name)
    except PackError as error:
        problems.append(str(error))
        return
    others = [r for r in regimes.available(None).values() if r.id != regime.id]
    clash = next((r for r in others if r.letter == regime.letter or r.prefix == regime.prefix), None)
    if clash:
        problems.append(f"regime {regime.id}: letter {regime.letter} or prefix {regime.prefix} is already "
                        f"archvow's regime {clash.id} (letter {clash.letter}, prefix {clash.prefix})")
        return
    raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    texts = [("title", raw), *[("title", r) for r in (raw.get("rules") or {}).values()],
             *[("text", q) for items in (raw.get("questions") or {}).values() for q in items or []],
             *[(k, raw.get("register") or {}) for k in ("title", "intro", "answers")]]
    for lang in [lang for lang in languages if lang != "en"]:
        missing = sum(1 for key, part in texts if part.get(key) and not part.get(f"{key}_{lang}"))
        if missing:
            problems.append(f"regime {regime.id}: {missing} text(s) without their {lang} version ({texts[0][0]}_{lang}...)")
            return
    asked = sum(len(q) for q in regime.questions.values())
    proved.append(f"regime {regime.id}: {regime.name}, {asked} question(s) {regime.letter}1..., "
                  f"{len(regime.rules)} rule(s), register {regime.register['file']}")


def _check_template(folder: Path, pack: packs.Pack, directory: Path, languages: list[str], problems: list[str],
                    proved: list[str]) -> None:
    name = f"{pack.name}/{directory.name}"
    for language in languages:
        if language != "en" and not (directory / f"template.{language}.yaml").is_file():
            problems.append(f"template {name}: no template.{language}.yaml (its texts in {language})")
        english = {p.relative_to(directory / "files").as_posix() for p in (directory / "files").rglob("*")
                   if p.is_file()} if (directory / "files").is_dir() else set()
        if language != "en" and english:
            local = directory / f"files-{language}"
            have = {p.relative_to(local).as_posix() for p in local.rglob("*") if p.is_file()} if local.is_dir() else set()
            texts = sorted(r for r in english - have if r.endswith((".md", ".md.j2")))
            if texts:
                problems.append(f"template {name}: files-{language}/ lacks {', '.join(texts[:5])}"
                                + (" ..." if len(texts) > 5 else ""))
        try:
            template = load_template(name, None, language=language, extra=(folder,))
        except ArchvowError as error:
            problems.append(f"template {name}: {error}")
            return
        if template.data.get("abstract"):
            proved.append(f"template {name} ({language}): read (a base others extend)")
            continue
        answers = dict(SAMPLE_ANSWERS)
        for question in template.data.get("questions", []):
            if question.get("required") and question["id"] not in answers and \
                    question_default(template, question, answers) in (None, ""):
                problems.append(f"template {name}: required answer '{question['id']}' has no default - "
                                "pack check cannot try it; give it a default or an example")
                return
        if any(q.get("id") == "language" for q in template.data.get("questions", [])):
            answers["language"] = language
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "project"
            (target / packs.PROJECT_PACKS).mkdir(parents=True)
            packs.copy_in(target, folder)
            try:
                written = init_project(target, name, "pack_check", None, answers)
            except ArchvowError as error:
                problems.append(f"template {name} ({language}): a project from it fails: {error}")
                continue
        proved.append(f"template {name} ({language}): a project from it writes {len(written)} files")
