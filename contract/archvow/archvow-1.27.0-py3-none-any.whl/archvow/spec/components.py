"""`archvow component add|edit|remove`: what must exist - its type, name, description, uses, routes,
the file it lives in.
"""

from __future__ import annotations

import keyword
import re
from pathlib import Path

from archvow import toreview
from archvow.branches import check_ticket
from archvow.checks.code import symbols_of_file
from archvow.checks.layers import file_layer_of
from archvow.foundation.errors import SpecError
from archvow.foundation.text import one_line
from archvow.limits import refuse_new_component
from archvow.model import store
from archvow.model.spec import (
    find_component,
)
from archvow.spec.project_files import (
    _load,
)
from archvow.templates import (
    Template,
    edge_case_text,
    load_template,
    template_name,
)

GROUP_RE = re.compile(r"^[a-z][a-z0-9_]*$")


def _check_group(group: str | None) -> str | None:
    """A group is one folder level inside a layer: a snake_case name, or none."""
    if group is None or not group.strip():
        return None
    group = group.strip()
    if not GROUP_RE.fullmatch(group) or keyword.iskeyword(group):
        raise SpecError(f"group '{group}' must be a snake_case folder name, e.g. orders")
    return group


def add_component(root: Path, type_name: str, name: str, description: str, *,
                  spec: str | None = None, uses: list[str] | None = None,
                  signature: str | None = None, container_id: str | None = None,
                  group: str | None = None, routes: list[str] | None = None, source: dict | None = None,
                  kind: str | None = None, file: str | None = None, created_by: str | None = None) -> dict:
    """Declare a component. `created_by`: the AI agent that ran the command (modes guided and free) - the
    component is marked `origin ai` until a person accepts it (archvow component accept). Writes the spec only: no source or test files. A type with kinds (a
    reader: files, table, jdbc...) takes its kind's symbols and questions (default: the first kind).
    `file` adopts an existing module where it is: its layer comes from `layer_paths`, its symbols are
    the public functions, classes, constants and routes the file has today."""
    data, container, template = _load(root, container_id)
    ctype = template.component_types.get(type_name)
    if ctype is None:
        addable = [k for k, v in template.component_types.items() if v.get("addable", True)]
        raise SpecError(f"unknown component type '{type_name}' (available: {', '.join(addable)})")
    if not ctype.get("addable", True):
        raise SpecError(f"component type '{type_name}' is managed by the template")
    pattern = ctype.get("name_pattern", r"^[a-z][a-z0-9_]*$")
    if keyword.iskeyword(name):
        raise SpecError(f"name '{name}' is a Python keyword: choose another name")
    if not re.fullmatch(pattern, name):
        hint = ctype.get("name_hint", "")
        raise SpecError(f"name '{name}' must match {pattern}" + (f" ({hint})" if hint else ""))
    if not description.strip():
        raise SpecError("a description is required")
    description = one_line(description)
    kinds = template.kinds(type_name)
    if kind and not kinds:
        raise SpecError(f"type '{type_name}' has no kinds: leave -k out")
    if kind and kind not in kinds:
        raise SpecError(f"unknown kind '{kind}' for a {type_name} (available: {', '.join(kinds)})")
    if kinds:
        kind = kind or kinds[0]
        ctype = template.type_of({"type": type_name, "kind": kind})
    if signature and not ctype.get("signature_overridable", False):
        raise SpecError(f"type '{type_name}' has a fixed signature")

    group = _check_group(group)
    fmt = store.name_values(name)
    component_id = ctype["module"].format(**fmt)
    layer = ctype["layer"]
    components = container.setdefault("components", [])
    if any(c["id"] == component_id for c in components):
        raise SpecError(f"component '{component_id}' already exists")
    refused = refuse_new_component(data, container.get("package", "<package>"))
    if refused:
        raise SpecError(refused)
    import difflib

    near = difflib.get_close_matches(component_id, [c["id"] for c in components], n=3, cutoff=0.85)
    warnings = [(f"{', '.join(near)} already {'exists' if len(near) == 1 else 'exist'}, with almost the same name: "
                 f"reuse {'it' if len(near) == 1 else 'one of them'} if it does the same job "
                 f"(archvow component remove {component_id})")] if near else []
    by_id = {c["id"]: c for c in components}
    allowed = (template.layer(layer) or {}).get("may_import", [])
    for used in uses or []:
        if used not in by_id:
            raise SpecError(f"--uses: unknown component '{used}'")
        if by_id[used]["layer"] != layer and by_id[used]["layer"] not in allowed:
            raise SpecError(f"layer '{layer}' may not depend on '{used}' (layer '{by_id[used]['layer']}')")

    symbols = []
    for index, sym in enumerate(ctype.get("symbols", [])):
        entry = {"kind": sym.get("kind", "function"), "name": sym["name"].format(**fmt)}
        if signature and index == 0:
            entry["signature"] = signature
        elif "signature" in sym:
            entry["signature"] = sym["signature"]
        if "annotation" in sym:
            entry["annotation"] = sym["annotation"]
        symbols.append(entry)

    symbols += _routes(ctype, routes)
    folder = f"{group}." if group else ""
    module = f"{container['package']}.{layer}.{folder}{component_id}"
    if file:
        if group or routes or signature:
            raise SpecError("--file keeps the file as it is: leave out --group, --route and --signature")
        module, symbols = _adopted_module(root, data, container, template, file, layer, type_name)
        if any(c.get("module") == module for c in components):
            raise SpecError(f"{file} is already a component")
    entry = {"id": component_id, "name": name, "type": type_name, **({"kind": kind} if kinds else {}),
             "layer": layer, "module": module}
    if file:
        entry["adopted"] = True
    if group:
        entry["group"] = group
    if spec:
        check_ticket(data, spec.strip())
        entry["spec"] = spec
    entry["description"] = description.strip()
    entry["uses"] = list(uses or [])
    entry["symbols"] = symbols
    # Ambiguity is resolved by a human before coding, never silently by the implementer.
    entry["decisions"] = [{"question": edge_case_text(q), "answer": None} for q in ctype.get("edge_cases", [])]
    entry["assumptions"] = []
    if source:
        entry["source"] = source
    if created_by:
        entry["origin"] = "ai"          # a person accepts it: archvow component accept <id>
        entry["created_by"] = created_by
    components.append(entry)
    store.save(root, data)
    return {**entry, **({"warnings": warnings} if warnings else {})}


def _adopted_module(root: Path, data: dict, container: dict, template: Template, file: str, layer: str,
                    type_name: str) -> tuple[str, list[dict]]:
    """Module and current symbols of an existing file declared with --file, checked against its layer."""
    rel = file.replace("\\", "/").removeprefix("./")
    path = root / rel
    base = (root / container["path"]).resolve()
    if not path.is_file() or path.suffix != ".py":
        raise SpecError(f"--file {file}: no such Python file (give its path from the project root)")
    if not path.resolve().is_relative_to(base):
        raise SpecError(f"--file {file}: not inside {container['path']}/, the package archvow checks")
    if path.name == "__init__.py":
        raise SpecError(f"--file {file}: a package __init__ is not a component; declare a module file")
    parts = path.resolve().relative_to(base).with_suffix("").parts
    module = ".".join([container["package"], *parts])
    found = file_layer_of(root, data, template, rel, module)
    if found != layer:
        raise SpecError(f"--file {file} is in layer {found or 'none'}, a {type_name} belongs in {layer}: an "
                        f"architect maps it in `layer_paths` of .archvow/spec.vow ({layer}: [{rel}]), or "
                        f"archvow init {container['package']} --force --adopt proposes the mapping")
    try:
        symbols = symbols_of_file(path.read_text(encoding="utf-8"))
    except SyntaxError as exc:
        raise SpecError(f"--file {file}: cannot be parsed ({exc.msg})") from exc
    return module, symbols


ROUTE_RE = re.compile(r"^\s*([a-z_][a-z0-9_]*)\s*:\s*(GET|POST|PUT|PATCH|DELETE)\s+(/\S*)\s*$")


def _routes(ctype: dict, routes: list[str] | None) -> list[dict]:
    """`name: METHOD /path` entries, for component types that declare routes (`routes: true`)."""
    if not routes:
        return []
    if not ctype.get("routes"):
        raise SpecError("--route: this component type has no routes")
    result, seen = [], set()
    for text in routes:
        match = ROUTE_RE.fullmatch(text)
        if not match:
            raise SpecError(f"--route '{text}': write it as \"<function>: <METHOD> <path>\", "
                            "e.g. \"get_order: GET /orders/{order_id}\"")
        name, method, path = match.groups()
        if name in seen or (method, path) in {(r["method"], r["path"]) for r in result}:
            raise SpecError(f"--route '{text}': declared twice")
        seen.add(name)
        result.append({"kind": "route", "name": name, "method": method, "path": path})
    return result


def edit_component(root: Path, component_id: str, *, description: str | None = None,
                   spec: str | None = None, uses: list[str] | None = None,
                   signature: str | None = None, group: str | None = None,
                   routes: list[str] | None = None, source: dict | None = None,
                   owners: list[str] | None = None) -> dict:
    """Change what may change after creation. Name, type and file stay fixed: remove and re-add.

    When the description, the signature or the routes change, every item recorded before (decisions,
    hazards, invariants, not applicable, accepted assumptions, examples) is marked to review (ARCH057):
    the returned component lists them under `to_review`."""
    import copy


    data = store.load(root)
    container, comp = find_component(data, component_id)
    before = copy.deepcopy(comp)
    template = load_template(template_name(container)[0], root)
    ctype = template.type_of(comp)
    if description is not None:
        if not description.strip():
            raise SpecError("a description is required")
        comp["description"] = one_line(description)
    if spec is not None:
        if spec.strip():
            check_ticket(data, spec.strip())
        comp["spec"] = spec.strip()
    if uses is not None:
        by_id = {c["id"]: c for c in container.get("components", [])}
        allowed = (template.layer(comp["layer"]) or {}).get("may_import", [])
        for used in uses:
            if used not in by_id or used == component_id:
                raise SpecError(f"--uses: unknown component '{used}'")
            if by_id[used]["layer"] != comp["layer"] and by_id[used]["layer"] not in allowed:
                raise SpecError(f"layer '{comp['layer']}' may not depend on '{used}'")
            loop = _path_to(by_id, used, component_id)
            if loop:
                raise SpecError(f"--uses: '{component_id}' -> {' -> '.join(loop)} would be a cycle "
                                "(the code could not import itself)")
        comp["uses"] = list(uses)
    if signature is not None:
        if not ctype.get("signature_overridable", False):
            raise SpecError(f"type '{comp['type']}' has a fixed signature")
        if not comp.get("symbols") or comp["symbols"][0].get("kind", "function") != "function":
            raise SpecError(f"'{component_id}' has no function signature to change")
        comp["symbols"][0]["signature"] = signature.strip()
    if group is not None:  # "" takes it out of its group
        new_group = _check_group(group)
        comp.pop("group", None)
        if new_group:
            comp["group"] = new_group
        comp["module"] = ".".join([container["package"], comp["layer"], *([new_group] if new_group else []), comp["id"]])
    if routes is not None:  # the complete new list of routes
        comp["symbols"] = [s for s in comp.get("symbols", []) if s.get("kind") != "route"] + _routes(ctype, routes)
    if source:
        comp["source"] = source
    if owners is not None:  # [] gives the component back to the architects
        bad = [o for o in owners if "@" not in o]
        if bad:
            raise SpecError(f"--owners: '{bad[0]}' is not an owner - @user, @group/subgroup or an e-mail")
        if owners:
            comp["owners"] = list(dict.fromkeys(owners))
        else:
            comp.pop("owners", None)
    marked = toreview.mark(data, comp, toreview.what_changed(before, comp))
    store.save(root, data)
    return {**comp, "to_review": marked}


def _path_to(by_id: dict, start: str, target: str) -> list[str]:
    """The `uses` path from start to target ([] when target cannot be reached)."""
    stack, seen = [[start]], set()
    while stack:
        path = stack.pop()
        if path[-1] == target:
            return path
        if path[-1] in seen:
            continue
        seen.add(path[-1])
        stack += [[*path, nxt] for nxt in (by_id.get(path[-1], {}).get("uses") or [])]
    return []


def remove_component(root: Path, component_id: str) -> dict:
    """Remove a component from the spec, with the hazards and invariants that belong to it."""
    data = store.load(root)
    container, comp = find_component(data, component_id)
    if comp.get("type") == "foundation":
        raise SpecError(f"'{component_id}' is a template foundation and cannot be removed")
    users = [c["id"] for c in container.get("components", []) if component_id in (c.get("uses") or [])]
    if users:
        raise SpecError(f"'{component_id}' is used by {', '.join(users)}: remove it from their "
                        f"`uses` first (archvow component edit <component> -u ...)")
    container["components"] = [c for c in container["components"] if c["id"] != component_id]
    hazards = [h for h in data.get("hazards", []) or [] if h.get("component") == component_id]
    hazard_ids = {h["id"] for h in hazards}
    data["hazards"] = [h for h in data.get("hazards", []) or [] if h.get("component") != component_id]
    invariants = [i for i in data.get("invariants", []) or []
                  if i.get("component") == component_id or set(i.get("mitigates") or []) <= hazard_ids
                  and i.get("mitigates")]
    data["invariants"] = [i for i in data.get("invariants", []) or [] if i not in invariants]
    if data.get("dismissed"):
        data["dismissed"] = [d for d in data["dismissed"] if d.get("component") != component_id]
    for rule in data.get("project_rules") or []:
        listed = (rule.get("scope") or {}).get("components")
        if listed and component_id in listed:
            listed.remove(component_id)
    if data.get("project_rules"):
        data["project_rules"] = [r for r in data["project_rules"]
                                 if (r.get("scope") or {}).get("components", True)]
    store.save(root, data)
    return {"component": component_id, "hazards": sorted(hazard_ids),
            "invariants": sorted(i["id"] for i in invariants)}
