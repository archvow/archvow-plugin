"""`archvow init`: a new project from a template, or an existing one rewritten (--force) with its committed
spec and answers kept; the starting components; a project's language changed.
"""

from __future__ import annotations

import keyword
import shlex
from pathlib import Path
from typing import cast

from jinja2 import Environment

from archvow import __version__, agents, templates
from archvow.branches import ticket_example
from archvow.briefs import folder_problems
from archvow.dora import normalise, requirements
from archvow.examples import GITIGNORE as EXAMPLES_GITIGNORE
from archvow.foundation import logs
from archvow.foundation.errors import SpecError
from archvow.foundation.files import write_text
from archvow.foundation.git import succeeds
from archvow.foundation.i18n import DEFAULT_LANGUAGE
from archvow.model import store
from archvow.model.spec import (
    stamp,
)
from archvow.packs import store as packs
from archvow.spec.answers import (
    DEFAULT_TEMPLATE,
    PACKAGE_RE,
    _env,
    answers_with_defaults,
    auto_approval,
    derive,
    dora_approvers_problem,
    rules_answer,
    rules_context,
    verbatim_prefixes,
)
from archvow.spec.project_files import (
    AGENT_GITIGNORE,
    GITATTRIBUTES,
    REVIEW_GITIGNORE,
    _existing_tooling,
    _pytest_configured,
    _render,
    _write_skill,
    merge_gitignore,
    merge_marked,
    write_agent_files,
)
from archvow.templates import (
    Template,
    edge_case_text,
    load_template,
)

log = logs.get("specs")


def init_command(template_name: str, package: str, description: str, answers: dict) -> str:
    """The `archvow init` command line that creates this project (shown in its README)."""
    first = f"archvow init {package} -t {template_name} -d {shlex.quote(description)}"
    options = [f"-a {shlex.quote(f'{key}={value}')}" for key, value in answers.items()
               if value not in ("", [], None)]  # an empty answer is the default: not worth showing
    return first + (" \\\n    " + " ".join(options) if options else "")


def spec_committed(root: Path) -> bool:
    """True when the spec is in Git: it is then the team's, and init never resets it."""
    return succeeds(root, "ls-files", "--error-unmatch", str(store.PROJECT_REL))


def _existing_project(root: Path) -> dict | None:
    """The spec of the project already in `root`, if any (None: no project, or unreadable)."""
    if not store.is_project(root):
        return None
    try:
        return store.load(root)
    except store.ManifestError:
        logs.swallowed(log, "_existing_project: store.ManifestError")
        return None


def _already_a_project(root: Path, data: dict | None, package: str) -> str:
    if data is None:
        return f"{root / store.PROJECT_REL} already exists: this folder is already an archvow project"
    container = (data.get("containers") or [{}])[0]
    count = len(container.get("components", []) or [])
    name = container.get("package", package)
    return (f"this folder is already the archvow project '{name}' ({container.get('template', '?')}, "
            f"{count} components): nothing to initialise.\n"
            "  To work on it:  pip install -r requirements.txt, then: archvow next\n"
            "  To rewrite the generated files (AGENTS.md, CI, hooks...) from the template, keeping the spec:\n"
            f"                  archvow init {name} --force -a architects=...")


def init_project(root: Path, template_name: str | None, package: str, description: str | None,
                 answers: dict | None = None, src: str = "src", force: bool = False) -> list[Path]:
    """Add archvow to a repository (new or existing). Creates no source folders.

    In a folder that is already a project, `init` refuses. With `force` it rewrites the generated
    files; once the manifest is committed it keeps the spec (components, decisions, hazards,
    invariants): only `git rm -r .archvow` - a visible, reviewed change - starts over.
    """
    if not PACKAGE_RE.match(package) or keyword.iskeyword(package):
        raise SpecError(f"'{package}' is not a valid snake_case Python package name")
    existing = _existing_project(root)
    if store.is_project(root) and not force:
        raise SpecError(_already_a_project(root, existing, package))
    committed = existing is not None and spec_committed(root)
    kept = existing if committed else None
    answers = dict(answers or {})
    if kept is not None:
        container = kept["containers"][0]
        kept_template = templates.template_name(container)[0]
        if container.get("package") != package:
            raise SpecError(f"this project's package is '{container.get('package')}', not '{package}': "
                            f"archvow init {container.get('package')} --force ...")
        if template_name is not None and templates.resolve(template_name, root) != templates.resolve(kept_template, root):
            raise SpecError(f"this project uses template '{kept_template}', not '{template_name}' "
                            "(changing the template of a committed spec is not supported)")
        template_name = kept_template
        description = description or kept.get("system", {}).get("description")
        # the answers given at init stay, unless given again: --force changes only what is passed
        answers = {**(kept.get("init_answers") or {}), **answers}
        for key in APPROVALS:  # the current approvals, as the manifest holds them
            stored = kept.get(key) if key != "rules" else None
            if key not in answers and stored is not None:
                answers[key] = stored if isinstance(stored, str) else ",".join(stored)
    template_name = template_name or DEFAULT_TEMPLATE
    description = description or package.replace("_", " ").capitalize()
    template = load_template(template_name, root if root.is_dir() else None, language=DEFAULT_LANGUAGE)
    if template.data.get("abstract"):
        raise SpecError(f"template '{template.name}' is a shared base that other templates extend; "
                        "choose one of them (archvow catalog)")
    if kept is not None and "rules" not in answers:  # the rules the project runs today
        answers["rules"] = rules_answer(template, kept)
    asks_language = any(q.get("id") == "language" for q in template.data.get("questions", []))
    old_language = (kept.get("language") or DEFAULT_LANGUAGE) if kept is not None else None
    if kept is not None and asks_language and "language" not in answers:
        answers["language"] = old_language  # a project keeps its language
    language = answers_with_defaults(template, answers).get("language") if asks_language else None
    language = str(language or DEFAULT_LANGUAGE)
    template = load_template(template_name, root if root.is_dir() else None, language=language)
    known = agents.profiles(root if root.is_dir() else None)
    company_pattern = (template.data.get("questions_defaults") or {}).get("ticket_pattern")
    if company_pattern and "ticket_pattern" not in answers:  # a company template's pattern is the project's
        answers["ticket_pattern"] = str(company_pattern)
    context = {
        "init_command": init_command(template.qualified, package, description, answers),
        "package": package,
        "project_name": package.replace("_", "-"),
        "description": description,
        "template": template.ref,
        "layers": template.layers,
        "src": src,
        "archvow_version": __version__,
        "pytest_configured": _pytest_configured(root),
        **_existing_tooling(root, src),
        "ai_tool_names": {name: p.title for name, p in known.items() if p.title},
        "known_ai_tools": sorted(known),
        **template.data.get("context", {}),
        **answers_with_defaults(template, answers),
    }
    context["ticket_pattern_set"] = "ticket_pattern" in answers  # set by the architect, or not yet
    context.update(rules_context(template, context.get("rules")))
    pattern = answers.get("ticket_pattern")
    context["ticket"] = lambda number=1: ticket_example(pattern, number)  # examples use the project's tickets
    if "reviewers" in context and "none" in (context["reviewers"] or []):
        context["reviewers"] = []  # `none`: no AI reviewer
    context["instructed_tools"] = store.instructed_tools(context)
    context["agents_approved"] = [t for t in context.get("ai_tools") or [] if t != "none"]  # agents write code
    context["ai_tool_review"] = {name: p.review for name, p in known.items() if p.review}
    context["review_secrets"] = [entry["secret"] for tool in context.get("reviewers") or []
                                 if (entry := context["ai_tool_review"].get(tool) or {}).get("secret")]
    context.update(derive(template, context))
    context["auto"] = auto_approval(template, context)  # what the AI may do without asking
    if dora_approvers_problem(template, context):  # caught here, not at the first commit (DORA002)
        raise SpecError(dora_approvers_problem(template, context))
    if "briefs" in context:  # the briefs folders: in the project, not hidden, not code or tests, not nested
        problems = folder_problems(list(context["briefs"] or []), f"{src}/{package}")
        if problems:
            raise SpecError("answer 'briefs': " + "; ".join(problems))
    root.mkdir(parents=True, exist_ok=True)  # only once every answer is valid
    instructed = [agents.profile(tool, root, known) for tool in context["instructed_tools"]]
    guarded = tuple(template.data.get("protected_paths") or [])
    context["ai_instruction_paths"] = sorted({  # an approved agent's own file no guard covers yet
        rel.removesuffix(".j2") for p in instructed for rel in p.files(language)
        if not any(rel == g or rel.startswith(g.rstrip("/") + "/") for g in guarded)})
    env = _env()
    conditions = template.data.get("file_conditions", {}) or {}
    skeleton = template.skeleton_files()
    if "AGENTS.md.j2" in skeleton:  # tool-specific rule files embed the shared rules
        context["agents_rules"] = template.rename_layers(
            env.from_string(skeleton["AGENTS.md.j2"].read_text("utf-8")).render(**context))
    written: list[Path] = []
    verbatim = verbatim_prefixes(template)  # copied as they are, even .j2
    for rel, source in skeleton.items():
        if rel.startswith("skills/"):  # one source: .agents/skills, and the folder of each agent that reads elsewhere
            written += _write_skill(root, rel, source, instructed, context, env, template, force)
            continue
        as_is = rel.startswith(verbatim) if verbatim else False
        target_rel = rel[:-3] if rel.endswith(".j2") and not as_is else rel
        if "{{" in target_rel:  # a file named after the project, e.g. dags/{{ package }}_dag.py
            target_rel = env.from_string(target_rel).render(**context)
        target_rel = template.rename_layers(target_rel)
        matches = [prefix for prefix in conditions if target_rel.startswith(prefix)]
        rule = conditions[max(matches, key=len)] if matches else None  # most specific prefix wins
        if rule is not None and not env.compile_expression(rule)(**context):
            if force and target_rel in (template.data.get("withdrawn_files") or []):
                (root / target_rel).unlink(missing_ok=True)  # its condition turned false: it goes
            continue
        target = root / target_rel
        merged = target_rel in (template.data.get("merged_files") or [])
        if target.exists() and not force and not merged:
            continue  # never overwrite a file the team already owns (e.g. ruff.toml, CODEOWNERS)
        content = source.read_text(encoding="utf-8")
        if rel.endswith(".j2") and not as_is:  # rendered, with the layers' folders the template names
            content = template.rename_layers(env.from_string(content).render(**context))
        if merged:
            content = merge_marked(target, content, language, force=force, ours=existing is not None)
            if content is None:
                continue
        target.parent.mkdir(parents=True, exist_ok=True)
        write_text(target, content)
        if target_rel in (template.data.get("executable_files") or []):
            target.chmod(0o755)
        written.append(target)
    for profile in instructed:  # each approved agent's own files (its rules, its permissions)
        written += write_agent_files(root, profile, context, env, template, language, force)
    ignored = merge_gitignore(root, [*(template.data.get("gitignore", []) or []), *AGENT_GITIGNORE,
                                     *EXAMPLES_GITIGNORE, *(REVIEW_GITIGNORE if context.get("reviewers") else [])])
    if ignored:
        written.append(ignored)
    attributes = merge_gitignore(root, GITATTRIBUTES, ".gitattributes")
    if attributes:
        written.append(attributes)
    if kept is not None:  # the committed spec stays; only the approvals follow the answers
        _store_answers(kept, context, answers, template)
        kept["containers"][0]["template"] = template.ref  # the files now come from this version
        _add_new_starting_components(kept, template, env, context)
        _register_template_parties(root, kept, template)
        record_added_packs(root, kept)
        if asks_language and old_language != language:  # the template's own texts follow the language
            previous = load_template(template_name, root, language=old_language)
            relocalize(kept, previous, template)
        if asks_language:
            kept["language"] = language
        written.append(store.save(root, kept))
        return written
    initial = [_starting_component(env, component, context)
               for component in template.data.get("initial_components", [])]
    data = {
        "schema_version": store.SCHEMA_VERSION,
        "system": {"name": package, "description": description},
        "containers": [{
            "id": package, "template": template.ref, "package": package,
            "path": f"{src}/{package}", "components": initial,
        }],
        "hazards": [],
        "invariants": [],
        "rules": {},
    }
    if asks_language:
        data["language"] = language
    _store_answers(data, context, answers, template)
    _register_template_parties(root, data, template)
    record_added_packs(root, data)
    written.append(store.save(root, data))
    return written


def record_added_packs(root: Path, data: dict) -> None:
    """The packs `archvow pack add` copied before this project had a spec: recorded now, with the source it noted
    beside the copy (.archvow/packs/<name>.source), which then goes."""
    for pack in packs.project_packs(root):
        note = root / packs.PROJECT_PACKS / f"{pack.name}.source"
        if pack.name in packs.recorded(data) or not note.is_file():
            continue
        packs.record(data, pack, note.read_text(encoding="utf-8").strip())
        note.unlink()


def _starting_component(env: Environment, component: dict, context: dict) -> dict:
    """One of the template's starting components (foundations), its questions open."""
    rendered = cast(dict, _render(env, component, context))
    rendered["decisions"] = [{"question": edge_case_text(q), "answer": None} for q in rendered.pop("edge_cases", []) or []]
    rendered["assumptions"] = []
    return rendered


def _add_new_starting_components(data: dict, template: Template, env: Environment, context: dict) -> list[str]:
    """`init --force` with a newer template: the starting components it gained (e.g. logging_setup in
    fastapi-service 1.22.0) join the spec, planned, after the existing ones of their kind; nothing else
    changes. Returns their ids."""
    components = data["containers"][0].setdefault("components", [])
    present = {c["id"] for k in data.get("containers") or [] for c in k.get("components") or []}
    added = [_starting_component(env, c, context) for c in template.data.get("initial_components", []) or []
             if c.get("id") not in present]
    if added:
        last = max((i for i, c in enumerate(components) if c.get("type") == added[0].get("type")), default=-1)
        components[last + 1:last + 1] = added
    return [c["id"] for c in added]


def _register_template_parties(root: Path, data: dict, template: Template) -> None:
    """With DORA on: the template's own packages (pyspark, ruff, pytest...) enter the third-party
    register with their supplier, licence and criticality; the project's others are added with
    `archvow dependency add`. A package the register already has is never changed."""
    if "dora" not in (data.get("compliance") or []):
        return
    present = {normalise(name) for name, _, _ in requirements(root)}
    register = data.setdefault("third_parties", [])
    known = {normalise(e.get("name", "")) for e in register}
    for entry in template.data.get("third_parties") or []:
        if normalise(entry["name"]) in present and normalise(entry["name"]) not in known:
            register.append({**entry, **stamp(root)})
    register.sort(key=lambda e: normalise(e["name"]))
    if not register:
        data.pop("third_parties")


def relocalize(data: dict, old: Template, new: Template) -> None:
    """Replace the texts the template wrote into the manifest by the same texts in the new language.

    The questions of each component type, and the descriptions and questions of the starting
    components, are matched by position; anything a person wrote stays as it is.
    """
    for comp in (data.get("containers") or [{}])[0].get("components", []) or []:
        before = old.type_of(comp)
        after = new.type_of(comp)
        pairs = list(zip(map(edge_case_text, before.get("edge_cases") or []), map(edge_case_text, after.get("edge_cases") or []),
                         strict=False))
        initial_old = next((c for c in old.data.get("initial_components", []) if c.get("id") == comp["id"]), None)
        initial_new = next((c for c in new.data.get("initial_components", []) if c.get("id") == comp["id"]), None)
        if initial_old and initial_new:
            pairs += list(zip(map(edge_case_text, initial_old.get("edge_cases") or []),
                              map(edge_case_text, initial_new.get("edge_cases") or []), strict=False))
            if comp.get("description") == initial_old.get("description"):
                comp["description"] = initial_new.get("description", comp["description"])
        mapping = dict(pairs)
        for decision in comp.get("decisions", []) or []:
            decision["question"] = mapping.get(decision.get("question"), decision.get("question"))


# Init answers kept as approvals at the top of the manifest (protected: a new one is ARCH020).
APPROVALS = ("ai_tools", "reviewers", "dependencies", "mode", "rules")


def _store_answers(data: dict, context: dict, answers: dict, template: Template) -> None:
    """Approvals the checks use, and every init answer as it is now - given with -a or asked, or the
    template's default - so `init --force` keeps them: a project changes only when an architect
    changes an answer, never because a template's default changed. The ticket pattern is recorded
    only once an architect sets it (until then the hooks say how)."""
    if "ai_tools" in context:
        data["ai_tools"] = context["ai_tools"]  # approved assistants (protected, checked by ARCH040)
    if context.get("reviewers"):
        data["reviewers"] = context["reviewers"]  # approved AI reviewers (ARCH041, ARCH042)
    else:
        data.pop("reviewers", None)
    if "dependencies" in context:
        data["dependencies"] = context["dependencies"]  # approved third-party imports (ARCH023)
    if "compliance" in context:  # the compliance families of `rules` (gdpr, us-privacy, tst, dora...); a guard
        data["compliance"] = list(context["compliance"] or ["none"])
    if "mode" in context:  # how much the AI decides on its own (proposals.py); loosening it is a weakening
        data["mode"] = context["mode"] or "strict"
    if "families" in context:  # the code families of `rules` check applies (the floor stays)
        data["families"] = list(context["families"])
    kept = {}
    for question in template.data.get("questions", []):
        qid = question["id"]
        if qid in APPROVALS or (qid == "ticket_pattern" and qid not in answers):
            continue
        value = answers[qid] if qid in answers else context.get(qid)
        if isinstance(value, list):
            value = ",".join(str(v) for v in value)
        if value is not None:
            kept[qid] = value
    kept |= {k: v for k, v in answers.items() if k not in APPROVALS and k not in kept}
    if kept:
        data["init_answers"] = kept
