"""ARCH rules on the project's files around its code, once per check: AI assistants' files approved (ARCH040),
third-party imports and packages approved (ARCH023, ARCH024), no Python file outside the architecture (ARCH015),
tests laid out like the components (ARCH016), each component's task short enough for one AI session (ARCH044),
nothing in .archvow/ that archvow does not write (ARCH050).
"""

from __future__ import annotations

import ast
import re
import sys
import tomllib
from pathlib import Path

from archvow import agents
from archvow.checks.engine import IGNORED_DIRS, Checker, Violation
from archvow.foundation import logs
from archvow.foundation.text import tokens
from archvow.model import store
from archvow.model.spec import mode
from archvow.review import check_reports
from archvow.templates import Template

log = logs.get("check")


REQUIREMENT_RE = re.compile(r"^\s*([A-Za-z0-9][A-Za-z0-9._-]*)")


def _pep503(name: str) -> str:
    """A package name as pip compares it: PyYAML, pyyaml and py_yaml are one package."""
    return re.sub(r"[-_.]+", "-", name).lower()


def _requirement_names(path: Path) -> list[tuple[str, int]]:
    """The packages a requirements file lists (options, -r, -e and URLs are not packages)."""
    if not path.is_file():
        return []
    found = []
    for number, line in enumerate(path.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
        text = line.split("#", 1)[0].strip()
        if not text or text.startswith(("-", "{", "git+", "http")) or ("://" in text and "@" not in text):
            continue
        match = REQUIREMENT_RE.match(text)
        if match:
            found.append((match.group(1), number))
    return found


def _pyproject_names(path: Path) -> list[tuple[str, int]]:
    """The packages of [project] dependencies and optional-dependencies (not the build tools)."""
    if not path.is_file():
        return []
    text = path.read_text(encoding="utf-8", errors="replace")
    try:
        project = tomllib.loads(text).get("project") or {}
    except tomllib.TOMLDecodeError:
        logs.swallowed(log, "_pyproject_names: tomllib.TOMLDecodeError")
        return []
    entries = list(project.get("dependencies") or [])
    for extra in (project.get("optional-dependencies") or {}).values():
        entries += list(extra or [])
    lines = text.splitlines()
    found = []
    for entry in entries:
        match = REQUIREMENT_RE.match(str(entry))
        if match:
            number = next((n for n, line in enumerate(lines, 1) if str(entry) in line), 0)
            found.append((match.group(1), number))
    return found


def _template_packages(template: Template) -> list[str]:
    """The packages the template itself writes into requirements.txt and pyproject.toml."""
    names = []
    for rel, source in template.skeleton_files().items():
        if rel in ("requirements.txt.j2", "requirements.txt"):
            names += [n for n, _ in _requirement_names(source)]
        elif rel in ("pyproject.toml.j2", "pyproject.toml"):
            text = source.read_text(encoding="utf-8")
            for pattern in (r"^dependencies\s*=\s*\[(.*?)\]", r"^\[project\.optional-dependencies\](.*?)(?:^\[|\Z)"):
                block = re.search(pattern, text, re.DOTALL | re.MULTILINE)
                names += re.findall(r'"([A-Za-z0-9][A-Za-z0-9._-]*)', block.group(1)) if block else []
    return names


def _is_local_module(folder: Path, name: str) -> bool:
    """True when `name` is a module or package next to the importing file."""
    return (folder / f"{name}.py").is_file() or (folder / name / "__init__.py").is_file()


def generated_python_folders(template: Template) -> set[str]:
    """Top folders where the template itself writes Python files (an Airflow DAG in dags/): always
    allowed, whatever a company template's `allowed_paths` says."""
    folders = set()
    for rel in template.skeleton_files():
        target = rel.removesuffix(".j2")
        if target.endswith(".py") and "/" in target and not target.startswith("."):
            folders.add(target.split("/", 1)[0])
    return folders


def check_ai_tools(checker: Checker, templates: list[Template]) -> None:
    """ARCH040: files of AI assistants that are not approved in the vow."""
    approved = store.instructed_tools(checker.manifest)  # reviewers have their tool's files too
    if not templates:
        return
    for tool, paths in agents.owned_files(checker.root).items():  # the agents' profiles (archvow/agents.py)
        if tool in approved:
            continue
        label = f"'{tool}'"
        for rel in paths:
            if (checker.root / rel).exists():
                checker.add("ARCH040", f"{rel} configures {label}; approved AI assistants: "
                            f"{', '.join(approved)}", rel)


def check_dependencies(checker: Checker, templates: list[Template]) -> None:
    """ARCH023: a third-party import needs approval (template `dependencies` + the answer)."""
    if not any("dependencies" in t.data for t in templates):
        return  # the template does not govern dependencies
    allowed = {d for t in templates for d in (t.data.get("dependencies") or [])}
    allowed |= set(checker.manifest.get("dependencies") or [])
    own = {c["package"] for c in checker.manifest["containers"]} | {"tests", "conftest", "__future__"}
    known = set(sys.stdlib_module_names) | own | allowed
    # A folder that may import more: the Airflow DAG folder may import airflow (template); a
    # project may keep a shared library to its I/O layer (manifest, optional).
    by_path: dict[str, set[str]] = {}
    sources = [t.data.get("dependencies_by_path") or {} for t in templates]
    for mapping in [*sources, checker.manifest.get("dependencies_by_path") or {}]:
        for folder, names in mapping.items():
            by_path.setdefault(folder.strip("/"), set()).update(names or [])
    for path in sorted(checker.root.rglob("*.py")):
        rel = path.relative_to(checker.root)
        if any(part.startswith(".") or part in IGNORED_DIRS for part in rel.parts[:-1]):
            continue
        here = set(known)
        for folder, names in by_path.items():
            if rel.as_posix().startswith(folder + "/"):
                here |= names
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
        except (SyntaxError, UnicodeDecodeError):
            logs.swallowed(log, "check_dependencies: SyntaxError, UnicodeDecodeError")
            continue  # reported as ARCH013 for component files
        reported: set[str] = set()  # one hit per package and file, at its first import
        for node in sorted((n for n in ast.walk(tree) if isinstance(n, (ast.Import, ast.ImportFrom))),
                           key=lambda n: n.lineno):
            if isinstance(node, ast.Import):
                names = [a.name for a in node.names]
            elif not node.level and node.module:
                names = [node.module]
            else:
                continue
            for top in sorted({n.split(".")[0] for n in names} - here - reported):
                reported.add(top)
                if _is_local_module(path.parent, top):
                    continue  # a module next to the file (a script importing its sibling)
                folders = sorted(folder for folder, names in by_path.items() if top in names)
                if folders:
                    checker.add("ARCH023", f"'{top}' may be imported only under {', '.join(folders)} "
                                "(dependencies_by_path); call it from there", rel.as_posix(), node.lineno)
                    continue
                package = checker.manifest["containers"][0]["package"]
                approved = ",".join([*(checker.manifest.get("dependencies") or []), top])
                checker.add("ARCH023", f"'{top}' is not an approved dependency. An architect approves it: "
                            f"archvow init {package} --force -a dependencies={approved}",
                            rel.as_posix(), node.lineno)


def check_requirements(checker: Checker, templates: list[Template]) -> None:
    """ARCH024: a package in requirements.txt or pyproject.toml nobody approved. Approved: what the
    template's own requirements.txt and pyproject.toml list, and the `dependencies` answer. Mode
    strict: an error (only an architect approves, through the manifest); guided: an error for the
    release gate (check --complete); free: a warning."""
    if not any("dependencies" in t.data for t in templates):
        return
    approved = {_pep503(n) for t in templates for n in _template_packages(t)}
    approved |= {_pep503(str(n)) for t in templates for n in (t.data.get("dependencies") or [])}
    approved |= {_pep503(str(n)) for n in checker.manifest.get("dependencies") or []}
    package = checker.manifest["containers"][0]["package"]
    approved.add(_pep503(package))
    found = [(n, "requirements.txt", line) for n, line in _requirement_names(checker.root / "requirements.txt")]
    found += [(n, "pyproject.toml", line) for n, line in _pyproject_names(checker.root / "pyproject.toml")]
    project_mode = mode(checker.manifest)
    for name, rel, line in found:
        if _pep503(name) in approved:
            continue
        listed = ",".join([*(checker.manifest.get("dependencies") or []), name])
        message = (f"'{name}' is not an approved package: an architect approves it - archvow init {package} "
                   f"--force -a dependencies={listed}")
        if project_mode == "strict" or (project_mode == "guided" and checker.complete):
            checker.report.violations.append(Violation("ARCH024", "error", message, rel, line, 0,
                                                       checker.rules["ARCH024"][1]))
        else:
            checker.add("ARCH024", message, rel, line)


ARCHVOW_FILES = ("spec.vow", "proposals.vow", "README.md", "spec.md", "frozen.json", "status.md",
                 "agents.local", "trailer.local", "write.local")  # local, gitignored: agent.py's state, the spec lock
ARCHVOW_FOLDERS = ("components", "packs")
COMPONENT_FILES = ("spec.vow", "spec.md")


def check_task_size(checker: Checker) -> None:
    """ARCH044: the task an AI reads for one component (its spec.md) stays short enough to follow."""
    if not checker.enabled("ARCH044"):
        return
    limit = checker.param("ARCH044", "max_tokens")
    for container in checker.manifest["containers"]:
        for comp in container.get("components", []):
            path = checker.root / store.COMPONENTS_REL / comp["id"] / store.CARD_FILE
            try:
                text = path.read_text(encoding="utf-8")
            except OSError:
                logs.swallowed(log, "check_task_size: OSError")
                continue  # not generated yet: docs --check reports it
            size = tokens(text)
            if size > limit:
                tasks = "\n## Tasks" in text or "\n## Tâches" in text
                one_at_a_time = (", or give the AI one task at a time: "
                                 f"archvow prompt {comp['id']} --task 1" if tasks else "")
                checker.add("ARCH044", f"{comp['id']}: its task is about {size:,} tokens, over {limit:,}"
                                       f" - split it into smaller components{one_at_a_time}",
                            path.relative_to(checker.root).as_posix())


def check_archvow_folder(checker: Checker) -> None:
    """ARCH050: CODEOWNERS lists what archvow writes in .archvow/, path by path (the AI's
    proposals are not the architects' in mode free); anything else there would be owned by nobody.
    A component folder holds its spec.vow and its spec.md, nothing else."""
    folder = checker.root / ".archvow"
    if not folder.is_dir():
        return
    strays = []
    for path in sorted(folder.iterdir()):
        if path.name in (ARCHVOW_FOLDERS if path.is_dir() else ARCHVOW_FILES):
            continue
        strays.append(path)
    components = folder / "components"
    if components.is_dir():
        for sub in sorted(components.iterdir()):
            if sub.is_dir() and not (sub / store.COMPONENT_FILE).is_file():  # a component lost its vow
                rel = sub.relative_to(checker.root).as_posix()
                checker.add("ARCH050", store.broken_message(rel), rel)
                continue
            if not sub.is_dir():
                strays.append(sub)
                continue
            strays += [p for p in sorted(sub.iterdir()) if p.name not in COMPONENT_FILES]
    for path in strays:
        rel = path.relative_to(checker.root).as_posix()
        checker.add("ARCH050", f"{rel}: archvow does not write it, so CODEOWNERS gives it to nobody - move it "
                    "out of .archvow/ (only archvow's own files live there)", rel)


def check_project_files(checker: Checker) -> None:
    """The project's files around the code: approved AI assistants (ARCH040) and reviews (ARCH041/042, review.py),
    imports and packages approved (ARCH023/024), stray Python files (ARCH015), the test layout (ARCH016)."""
    templates = list(checker.templates.values())
    check_ai_tools(checker, templates)
    check_reports(checker)
    check_dependencies(checker, templates)
    check_requirements(checker, templates)
    container_dirs = [checker.root / c["path"] for c in checker.manifest["containers"]]
    allowed = {"tests"}
    for template in templates:
        allowed.update(template.data.get("allowed_paths", []))
        allowed.update(generated_python_folders(template))  # dags/...: archvow wrote them
    allowed.update(checker.manifest.get("allowed_paths", []) or [])
    mirror = any(t.data.get("test_layout") == "mirror" for t in templates)
    free_dirs = [d.rstrip("/") for t in templates for d in (t.data.get("free_test_dirs") or [])]
    components = {store.test_path(c) for container in checker.manifest["containers"]
                  for c in container.get("components", [])}
    for path in sorted(checker.root.rglob("*.py")):
        rel = path.relative_to(checker.root)
        if any(part.startswith(".") or part in IGNORED_DIRS for part in rel.parts[:-1]):
            continue
        if any(path.is_relative_to(d) for d in container_dirs):
            continue
        top = rel.parts[0] if len(rel.parts) > 1 else rel.name
        if top not in allowed:
            checker.add("ARCH015", f"{rel.as_posix()} is outside the architecture; move it into a "
                        "component or list its folder in `allowed_paths` (architect review)", rel.as_posix())
            continue
        if top == "tests" and mirror and not any(rel.as_posix().startswith(d + "/") for d in free_dirs):
            check_test_file(checker, rel, components)


def check_test_file(checker: Checker, rel: Path, components: set[str]) -> None:
    if rel.name in {"conftest.py", "__init__.py"}:
        return
    if rel.as_posix() not in components:
        checker.add("ARCH016", f"{rel.as_posix()}: tests live in tests/<layer>/[<group>/]test_<component>.py "
                    "for a declared component", rel.as_posix())
