"""The check engine: it walks the project - each container with its template, then each Python file of the
container - and records what the rule families find (Violation, Report). It holds only the rules about the walk
itself: a template that cannot load (ARCH009), a template version (ARCH012), a file that cannot be read (ARCH013),
a planned module not created (ARCH008), a suppression without its reason (ARCH011). What to check in a container
and in a file comes from checks/families/, handed over by checks/run.py; which rules exist and which are on comes
from checks/catalogue.py.

Static only (Python `ast`): the project code is never imported or executed, so the check needs neither PySpark
nor a JVM and runs in milliseconds - fast enough for CI, pre-commit hooks and live IDE inspections.
"""

from __future__ import annotations

import ast
import re
import sys
import time
import tomllib
from collections.abc import Callable
from dataclasses import asdict, dataclass, field
from pathlib import Path

from archvow.checks.catalogue import (
    DEFAULT_PARAMS,
    FLOOR,
    RULES,
    all_rules,
    chosen_families,
    family_enabled,
    project_rule_sets,
    rule_enabled,
)
from archvow.checks.layers import layer_paths, mapped_layer
from archvow.foundation import logs
from archvow.imports import Names
from archvow.model import store
from archvow.templates import Template, TemplateError, load_template, template_name

IGNORED_DIRS = {"venv", "env", "build", "dist", "node_modules", "__pycache__", "site-packages",
                "spark-warehouse"}
SUPPRESS_RE = re.compile(r"#\s*archvow:\s*ignore\[([A-Z0-9, ]+)\](.*)$")
REQUIRES_PYTHON_RE = re.compile(r">=?\s*3\.(\d+)")

log = logs.get("check")


@dataclass
class Violation:
    code: str
    severity: str
    message: str
    file: str
    line: int = 0
    col: int = 0
    title: str = ""
    guide: dict | None = None  # what to do about it, in the project's language (archvow.guidance)


@dataclass
class SymbolStatus:
    container: str
    component: str
    symbol: str
    status: str  # planned | implemented
    reason: str = ""  # why a planned symbol is not done: missing | placeholder (its file exists)


@dataclass
class ComponentStatus:
    container: str
    component: str
    type: str
    layer: str
    status: str  # planned | implemented | tested | verified | drift
    tested: bool = False
    invariants_total: int = 0
    invariants_verified: int = 0
    open_questions: int = 0
    pending_assumptions: int = 0
    hazards: int = 0


@dataclass
class Report:
    violations: list[Violation] = field(default_factory=list)
    statuses: list[SymbolStatus] = field(default_factory=list)
    suppressed: list[dict] = field(default_factory=list)
    changes: list[dict] = field(default_factory=list)
    components: list[ComponentStatus] = field(default_factory=list)
    invariants: list[dict] = field(default_factory=list)
    frozen: list[dict] = field(default_factory=list)        # existing violations, ignored
    stale_frozen: list[dict] = field(default_factory=list)  # frozen but fixed since
    budget: dict | None = None  # with a base: the change's size against the ARCH022 budget
    safety: dict = field(default_factory=dict)  # safety questions: {"answered": n, "total": m}

    @property
    def errors(self) -> list[Violation]:
        return [v for v in self.violations if v.severity == "error"]

    def to_dict(self) -> dict:
        return {
            "ok": not self.errors,
            "errors": len(self.errors),
            "warnings": len(self.violations) - len(self.errors),
            "violations": [asdict(v) for v in self.violations],
            "statuses": [asdict(s) for s in self.statuses],
            "suppressed": self.suppressed,
            "changes": self.changes,
            "components": [asdict(c) for c in self.components],
            "invariants": self.invariants,
            "frozen": len(self.frozen),
            "stale_frozen": self.stale_frozen,
            "budget": self.budget,
            "safety": self.safety,
            "counts": self.counts(),
        }

    def counts(self) -> dict[str, int]:
        """How many violations each rule found, most first (then by code)."""
        found: dict[str, int] = {}
        for v in self.violations:
            found[v.code] = found.get(v.code, 0) + 1
        return dict(sorted(found.items(), key=lambda item: (-item[1], item[0])))


@dataclass
class SourceFile:
    """One Python file of a container, read and parsed once: what every file check receives."""
    container: dict
    template: Template
    by_module: dict  # module -> its component, in this container
    component: dict | None  # the component the file implements (None: not declared, or a package __init__)
    layer: dict | None  # the template's layer the file sits in (None: in no layer)
    path: Path
    rel: str  # from the project root, with /
    module: str
    is_init: bool
    source: str
    tree: ast.Module
    names: Names


# What a family gives the engine (checks/run.py): a check of one container, a check of one file.
ContainerCheck = Callable[["Checker", dict, Template], None]
FileCheck = Callable[["Checker", SourceFile], None]


def newer_python_needed(root: Path) -> str | None:
    """The project's requires-python when it asks for a newer Python than the one running archvow."""
    try:
        data = tomllib.loads((root / "pyproject.toml").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        logs.swallowed(log, "newer_python_needed: OSError, ValueError")
        return None
    wanted = str((data.get("project") or {}).get("requires-python") or "")
    match = REQUIRES_PYTHON_RE.search(wanted)
    if match and int(match.group(1)) > sys.version_info.minor:
        return wanted
    return None


class Checker:
    """One check run: the project's spec, the rules on and their settings, and the findings so far."""

    def __init__(self, root: Path, overrides: dict[Path, str] | None = None,
                 complete: bool = False, test_report: Path | None = None) -> None:
        self.root = root
        self.complete = complete
        self.test_report = test_report  # JUnit XML of pytest: ARCH046 checks the marked tests passed
        self.templates: dict[str, Template] = {}
        self.overrides = {p.resolve(): text for p, text in (overrides or {}).items()}
        self.report = Report()
        self.timings: list[str] = []  # each step's time, for the log
        self.container_checks: list[ContainerCheck] = []  # given by checks/run.py
        self.file_checks: list[FileCheck] = []  # given by checks/run.py, run in that order on every file
        self.manifest = store.load(root)
        self.settings: dict[str, dict] = {}
        self.rule_sets: set[str] = set()
        self.rules: dict[str, tuple[str, str]] = dict(RULES)
        self.families: dict = {}
        self.chosen = chosen_families(self.manifest)
        self.layer_map = layer_paths(self.manifest)

    # ---- the rules on, and the findings
    def _configure(self, template: Template | None) -> None:
        templates = [template] if template else []
        self.rule_sets = project_rule_sets(templates, self.manifest)
        self.rules = all_rules(templates)
        self.families = dict((template.data.get("rule_families") or {}) if template else {})
        self.settings = {}
        for code, (severity, _) in self.rules.items():
            self.settings[code] = {"severity": severity, **DEFAULT_PARAMS.get(code, {})}
        for source in ((template.rules if template else {}), self.manifest.get("rules", {})):
            for code, value in (source or {}).items():
                if code in self.settings and isinstance(value, dict):
                    self.settings[code].update(value)

    def param(self, code: str, key: str) -> int:
        return int(self.settings[code][key])

    def add(self, code: str, message: str, file: str, line: int = 0, col: int = 0,
            escalate: bool = False) -> None:
        """Record a violation at its severity; `escalate` makes a warning an error (mode strict, --complete)."""
        severity = self.settings.get(code, {}).get("severity", self.rules[code][0])
        if code in FLOOR and severity == "off":  # the floor cannot be switched off
            severity = self.rules[code][0]
        if severity == "off" or not rule_enabled(code, self.rule_sets, self.families) \
                or not family_enabled(code, self.families, self.chosen):
            return
        if escalate:
            severity = "error"
        self.report.violations.append(
            Violation(code, severity, message, file, line, col, self.rules[code][1])
        )

    def enabled(self, code: str) -> bool:
        return (rule_enabled(code, self.rule_sets, self.families) and family_enabled(code, self.families, self.chosen)
                and (code in FLOOR or self.settings.get(code, {}).get("severity") != "off"))

    def timed(self, name: str, step, *args) -> None:
        """Runs one step of the check and records how long it took (the log's "checks ..." line)."""
        start = time.perf_counter()
        step(*args)
        self.timings.append(f"{name} {round((time.perf_counter() - start) * 1000)} ms")

    def finish(self) -> Report:
        """The findings once every step ran: each once, in file order."""
        log.info("checks %s: %d finding(s)", ", ".join(self.timings), len(self.report.violations))
        self.report.violations = _unique(self.report.violations)
        self.report.violations.sort(key=lambda v: (v.file, v.line, v.code))
        return self.report

    # ---- the walk: containers, then their files
    def check_code(self) -> bool:
        """Every container's code against the spec, and its template loaded. False when a template is missing:
        then nothing else can be judged (one clear error, ARCH009)."""
        templates: list[Template] = []
        start = time.perf_counter()
        for container in self.manifest["containers"]:
            self._check_container(container)
            try:
                template = load_template(template_name(container)[0], self.root)
                templates.append(template)
                self.templates[container["id"]] = template
            except TemplateError:
                logs.swallowed(log, f"container {container.get('id')}: template not loaded (reported as ARCH009)")
        self.timings.append(f"code {round((time.perf_counter() - start) * 1000)} ms")
        if len(templates) < len(self.manifest["containers"]):
            log.info("checks stopped after the code: a template is missing (ARCH009)")
            return False
        return True

    def _check_container(self, container: dict) -> None:
        name, version = template_name(container)
        try:
            template = load_template(name, self.root)
        except TemplateError as exc:
            self._configure(None)
            pack = name.split("/", 1)[0] if "/" in name else "<pack>"
            self.add("ARCH009", f"container '{container['id']}': {exc}. A company template comes in a pack that "
                     f"lives in the project: archvow pack add <the folder of pack {pack}>, then commit "
                     f".archvow/packs/", str(store.PROJECT_REL))
            return
        self._configure(template)
        if version and version != template.version:
            self.add(
                "ARCH012",
                f"the vow says {name}@{version}, the template is {template.ref}: to adopt it, "
                f"archvow init {container.get('package', '<package>')} --force (then review and commit)",
                str(store.PROJECT_REL),
            )
        for check in self.container_checks:
            check(self, container, template)
        components = container.get("components", [])
        by_module = {c["module"]: c for c in components}
        base = self.root / container["path"]
        seen: set[str] = set()
        for path in sorted(base.rglob("*.py")):
            module = self._module_name(container, path)
            seen.add(module)
            self._check_file(container, template, by_module, path, module)
        for component in components:
            if component["module"] not in seen:
                for symbol in component.get("symbols", []):
                    self.report.statuses.append(
                        SymbolStatus(container["id"], component["id"], symbol["name"], "planned"))
                if self.complete:
                    self.add("ARCH008", f"component '{component['id']}': {component['module']} "
                             "is planned but not created", str(store.PROJECT_REL))

    def _check_file(self, container: dict, template: Template, by_module: dict,
                    path: Path, module: str) -> None:
        rel = path.relative_to(self.root).as_posix()
        try:
            source = self.overrides.get(path.resolve()) or path.read_text(encoding="utf-8")
        except UnicodeDecodeError as exc:
            self.add("ARCH013", f"cannot be parsed: the file is not UTF-8 (byte {exc.start}) - save it as UTF-8", rel)
            return
        try:
            tree = ast.parse(source, filename=rel)
        except SyntaxError as exc:
            newer = newer_python_needed(self.root)
            hint = (f" - archvow runs on Python {sys.version_info.major}.{sys.version_info.minor} and this project "
                    f"needs {newer}: run archvow with that Python (archvow doctor shows it)") if newer else ""
            self.add("ARCH013", f"syntax error: {exc.msg}{hint}", rel, exc.lineno or 0)
            return
        layer_name = self.file_layer(container, template, rel, module)
        suppressions = self._suppressions(source, rel)
        before = len(self.report.violations)
        file = SourceFile(container, template, by_module, by_module.get(module),
                          template.layer(layer_name) if layer_name else None, path, rel, module,
                          path.name == "__init__.py", source, tree, Names(tree))
        for check in self.file_checks:
            check(self, file)
        self._apply_suppressions(before, suppressions, rel)

    # ---- where a file sits
    def file_layer(self, container: dict, template: Template, rel: str, module: str) -> str | None:
        """A file's layer: the one `layer_paths` maps it to, else the folder under the package."""
        mapped = mapped_layer(self.layer_map, rel)
        if mapped is not None:
            return mapped
        parts = module.split(".")
        return parts[1] if len(parts) > 1 and template.layer(parts[1]) is not None else None

    def module_layer(self, container: dict, template: Template, target: str) -> str | None:
        """The layer of an imported module of the project (its file, mapped or by folder)."""
        base = self.root / container["path"]
        parts = target.split(".")[1:]
        for end in range(len(parts), 0, -1):
            for candidate in (base.joinpath(*parts[:end - 1], parts[end - 1] + ".py"),
                              base.joinpath(*parts[:end], "__init__.py")):
                if candidate.is_file():
                    rel = candidate.relative_to(self.root).as_posix()
                    return self.file_layer(container, template, rel, self._module_name(container, candidate))
        return parts[0] if parts and template.layer(parts[0]) is not None else None

    def _module_name(self, container: dict, path: Path) -> str:
        rel = path.relative_to(self.root / container["path"]).with_suffix("")
        parts = [container["package"], *rel.parts]
        if parts[-1] == "__init__":
            parts = parts[:-1]
        return ".".join(parts)

    # ---- suppressions: `# archvow: ignore[CODE] -- why`
    def _suppressions(self, source: str, rel: str) -> dict[int, set[str]]:
        found: dict[int, set[str]] = {}
        for number, text in enumerate(source.splitlines(), start=1):
            match = SUPPRESS_RE.search(text)
            if not match:
                continue
            codes = {c.strip() for c in match.group(1).split(",") if c.strip()}
            reason = match.group(2).strip().lstrip("-—: ").strip()
            if len(reason) < 5:
                self.add("ARCH011", f"suppression of {', '.join(sorted(codes))} needs a reason: "
                         "`# archvow: ignore[CODE] -- why`", rel, number)
                continue
            found[number] = codes
        return found

    def _apply_suppressions(self, start: int, suppressions: dict[int, set[str]], rel: str) -> None:
        if not suppressions:
            return
        kept = self.report.violations[:start]
        for violation in self.report.violations[start:]:
            codes = suppressions.get(violation.line, set())
            if violation.code in codes and violation.code != "ARCH011":
                self.report.suppressed.append({"file": rel, "line": violation.line, "code": violation.code})
            else:
                kept.append(violation)
        self.report.violations = kept


def _unique(violations: list[Violation]) -> list[Violation]:
    """One hit per rule, file, line and message (an import of nine names is one import)."""
    seen: set[tuple[str, str, int, str]] = set()
    kept = []
    for v in violations:
        key = (v.code, v.file, v.line, v.message)
        if key not in seen:
            seen.add(key)
            kept.append(v)
    return kept
