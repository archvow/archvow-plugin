"""archvow: architecture specifications for AI-written code, and the guards that enforce them."""

__version__ = "1.27.0"
# What the IDE plugins and scripts may rely on in archvow's --json output: MINOR goes up when something is
# added, MAJOR when something they read is removed, renamed or changes meaning (wiki 13).
__contract__ = "1.3"
