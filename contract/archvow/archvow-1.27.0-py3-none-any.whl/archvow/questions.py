"""Question sets beyond a component's own questions: one per privacy regime on (P for GDPR, U for US-PRIVACY,
G for GLBA...), O (operations) and C (a company's `require_question` rules).

A regime's questions come from its file (packs/regimes.py), by privacy role; the template says which of its
component types play each role (`privacy_roles: {purpose: [job], store: [writer]}`). A template declares its
other sets as data (`question_sets`). Each question names the rule that fails while it is open on a coded
component, so a new set or question needs no code:

    question_sets:
      O:
        title: Operations
        rule_set: dora          # asked only when this family is on (`rules` answer)
        when: always            # personal | writes | special | always (per question too)
        questions:
          job:
            - {id: detection, rule: DORA005, text: "Failure detection: how ...?"}

Answers live in the component, keyed by the question id: `answers: {P.purpose: {answer, by, on}}`,
so adding or removing a question never moves another one's answer. People see them numbered
P1, P2... and answer with `archvow decision make <component> P1 "..."`.
"""

from __future__ import annotations

import re
from pathlib import Path

from archvow.checks.catalogue import custom_rules, project_rule_sets, rule_enabled
from archvow.foundation import logs
from archvow.foundation.errors import SpecError
from archvow.foundation.text import one_line
from archvow.model import store
from archvow.model.spec import find_component, stamp
from archvow.packs.regimes import Regime, in_scope
from archvow.privacy import column_tags, personal_flow
from archvow.templates import Template, templates_of

log = logs.get("questions")

KEY_RE = re.compile(r"^([A-Z])([0-9]+)$")
WHEN = ("always", "personal", "writes", "special")


def question_sets(template: Template, data: dict) -> dict[str, dict]:
    """The sets switched on for this project: letter -> {title, when, questions: {type: [...]}, regime}."""
    rule_sets = project_rule_sets([template], data)
    sets: dict[str, dict] = {}
    roles = template.data.get("privacy_roles") or {}
    for regime in template.regimes:
        if regime.id not in rule_sets:
            continue
        by_type: dict[str, list] = {}
        for role, items in regime.questions.items():
            for ctype in roles.get(role) or []:
                by_type.setdefault(str(ctype), []).extend(items)
        sets[regime.letter] = {"title": regime.name, "questions": by_type, "regime": regime}
    for letter, spec in (template.data.get("question_sets") or {}).items():
        family = spec.get("rule_set")
        if family and family not in rule_sets:
            continue
        sets[str(letter)] = spec
    company: dict[str, list] = {}
    for code, rule in custom_rules([template]).items():
        if rule["kind"] != "require_question" or not rule_enabled(code, rule_sets) or rule.get("severity") == "off":
            continue
        for ctype in rule["types"]:
            company.setdefault(ctype, []).append({"id": code, "rule": code, "text": rule["targets"][0]})
    if company:
        sets["C"] = {"title": "Company questions", "when": "always", "questions": company}
    return sets


def _applies(when: str, flow: dict, tags: list[str] | None = None, column_tags: dict | None = None) -> bool:
    """A question applies to a component by what its personal-data flow holds (`tags`: one of its columns has
    one of them)."""
    if tags and not any(set(tags) & (column_tags or {}).get(name, set()) for name in flow.get("handles") or {}):
        return False
    if when == "personal":
        return bool(flow.get("handles"))
    if when == "writes":
        return bool(flow.get("writes"))
    if when == "special":
        return "special" in (flow.get("handles") or {}).values()
    return True


def component_questions(root: Path, data: dict, comp: dict, template: Template | None = None,
                        flows: dict | None = None) -> list[dict]:
    """The P/O/C questions a component must answer, numbered per set, with their answers."""
    if template is None:
        container = next(c for c in data["containers"] if comp in c.get("components", []))
        template = templates_of(root, data).get(container["id"])
        if template is None:
            return []
    if flows is None:
        flows = personal_flow(root, data)
    answers = comp.get("answers") or {}
    sets = question_sets(template, data)
    tags = column_tags(data)
    on = {s["regime"].id for s in sets.values() if s.get("regime")}
    out = []
    for letter, spec in sets.items():
        flow = _flow_for(flows.get(comp["id"], {}), spec.get("regime"), tags, on)
        number = 0
        for question in (spec.get("questions") or {}).get(comp.get("type"), []) or []:
            if not _applies(question.get("when") or spec.get("when") or "always", flow, question.get("tags"), tags):
                continue
            number += 1
            stored = answers.get(f"{letter}.{question['id']}") or {}
            out.append({"key": f"{letter}{number}", "set": letter, "title": spec.get("title", letter),
                        "id": question["id"], "rule": question.get("rule", ""), "question": question["text"],
                        "answer": stored.get("answer") or None,
                        **{k: stored[k] for k in ("by", "on") if k in stored}})
    return out


def _flow_for(flow: dict, regime: Regime | None, tags: dict[str, set[str]], on: set[str]) -> dict:
    """A component's personal-data flow as one regime sees it: only the columns it covers."""
    if regime is None:
        return flow
    return {"handles": in_scope(regime, flow.get("handles") or {}, tags, on),
            "writes": in_scope(regime, flow.get("writes") or {}, tags, on)}


def is_key(text: str) -> bool:
    return bool(KEY_RE.match(str(text).strip().upper()))


def answer(root: Path, component_id: str, key: str, text: str) -> dict:
    """`archvow decision make <component> P1 "..."`: answer a P/O/C question by its number."""
    data = store.load(root)
    _, comp = find_component(data, component_id)
    questions = component_questions(root, data, comp)
    wanted = key.strip().upper()
    question = next((q for q in questions if q["key"] == wanted), None)
    if question is None:
        known = ", ".join(q["key"] for q in questions) or "none"
        raise SpecError(f"'{component_id}' has no question {wanted} (it has: {known}; see archvow show "
                        f"{component_id})")
    if not text.strip():
        raise SpecError("an answer is required")
    entry = {"answer": one_line(text), **stamp(root)}
    comp.setdefault("answers", {})[f"{question['set']}.{question['id']}"] = entry
    store.save(root, data)
    return {**question, **entry}
