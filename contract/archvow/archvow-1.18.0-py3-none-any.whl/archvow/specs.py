"""Spec authoring: archvow writes specifications, never source code.

Everything here edits the vows - `.archvow/spec.vow` and `.archvow/components/<c>/spec.vow` - the
single source of truth. Source files are written by humans or AI and verified by `archvow check`.
"""

from __future__ import annotations

import keyword
import os
import re
import shlex
import subprocess
from collections.abc import Callable
from pathlib import Path

from jinja2 import Environment, StrictUndefined, UndefinedError

from archvow import __version__, ui
from archvow import manifest as mf
from archvow.templates import (
    DEFAULT_LANGUAGE,
    Template,
    TemplateError,
    edge_case_text,
    load_template,
)

PACKAGE_RE = re.compile(r"^[a-z][a-z0-9_]*$")
SEVERITIES = ("critical", "high", "medium", "low")
VERIFY_METHODS = ("static", "example_test", "property_test", "runtime", "model_check", "proof")
ASSUMPTION_STATES = ("proposed", "accepted", "rejected")


DEFAULT_TEMPLATE = "python-app"


class SpecError(Exception):
    """Raised when a spec change is invalid."""


def verbatim_prefixes(template: Template) -> tuple[str, ...]:
    """The folders of files/ copied exactly as they are, .j2 included: `verbatim_folders` (a folder
    and everything under it)."""
    return tuple(f"{str(folder).strip('/')}/" for folder in template.data.get("verbatim_folders") or [])


def _env() -> Environment:
    return Environment(undefined=StrictUndefined, keep_trailing_newline=True, autoescape=False)


def resolved_choices(template: Template, question: dict) -> list | None:
    """Static `choices`, or `choices_from: <mapping>`: its keys (except `unlisted`) plus `none`."""
    source = question.get("choices_from")
    if not source:
        return question.get("choices")
    if source == "rule_families":  # the families `rules` chooses from: their names, not the code prefixes
        return [*template.selectable_families(), "all", "none"]
    keys = [k for k in (template.data.get(source) or {}) if k != "unlisted"]
    return [*keys, "none"]


def answers_with_defaults(template: Template, answers: dict) -> dict:
    result = {}
    for question in template.data.get("questions", []):
        qid = question["id"]
        result[qid] = check_answer(template, question,
                                   answers.get(qid, question_default(template, question, result)))
    unknown = set(answers) - set(result)
    if unknown:
        raise SpecError(f"unknown answer(s): {', '.join(sorted(unknown))}")
    return result


def question_default(template: Template, question: dict, known: dict | None = None) -> object:
    """A question's default: the company's, else `default_from` (it follows an earlier answer, e.g.
    sandbox: yes in mode strict), else `default`."""
    company = (template.data.get("questions_defaults") or {}).get(question["id"])
    if company is not None:
        return company
    for other, values in (question.get("default_from") or {}).items():
        earlier = (known or {}).get(other)
        if earlier is None:  # not answered yet: that question's own default
            earlier = next((q.get("default") for q in template.data.get("questions", []) if q["id"] == other), None)
        if str(earlier) in (values or {}):
            return values[str(earlier)]
    default = question.get("default")
    if default is None and question.get("choices_from") == "rule_families":
        return ",".join(template.recommended_families())  # every family but DORA
    return default


def split_rules(template: Template, chosen: list[str]) -> tuple[list[str], list[str]]:
    """The one `rules` answer as the manifest keeps it: the code families (`families`: ARCH, STYLE,
    SPARK..., or all) and the compliance ones (`compliance`: gdpr, tst, dora, or none)."""
    every = template.selectable_families()
    names = every if "all" in chosen else [c for c in chosen if c != "none"]
    code = [n for n in names if n not in template.COMPLIANCE]
    compliance = [n.lower() for n in names if n in template.COMPLIANCE]
    all_code = [n for n in every if n not in template.COMPLIANCE]
    families = ["all"] if code == all_code else (code or ["none"])
    return families, compliance or ["none"]


def rules_answer(template: Template, data: dict) -> str:
    """The `rules` answer back from what the manifest keeps (init --force keeps it)."""
    every = template.selectable_families()
    families = data.get("families")
    if families is None or "all" in families:
        code = [n for n in every if n not in template.COMPLIANCE]
    else:
        code = [str(f).upper() for f in families if f != "none"]
    compliance = [str(c).upper() for c in data.get("compliance") or [] if c != "none"]
    names = [n for n in every if n in code or n in compliance]
    if names == every:
        return "all"
    return ",".join(names) or "none"


def check_answer(template: Template, question: dict, value: object) -> object:
    """One answer, checked against its question (required, choices, pattern) and normalised."""
    qid = question["id"]
    if value is None or str(value).strip() == "":
        if question.get("required"):
            raise SpecError(f"'{qid}' is required - {question.get('prompt', qid)}: pass -a {qid}=...")
        value = ""
    if isinstance(value, str):
        value = " ".join(value.split())
    choices = resolved_choices(template, question)
    if question.get("multiple"):
        items = value if isinstance(value, list) else [v.strip() for v in str(value).split(",") if v.strip()]
        if question.get("choices_from") == "rule_families":  # family names in any case: arch,spark
            items = [v if v.lower() in ("all", "none") else v.upper() for v in (str(i) for i in items)]
            items = [v.lower() if v.lower() in ("all", "none") else v for v in items]
        unknown = [v for v in items if choices and v not in choices]
        if unknown:
            raise SpecError(f"answer '{qid}': {', '.join(unknown)} not in {choices}")
        for alone in ("none", "all"):
            if alone in items and len(items) > 1:
                raise SpecError(f"answer '{qid}': '{alone}' cannot be combined with other values")
        return list(dict.fromkeys(items))
    if choices and str(value) not in [str(c) for c in choices]:
        raise SpecError(f"answer '{qid}={value}' not in {choices}")
    pattern = question.get("pattern")
    if pattern and not re.fullmatch(pattern, str(value)):
        raise SpecError(f"answer '{qid}={value}' is invalid: {question.get('pattern_hint', pattern)}")
    return value


def ask_answers(template: Template, answers: dict, read: Callable[[str], str] | None = None) -> dict:
    """In a terminal, `init` asks the main questions (`ask: true`) that no `-a` answered.

    A list of choices is shown numbered: type a number, a value, or several separated by commas
    when more than one is allowed. Enter keeps the default. A wrong answer is asked again.
    """
    result = dict(answers)
    questions = {q["id"]: q for q in template.data.get("questions", [])}
    for question in template.data.get("questions", []):
        if question.get("ask") and question["id"] not in result:
            result[question["id"]] = _ask_one(template, question, read, known=result)
    while "architects" in questions and dora_approvers_problem(template, result):  # asked again, not refused
        print(f"\n  {dora_approvers_problem(template, result)}")
        result["architects"] = _ask_one(template, questions["architects"], read)
    return result


def ask_company_defaults(template: Template, read: Callable[[str], str] | None = None) -> dict:
    """`template new`: every init answer of the base, one at a time, as `init` asks them. Enter keeps
    the base's default (nothing written); an answer becomes the company's default."""
    chosen = {}
    for question in template.data.get("questions", []):
        value = _ask_one(template, question, read, keep=True)
        if value is not None:
            chosen[question["id"]] = value
    return chosen


def _ask_one(template: Template, question: dict, read: Callable[[str], str] | None,
             keep: bool = False, known: dict | None = None) -> str | None:
    """One init question in a terminal, until the answer is valid. `keep`: Enter answers None (the
    default stays the base's, for a company template). `known`: the answers so far."""
    qid = question["id"]
    choices = [str(c) for c in resolved_choices(template, question) or []]
    default = question_default(template, question, known)
    default = ",".join(default) if isinstance(default, list) else str(default or "")
    print("\n" + ui.question(question.get("prompt", qid)))
    titles = {c: template.family_title(c) for c in choices} if question.get("choices_from") == "rule_families" else {}
    width = max((len(c) for c in titles), default=0)
    for number, choice in enumerate(choices, 1):
        print(f"  {number}. {choice.ljust(width)}  {titles[choice]}".rstrip() if titles.get(choice)
              else f"  {number}. {choice}")
    hint = " (several: 1,3)" if question.get("multiple") and choices else ""
    while True:
        prompt = f"{qid}{hint} " + ui.hint(f"[{default}]") + ": "
        typed = (read(prompt) if read else ui.ask(prompt, default)).strip()
        if keep and not typed:
            return None
        typed = typed or default
        items = [item.strip() for item in typed.split(",")] if question.get("multiple") else [typed]
        items = [choices[int(item) - 1] if item.isdigit() and 0 < int(item) <= len(choices) else item
                 for item in items]
        value = ",".join(items)
        try:
            check_answer(template, question, value)
        except SpecError as error:
            print(f"  {error}")
            continue
        return value


DORA_APPROVERS = ("DORA needs two people who can approve guard changes, or a group (separation of duties: "
                  "an author never approves their own change) - e.g. -a architects=\"@first @second\" or "
                  "-a architects=@acme/architects")


def dora_approvers_problem(template: Template, answers: dict) -> str:
    """With DORA among the rules, a single architect who is not a group: what to do, else ''."""
    rules = answers.get("rules")
    if rules is None:
        rules = question_default(template, next((q for q in template.data.get("questions", [])
                                                 if q["id"] == "rules"), {"id": "rules"}))
    chosen = [str(r).strip().upper() for r in (rules if isinstance(rules, list) else str(rules or "").split(","))]
    if not ({"ALL", "DORA"} & set(chosen)) or "DORA" not in template.selectable_families():
        return ""
    owners = str(answers.get("architects") or "").split()
    return "" if len(owners) >= 2 or any("/" in o for o in owners) else DORA_APPROVERS


def migrate_answers(template: Template, answers: dict) -> dict:
    """Answers of earlier template versions in today's terms (`answer_migrations:` of the template)."""
    env = _env()
    result = dict(answers)
    for migration in template.data.get("answer_migrations") or []:
        try:
            applies = env.compile_expression(migration["when"], undefined_to_none=True)(**result)
        except UndefinedError:  # the answer it looks at was not given: nothing to translate
            applies = False
        if applies:
            result.update(migration.get("set") or {})
    return result


def derive(template: Template, context: dict) -> dict:
    """Values computed from the answers (`derived:`), after the answers are checked together
    (`answer_rules:`): e.g. ci_tool = the platform's own CI when `ci` is `auto`."""
    env = _env()
    for rule in template.data.get("answer_rules") or []:
        if not env.compile_expression(rule["check"])(**context):
            raise SpecError(env.from_string(rule["message"]).render(**context))
    derived = {}
    for name, expression in (template.data.get("derived") or {}).items():
        derived[name] = env.compile_expression(expression)(**context, **derived)
    return derived


# ------------------------------------------------------------------ AI auto-approval


def auto_approval(template: Template, context: dict) -> dict:
    """What the approved AI assistants may do without asking (`auto_approve` yes), from the template's
    `ai_auto_approve`: {"commands": ["archvow check", "ruff check *", ...], "edit": ["src/acme", "tests"],
    "claude": [Claude Code allow rules], "cursor": [Cursor CLI allow rules]}. Empty when the answer is no."""
    if str(context.get("auto_approve", "no")) != "yes":
        return {"commands": [], "edit": [], "claude": [], "cursor": []}
    spec = template.data.get("ai_auto_approve") or {}
    env = _env()
    commands = [env.from_string(str(c)).render(**context) for c in spec.get("commands") or []]
    if str(context.get("mode") or "strict") != "strict":  # guided/free: the AI proposes, a person decides
        commands.append("archvow decision propose *")
    commands = list(dict.fromkeys(commands))
    edit = [env.from_string(str(e)).render(**context).strip("/") for e in spec.get("edit") or []]
    claude, cursor = [], []
    for command in commands:
        any_args = command.endswith(" *")
        words = command.removesuffix(" *")
        claude.append(f"Bash({words}:*)" if any_args else f"Bash({words})")
        base, _, rest = words.partition(" ")
        cursor.append(f"Shell({base}:{rest}*)" if any_args else
                      (f"Shell({base}:{rest})" if rest else f"Shell({base})"))
    claude += [f"Edit({folder}/**)" for folder in edit]
    cursor += [f"Write({folder}/**)" for folder in edit]
    return {"commands": commands, "edit": edit, "claude": list(dict.fromkeys(claude)),
            "cursor": list(dict.fromkeys(cursor))}


# Tools that keep their permissions outside the project: init prints where each developer adds the
# auto-approved commands once (archvow cannot write them). Claude Code and Cursor get a project file.
AUTO_APPROVE_ELSEWHERE = {
    "copilot": "VS Code: user setting chat.tools.terminal.autoApprove, one entry per command set to true; "
               "IntelliJ: the Copilot settings",
    "jetbrains-ai-chat": "IDE settings of the AI Assistant: the commands it may run without asking",
    "junie": "~/.junie/allowlist.json (executables rules, action allow), or the IDE's Junie settings",
    "continue": "~/.continue/permissions.yaml, under allow: Bash(<command>*)",
    "antigravity": "Settings > Terminal command auto execution > allow list",
}


def auto_approve_notes(root: Path) -> list[str]:
    """Lines init prints when auto_approve is yes and an approved assistant keeps its permissions
    outside the project: where to add the commands, and the commands."""
    data = mf.load(root)
    if str((data.get("init_answers") or {}).get("auto_approve", "no")) != "yes":
        return []
    tools = [t for t in data.get("ai_tools") or [] if t in AUTO_APPROVE_ELSEWHERE]
    if not tools:
        return []
    container = data["containers"][0]
    template = load_template(mf.template_name(container)[0], root)
    context = {**template.data.get("context", {}), **(data.get("init_answers") or {}),
               "mode": data.get("mode") or "strict", "src": "src", "package": container.get("package", "")}
    auto = auto_approval(template, context)
    lines = [f"{tool}: {AUTO_APPROVE_ELSEWHERE[tool]}" for tool in tools]
    shown = {}  # "x" and "x *" -> "x ..." (any arguments); an exact command stays as it is
    for command in auto["commands"]:
        words = command.removesuffix(" *")
        shown[words] = shown.get(words, False) or command.endswith(" *")
    lines.append("commands (... = any arguments): " + ", ".join(f"{w} ..." if a else w for w, a in shown.items()))
    lines.append("edits: " + ", ".join(f"{e}/" for e in auto["edit"]))
    return lines


# ------------------------------------------------------------------ init


def init_command(template_name: str, package: str, description: str, answers: dict) -> str:
    """The `archvow init` command line that creates this project (shown in its README)."""
    first = f"archvow init {package} -t {template_name} -d {shlex.quote(description)}"
    options = [f"-a {shlex.quote(f'{key}={value}')}" for key, value in answers.items()
               if value not in ("", [], None)]  # an empty answer is the default: not worth showing
    return first + (" \\\n    " + " ".join(options) if options else "")


def spec_committed(root: Path) -> bool:
    """True when the spec is in Git: it is then the team's, and init never resets it."""
    try:
        result = subprocess.run(["git", "-C", str(root), "ls-files", "--error-unmatch", str(mf.PROJECT_REL)],
                                capture_output=True, text=True,
                                encoding="utf-8", errors="replace", check=False)
    except FileNotFoundError:
        return False
    return result.returncode == 0


def _existing_project(root: Path) -> dict | None:
    """The spec of the project already in `root`, if any (None: no project, or unreadable)."""
    if not mf.is_project(root):
        return None
    try:
        return mf.load(root)
    except mf.ManifestError:
        return None


def _already_a_project(root: Path, data: dict | None, package: str) -> str:
    if data is None:
        return f"{root / mf.PROJECT_REL} already exists: this folder is already an archvow project"
    container = (data.get("containers") or [{}])[0]
    count = len(container.get("components", []) or [])
    name = container.get("package", package)
    return (f"this folder is already the archvow project '{name}' ({container.get('template', '?')}, "
            f"{count} components): nothing to initialise.\n"
            "  To work on it:  pip install -r requirements.txt, then: archvow next\n"
            "  To rewrite the generated files (AGENTS.md, CI, hooks...) from the template, keeping the spec:\n"
            f"                  archvow init {name} --force -a architects=...")


def init_project(root: Path, template_name: str | None, package: str, description: str | None,
                 answers: dict | None = None, src: str = "src", force: bool = False) -> list[Path]:
    """Add archvow to a repository (new or existing). Creates no source folders.

    In a folder that is already a project, `init` refuses. With `force` it rewrites the generated
    files; once the manifest is committed it keeps the spec (components, decisions, hazards,
    invariants): only `git rm -r .archvow` - a visible, reviewed change - starts over.
    """
    if not PACKAGE_RE.match(package) or keyword.iskeyword(package):
        raise SpecError(f"'{package}' is not a valid snake_case Python package name")
    existing = _existing_project(root)
    if mf.is_project(root) and not force:
        raise SpecError(_already_a_project(root, existing, package))
    committed = existing is not None and spec_committed(root)
    kept = existing if committed else None
    answers = dict(answers or {})
    if kept is not None:
        container = kept["containers"][0]
        kept_template = mf.template_name(container)[0]
        if container.get("package") != package:
            raise SpecError(f"this project's package is '{container.get('package')}', not '{package}': "
                            f"archvow init {container.get('package')} --force ...")
        if template_name not in (None, kept_template):
            raise SpecError(f"this project uses template '{kept_template}', not '{template_name}' "
                            "(changing the template of a committed spec is not supported)")
        template_name = kept_template
        description = description or kept.get("system", {}).get("description")
        # the answers given at init stay, unless given again: --force changes only what is passed
        answers = {**(kept.get("init_answers") or {}), **answers}
        for key in APPROVALS:  # the current approvals, as the manifest holds them
            stored = kept.get(key) if key != "rules" else None
            if key not in answers and stored is not None:
                answers[key] = stored if isinstance(stored, str) else ",".join(stored)
    template_name = template_name or DEFAULT_TEMPLATE
    if kept is not None:  # init --force: a newer company template found outside replaces the project's copy
        from archvow.templates import vendor

        vendor(root, template_name)
    description = description or package.replace("_", " ").capitalize()
    template = load_template(template_name, root if root.is_dir() else None, language=DEFAULT_LANGUAGE)
    if template.data.get("abstract"):
        raise SpecError(f"template '{template.name}' is a shared base that other templates extend; "
                        "choose one of them (archvow catalog)")
    answers = migrate_answers(template, answers)
    if kept is not None and "rules" not in answers:  # the rules the project runs today
        answers["rules"] = rules_answer(template, kept)
    asks_language = any(q.get("id") == "language" for q in template.data.get("questions", []))
    old_language = (kept.get("language") or DEFAULT_LANGUAGE) if kept is not None else None
    if kept is not None and asks_language and "language" not in answers:
        answers["language"] = old_language  # a project keeps its language
    language = answers_with_defaults(template, answers).get("language") if asks_language else None
    language = str(language or DEFAULT_LANGUAGE)
    template = load_template(template_name, root if root.is_dir() else None, language=language)
    company_pattern = (template.data.get("questions_defaults") or {}).get("ticket_pattern")
    if company_pattern and "ticket_pattern" not in answers:  # a company template's pattern is the project's
        answers["ticket_pattern"] = str(company_pattern)
    context = {
        "init_command": init_command(template.name, package, description, answers),
        "package": package,
        "project_name": package.replace("_", "-"),
        "description": description,
        "template": template.ref,
        "layers": template.layers,
        "src": src,
        "archvow_version": __version__,
        "pytest_configured": _pytest_configured(root),
        **_existing_tooling(root, src),
        "ai_tool_names": template.data.get("ai_tool_names") or {},
        "known_ai_tools": [t for t in (template.data.get("ai_tool_files") or {}) if t != "unlisted"],
        **template.data.get("context", {}),
        **answers_with_defaults(template, answers),
    }
    context["ticket_pattern_set"] = "ticket_pattern" in answers  # set by the architect, or not yet
    context["families"], context["compliance"] = split_rules(template, context.get("rules") or ["all"])
    from archvow.branches import ticket_example

    pattern = answers.get("ticket_pattern")
    context["ticket"] = lambda number=1: ticket_example(pattern, number)  # examples use the project's tickets
    if "reviewers" in context and "none" in (context["reviewers"] or []):
        context["reviewers"] = []  # `none`: no AI reviewer
    context["instructed_tools"] = mf.instructed_tools(context)
    context["agents_approved"] = [t for t in context.get("ai_tools") or [] if t != "none"]  # agents write code
    context["ai_tool_review"] = template.data.get("ai_tool_review") or {}
    context["review_secrets"] = [entry["secret"] for tool in context.get("reviewers") or []
                                 if (entry := context["ai_tool_review"].get(tool) or {}).get("secret")]
    context.update(derive(template, context))
    context["auto"] = auto_approval(template, context)  # what the AI may do without asking
    if dora_approvers_problem(template, context):  # caught here, not at the first commit (DORA002)
        raise SpecError(dora_approvers_problem(template, context))
    if "briefs" in context:  # the briefs folders: in the project, not hidden, not code or tests, not nested
        from archvow.briefs import folder_problems

        problems = folder_problems(list(context["briefs"] or []), f"{src}/{package}")
        if problems:
            raise SpecError("answer 'briefs': " + "; ".join(problems))
    root.mkdir(parents=True, exist_ok=True)  # only once every answer is valid
    from archvow.templates import vendor

    vendor(root, template.name)  # company packs travel with the project: no ARCHVOW_TEMPLATES needed
    context["ai_instruction_paths"] = [
        rel for tool, rel in (template.data.get("ai_tool_instructions") or {}).items()
        if tool in context["instructed_tools"]]
    env = _env()
    conditions = template.data.get("file_conditions", {}) or {}
    skeleton = template.skeleton_files()
    if "AGENTS.md.j2" in skeleton:  # tool-specific rule files embed the shared rules
        context["agents_rules"] = template.rename_layers(
            env.from_string(skeleton["AGENTS.md.j2"].read_text("utf-8")).render(**context))
    written: list[Path] = []
    verbatim = verbatim_prefixes(template)  # copied as they are, even .j2
    for rel, source in skeleton.items():
        as_is = rel.startswith(verbatim) if verbatim else False
        target_rel = rel[:-3] if rel.endswith(".j2") and not as_is else rel
        if "{{" in target_rel:  # a file named after the project, e.g. dags/{{ package }}_dag.py
            target_rel = env.from_string(target_rel).render(**context)
        target_rel = template.rename_layers(target_rel)
        matches = [prefix for prefix in conditions if target_rel.startswith(prefix)]
        rule = conditions[max(matches, key=len)] if matches else None  # most specific prefix wins
        if rule is not None and not env.compile_expression(rule)(**context):
            if force and target_rel in (template.data.get("withdrawn_files") or []):
                (root / target_rel).unlink(missing_ok=True)  # its condition turned false: it goes
            continue
        target = root / target_rel
        merged = target_rel in (template.data.get("merged_files") or [])
        if target.exists() and not force and not merged:
            continue  # never overwrite a file the team already owns (e.g. ruff.toml, CODEOWNERS)
        content = source.read_text(encoding="utf-8")
        if rel.endswith(".j2") and not as_is:  # rendered, with the layers' folders the template names
            content = template.rename_layers(env.from_string(content).render(**context))
        if merged:
            content = merge_marked(target, content, language, force=force, ours=existing is not None)
            if content is None:
                continue
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8", newline="\n")
        if target_rel in (template.data.get("executable_files") or []):
            target.chmod(0o755)
        written.append(target)
    for tool, rel in (template.data.get("ai_tool_instructions") or {}).items():
        target = root / rel
        if tool in context["instructed_tools"] and (force or not target.exists()):
            target.parent.mkdir(parents=True, exist_ok=True)
            from archvow.i18n import tr

            target.write_text(
                tr(language, "# Instructions for {tool}", tool=tool) + "\n\n"
                + tr(language, "The rules for every AI assistant are in AGENTS.md at the repository root; they "
                     "are copied below so they apply even when that file is not loaded. If the two "
                     "differ, AGENTS.md wins.") + "\n\n" + context.get("agents_rules", ""),
                encoding="utf-8", newline="\n")
            written.append(target)
    ignored = merge_gitignore(root, [*(template.data.get("gitignore", []) or []), *AGENT_GITIGNORE,
                                     *(REVIEW_GITIGNORE if context.get("reviewers") else [])])
    if ignored:
        written.append(ignored)
    attributes = merge_gitignore(root, GITATTRIBUTES, ".gitattributes")
    if attributes:
        written.append(attributes)
    if kept is not None:  # the committed spec stays; only the approvals follow the answers
        _store_answers(kept, context, answers, template)
        kept["containers"][0]["template"] = template.ref  # the files now come from this version
        reword_questions(kept, template)  # clearer wording reaches the questions not answered yet
        _register_template_parties(root, kept, template)
        if asks_language and old_language != language:  # the template's own texts follow the language
            previous = load_template(template_name, root, language=old_language)
            relocalize(kept, previous, template)
        if asks_language:
            kept["language"] = language
        written.append(mf.save(root, kept))
        return written
    initial = []
    for component in template.data.get("initial_components", []):
        rendered = _render(env, component, context)
        rendered["decisions"] = [{"question": edge_case_text(q), "answer": None} for q in rendered.pop("edge_cases", []) or []]
        rendered["assumptions"] = []
        initial.append(rendered)
    data = {
        "schema_version": mf.SCHEMA_VERSION,
        "system": {"name": package, "description": description},
        "containers": [{
            "id": package, "template": template.ref, "package": package,
            "path": f"{src}/{package}", "components": initial,
        }],
        "hazards": [],
        "invariants": [],
        "rules": {},
    }
    if asks_language:
        data["language"] = language
    _store_answers(data, context, answers, template)
    _register_template_parties(root, data, template)
    written.append(mf.save(root, data))
    return written


def _register_template_parties(root: Path, data: dict, template: Template) -> None:
    """With DORA on: the template's own packages (pyspark, ruff, pytest...) enter the third-party
    register with their supplier, licence and criticality; the project's others are added with
    `archvow dependency add`. A package the register already has is never changed."""
    if "dora" not in (data.get("compliance") or []):
        return
    from archvow.dora import normalise, requirements

    present = {normalise(name) for name, _, _ in requirements(root)}
    register = data.setdefault("third_parties", [])
    known = {normalise(e.get("name", "")) for e in register}
    for entry in template.data.get("third_parties") or []:
        if normalise(entry["name"]) in present and normalise(entry["name"]) not in known:
            register.append({**entry, **stamp(root)})
    register.sort(key=lambda e: normalise(e["name"]))
    if not register:
        data.pop("third_parties")


def reword_questions(data: dict, template: Template) -> int:
    """`init --force`: unanswered questions take the template's newer wording (`reworded_questions`).

    An answered question keeps the words it was answered with. Returns how many were reworded.
    """
    reworded = template.data.get("reworded_questions") or {}
    count = 0
    for container in data.get("containers", []) or []:
        for comp in container.get("components", []) or []:
            for decision in comp.get("decisions", []) or []:
                seen = set()
                while not (decision.get("answer") or "").strip() and decision.get("question") in reworded \
                        and decision["question"] not in seen:  # follows several rewordings, never loops
                    seen.add(decision["question"])
                    decision["question"] = reworded[decision["question"]]
                count += bool(seen)
    return count


def relocalize(data: dict, old: Template, new: Template) -> None:
    """Replace the texts the template wrote into the manifest by the same texts in the new language.

    The questions of each component type, and the descriptions and questions of the starting
    components, are matched by position; anything a person wrote stays as it is.
    """
    for comp in (data.get("containers") or [{}])[0].get("components", []) or []:
        before = old.type_of(comp)
        after = new.type_of(comp)
        pairs = list(zip(map(edge_case_text, before.get("edge_cases") or []), map(edge_case_text, after.get("edge_cases") or []),
                         strict=False))
        initial_old = next((c for c in old.data.get("initial_components", []) if c.get("id") == comp["id"]), None)
        initial_new = next((c for c in new.data.get("initial_components", []) if c.get("id") == comp["id"]), None)
        if initial_old and initial_new:
            pairs += list(zip(map(edge_case_text, initial_old.get("edge_cases") or []),
                              map(edge_case_text, initial_new.get("edge_cases") or []), strict=False))
            if comp.get("description") == initial_old.get("description"):
                comp["description"] = initial_new.get("description", comp["description"])
        mapping = dict(pairs)
        for decision in comp.get("decisions", []) or []:
            decision["question"] = mapping.get(decision.get("question"), decision.get("question"))



# Only with AI reviewers: their reports stay local (a project without reviewers is left as it was,
# including a `reviews/` folder of its own).
REVIEW_GITIGNORE = ["# archvow: AI review reports (local; CI keeps them with the merge request)", "reviews/"]

# Each AI agent's last run in this project and the next commit's Archvow-Agent line (agent.py).
AGENT_GITIGNORE = ["# archvow: how each AI agent last ran here, for the commit check (local)", ".archvow/*.local"]

# Init answers kept as approvals at the top of the manifest (protected: a new one is ARCH020).
APPROVALS = ("ai_tools", "reviewers", "dependencies", "mode", "rules")


def _store_answers(data: dict, context: dict, answers: dict, template: Template) -> None:
    """Approvals the checks use, and every init answer as it is now - given with -a or asked, or the
    template's default - so `init --force` keeps them: a project changes only when an architect
    changes an answer, never because a template's default changed. The ticket pattern is recorded
    only once an architect sets it (until then the hooks say how)."""
    if "ai_tools" in context:
        data["ai_tools"] = context["ai_tools"]  # approved assistants (protected, checked by ARCH040)
    if context.get("reviewers"):
        data["reviewers"] = context["reviewers"]  # approved AI reviewers (ARCH041, ARCH042)
    else:
        data.pop("reviewers", None)
    if "dependencies" in context:
        data["dependencies"] = context["dependencies"]  # approved third-party imports (ARCH023)
    if "compliance" in context:  # the compliance families of `rules` (gdpr, tst, dora); a guard, like the others
        data["compliance"] = list(context["compliance"] or ["none"])
    if "mode" in context:  # how much the AI decides on its own (proposals.py); loosening it is a weakening
        data["mode"] = context["mode"] or "strict"
    if "families" in context:  # the code families of `rules` check applies (the floor stays)
        data["families"] = list(context["families"])
    kept = {}
    for question in template.data.get("questions", []):
        qid = question["id"]
        if qid in APPROVALS or (qid == "ticket_pattern" and qid not in answers):
            continue
        value = answers[qid] if qid in answers else context.get(qid)
        if isinstance(value, list):
            value = ",".join(str(v) for v in value)
        if value is not None:
            kept[qid] = value
    kept |= {k: v for k, v in answers.items() if k not in APPROVALS and k not in kept}
    if kept:
        data["init_answers"] = kept


GITATTRIBUTES = ["# the scripts run on Linux (cluster, container, CI): they keep LF line endings, even from Windows",
                 "*.sh text eol=lf", ".githooks/* text eol=lf",
                 "# business examples keep their bytes on every system (archvow compares their fingerprint)",
                 "tests/examples/** text eol=lf"]


def merge_gitignore(root: Path, lines: list[str], name: str = ".gitignore") -> Path | None:
    """Create .gitignore (or .gitattributes) or append the missing archvow lines; never remove the
    team's own."""
    if not lines:
        return None
    path = root / name
    existing = path.read_text(encoding="utf-8").splitlines() if path.is_file() else []
    present = {line.strip() for line in existing}
    missing = [line for line in lines if line.startswith("#") or line.strip() not in present]
    if not [line for line in missing if not line.startswith("#")]:
        return None
    block = []
    for index, line in enumerate(missing):
        if line.startswith("#"):
            nxt = missing[index + 1] if index + 1 < len(missing) else "#"
            if nxt.startswith("#"):
                continue  # drop a comment whose entries are all already present
            if block:
                block.append("")
        block.append(line)
    text = "\n".join(existing).rstrip("\n")
    if text:
        text += "\n\n# --- added by archvow init ---\n"
    path.write_text(text + "\n".join(block) + "\n", encoding="utf-8", newline="\n")
    return path


BEGIN_MARK, END_MARK = "<!-- archvow:begin -->", "<!-- archvow:end -->"


def merge_marked(path: Path, content: str, language: str, *, force: bool, ours: bool) -> str | None:
    """A file shared with the team (README.md): archvow owns only the part between its markers.

    New file: its title, then the rest inside the markers. The team's file: the part added at its
    end, once.
    `--force` replaces only that part; in a project archvow made, a file without markers is
    replaced whole. None: nothing to write.
    """
    from archvow.i18n import tr

    note = tr(language, "<!-- Added by archvow init: `archvow init --force` rewrites only what is between "
              "these two markers; write your own text outside them. -->")
    title = ""
    if content.startswith("# "):  # the title belongs to the team: it stays outside the markers
        title, _, content = content.partition("\n")
    block = f"{BEGIN_MARK}\n{note}\n\n{content.strip()}\n\n{END_MARK}\n"
    text = path.read_text(encoding="utf-8") if path.is_file() else ""
    if BEGIN_MARK in text and END_MARK in text.split(BEGIN_MARK, 1)[1]:
        if not force:
            return None
        before, rest = text.split(BEGIN_MARK, 1)
        after = rest.split(END_MARK, 1)[1]
        return before + block + after.removeprefix("\n")
    if not text.strip() or (force and ours):
        return f"{title}\n\n{block}" if title else block
    return text.rstrip("\n") + "\n\n" + block


def _existing_tooling(root: Path, src: str) -> dict:
    """What the repository already has: archvow uses it instead of adding its own."""
    def theirs(name: str, *generated_marks: str) -> bool:  # the team's file, not one archvow wrote
        path = root / name
        text = path.read_text(encoding="utf-8", errors="replace") if path.is_file() else ""
        return path.is_file() and not any(mark in text for mark in generated_marks)

    existing = next((name for name in ("requirements.txt", "requirements", "requirements-dev.txt")
                     if theirs(name, "archvow==")), None)
    pyproject = theirs("pyproject.toml", "./entrypoint.sh --package", "(generated by archvow")
    if existing:
        install = f"pip install -r {existing}"
    elif pyproject:
        install = 'pip install -e ".[dev]"'
    else:
        install = "pip install -r requirements.txt"
    return {
        "makefile_exists": any((root / name).is_file() for name in ("Makefile", "makefile", "GNUmakefile")),
        "requirements_file_exists": bool(existing) or pyproject,
        "requirements_name": existing or ("pyproject.toml" if pyproject else "requirements.txt"),
        "pyproject_exists": pyproject,
        "install_command": install,
        "cov_option": "--cov" if (root / ".coveragerc").is_file() else f"--cov={src}",
    }


def _pytest_configured(root: Path) -> bool:
    """True when the repository already configures pytest (archvow then writes no pytest.ini)."""
    markers = {"pytest.ini": "", "pyproject.toml": "[tool.pytest", "setup.cfg": "[tool:pytest]",
               "tox.ini": "[pytest]"}
    for name, marker in markers.items():
        path = root / name
        if path.is_file() and marker in path.read_text(encoding="utf-8", errors="ignore"):
            return True
    return False


def init_git(root: Path) -> tuple[str, str]:
    """Create a Git repository (branch main) unless the folder is already inside one."""
    import subprocess

    try:
        inside = subprocess.run(["git", "-C", str(root), "rev-parse", "--is-inside-work-tree"],
                                capture_output=True, text=True,
                                encoding="utf-8", errors="replace", check=False)
    except FileNotFoundError:
        return "warn", "Git is not installed: run `git init`, then `git config core.hooksPath .githooks`"
    parent = None
    if inside.returncode == 0:
        top = subprocess.run(["git", "-C", str(root), "rev-parse", "--show-toplevel"],
                             capture_output=True, text=True,
                             encoding="utf-8", errors="replace", check=False).stdout.strip()
        if not top or Path(top).resolve() == root.resolve():
            return "", ""  # already its own repository
        parent = Path(top)  # CI files, CODEOWNERS and hooks only work at a repository root
    subprocess.run(["git", "-C", str(root), "init", "-q"], check=True)
    subprocess.run(["git", "-C", str(root), "symbolic-ref", "HEAD", "refs/heads/main"], check=True)
    if parent is not None:
        rel = root.resolve().relative_to(parent.resolve()).as_posix()
        return "warn", (f"Git repository created (branch main) inside the repository {parent}: "
                        f"add '{rel}/' to its .gitignore so the two stay separate")
    return "ok", "Git repository created (branch main)"


def enable_git_hooks(root: Path) -> tuple[str, str]:
    """Point Git at .githooks when this is a Git repository (local setting, this clone only)."""
    import subprocess

    if not (root / ".githooks").is_dir():
        return "", ""
    try:
        inside = subprocess.run(["git", "-C", str(root), "rev-parse", "--show-toplevel"],
                                capture_output=True, text=True,
                                encoding="utf-8", errors="replace", check=False)
    except FileNotFoundError:
        return "warn", "Local checks not enabled (git not found): later run `git config core.hooksPath .githooks`"
    if inside.returncode != 0:
        return ("warn", "Local checks not enabled (not a Git repository): after `git init`, "
                "run `git config core.hooksPath .githooks`")
    top = Path(inside.stdout.strip()).resolve()
    if top != root.resolve():
        rel = root.resolve().relative_to(top).as_posix()
        return ("warn", f"Local checks not enabled: the repository root is {top}. If this is its only "
                f"project, run `git -C {top} config core.hooksPath {rel}/.githooks`")
    subprocess.run(["git", "-C", str(root), "config", "core.hooksPath", ".githooks"], check=False)
    if os.name == "nt":  # Windows has no executable bit: Git records it, so Linux (CI, cluster) can run them
        scripts = [p.relative_to(root).as_posix() for p in [*(root / ".githooks").iterdir(), *root.glob("*.sh")]
                   if p.is_file()]
        subprocess.run(["git", "-C", str(root), "add", "--chmod=+x", "--", *scripts], check=False,
                       capture_output=True)
        return "ok", "Local checks enabled for this clone (.githooks); the scripts staged as executable"
    return "ok", "Local checks enabled for this clone (.githooks)"


def next_steps(template_name: str, root: Path, answers: dict | None = None) -> str:
    """Platform setup steps printed after `init`."""
    template = load_template(template_name, root)
    text = template.data.get("next_steps")
    if not text:
        return ""
    answers = migrate_answers(template, answers or {})
    context = {**template.data.get("context", {}), **answers_with_defaults(template, answers)}
    context["families"], context["compliance"] = split_rules(template, context.get("rules") or ["all"])
    context["agents_approved"] = [t for t in context.get("ai_tools") or [] if t != "none"]
    context.update(derive(template, context))
    return _env().from_string(text).render(**context).strip()


def _render(env: Environment, value: object, context: dict) -> object:
    if isinstance(value, str):
        return env.from_string(value).render(**context)
    if isinstance(value, list):
        return [_render(env, item, context) for item in value]
    if isinstance(value, dict):
        return {k: _render(env, v, context) for k, v in value.items()}
    return value


# ------------------------------------------------------------------ components


def _load(root: Path, container_id: str | None) -> tuple[dict, dict, Template]:
    data = mf.load(root)
    container = mf.container(data, container_id)
    return data, container, load_template(mf.template_name(container)[0], root)


def find_component(data: dict, component_id: str) -> tuple[dict, dict]:
    for container in data.get("containers", []):
        for component in container.get("components", []):
            if component["id"] == component_id:
                return container, component
    import difflib

    known = [c["id"] for ct in data.get("containers", []) for c in ct.get("components", [])]
    close = difflib.get_close_matches(component_id, known, n=1)
    hint = f" Did you mean '{close[0]}'?" if close else ""
    raise SpecError(f"unknown component '{component_id}'.{hint} Components in this project: "
                    f"{', '.join(known) or 'none'}. Declare a new one with "
                    f"`archvow component add <type> <name> -d \"...\"` (`archvow catalog` lists the types).")


GROUP_RE = re.compile(r"^[a-z][a-z0-9_]*$")


def _check_group(group: str | None) -> str | None:
    """A group is one folder level inside a layer: a snake_case name, or none."""
    if group is None or not group.strip():
        return None
    group = group.strip()
    if not GROUP_RE.fullmatch(group) or keyword.iskeyword(group):
        raise SpecError(f"group '{group}' must be a snake_case folder name, e.g. orders")
    return group


def add_component(root: Path, type_name: str, name: str, description: str, *,
                  spec: str | None = None, uses: list[str] | None = None,
                  signature: str | None = None, container_id: str | None = None,
                  group: str | None = None, routes: list[str] | None = None, source: dict | None = None,
                  kind: str | None = None, file: str | None = None) -> dict:
    """Declare a component. Writes the spec only: no source or test files. A type with kinds (a
    reader: files, table, jdbc...) takes its kind's symbols and questions (default: the first kind).
    `file` adopts an existing module where it is: its layer comes from `layer_paths`, its symbols are
    the public functions, classes, constants and routes the file has today."""
    data, container, template = _load(root, container_id)
    ctype = template.component_types.get(type_name)
    if ctype is None:
        addable = [k for k, v in template.component_types.items() if v.get("addable", True)]
        raise SpecError(f"unknown component type '{type_name}' (available: {', '.join(addable)})")
    if not ctype.get("addable", True):
        raise SpecError(f"component type '{type_name}' is managed by the template")
    pattern = ctype.get("name_pattern", r"^[a-z][a-z0-9_]*$")
    if keyword.iskeyword(name):
        raise SpecError(f"name '{name}' is a Python keyword: choose another name")
    if not re.fullmatch(pattern, name):
        hint = ctype.get("name_hint", "")
        raise SpecError(f"name '{name}' must match {pattern}" + (f" ({hint})" if hint else ""))
    if not description.strip():
        raise SpecError("a description is required")
    description = _one_line(description)
    kinds = template.kinds(type_name)
    if kind and not kinds:
        raise SpecError(f"type '{type_name}' has no kinds: leave -k out")
    if kind and kind not in kinds:
        raise SpecError(f"unknown kind '{kind}' for a {type_name} (available: {', '.join(kinds)})")
    if kinds:
        kind = kind or kinds[0]
        ctype = template.type_of({"type": type_name, "kind": kind})
    if signature and not ctype.get("signature_overridable", False):
        raise SpecError(f"type '{type_name}' has a fixed signature")

    group = _check_group(group)
    fmt = mf.name_values(name)
    component_id = ctype["module"].format(**fmt)
    layer = ctype["layer"]
    components = container.setdefault("components", [])
    if any(c["id"] == component_id for c in components):
        raise SpecError(f"component '{component_id}' already exists")
    by_id = {c["id"]: c for c in components}
    allowed = (template.layer(layer) or {}).get("may_import", [])
    for used in uses or []:
        if used not in by_id:
            raise SpecError(f"--uses: unknown component '{used}'")
        if by_id[used]["layer"] != layer and by_id[used]["layer"] not in allowed:
            raise SpecError(f"layer '{layer}' may not depend on '{used}' (layer '{by_id[used]['layer']}')")

    symbols = []
    for index, sym in enumerate(ctype.get("symbols", [])):
        entry = {"kind": sym.get("kind", "function"), "name": sym["name"].format(**fmt)}
        if signature and index == 0:
            entry["signature"] = signature
        elif "signature" in sym:
            entry["signature"] = sym["signature"]
        if "annotation" in sym:
            entry["annotation"] = sym["annotation"]
        symbols.append(entry)

    symbols += _routes(ctype, routes)
    folder = f"{group}." if group else ""
    module = f"{container['package']}.{layer}.{folder}{component_id}"
    if file:
        if group or routes or signature:
            raise SpecError("--file keeps the file as it is: leave out --group, --route and --signature")
        module, symbols = _adopted_module(root, data, container, template, file, layer, type_name)
        if any(c.get("module") == module for c in components):
            raise SpecError(f"{file} is already a component")
    entry = {"id": component_id, "name": name, "type": type_name, **({"kind": kind} if kinds else {}),
             "layer": layer, "module": module}
    if file:
        entry["adopted"] = True
    if group:
        entry["group"] = group
    if spec:
        from archvow.branches import check_ticket

        check_ticket(data, spec.strip())
        entry["spec"] = spec
    entry["description"] = description.strip()
    entry["uses"] = list(uses or [])
    entry["symbols"] = symbols
    # Ambiguity is resolved by a human before coding, never silently by the implementer.
    entry["decisions"] = [{"question": edge_case_text(q), "answer": None} for q in ctype.get("edge_cases", [])]
    entry["assumptions"] = []
    if source:
        entry["source"] = source
    components.append(entry)
    mf.save(root, data)
    return entry


def _adopted_module(root: Path, data: dict, container: dict, template: Template, file: str, layer: str,
                    type_name: str) -> tuple[str, list[dict]]:
    """Module and current symbols of an existing file declared with --file, checked against its layer."""
    from archvow.check import file_layer_of, symbols_of_file

    rel = file.replace("\\", "/").removeprefix("./")
    path = root / rel
    base = (root / container["path"]).resolve()
    if not path.is_file() or path.suffix != ".py":
        raise SpecError(f"--file {file}: no such Python file (give its path from the project root)")
    if not path.resolve().is_relative_to(base):
        raise SpecError(f"--file {file}: not inside {container['path']}/, the package archvow checks")
    if path.name == "__init__.py":
        raise SpecError(f"--file {file}: a package __init__ is not a component; declare a module file")
    parts = path.resolve().relative_to(base).with_suffix("").parts
    module = ".".join([container["package"], *parts])
    found = file_layer_of(root, data, template, rel, module)
    if found != layer:
        raise SpecError(f"--file {file} is in layer {found or 'none'}, a {type_name} belongs in {layer}: an "
                        f"architect maps it in `layer_paths` of .archvow/spec.vow ({layer}: [{rel}]), or "
                        f"archvow init {container['package']} --force --adopt proposes the mapping")
    try:
        symbols = symbols_of_file(path.read_text(encoding="utf-8"))
    except SyntaxError as exc:
        raise SpecError(f"--file {file}: cannot be parsed ({exc.msg})") from exc
    return module, symbols


ROUTE_RE = re.compile(r"^\s*([a-z_][a-z0-9_]*)\s*:\s*(GET|POST|PUT|PATCH|DELETE)\s+(/\S*)\s*$")


def _routes(ctype: dict, routes: list[str] | None) -> list[dict]:
    """`name: METHOD /path` entries, for component types that declare routes (`routes: true`)."""
    if not routes:
        return []
    if not ctype.get("routes"):
        raise SpecError("--route: this component type has no routes")
    result, seen = [], set()
    for text in routes:
        match = ROUTE_RE.fullmatch(text)
        if not match:
            raise SpecError(f"--route '{text}': write it as \"<function>: <METHOD> <path>\", "
                            "e.g. \"get_order: GET /orders/{order_id}\"")
        name, method, path = match.groups()
        if name in seen or (method, path) in {(r["method"], r["path"]) for r in result}:
            raise SpecError(f"--route '{text}': declared twice")
        seen.add(name)
        result.append({"kind": "route", "name": name, "method": method, "path": path})
    return result


def edit_component(root: Path, component_id: str, *, description: str | None = None,
                   spec: str | None = None, uses: list[str] | None = None,
                   signature: str | None = None, group: str | None = None,
                   routes: list[str] | None = None, source: dict | None = None,
                   owners: list[str] | None = None) -> dict:
    """Change what may change after creation. Name, type and file stay fixed: remove and re-add.

    When the description, the signature or the routes change, every item recorded before (decisions,
    hazards, invariants, not applicable, accepted assumptions, examples) is marked to review (ARCH057):
    the returned component lists them under `to_review`."""
    import copy

    from archvow import toreview

    data = mf.load(root)
    container, comp = find_component(data, component_id)
    before = copy.deepcopy(comp)
    template = load_template(mf.template_name(container)[0], root)
    ctype = template.type_of(comp)
    if description is not None:
        if not description.strip():
            raise SpecError("a description is required")
        comp["description"] = _one_line(description)
    if spec is not None:
        if spec.strip():
            from archvow.branches import check_ticket

            check_ticket(data, spec.strip())
        comp["spec"] = spec.strip()
    if uses is not None:
        by_id = {c["id"]: c for c in container.get("components", [])}
        allowed = (template.layer(comp["layer"]) or {}).get("may_import", [])
        for used in uses:
            if used not in by_id or used == component_id:
                raise SpecError(f"--uses: unknown component '{used}'")
            if by_id[used]["layer"] != comp["layer"] and by_id[used]["layer"] not in allowed:
                raise SpecError(f"layer '{comp['layer']}' may not depend on '{used}'")
            loop = _path_to(by_id, used, component_id)
            if loop:
                raise SpecError(f"--uses: '{component_id}' -> {' -> '.join(loop)} would be a cycle "
                                "(the code could not import itself)")
        comp["uses"] = list(uses)
    if signature is not None:
        if not ctype.get("signature_overridable", False):
            raise SpecError(f"type '{comp['type']}' has a fixed signature")
        if not comp.get("symbols") or comp["symbols"][0].get("kind", "function") != "function":
            raise SpecError(f"'{component_id}' has no function signature to change")
        comp["symbols"][0]["signature"] = signature.strip()
    if group is not None:  # "" takes it out of its group
        new_group = _check_group(group)
        comp.pop("group", None)
        if new_group:
            comp["group"] = new_group
        comp["module"] = ".".join([container["package"], comp["layer"], *([new_group] if new_group else []), comp["id"]])
    if routes is not None:  # the complete new list of routes
        comp["symbols"] = [s for s in comp.get("symbols", []) if s.get("kind") != "route"] + _routes(ctype, routes)
    if source:
        comp["source"] = source
    if owners is not None:  # [] gives the component back to the architects
        bad = [o for o in owners if "@" not in o]
        if bad:
            raise SpecError(f"--owners: '{bad[0]}' is not an owner - @user, @group/subgroup or an e-mail")
        if owners:
            comp["owners"] = list(dict.fromkeys(owners))
        else:
            comp.pop("owners", None)
    marked = toreview.mark(data, comp, toreview.what_changed(before, comp))
    mf.save(root, data)
    return {**comp, "to_review": marked}


def _path_to(by_id: dict, start: str, target: str) -> list[str]:
    """The `uses` path from start to target ([] when target cannot be reached)."""
    stack, seen = [[start]], set()
    while stack:
        path = stack.pop()
        if path[-1] == target:
            return path
        if path[-1] in seen:
            continue
        seen.add(path[-1])
        stack += [[*path, nxt] for nxt in (by_id.get(path[-1], {}).get("uses") or [])]
    return []


def _required(text: str, what: str) -> str:
    """Spec texts are never empty, and fit on one line (they appear in lists and tables)."""
    if not str(text).strip():
        raise SpecError(f"{what} is required")
    return _one_line(text)


# A placeholder left from an example: "<column>", "<colonne clé>" - never "a < b" or "x <= 0".
PLACEHOLDER_RE = re.compile(r"<[^\W\d_][^<>\n]*[^\W_]>|<[^\W\d_]>")


def _one_line(text: str) -> str:
    """One line, and no `<...>` placeholder copied from an example: the spec says what is meant."""
    line = " ".join(str(text).split())
    found = PLACEHOLDER_RE.search(line)
    if found:
        raise SpecError(f"'{found.group(0)}' is a placeholder from an example: write the real value "
                        f"instead (in: {line})")
    return line


def remove_component(root: Path, component_id: str) -> dict:
    """Remove a component from the spec, with the hazards and invariants that belong to it."""
    data = mf.load(root)
    container, comp = find_component(data, component_id)
    if comp.get("type") == "foundation":
        raise SpecError(f"'{component_id}' is a template foundation and cannot be removed")
    users = [c["id"] for c in container.get("components", []) if component_id in (c.get("uses") or [])]
    if users:
        raise SpecError(f"'{component_id}' is used by {', '.join(users)}: remove it from their "
                        f"`uses` first (archvow component edit <component> -u ...)")
    container["components"] = [c for c in container["components"] if c["id"] != component_id]
    hazards = [h for h in data.get("hazards", []) or [] if h.get("component") == component_id]
    hazard_ids = {h["id"] for h in hazards}
    data["hazards"] = [h for h in data.get("hazards", []) or [] if h.get("component") != component_id]
    invariants = [i for i in data.get("invariants", []) or []
                  if i.get("component") == component_id or set(i.get("mitigates") or []) <= hazard_ids
                  and i.get("mitigates")]
    data["invariants"] = [i for i in data.get("invariants", []) or [] if i not in invariants]
    if data.get("dismissed"):
        data["dismissed"] = [d for d in data["dismissed"] if d.get("component") != component_id]
    for rule in data.get("project_rules") or []:
        listed = (rule.get("scope") or {}).get("components")
        if listed and component_id in listed:
            listed.remove(component_id)
    if data.get("project_rules"):
        data["project_rules"] = [r for r in data["project_rules"]
                                 if (r.get("scope") or {}).get("components", True)]
    mf.save(root, data)
    return {"component": component_id, "hazards": sorted(hazard_ids),
            "invariants": sorted(i["id"] for i in invariants)}


def suggested_answer(root: Path, data: dict, component_id: str, number: int) -> str | None:
    """The template's suggested answer to question `number` of a component, if it has one."""
    container, comp = find_component(data, component_id)
    decisions = comp.get("decisions", []) or []
    if not 1 <= number <= len(decisions):
        return None
    template = load_template(mf.template_name(container)[0], root)
    return template.suggested_answers(comp).get(decisions[number - 1].get("question"))


def decide(root: Path, component_id: str, question: int | str, answer: str, source: dict | None = None,
           origin: str | None = None) -> dict:
    """Answer an edge-case question (or add a new question with its answer)."""
    data = mf.load(root)
    _, component = find_component(data, component_id)
    decisions = component.setdefault("decisions", [])
    if not answer.strip():
        raise SpecError("an answer is required")
    if isinstance(question, int) or str(question).isdigit():
        index = int(question) - 1
        if not 0 <= index < len(decisions):
            raise SpecError(f"'{component_id}' has no question {question} (it has 1..{len(decisions)}; "
                            f"see archvow show {component_id})")
        decisions[index]["answer"] = _one_line(answer)
        decisions[index].update(stamp(root))
        decisions[index].pop("origin", None)
        decisions[index].pop("review", None)  # recorded again: looked at after the component's change
        if origin:  # the AI proposed it, a person accepted it (archvow decision accept)
            decisions[index]["origin"] = origin
        decision = decisions[index]
    else:
        decision = {"question": _required(question, "the question"), "answer": _one_line(answer), **stamp(root),
                    **({"source": source} if source else {})}
        decisions.append(decision)
    mf.save(root, data)
    return decision


# ------------------------------------------------------------------ answers for a whole type


def type_questions(root: Path, data: dict, type_name: str) -> list[tuple[str, str | None]]:
    """[(question, suggested answer)] a component type asks, numbered from 1 like archvow show."""
    from archvow.templates import edge_case_suggestion, edge_case_text

    container = (data.get("containers") or [None])[0]
    if container is None:
        raise SpecError("no container in this project")
    template = load_template(mf.template_name(container)[0], root)
    if type_name not in template.component_types:
        raise SpecError(f"unknown component type '{type_name}' (types: {', '.join(sorted(template.component_types))})")
    return [(edge_case_text(q), edge_case_suggestion(q)) for q in template.type_of({"type": type_name}).get("edge_cases") or []]


def decide_for_type(root: Path, type_name: str, number: int, answer: str | None) -> dict:
    """Answer question `number` once for every component of a type, today and later. A component that
    already has its own answer keeps it. answer None: the template's suggestion. Returns the entry with
    `components` (who takes it) and `own` (who keeps their own answer)."""
    data = mf.load(root)
    asked = type_questions(root, data, type_name)
    if not 1 <= number <= len(asked):
        listing = "; ".join(f"{n}. {q}" for n, (q, _) in enumerate(asked, 1))
        raise SpecError(f"a {type_name} has no question {number} (it has 1..{len(asked)}: {listing})")
    question, suggested = asked[number - 1]
    if answer is None:
        if not suggested:
            raise SpecError(f"question {number} of a {type_name} has no suggested answer: give yours "
                            f"(archvow decision make --type {type_name} {number} \"...\")")
        answer = suggested
    entry = {"type": type_name, "question": question, "answer": _one_line(answer), **stamp(root)}
    shared = [a for a in data.get("type_answers") or []
              if not (a.get("type") == type_name and a.get("question") == question)]
    data["type_answers"] = [*shared, entry]
    own, takes = _type_users(data, type_name, question)
    mf.save(root, data)
    return {**entry, "number": number, "components": takes, "own": own}


def unset_for_type(root: Path, type_name: str, number: int) -> dict:
    """Stop answering question `number` for the whole type: each component answers it on its own again."""
    data = mf.load(root)
    asked = type_questions(root, data, type_name)
    if not 1 <= number <= len(asked):
        raise SpecError(f"a {type_name} has no question {number} (it has 1..{len(asked)})")
    question = asked[number - 1][0]
    found = [a for a in data.get("type_answers") or [] if a.get("type") == type_name and a.get("question") == question]
    if not found:
        raise SpecError(f"question {number} of a {type_name} is not answered for the whole type")
    _, takes = _type_users(data, type_name, question)
    data["type_answers"] = [a for a in data["type_answers"] if a not in found]
    if not data["type_answers"]:
        data.pop("type_answers")
    mf.save(root, data)
    return {"type": type_name, "question": question, "number": number, "components": takes}


def _type_users(data: dict, type_name: str, question: str) -> tuple[list[str], list[str]]:
    """(components of the type with their own answer to it, components that take the type's answer)."""
    own, takes = [], []
    for container in data.get("containers") or []:
        for comp in container.get("components") or []:
            if comp.get("type") != type_name:
                continue
            decision = next((d for d in comp.get("decisions") or [] if d.get("question") == question), None)
            if decision is None:
                continue
            mine = str(decision.get("answer") or "").strip() and decision.get("origin") != mf.TYPE_ORIGIN
            (own if mine else takes).append(comp["id"])
    return own, takes


# ------------------------------------------------------------------ rules (R1, R2...)


def rule_scope(rule: dict, language: str = DEFAULT_LANGUAGE) -> str:
    """Who a rule applies to, in words: 'sales_reader, orders_reader', 'every reader', 'all components'."""
    from archvow.i18n import tr

    scope = rule.get("scope") or {}
    if scope.get("all"):
        return tr(language, "all components")
    if scope.get("type"):
        return tr(language, "every {type}", type=scope["type"])
    return ", ".join(scope.get("components") or [])


def rule_applies(rule: dict, component: dict) -> bool:
    scope = rule.get("scope") or {}
    return bool(scope.get("all") or (scope.get("type") and scope["type"] == component.get("type"))
                or component.get("id") in (scope.get("components") or []))


def rules_for(data: dict, component: dict) -> list[dict]:
    """The project rules that apply to a component, in their R order."""
    return [r for r in data.get("project_rules") or [] if rule_applies(r, component)]


def add_rule(root: Path, text: str, *, components: list[str] | None = None, type_name: str | None = None,
             all_components: bool = False, source: dict | None = None) -> dict:
    """Record a rule in your own words (best: "Given ..., when ..., then ..."), for one or several
    components, every component of a type (future ones too) or all components. One test each."""
    if sum(bool(x) for x in (components, type_name, all_components)) != 1:
        raise SpecError("say who the rule applies to: components (a,b), --type <type> or --all")
    data = mf.load(root)
    if components:
        for cid in components:
            find_component(data, cid)
        scope: dict = {"components": list(dict.fromkeys(components))}
    elif type_name:
        types = {t for c in data["containers"] for t in load_template(mf.template_name(c)[0], root).component_types}
        if type_name not in types:
            raise SpecError(f"unknown component type '{type_name}' (types: {', '.join(sorted(types))})")
        scope = {"type": type_name}
    else:
        scope = {"all": True}
    rules = data.setdefault("project_rules", [])
    number = max((int(r["id"][1:]) for r in rules if str(r.get("id", "")).startswith("R")), default=0) + 1
    entry = {"id": f"R{number}", "text": _required(text, "the rule"), "scope": scope, **stamp(root),
             **({"source": source} if source else {})}
    rules.append(entry)
    mf.save(root, data)
    return entry


def _find_rule(data: dict, rule_id: str) -> dict:
    wanted = str(rule_id).upper()
    wanted = wanted if wanted.startswith("R") else f"R{wanted}"
    for rule in data.get("project_rules") or []:
        if rule.get("id") == wanted:
            return rule
    known = ", ".join(r["id"] for r in data.get("project_rules") or []) or "none yet"
    raise SpecError(f"no rule {rule_id} (rules: {known}; archvow show lists them)")


def edit_rule(root: Path, rule_id: str, text: str) -> dict:
    data = mf.load(root)
    rule = _find_rule(data, rule_id)
    rule["text"] = _required(text, "the rule")
    rule.update(stamp(root))
    mf.save(root, data)
    return rule


def remove_rule(root: Path, rule_id: str) -> dict:
    data = mf.load(root)
    rule = _find_rule(data, rule_id)
    data["project_rules"] = [r for r in data["project_rules"] if r is not rule]
    mf.save(root, data)
    return rule



ITEM_ID = re.compile(r"^[a-z][a-z0-9_]*\.(?i:H|INV)\d+$|^[Rr]\d+$")


def find_item(data: dict, item_id: str) -> tuple[str, dict]:
    """A hazard (clean_orders.H1), an invariant (clean_orders.INV1) or a project rule (R1), by its id."""
    wanted = mf.normalise_item_id(item_id)
    match = mf.ITEM_ID_RE.match(wanted)
    if match:
        wanted = f"{match.group('scope')}.{match.group('kind').upper()}{match.group('n')}"
        kind = "hazard" if match.group("kind").upper() == "H" else "invariant"
    elif re.fullmatch(r"(?i)R\d+", wanted):
        wanted, kind = wanted.upper(), "rule"
    else:
        raise SpecError(f"{item_id!r} is not an id: a hazard <component>.H1, an invariant <component>.INV1 "
                        "or a rule R1")
    pool = {"hazard": data.get("hazards"), "invariant": data.get("invariants"), "rule": data.get("project_rules")}
    for item in pool[kind] or []:
        if str(item.get("id", "")) == wanted:
            return kind, item
    raise SpecError(f"no {kind} {wanted} (archvow show <component> lists them)")


def remove_hazard(root: Path, hazard_id: str) -> dict:
    """Remove a hazard; the invariants that prevented it no longer point to it."""
    data = mf.load(root)
    _, hazard = find_item(data, hazard_id)
    data["hazards"] = [h for h in data.get("hazards", []) or [] if h is not hazard]
    unlinked = []
    for inv in data.get("invariants", []) or []:
        if hazard["id"] in (inv.get("mitigates") or []):
            inv["mitigates"] = [m for m in inv["mitigates"] if m != hazard["id"]]
            unlinked.append(inv["id"])
    mf.save(root, data)
    return {**hazard, "unlinked": unlinked}


def remove_invariant(root: Path, invariant_id: str) -> dict:
    """Remove an invariant - never one that is the last guard of a critical or high hazard."""
    data = mf.load(root)
    _, inv = find_item(data, invariant_id)
    others = check_invariant_removable(data, inv)
    data["invariants"] = others
    mf.save(root, data)
    return inv


def check_invariant_removable(data: dict, inv: dict) -> list[dict]:
    """The other invariants, if `inv` is not the last guard of a critical or high hazard."""
    others = [i for i in data.get("invariants", []) or [] if i is not inv]
    for hid in inv.get("mitigates") or []:
        hazard = next((h for h in data.get("hazards", []) or [] if h["id"] == hid), None)
        guarded = any(hid in (i.get("mitigates") or []) for i in others)
        if hazard and hazard.get("severity") in ("critical", "high") and not guarded:
            raise SpecError(f"{inv['id']} is the only guard of {hid} ({hazard['severity']}: "
                            f"{hazard.get('description')}): add another first (archvow invariant add "
                            f"{hazard.get('component') or 'system'} \"...\" --prevents {hid}), or remove the "
                            f"hazard (archvow hazard remove {hid})")
    return others


def reopen_safety_question(root: Path, component: str, question: str) -> dict:
    """Undo a "not applicable": the safety question is open again."""
    data = mf.load(root)
    container, comp = find_component(data, component)
    template = load_template(mf.template_name(container)[0], root)
    word = resolve_guide_word(template, comp, question)
    entry = next((d for d in data.get("dismissed") or [] if d.get("component") == component
                  and d.get("guide_word") == word), None)
    if entry is None:
        hazard = next((h for h in data.get("hazards", []) or [] if h.get("component") == component
                       and h.get("guide_word") == word), None)
        hint = f": it is answered by {hazard['id']} (archvow hazard remove {hazard['id']})" if hazard else ""
        raise SpecError(f"{question} of {component} is not marked not applicable{hint}")
    data["dismissed"] = [d for d in data["dismissed"] if d is not entry]
    if not data["dismissed"]:
        data.pop("dismissed")
    mf.save(root, data)
    return entry


def template_question_count(root: Path, data: dict, component_id: str) -> int:
    """How many of a component's questions come from its template (the first ones)."""
    container, comp = find_component(data, component_id)
    template = load_template(mf.template_name(container)[0], root)
    initial = next((c for c in template.data.get("initial_components", []) or [] if c.get("id") == comp["id"]), None)
    source = initial if initial is not None else template.type_of(comp)
    texts = [edge_case_text(q) for q in source.get("edge_cases") or []]
    decisions = comp.get("decisions", []) or []
    count = min(len(texts), len(decisions))
    known = {*texts, *(template.data.get("reworded_questions") or {}), *(template.data.get("reworded_questions") or {}).values()}
    while count and decisions[count - 1].get("question") not in known:  # a component made before the
        count -= 1  # template gained a question: what follows its own questions is a person's
    return count


def remove_question(root: Path, component_id: str, number: int) -> dict:
    """Remove a question a person added (ask, or decide with a new question); the template's stay."""
    data = mf.load(root)
    _, comp = find_component(data, component_id)
    decisions = comp.get("decisions", []) or []
    if not 1 <= number <= len(decisions):
        raise SpecError(f"'{component_id}' has no question {number} (it has 1..{len(decisions)})")
    if number <= template_question_count(root, data, component_id):
        raise SpecError(f"question {number} comes from the template: it stays - answer it "
                        f"(archvow decision make {component_id} {number} \"...\")")
    entry = decisions.pop(number - 1)
    mf.save(root, data)
    return entry


def ask(root: Path, component_id: str, question: str, source: dict | None = None) -> dict:
    """Record an open question (for example raised by the AI before coding)."""
    data = mf.load(root)
    _, component = find_component(data, component_id)
    entry = {"question": _required(question, "the question"), "answer": None, **({"source": source} if source else {})}
    component.setdefault("decisions", []).append(entry)
    mf.save(root, data)
    return entry


def assume(root: Path, component_id: str, text: str) -> dict:
    """Record an assumption made by the implementer. It blocks until a human reviews it."""
    data = mf.load(root)
    _, component = find_component(data, component_id)
    entry = {"text": _required(text, "the assumption"), "status": "proposed", **stamp(root)}
    component.setdefault("assumptions", []).append(entry)
    mf.save(root, data)
    return entry


def review_assumption(root: Path, component_id: str, number: int, status: str) -> dict:
    if status not in ("accepted", "rejected"):
        raise SpecError("status must be accepted or rejected")
    data = mf.load(root)
    _, component = find_component(data, component_id)
    assumptions = component.setdefault("assumptions", [])
    if not 1 <= number <= len(assumptions):
        if not assumptions:
            raise SpecError(f"'{component_id}' has no assumption to review")
        raise SpecError(f"'{component_id}' has no assumption {number} (it has 1..{len(assumptions)}; "
                        f"see archvow show {component_id})")
    assumptions[number - 1]["status"] = status
    assumptions[number - 1].pop("review", None)  # looked at again after the component's change
    reviewed = stamp(root)
    assumptions[number - 1]["reviewed_by"] = reviewed["by"]
    assumptions[number - 1]["reviewed_on"] = reviewed["on"]
    mf.save(root, data)
    return assumptions[number - 1]


# ------------------------------------------------------------------ safety analysis


def stamp(root: Path) -> dict:
    """Who and when, recorded on every human decision (`archvow audit` cross-checks Git)."""
    import getpass
    import subprocess
    from datetime import datetime, timezone

    who = ""
    try:
        who = subprocess.run(["git", "-C", str(root), "config", "user.email"], capture_output=True,
                             text=True,
                             encoding="utf-8", errors="replace", check=False).stdout.strip()
    except FileNotFoundError:
        pass
    when = datetime.now(timezone.utc).isoformat()  # microseconds: unique, so audit finds the right commit
    return {"by": who or getpass.getuser(), "on": when}


def _next_id(items: list[dict], scope: str | None, kind: str) -> str:
    """Hazards and invariants are numbered per component: clean_orders.H1, clean_orders.INV2."""
    return mf.next_item_id(items, scope, kind)


def add_hazard(root: Path, description: str | None, *, guide_word: str, severity: str,
               component: str | None = None, rationale: str | None = None) -> dict:
    """Record a hazard: what must never happen, for one safety question of a component.

    `guide_word` is the question's number in `archvow show`, or its guide word. Without a
    description, the template's suggestion for that question is used."""
    data = mf.load(root)
    comp = None
    if component:
        container, comp = find_component(data, component)
    else:
        container = data["containers"][0]
    template = load_template(mf.template_name(container)[0], root)
    guide_word = resolve_guide_word(template, comp, guide_word)
    if severity not in SEVERITIES:
        raise SpecError(f"severity must be one of {', '.join(SEVERITIES)}")
    if description is None:
        description = safety_suggestion(template, data, comp, guide_word).get("hazard")
        if not description:
            raise SpecError("no suggestion for this question: write what must never happen, in quotes")
    hazards = data.setdefault("hazards", [])
    entry = {"id": _next_id(hazards, component, "H"), "component": component, "guide_word": guide_word,
             "severity": severity, "description": _required(description, "what must never happen")}
    if rationale:
        entry["rationale"] = _one_line(rationale)
    entry.update(stamp(root))
    hazards.append(entry)
    mf.save(root, data)
    return entry


def dismiss_question(root: Path, component: str | None, guide_word: str, rationale: str) -> dict:
    """Answer a safety question "not applicable", with the reason. It is not a hazard: no H number."""
    data = mf.load(root)
    comp = None
    if component:
        container, comp = find_component(data, component)
    else:
        container = data["containers"][0]
    template = load_template(mf.template_name(container)[0], root)
    guide_word = resolve_guide_word(template, comp, guide_word)
    if not (rationale or "").strip():
        raise SpecError("say why it cannot happen here: a dismissal needs a reason")
    if (component, guide_word) in mf.answered_safety(data):
        target = f" {component}" if component else ""
        raise SpecError(f"this safety question of {component or 'the system'} is already answered "
                        f"(archvow show{target})")
    entry = {"component": component, "guide_word": guide_word, "rationale": _one_line(rationale),
             **stamp(root)}
    data.setdefault("dismissed", []).append(entry)
    mf.save(root, data)
    return entry


def safety_suggestion(template: Template, data: dict, comp: dict | None, guide_word: str) -> dict:
    """What the template suggests for one safety question: `hazard` and `invariant` texts, and the
    component's `decision` that already answers it (its answer then becomes the invariant)."""
    from archvow.i18n import tr

    ctype = template.type_of(comp) if comp else {}
    suggestion = {**((template.data.get("safety_suggestions") or {}).get(guide_word) or {}),
                  **((ctype.get("safety_suggestions") or {}).get(guide_word) or {})}
    number = (ctype.get("safety_decisions") or {}).get(guide_word)
    decisions = (comp or {}).get("decisions", []) or []
    if number and number <= len(decisions) and (decisions[number - 1].get("answer") or "").strip():
        answer = decisions[number - 1]["answer"]
        suggestion["decision"] = {"number": number, "answer": answer}
        suggestion["invariant"] = tr(data.get("language") or DEFAULT_LANGUAGE, "{answer} (decision {number})",
                                     answer=answer.rstrip("."), number=number)
    return suggestion


def suggestion_for(root: Path, component: str | None, question: str) -> tuple[str, dict]:
    """The guide word of a safety question (number or word) and the template's suggestion for it."""
    data = mf.load(root)
    comp = find_component(data, component)[1] if component else None
    container = find_component(data, component)[0] if component else data["containers"][0]
    template = load_template(mf.template_name(container)[0], root)
    word = resolve_guide_word(template, comp, question)
    return word, safety_suggestion(template, data, comp, word)


def safety_questions(template: Template, comp: dict | None) -> list[str]:
    """The guide words a component answers, in the order `archvow show` numbers them."""
    if comp is None:  # the whole system: every guide word of the template
        return list(template.data.get("guide_words", {}) or {})
    ctype = template.type_of(comp)
    return list(ctype.get("guide_words", []) or [])


def resolve_guide_word(template: Template, comp: dict | None, value: str) -> str:
    """A safety question's number (`archvow show` shows it) or its guide word."""
    words = safety_questions(template, comp)
    value = str(value).strip()
    if value[:1] in ("S", "s") and value[1:].isdigit():  # S2: the safety question's number in `show`
        value = value[1:]
    if str(value).isdigit():
        number = int(value)
        if not 1 <= number <= len(words):
            target = f" {comp['id']}" if comp else ""
            raise SpecError(f"safety question S{number} does not exist: there are {len(words)} "
                            f"(archvow show{target})")
        return words[number - 1]
    if value not in (template.data.get("guide_words", {}) or {}):
        raise SpecError(f"unknown safety question '{value}': give its number from archvow show (S1, S2...) "
                        f"(or a guide word: {', '.join(template.data.get('guide_words', {}) or {})})")
    return value


def weakest_verification(template: Template, severity: str | None) -> str:
    """The proof a severity accepts with the least effort: a test, or a property test for critical."""
    allowed = (template.data.get("verification_floor", {}) or {}).get(severity or "")
    for method in ("example_test", "property_test", "runtime", "static", "model_check", "proof"):
        if not allowed or method in allowed:
            return method
    return "property_test"


def add_invariant(root: Path, statement: str, *, verify: str | None = None, mitigates: list[str] | None = None,
                  component: str | None = None, evidence: str | None = None,
                  rule: str | None = None) -> dict:
    """Record an invariant. Without `mitigates`: the component's one hazard that has no invariant
    yet. Without `verify`: the weakest proof its severity accepts (`weakest_verification`)."""
    _required(statement, "the invariant's statement")
    data = mf.load(root)
    if component:
        container, _ = find_component(data, component)
    else:
        container = data["containers"][0]
    hazards = data.get("hazards", []) or []
    if not mitigates:
        guarded = {h for inv in data.get("invariants", []) or [] for h in inv.get("mitigates", []) or []}
        candidates = [h["id"] for h in mf.hazards(data) if h.get("component") == component
                      and h["id"] not in guarded]
        if len(candidates) != 1:
            where = component or "system"
            raise SpecError(f"say which hazard it prevents: --prevents <component>.H<n> ({where} has "
                            + (f"{len(candidates)} without an invariant: {', '.join(candidates)})" if candidates
                               else "no hazard without an invariant)"))
        mitigates = candidates
    if verify is None:
        ranked = [s for s in SEVERITIES if s in {h.get("severity") for h in hazards if h.get("id") in mitigates}]
        template = load_template(mf.template_name(container)[0], root)
        verify = weakest_verification(template, ranked[0] if ranked else None)
    if verify not in VERIFY_METHODS:
        raise SpecError(f"verify must be one of {', '.join(VERIFY_METHODS)}")
    known = {h["id"] for h in data.get("hazards", [])}
    mitigates = [mf.normalise_item_id(h) if "." in h else mf.qualify(component, h.upper()) for h in mitigates]
    unknown = [h for h in mitigates if h not in known]
    if unknown:
        raise SpecError(f"unknown hazard(s): {', '.join(unknown)}")
    if verify in ("model_check", "proof") and not evidence:
        raise SpecError(f"verify={verify} needs --evidence (path of the model or proof file)")
    if verify == "static" and not rule:
        raise SpecError("verify=static needs --rule (the archvow rule add code that enforces it)")
    invariants = data.setdefault("invariants", [])
    entry = {"id": _next_id(invariants, component, "INV"), "statement": _one_line(statement), "component": component,
             "mitigates": mitigates, "verify": verify}
    if evidence:
        entry["evidence"] = evidence
    if rule:
        entry["rule"] = rule
    entry.update(stamp(root))
    invariants.append(entry)
    mf.save(root, data)
    return entry


__all__ = ["SpecError", "TemplateError", "add_component", "add_hazard", "add_invariant", "ask",
           "assume", "decide", "init_project", "review_assumption"]
