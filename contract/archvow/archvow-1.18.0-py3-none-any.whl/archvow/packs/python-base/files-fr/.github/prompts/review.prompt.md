---
description: "Relire un composant, ou le dernier changement, par rapport à la spec - rapport seulement, jamais de code"
argument-hint: "<composant> (vide : le dernier changement)"
agent: agent
---

Relis (le texte donné avec cette commande) comme AGENTS.md le définit (section relecture) ; sans composant donné, relis le dernier changement. Seulement si tu es un relecteur approuvé : écris le rapport dans reviews/ et ne modifie rien d'autre.
