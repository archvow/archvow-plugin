---
description: "Proposer les commandes archvow qui spécifient une fonctionnalité décrite en mots simples, ou un brief (un fichier d'un dossier de briefs : briefs/ par défaut)"
argument-hint: "<la fonctionnalité, en mots simples> | briefs/<fichier>.md | specs/<fonctionnalité>/plan.md"
agent: agent
---

Rédige la spec de cette fonctionnalité, comme AGENTS.md définit « Rédige la spec de <fonctionnalité> » - ou, quand c'est un fichier d'un dossier de briefs (briefs/, ou un autre dossier que le projet déclare), « Rédige la spec depuis <brief> » : (le texte donné avec cette commande)

Propose les commandes ; n'en lance aucune et n'écris aucun code.
