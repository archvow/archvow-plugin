---
description: "Implémenter un composant de la spec archvow, ou tout ce qui est prêt"
argument-hint: "<composant> (vide : tout ce que archvow next liste comme prêt)"
---

Implémente $ARGUMENTS comme AGENTS.md définit « Implémente <composant> ». Sans composant donné, implémente tout ce que `archvow next --base develop` liste comme prêt, un composant à la fois, et arrête-toi quand plus rien n'est prêt. Vérifie d'abord la branche, comme le dit AGENTS.md (tu ne la crées jamais).
