---
description: "Lister ce que la spec d'un composant ne définit pas, sous forme de questions - sans rien décider"
argument-hint: "<composant>"
---

Lance `archvow prompt $ARGUMENTS --clarify` et fais la tâche qu'il affiche : liste ce que la spec de $ARGUMENTS ne définit pas, sous forme de commandes `archvow question add`. Ne propose aucune réponse et n'écris aucun code.
