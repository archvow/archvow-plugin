---
description: "Proposer les dangers, mises à l'écart et invariants d'un composant (ses questions de sûreté)"
argument-hint: "<composant>"
---

Analyse les risques de ce composant, comme AGENTS.md définit « Analyse les risques de <composant> » : $ARGUMENTS

Propose les commandes ; n'en lance aucune et n'écris aucun code.
