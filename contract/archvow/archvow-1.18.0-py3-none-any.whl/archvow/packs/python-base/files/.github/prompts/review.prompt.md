---
description: "Review a component, or the last change, against the spec - report only, never change code"
argument-hint: "<component> (empty: the last change)"
agent: agent
---

Review (the text given with this command) as AGENTS.md defines (section Review); with no component given, review the last change. Only if you are an approved reviewer: write the report in reviews/ and change nothing else.
