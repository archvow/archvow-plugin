"""Business examples: "given this input, we expect this result", from the business team, locked.

The data lives in files, never in the vow:

    tests/examples/<component>/<example>/input/<one file per source>     e.g. sales.csv
    tests/examples/<component>/<example>/expected/<one file per output>  e.g. revenue.csv

A person records an example with `archvow example add <component> <example> [-s <ticket>]`: archvow
checks the files (text formats only, small, no real-looking identifier: the TST002/TST003 checks)
and stores in the component's vow the example's name, ticket, who and when, and a **fingerprint** of
its files. The fingerprint is the lock: an AI that changes `expected/` to make its test pass fails
`archvow check` (ARCH055), whatever the editor. When the business team changes an expected result, a
person replaces the files and runs `example add` again.

Only the component types whose template says `examples: true` take examples (a job, a transformation,
a router...: input in, output out). Each example needs a test marked `@pytest.mark.example("<name>")`
(ARCH056), of the same kind as the type's tests: a job's or a router's example runs in the slower
integration run.
"""

from __future__ import annotations

import hashlib
import re
from pathlib import Path
from typing import TYPE_CHECKING

from archvow import manifest as mf
from archvow.specs import SpecError

if TYPE_CHECKING:
    from archvow.check import _Checker
    from archvow.templates import Template

FOLDER = "tests/examples"
PARTS = ("input", "expected")
NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]*$")


def folder(component_id: str, name: str) -> str:
    return f"{FOLDER}/{component_id}/{name}"


def level(template: Template, comp: dict) -> str | None:
    """'unit' or 'integration' (the kind of the type's own tests) when the type takes examples, else None."""
    ctype = template.type_of(comp)
    if not ctype.get("examples"):
        return None
    return "integration" if ctype.get("test") == "integration" else "unit"


def types_with_examples(template: Template) -> list[str]:
    return [name for name, ctype in template.component_types.items() if ctype.get("examples")]


def files_of(root: Path, rel: str) -> dict[str, list[Path]]:
    """{'input': [...], 'expected': [...]} - the files under each part, sorted."""
    base = root / rel
    return {part: sorted(p for p in (base / part).rglob("*") if p.is_file()) if (base / part).is_dir() else []
            for part in PARTS}


def fingerprint(root: Path, rel: str) -> str | None:
    """sha256 (12 characters) of the paths and contents of input/ and expected/, line endings as LF so
    a Windows checkout gives the same value. None when a part is missing or empty."""
    found = files_of(root, rel)
    if not all(found.values()):
        return None
    digest = hashlib.sha256()
    for path in (p for part in PARTS for p in found[part]):
        digest.update(path.relative_to(root / rel).as_posix().encode("utf-8") + b"\0")
        digest.update(path.read_bytes().replace(b"\r\n", b"\n") + b"\0")
    return digest.hexdigest()[:12]


def problems(root: Path, rel: str, max_kb: int, max_rows: int) -> list[str]:
    """What stops archvow from recording the files: the parts, the formats, the size, real-looking data."""
    from archvow.testdata import TEXT, identifiers

    found = files_of(root, rel)
    issues = [f"{rel}/{part}/ is missing or empty" for part in PARTS if not found[part]]
    for path in (p for part in PARTS for p in found[part]):
        name = path.relative_to(root).as_posix()
        if path.suffix.lower() not in TEXT:
            issues.append(f"{name}: an example is text ({', '.join(sorted(TEXT))}) - export a binary extract as CSV "
                          "or JSON, with invented values")
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        if len(path.read_bytes()) > max_kb * 1024 or text.count("\n") > max_rows:
            issues.append(f"{name}: over {max_kb} KB or {max_rows} rows - an example is a few rows that show the "
                          "case (a real extract is big)")
        issues += [f"{name}: {found_id} looks real (TST002) - invent it (e.g. name@example.com)"
                   for found_id in identifiers(text)]
    return issues


def _component(data: dict, component_id: str) -> tuple[dict, dict]:
    from archvow.specs import find_component

    return find_component(data, component_id)


def _template(root: Path, container: dict) -> Template:
    from archvow.templates import load_template

    return load_template(mf.template_name(container)[0], root)


def add(root: Path, component_id: str, name: str, ticket: str | None = None) -> dict:
    """Record (or accept again) the example whose files are in tests/examples/<component>/<name>/."""
    from archvow.check import DEFAULT_PARAMS
    from archvow.specs import stamp

    data = mf.load(root)
    container, comp = _component(data, component_id)
    template = _template(root, container)
    if level(template, comp) is None:
        allowed = ", ".join(types_with_examples(template)) or "none in this template"
        raise SpecError(f"a {comp['type']} takes no examples (input in, output out): they go on {allowed}")
    if not NAME_RE.fullmatch(name):
        raise SpecError(f"example name '{name}': letters, digits, - and _ only, e.g. FATTRIB-012-negative-quantity")
    if ticket:
        from archvow.branches import check_ticket

        check_ticket(data, ticket.strip())
    rel = folder(component_id, name)
    params = DEFAULT_PARAMS["TST003"]
    issues = problems(root, rel, params["max_kb"], params["max_rows"])
    if issues:
        raise SpecError("the example cannot be recorded:\n  " + "\n  ".join(issues))
    entry = {"name": name, **({"ticket": ticket.strip()} if ticket else {}),
             "fingerprint": fingerprint(root, rel), **stamp(root)}
    examples = comp.setdefault("examples", [])
    old = next((e for e in examples if e.get("name") == name), None)
    if old is not None:
        if "ticket" in old and not ticket:
            entry = {"name": name, "ticket": old["ticket"], **{k: v for k, v in entry.items() if k != "name"}}
        examples[examples.index(old)] = entry
    else:
        examples.append(entry)
    mf.save(root, data)
    return {**entry, "replaced": old is not None, "folder": rel, "level": level(template, comp)}


def remove(root: Path, component_id: str, name: str) -> dict:
    data = mf.load(root)
    _, comp = _component(data, component_id)
    examples = comp.get("examples") or []
    found = next((e for e in examples if e.get("name") == name), None)
    if found is None:
        known = ", ".join(e.get("name", "?") for e in examples) or "none"
        raise SpecError(f"'{component_id}' has no example '{name}' (its examples: {known})")
    comp["examples"] = [e for e in examples if e is not found]
    if not comp["examples"]:
        del comp["examples"]
    mf.save(root, data)
    return {**found, "folder": folder(component_id, name)}


def view(root: Path, comp: dict, template: Template | None, marks: set[str]) -> list[dict]:
    """The component's examples as show prints them: name, ticket, level, folder, test marked, who/when."""
    kind = level(template, comp) if template else None
    return [{"name": e["name"], **({"ticket": e["ticket"]} if e.get("ticket") else {}), "level": kind,
             "folder": folder(comp["id"], e["name"]), "tested": e["name"].upper() in marks,
             "unchanged": fingerprint(root, folder(comp["id"], e["name"])) == e.get("fingerprint"),
             "by": e.get("by"), "on": str(e.get("on"))[:10]} for e in comp.get("examples") or []]


def marked(root: Path) -> set[str]:
    """Every example name a test marks (upper case), wherever the test file is."""
    from archvow.evidence import mark_values, marked_tests

    return {v for t in marked_tests(root) for v in mark_values(t.marks, "example")}


def run_examples(checker: _Checker) -> None:
    """ARCH055: an example's files are the ones recorded; ARCH056: each example of a coded component has a
    marked test."""
    from archvow.proposals import mode

    root = checker.root
    strict = mode(checker.manifest) == "strict" or checker.complete
    names: set[str] | None = None
    planned = {s.component for s in checker.report.statuses if s.status == "planned"}
    coded = {s.component for s in checker.report.statuses} - planned  # a test is due once the code exists
    for container in checker.manifest.get("containers", []):
        for comp in container.get("components", []):
            for example in comp.get("examples") or []:
                name = example.get("name", "?")
                rel = folder(comp["id"], name)
                where = mf.where(comp["id"])
                now = fingerprint(root, rel)
                again = f"archvow example add {comp['id']} {name}"
                if now is None:
                    checker.add("ARCH055", f"example {name} of {comp['id']}: {rel}/ has no input/ or expected/ "
                                f"files any more -> put them back, or a person runs archvow example remove "
                                f"{comp['id']} {name}", where)
                elif now != example.get("fingerprint"):
                    checker.add("ARCH055", f"example {name} of {comp['id']}: the files in {rel}/ changed since "
                                f"{example.get('by', '?')} recorded them -> put them back (git checkout -- {rel}), "
                                f"or a person checks them with the business team and runs {again}", where)
                if comp["id"] not in coded:
                    continue
                if names is None:
                    names = marked(root)
                if name.upper() not in names:
                    checker.add("ARCH056", f"example {name} of {comp['id']} has no test marked "
                                f"@pytest.mark.example(\"{name}\") -> write the test that reads {rel}/input/ and "
                                f"compares with {rel}/expected/", where, escalate=strict)
