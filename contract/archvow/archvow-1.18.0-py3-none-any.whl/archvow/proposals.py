"""The AI's proposals: decisions the AI proposed, kept apart from the decisions people made.

The vows (`.archvow/spec.vow`, `.archvow/components/<c>/spec.vow`) hold what people decided. In mode
`guided` or `free` (init answer `mode`), the AI may answer an open question itself with
`archvow decision propose <c> <n> "..."`; the answer goes into `.archvow/proposals.vow`, never into a
vow:

    vow 1 proposals
    proposal
      component clean_sales
      number 6
      question "..."
      answer "..."
      by ...
      on ...

A person reviews it: `archvow decision accept <c> <n>` moves the answer into the component's vow (marked
`origin: ai`), `archvow decision make <c> <n> "..."` replaces it with their own. Until then the
question no longer blocks the code (ARCH033), but `check` reports it (ARCH043): a warning, and in
mode `guided` an error for `check --complete` (the release gate). CODEOWNERS gives the file to the
architects in mode `guided` (a merge request carrying proposals needs their approval), not in mode
`free` (they review later, in a spec merge request). Mode `strict` has no proposals: the AI asks.
"""

from __future__ import annotations

from pathlib import Path

from archvow import manifest as mf
from archvow import vowfile

AI_MANIFEST_REL = Path(".archvow/proposals.vow")
MODES = ("strict", "guided", "free")
HEADER = ("# archvow proposals - decisions the AI proposed (archvow decision propose), waiting for a person:\n"
          "# archvow decision accept <component> <n>, or archvow decision make <component> <n> \"...\".\n")


class ProposalError(ValueError):
    pass


def mode(data: dict) -> str:
    """The project's mode: how much the AI decides on its own (strict when the vow says nothing)."""
    value = str(data.get("mode") or "strict")
    return value if value in MODES else "strict"


def load(root: Path) -> list[dict]:
    path = root / AI_MANIFEST_REL
    if path.is_file():
        return parse(path.read_text(encoding="utf-8"), AI_MANIFEST_REL.as_posix())
    return []


def parse(text: str, path: str) -> list[dict]:
    """The proposals in proposals.vow."""
    return list(mf.read_vow(text, path, "proposals")[1].get("proposals") or [])


def save(root: Path, proposals: list[dict]) -> None:
    before = {(p["component"], int(p["number"]), p.get("answer")) for p in load(root)}
    after = {(p["component"], int(p["number"]), p.get("answer")) for p in proposals}
    mf.LAST_CHANGED.update(c for c, _, _ in before ^ after)  # their specs show the proposals
    path = root / AI_MANIFEST_REL
    if not proposals:
        path.unlink(missing_ok=True)  # nothing left to review: the file goes, so does its CODEOWNERS weight
        return
    ordered = sorted(proposals, key=lambda p: (p["component"], int(p["number"])))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(vowfile.dumps("proposals", {"proposals": ordered}, comment=HEADER), encoding="utf-8",
                    newline="\n")


def by_question(root: Path) -> dict[tuple[str, int], dict]:
    """(component, question number) -> its proposal."""
    return {(p["component"], int(p["number"])): p for p in load(root)}


def propose(root: Path, component_id: str, number: int, answer: str) -> dict:
    """The AI's answer to an open question, for a person to review. Refused in mode strict and for a
    question a person already answered."""
    from archvow.specs import _one_line, find_component, stamp

    data = mf.load(root)
    if mode(data) == "strict":
        raise ProposalError("mode strict: the AI does not decide - ask the question and stop; a person answers "
                            f"with archvow decision make {component_id} {number} \"...\"")
    _, comp = find_component(data, component_id)
    decisions = comp.get("decisions", []) or []
    if not 1 <= number <= len(decisions):
        raise ProposalError(f"'{component_id}' has no question {number} (it has 1..{len(decisions)})")
    if (decisions[number - 1].get("answer") or "").strip():
        raise ProposalError(f"question {number} of {component_id} is already decided by a person")
    if not answer.strip():
        raise ProposalError("an answer is required")
    entry = {"component": component_id, "number": number, "question": decisions[number - 1]["question"],
             "answer": _one_line(answer), **stamp(root)}
    proposals = [p for p in load(root) if (p["component"], int(p["number"])) != (component_id, number)]
    save(root, [*proposals, entry])
    return entry


def take(root: Path, component_id: str, number: int) -> dict | None:
    """Remove the proposal for a question (accepted, or replaced by a person's answer) and return it."""
    proposals = load(root)
    found = next((p for p in proposals if (p["component"], int(p["number"])) == (component_id, number)), None)
    if found is not None:
        save(root, [p for p in proposals if p is not found])
    return found


def accept(root: Path, component_id: str, number: int) -> dict:
    """A person accepts the AI's answer: it becomes a decision of the component's vow (origin: ai)."""
    from archvow.specs import decide

    proposal = by_question(root).get((component_id, number))
    if proposal is None:
        raise ProposalError(f"the AI proposed nothing for question {number} of {component_id} "
                            f"(archvow show {component_id})")
    decision = decide(root, component_id, number, proposal["answer"], origin="ai")
    take(root, component_id, number)
    return decision


def drop_component(root: Path, component_id: str) -> None:
    save(root, [p for p in load(root) if p["component"] != component_id])


def renumber(root: Path, component_id: str, removed: int) -> None:
    """A question a person added was removed: the proposals after it move up by one."""
    kept = []
    for p in load(root):
        if p["component"] == component_id and int(p["number"]) == removed:
            continue
        if p["component"] == component_id and int(p["number"]) > removed:
            p = {**p, "number": int(p["number"]) - 1}
        kept.append(p)
    save(root, kept)


def run_proposals(checker) -> None:
    """ARCH043: a decision the AI proposed and no person reviewed yet (an error for the release gate in
    mode guided); a proposal for a question that no longer exists or was answered meanwhile."""
    data = checker.manifest
    project_mode = mode(data)
    components = {c["id"]: c for container in data.get("containers", []) for c in container.get("components", [])}
    for p in load(checker.root):
        comp = components.get(p.get("component"))
        decisions = (comp or {}).get("decisions", []) or []
        number = int(p.get("number") or 0)
        if comp is None or not 1 <= number <= len(decisions) or (decisions[number - 1].get("answer") or "").strip():
            checker.add("ARCH043", f"{p.get('component')} question {number}: a proposal for a question that does not "
                        "exist or is already decided - archvow decision make or accept again, or remove it",
                        AI_MANIFEST_REL.as_posix())
            continue
        message = (f"'{p['component']}' decision {number} was proposed by the AI, not reviewed yet: "
                   f"\"{p['answer']}\" -> a person runs archvow decision accept {p['component']} {number} "
                   f"(or decision make {p['component']} {number} \"...\")")
        if project_mode == "guided" and checker.complete:
            checker.report.violations.append(_error(checker, message))
        else:
            checker.add("ARCH043", message, AI_MANIFEST_REL.as_posix())


def _error(checker, message: str):
    from archvow.check import Violation

    return Violation("ARCH043", "error", message, AI_MANIFEST_REL.as_posix(), 0, 0, checker.rules["ARCH043"][1])
