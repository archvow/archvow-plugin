"""Readable terminal output: green success, yellow attention, red errors.

Colours are used only on an interactive terminal. They are switched off when the output is
piped or redirected (CI logs, files), when NO_COLOR is set (https://no-color.org) or TERM is
"dumb"; FORCE_COLOR switches them on. Symbols fall back to ASCII when the terminal cannot
print them. JSON output (--json) never goes through this module.
"""

from __future__ import annotations

import atexit
import os
import re
import shutil
import sys
import textwrap
from pathlib import Path
from typing import TextIO

RESET, BOLD, DIM = "\033[0m", "\033[1m", "\033[2m"
RED, GREEN, YELLOW, CYAN = "\033[31m", "\033[32m", "\033[33m", "\033[36m"
BLUE, MAGENTA = "\033[94m", "\033[95m"  # bright: readable on dark and light terminals


def _enabled(stream) -> bool:  # noqa: ANN001
    if os.environ.get("NO_COLOR"):
        return False
    if os.environ.get("FORCE_COLOR"):
        return True
    terminal = hasattr(stream, "isatty") and stream.isatty() and os.environ.get("TERM") != "dumb"
    return terminal and (os.name != "nt" or _windows_colours())


_WINDOWS: list[bool] = []


def _windows_colours() -> bool:
    """The Windows console shows colour codes once asked to (Windows 10 and later): ask once, with
    the standard library; if it refuses, archvow prints plain text - never stray codes."""
    if not _WINDOWS:
        try:
            import ctypes

            kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
            ok = True
            for handle in (-11, -12):  # standard output, standard error
                console = kernel32.GetStdHandle(handle)
                mode = ctypes.c_uint32()
                if not kernel32.GetConsoleMode(console, ctypes.byref(mode)):
                    ok = False
                    continue
                ok = bool(kernel32.SetConsoleMode(console, mode.value | 0x0004)) and ok  # VT processing
            _WINDOWS.append(ok)
        except (AttributeError, OSError, ImportError):
            _WINDOWS.append(False)
    return _WINDOWS[0]


def _unicode(stream) -> bool:  # noqa: ANN001
    encoding = (getattr(stream, "encoding", None) or "").lower()
    return "utf" in encoding


def _paint(text: str, *codes: str, stream=None) -> str:  # noqa: ANN001
    stream = stream or sys.stdout
    return f"{''.join(codes)}{text}{RESET}" if _enabled(stream) else text


def _symbol(fancy: str, plain: str, stream=None) -> str:  # noqa: ANN001
    return fancy if _unicode(stream or sys.stdout) else plain


def ok(text: str) -> str:
    return _paint(f"{_symbol('✔', 'OK')} {text}", GREEN)


def warn(text: str) -> str:
    return _paint(f"{_symbol('!', '!')} {text}", YELLOW)


def error(text: str) -> str:
    return _paint(f"{_symbol('✖', 'ERROR')} {text}", RED, stream=sys.stderr)


# archvow's icon: two arms that meet, held up by an arch (the same motif as the editor plugin's icon)
LOGO = (
    "▀█████      █████▀",
    " ▀█████    █████▀",
    "  ▀█████▄▄█████▀",
    "    ████▀▀████",
    "     ██    ██",
    "     ██    ██",
    "     ██    ██",
)
LOGO_ASCII = (
    "#####      #####",
    " #####    #####",
    "  #####..#####",
    "    ###..###",
    "     ##  ##",
    "     ##  ##",
)
LOGO_GREEN = "\033[38;5;36m"  # the icon's green (#1A876B), in the 256 colours every terminal has


def logo(caption: str = "", stream: TextIO | None = None) -> str:
    """archvow's icon, in green, with a caption beside its middle line."""
    stream = stream or sys.stdout
    lines = list(LOGO if _unicode(stream) else LOGO_ASCII)
    width = max(len(line) for line in lines) + 3
    middle = len(lines) // 2
    return "\n".join(_paint(line.ljust(width) if caption and i == middle else line, LOGO_GREEN, stream=stream)
                     + (_paint(caption, BOLD, stream=stream) if caption and i == middle else "")
                     for i, line in enumerate(lines))


def mark(state: str) -> str:
    """One status character: done / ready (green), open / blocked (red), waiting (dim)."""
    if state in ("done", "ready"):
        return _paint(_symbol("✔", "+"), GREEN)
    if state in ("open", "blocked"):
        return _paint(_symbol("✖", "x"), RED)
    return _paint(_symbol("·", "."), DIM)


def title(text: str) -> str:
    return _paint(text, BOLD)


def label(text: str, kind: str) -> str:
    """What `specify` asks now, in colour so it stands out: a spec decision in blue, a vow question
    (hazard, personal data, operations) in magenta."""
    return _paint(text, BOLD, BLUE if kind == "decision" else MAGENTA)


def dim(text: str) -> str:
    return _paint(text, DIM)


def hint(text: str) -> str:
    """A suggestion inside an input prompt, greyed like every suggestion (`ask` makes its colour
    codes invisible to line editing)."""
    return _paint(text, DIM)


# an example: "(e.g. ...)", or "- e.g. ..." up to the next " - " before the question mark, else up to
# a colon, the question mark or the end ("- e.g. amount = abc: stop or drop?")
EXAMPLE_RE = re.compile(r"\((?:e\.g\.|par ex\.)[^)]*\)"
                        r"|- (?:e\.g\.|par ex\.) (?:[^?]*?(?= - )|[^?:]*?(?=:|\?|$))")


def question(text: str, indent: int = 0) -> str:
    """A question as `specify` shows it: wrapped to the terminal, in bold, its examples in grey (an
    example cut over two lines stays grey on both)."""
    width = max(40, shutil.get_terminal_size((100, 24)).columns - 1)
    text = " ".join(str(text).split())
    if not _enabled(sys.stdout):
        return "\n".join(" " * indent + line for line in textwrap.wrap(text, width=width - indent))
    marked = EXAMPLE_RE.sub(lambda m: f"\x01{m.group(0)}\x02", text)  # marks, wrapped with their words
    out, grey = [], False
    for line in textwrap.wrap(marked, width=width - indent + 2):
        painted = line.replace("\x01", f"{RESET}{DIM}").replace("\x02", f"{RESET}{BOLD}")
        out.append(" " * indent + (DIM if grey else BOLD) + painted + RESET)
        grey = line.rfind("\x01") > line.rfind("\x02") if "\x01" in line or "\x02" in line else grey
    return "\n".join(out)


def wrap(text: str, indent: int = 0) -> str:
    """Plain text wrapped to the terminal's width, every line indented."""
    width = max(40, shutil.get_terminal_size((100, 24)).columns - 1)
    return textwrap.fill(" ".join(str(text).split()), width=width, initial_indent=" " * indent,
                         subsequent_indent=" " * indent)


# ---- typing an answer: line editing, history, Tab for the suggestion (standard library only)

_SUGGESTION: list[str] = []  # the suggestion of the question being asked (Tab puts it in the line)
_EDITING: list[bool] = []


def history_file() -> Path:
    """Where earlier answers are kept, so Up brings them back: the user's cache, never the project."""
    base = os.environ.get("XDG_CACHE_HOME") or str(Path.home() / ".cache")
    return Path(os.environ.get("ARCHVOW_HISTORY") or Path(base) / "archvow" / "history")


def setup_line_editing() -> bool:
    """In a terminal: arrows, Home/End, Up for earlier answers, Tab for the suggestion. Python's
    `readline` (GNU readline or macOS libedit); absent on Windows, whose console edits lines itself."""
    if _EDITING:
        return _EDITING[0]
    try:
        import readline
    except ImportError:
        _EDITING.append(False)
        return False
    readline.set_completer_delims("")
    readline.set_completer(_complete)
    if "libedit" in (readline.__doc__ or ""):
        readline.parse_and_bind("bind ^I rl_complete")
    else:
        readline.parse_and_bind("tab: complete")
    path = history_file()
    try:
        if path.is_file():
            readline.read_history_file(str(path))
        readline.set_history_length(500)
    except OSError:
        pass

    def save() -> None:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            readline.write_history_file(str(path))
        except OSError:
            pass  # a read-only home: no history, nothing else changes

    atexit.register(save)
    _EDITING.append(True)
    return True


def _complete(text: str, state: int) -> str | None:
    """Tab: the suggestion, when what is typed so far is its beginning (an empty line, or a start)."""
    if state == 0 and _SUGGESTION and _SUGGESTION[0] and _SUGGESTION[0].startswith(text):
        return _SUGGESTION[0]
    return None


ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")


def editable_prompt(prompt: str) -> str:
    """A prompt line editing can measure. Every colour code is wrapped in \\001 / \\002 (GNU
    readline then counts it as no width: moving in a long answer redraws it right). macOS libedit
    does not reliably understand those markers: there the prompt line has no colour at all, unless
    ARCHVOW_PROMPT_COLOURS=1 - the lines above it keep theirs. Without readline (Windows), the
    console edits the line itself and the prompt stays as it is."""
    if not ANSI_RE.search(prompt) or "readline" not in sys.modules:  # Windows: no readline, nothing to mark
        return prompt
    if _libedit() and os.environ.get("ARCHVOW_PROMPT_COLOURS") != "1":
        return ANSI_RE.sub("", prompt)
    return ANSI_RE.sub(lambda m: f"\001{m.group(0)}\002", prompt)


def _libedit() -> bool:
    module = sys.modules.get("readline")
    return module is not None and "libedit" in (module.__doc__ or "")


def ask(prompt: str, suggestion: str | None = None) -> str:
    """input() on an editable prompt, with Tab putting the suggestion into the line to edit it."""
    _SUGGESTION[:] = [suggestion or ""]
    try:
        return input(editable_prompt(prompt))
    finally:
        _SUGGESTION[:] = []


def code(text: str) -> str:
    return _paint(text, CYAN)


def severity(level: str, text: str) -> str:
    return _paint(text, RED if level == "error" else YELLOW)


def steps(text: str) -> str:
    """Render the template's setup text. Line conventions, so templates stay plain text:

        Title:           a section title (bold)
          - item         a normal point
          ! item         needs attention (yellow)
          > item         something to do (cyan arrow)
    """
    out = []
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            out.append("")
        elif not line.startswith(" ") and stripped.endswith(":"):
            out.append(title(stripped[:-1].rstrip()))
        elif stripped.startswith("! "):
            out.append("  " + warn(stripped[2:]))
        elif stripped.startswith("> "):
            out.append("  " + _paint(_symbol("→", ">"), CYAN) + " " + stripped[2:])
        elif stripped.startswith("- "):
            out.append(f"  {_symbol('•', '-')} {stripped[2:]}")
        else:
            out.append(line)
    return "\n".join(out)
