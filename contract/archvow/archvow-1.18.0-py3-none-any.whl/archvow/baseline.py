"""`check --base REF`: detect guards weakened since the base branch.

An AI (or a hurried human) that cannot satisfy a rule is tempted to change the rule instead:
turn it off in the manifest, add a ruff ignore or a `# noqa`, delete a failing test, edit
AGENTS.md. Each of these makes the build green while the code still ignores the guidance.
This module compares the working tree with the merge-base of REF and reports:

* ARCH020 (error)   - a guard was weakened or a protected file changed, or an item of the spec lost
  the marked test that proved it (deleted, unmarked or skipped);
* ARCH021 (warning) - new suppression comments (`# archvow: ignore`, `# noqa`, `# type: ignore`);
* report.changes    - components/symbols added or removed (for reviewers, not a failure).

`--accept-weakening` downgrades ARCH020 to a warning: CI passes it only once an architect has
approved the change (for example via a PR label).
"""

from __future__ import annotations

import re
import subprocess
from pathlib import Path
from typing import TYPE_CHECKING


from archvow import manifest as mf
from archvow.templates import TemplateError, load_template

if TYPE_CHECKING:
    from archvow.check import _Checker

try:
    import tomllib
except ModuleNotFoundError:  # Python 3.10
    tomllib = None  # type: ignore[assignment]

SEVERITY_RANK = {"off": 0, "warning": 1, "error": 2}
HUNK_RE = re.compile(r"^@@ -\d+(?:,\d+)? \+(\d+)(?:,\d+)? @@")
SUPPRESSION_RE = re.compile(r"#\s*(archvow:\s*ignore\[[^\]]*\]|noqa\b|type:\s*ignore\b)")
LOOSER_WHEN_HIGHER = ("line-length", "max-complexity", "max-args", "max-branches", "max-returns",
                      "max-statements", "max-chain", "max_chain", "max_lines", "max_tokens")


class GitError(Exception):
    """git is unavailable or the base reference cannot be resolved."""


def _git(root: Path, *args: str) -> str:
    try:
        result = subprocess.run(["git", "-C", str(root), *args], capture_output=True, text=True,
                                check=False, encoding="utf-8", errors="replace")
    except FileNotFoundError as exc:
        raise GitError("git is not installed") from exc
    if result.returncode != 0:
        raise GitError(result.stderr.strip() or f"git {' '.join(args)} failed")
    return result.stdout


def merge_base(root: Path, base: str) -> str:
    """The commit this branch's change started from, against `base` (`check --base`, `next --base`, `diff`,
    `review`: all the same way). A repository with no remote named like `base`'s first part (a project not
    pushed yet) compares `origin/main` with its own `main`: the same branch. Otherwise a GitError that says
    which branches exist, instead of git's "Not a valid object name"."""
    try:
        return _git(root, "merge-base", base, "HEAD").strip()
    except GitError as exc:
        twin = _local_twin(root, base)
        if twin:
            return _git(root, "merge-base", twin, "HEAD").strip()
        raise GitError(_why_not(root, base, exc)) from exc


def _refs(root: Path) -> list[str]:
    """The branches and tags as a person types them: main, origin/main, v1.2 (no origin/HEAD)."""
    try:
        out = _git(root, "for-each-ref", "--format=%(refname)", "refs/heads", "refs/remotes", "refs/tags")
    except GitError:
        return []
    names = []
    for ref in out.split():
        for prefix in ("refs/heads/", "refs/tags/", "refs/remotes/"):
            if ref.startswith(prefix) and not ref.endswith("/HEAD") and ref[len(prefix):] not in names:
                names.append(ref[len(prefix):])
    return names


def _remotes(root: Path) -> list[str]:
    try:
        return _git(root, "remote").split()
    except GitError:
        return []


def _local_twin(root: Path, base: str) -> str | None:
    """`origin/main` -> `main`, when there is no remote `origin` here and the local branch exists."""
    remote, _, branch = base.partition("/")
    if not branch or remote in _remotes(root):
        return None
    try:
        _git(root, "rev-parse", "--verify", "--quiet", f"refs/heads/{branch}")
    except GitError:
        return None
    return branch


def _why_not(root: Path, base: str, exc: GitError) -> str:
    """Why `base` cannot be compared with, and what exists instead."""
    try:
        _git(root, "rev-parse", "--verify", "--quiet", "HEAD")
    except GitError:
        return "this branch has no commit yet: commit first, then compare"
    try:
        _git(root, "rev-parse", "--verify", "--quiet", f"{base}^{{commit}}")
        return f"'{base}' has no commit in common with this branch ({exc})"
    except GitError:
        pass
    remote, _, branch = base.partition("/")
    refs = _refs(root)
    fetched = {r.split("/")[0] for r in refs if "/" in r}
    why = ("" if not branch or remote in fetched
           else f" (its remote '{remote}' was never fetched here: git fetch {remote})" if remote in _remotes(root)
           else f" (there is no remote '{remote}' here)")
    return (f"'{base}' is not a branch of this repository{why}. "
            + (f"Choose one that exists: {', '.join(refs[:12])}" if refs else "This repository has no other branch yet"))


def _show(root: Path, commit: str, rel: str) -> str | None:
    try:
        return _git(root, "show", f"{commit}:./{rel}")
    except GitError:
        return None


def compare(checker: _Checker, base: str, accept_weakening: bool) -> None:
    root = checker.root
    rel_manifest = mf.PROJECT_REL.as_posix()
    try:
        commit = merge_base(root, base)
    except GitError as exc:
        checker.add("ARCH020", f"cannot compare with base '{base}': {exc}", rel_manifest)
        return

    checker.report.budget = _budget(checker, root, commit, base)

    def weakened(message: str, file: str, line: int = 0) -> None:
        if accept_weakening:
            checker.report.violations.append(_accepted(message, file, line))
        else:
            checker.add("ARCH020", message, file, line)

    from archvow.agent import check_commits

    check_commits(checker, commit)  # ARCH053: each commit of AI-written code says how the agent ran
    base_manifest = mf.load_at(root, commit)
    if base_manifest is None:  # archvow arrives with this branch: the base has no guard to weaken
        checker.report.changes.append({"change": "archvow_introduced", "id": f"(not on {base} yet)"})
        _new_suppressions(checker, root, commit)
        return
    _compare_manifest(checker, base_manifest, weakened)
    _compare_ruff(root, commit, weakened)
    _compare_pytest(root, commit, weakened)
    _deleted_tests(root, commit, weakened)
    _lost_evidence(checker, root, commit, weakened)
    _frozen_growth(root, commit, weakened)
    _protected_files(checker, root, commit, weakened)
    _new_suppressions(checker, root, commit)
    _change_budget(checker, root, commit, accept_weakening)


def _change_size(root: Path, commit: str) -> tuple[int, int, int] | None:
    """Files changed, lines added and deleted since `commit`, uncommitted and new files included.
    The spec (.archvow/) does not count."""
    try:
        numstat = _git(root, "diff", "--numstat", commit, "--", ".", ":(exclude).archvow")
        untracked = _git(root, "ls-files", "--others", "--exclude-standard", "--", ".",
                         ":(exclude).archvow").split()
    except GitError:
        return None
    files, added, deleted = len(untracked), 0, 0
    for line in numstat.splitlines():
        plus, minus, _ = line.split("\t", 2)
        files += 1
        added += int(plus) if plus.isdigit() else 0
        deleted += int(minus) if minus.isdigit() else 0
    for rel in untracked:
        try:
            added += len((root / rel).read_text(encoding="utf-8").splitlines())
        except (OSError, UnicodeDecodeError):
            continue
    return files, added, deleted


def _budget(checker: _Checker, root: Path, commit: str, base: str) -> dict | None:
    """The change's size against the ARCH022 budget. `full`: no room left for one more component
    (it adds at least 2 files - its source and its test - and about a tenth of the line budget)."""
    size = _change_size(root, commit)
    if size is None:
        return None
    files, added, deleted = size
    limits = {key: checker.param("ARCH022", key) for key in ("max_files", "max_added_lines", "max_deleted_lines")}
    full = (files + 2 > limits["max_files"] or added + limits["max_added_lines"] // 10 > limits["max_added_lines"]
            or deleted > limits["max_deleted_lines"])
    return {"base": base, "files": files, "added_lines": added, "deleted_lines": deleted, **limits, "full": full}


def _change_budget(checker: _Checker, root: Path, commit: str, accept: bool) -> None:
    """ARCH022: a merge request small enough to review. The spec (.archvow/) does not count."""
    budget = checker.report.budget
    if budget is None:
        return
    over = [f"{label} {budget[value]} > {budget[key]}"
            for label, value, key in (("files", "files", "max_files"), ("lines added", "added_lines", "max_added_lines"),
                                      ("lines deleted", "deleted_lines", "max_deleted_lines"))
            if budget[value] > budget[key]]
    if not over:
        return
    message = (f"change too big to review: {', '.join(over)}. Split it into smaller merge requests "
               "(or the architects accept it)")
    if accept:
        checker.report.violations.append(_accepted(message, ".", code="ARCH022"))
    else:
        checker.add("ARCH022", message, ".")


def _accepted(message: str, file: str, line: int = 0, code: str = "ARCH020"):  # noqa: ANN202 - local import avoids a cycle
    from archvow.check import RULES, Violation

    return Violation(code, "warning", f"{message} (accepted)", file, line, 0, RULES[code][1])


# ------------------------------------------------------------------ manifest


def _compare_manifest(checker: _Checker, base: dict, weakened) -> None:  # noqa: ANN001
    from archvow.check import RULES

    where = mf.PROJECT_REL.as_posix()
    now = checker.manifest
    base_rules = base.get("rules", {}) or {}
    now_rules = now.get("rules", {}) or {}
    template_rules: dict = {}
    for container in now.get("containers", []):
        try:
            template_rules.update(load_template(mf.template_name(container)[0], checker.root).rules or {})
        except TemplateError:
            continue
    for code in sorted(set(base_rules) | set(now_rules)):
        default = (template_rules.get(code) or {}).get("severity", RULES.get(code, ("error",))[0])
        before = (base_rules.get(code) or {}).get("severity", default)
        after = (now_rules.get(code) or {}).get("severity", default)
        if SEVERITY_RANK.get(after, 2) < SEVERITY_RANK.get(before, 2):
            weakened(f"rule {code} lowered from {before} to {after}", where)
        for key in LOOSER_WHEN_HIGHER:
            old = (base_rules.get(code) or {}).get(key)
            new = (now_rules.get(code) or {}).get(key)
            if new is not None and (old is None or float(new) > float(old)):
                weakened(f"rule {code}: {key} relaxed from {old if old is not None else 'default'} to {new}",
                         where)
    for tool in [t for t in now.get("ai_tools", []) or [] if t not in (base.get("ai_tools") or [])]:
        if base.get("ai_tools") is not None:
            weakened(f"AI assistant '{tool}' approved for this repository", where)
    for tool in [t for t in now.get("reviewers", []) or [] if t not in (base.get("reviewers") or [])]:
        weakened(f"AI reviewer '{tool}' approved for this repository", where)
    for package in [d for d in now.get("dependencies", []) or [] if d not in (base.get("dependencies") or [])]:
        weakened(f"third-party dependency '{package}' approved", where)
    base_by_path = base.get("dependencies_by_path") or {}
    for folder, names in sorted((now.get("dependencies_by_path") or {}).items()):
        for package in [n for n in names or [] if n not in (base_by_path.get(folder) or [])]:
            weakened(f"third-party dependency '{package}' approved under {folder}", where)
    added_paths = set(now.get("allowed_paths", []) or []) - set(base.get("allowed_paths", []) or [])
    for path in sorted(added_paths):
        weakened(f"allowed_paths widened with '{path}'", where)
    base_layers = {(str(p), str(layer)) for layer, paths in (base.get("layer_paths") or {}).items() for p in paths or []}
    for layer, paths in sorted((now.get("layer_paths") or {}).items()):
        for path in [str(p) for p in paths or [] if (str(p), str(layer)) not in base_layers]:
            weakened(f"layer_paths maps '{path}' to {layer} (where code sits decides what it may do)", where)
    if base.get("compliance") is not None:  # a family switched off: its rules no longer run
        for family in sorted(set(base["compliance"]) - set(now.get("compliance") or []) - {"none"}):
            weakened(f"compliance rules '{family}' switched off", where)
    from archvow.proposals import MODES

    old_mode, new_mode = str(base.get("mode") or "strict"), str(now.get("mode") or "strict")
    if old_mode in MODES and new_mode in MODES and MODES.index(new_mode) > MODES.index(old_mode):
        weakened(f"mode loosened from {old_mode} to {new_mode} (the AI decides more on its own)", where)
    from archvow.agent import sandbox_required

    if sandbox_required(base) and not sandbox_required(now):
        weakened("sandbox switched off (an AI agent outside a sandbox may run archvow)", where)
    old_auto = str((base.get("init_answers") or {}).get("auto_approve") or "no")
    new_auto = str((now.get("init_answers") or {}).get("auto_approve") or "no")
    if old_auto != "yes" and new_auto == "yes":
        weakened("AI auto-approval turned on (the approved assistants run the safe commands and edit the "
                 "code without asking)", where)
    from archvow.check import COMPLIANCE_FAMILIES, chosen_families, family_name

    before, after = chosen_families(base), chosen_families(now)
    if after is not None:  # fewer rule families: their rules no longer run (the floor stays)
        every = {family_name(code, checker.families) for code in checker.rules} - set(COMPLIANCE_FAMILIES)
        for family in sorted((every if before is None else before) - after):
            weakened(f"rule family {family} switched off (rules: {', '.join(sorted(after)) or 'none'})", where)
    from archvow.briefs import folders

    for removed in [f for f in folders(base) if f not in folders(now)]:
        weakened(f"briefs folder '{removed}' removed: its files are no longer scanned for real-looking "
                 "identifiers (TST002) and nothing may be drawn from them", where)
    _compare_columns(base, now, weakened, where)
    _compare_safety(checker, base, now, weakened)

    base_containers = {c["id"]: c for c in base.get("containers", []) or []}
    for container in now.get("containers", []):
        old = base_containers.get(container["id"])
        if old is None:
            checker.report.changes.append({"change": "container_added", "id": container["id"]})
            continue
        if old.get("template") != container.get("template"):
            weakened(f"container '{container['id']}' template changed from {old.get('template')} "
                     f"to {container.get('template')}", where)
        old_components = {c["id"]: c for c in old.get("components", [])}
        new_components = {c["id"]: c for c in container.get("components", [])}
        for cid in sorted(set(new_components) - set(old_components)):
            checker.report.changes.append({"change": "component_added", "id": cid,
                                           "type": new_components[cid].get("type")})
        for cid in sorted(set(old_components) - set(new_components)):
            checker.report.changes.append({"change": "component_removed", "id": cid,
                                           "type": old_components[cid].get("type")})
        for cid in sorted(set(old_components) & set(new_components)):
            _compare_examples(checker, old_components[cid], new_components[cid], weakened)
            if _contract(old_components[cid]) != _contract(new_components[cid]):
                users = sorted(c["id"] for c in new_components.values() if cid in (c.get("uses") or []))
                checker.report.changes.append({"change": "contract_changed", "id": cid,
                                               "type": new_components[cid].get("type"), "users": users})


def _compare_examples(checker: _Checker, old: dict, new: dict, weakened) -> None:
    """A business example removed from the spec is a weakening; one accepted again with new files is a spec
    change the reviewers see (`report.changes`: example_changed)."""
    before = {e.get("name"): e for e in old.get("examples") or []}
    after = {e.get("name"): e for e in new.get("examples") or []}
    for name in sorted(set(before) - set(after)):
        weakened(f"example {name} of {new['id']} removed from the spec (its expected result is no longer checked)",
                 mf.where(new["id"]))
    for name in sorted(set(before) & set(after)):
        if before[name].get("fingerprint") != after[name].get("fingerprint"):
            checker.report.changes.append({"change": "example_changed", "id": new["id"], "example": name,
                                           "by": after[name].get("by")})


def _contract(comp: dict) -> list[tuple]:
    """What other components rely on: its public names, their kind, signature and route."""
    return sorted((str(s.get("name")), str(s.get("kind", "function")), str(s.get("signature", "")),
                   str(s.get("method", "")), str(s.get("path", ""))) for s in comp.get("symbols") or [])


def _compare_columns(base: dict, now: dict, weakened, where: str) -> None:  # noqa: ANN001
    """A column made less personal (special -> personal -> none), or a pseudonymisation or removal
    dropped, weakens the GDPR guards."""
    rank = {"none": 0, "personal": 1, "special": 2}

    def components(data: dict) -> dict:
        return {c["id"]: c for ct in data.get("containers", []) or [] for c in ct.get("components", [])}

    old = components(base)
    for cid, comp in components(now).items():
        before = old.get(cid) or {}
        for name, kind in (before.get("columns") or {}).items():
            after = (comp.get("columns") or {}).get(name)
            if after is not None and rank.get(after, 0) < rank.get(kind, 0):
                weakened(f"column {cid}.{name} classified {after}, was {kind}", where)
        for key in ("removes", "pseudonymises"):
            dropped = set((before.get("privacy") or {}).get(key) or []) - set((comp.get("privacy") or {}).get(key) or [])
            for name in sorted(dropped):
                weakened(f"{cid} no longer {key} {name}", where)
        now_questions = {d.get("question") for d in comp.get("decisions", []) or []}
        for decision in before.get("decisions", []) or []:  # `archvow question remove <component> <n>`: an answer is gone
            if (decision.get("answer") or "").strip() and decision.get("question") not in now_questions:
                weakened(f"{cid}: decision removed ('{decision.get('question')}' -> {decision.get('answer')})", where)


METHOD_STRENGTH = {"example_test": 1, "static": 2, "runtime": 3, "property_test": 3,
                   "model_check": 4, "proof": 5}
SEVERITY_ORDER = {"low": 1, "medium": 2, "high": 3, "critical": 4}


def _compare_safety(checker: _Checker, base: dict, now: dict, weakened) -> None:  # noqa: ANN001
    """Hazards and invariants are guards too: removing or softening them is weakening."""
    where = mf.PROJECT_REL.as_posix()
    old_h = {h.get("id"): h for h in base.get("hazards", []) or []}
    new_h = {h.get("id"): h for h in now.get("hazards", []) or []}
    for hid, hazard in old_h.items():
        if hid not in new_h:
            weakened(f"hazard {hid} removed ('{hazard.get('description')}')", where)
        elif SEVERITY_ORDER.get(new_h[hid].get("severity"), 0) < SEVERITY_ORDER.get(hazard.get("severity"), 0):
            weakened(f"hazard {hid} downgraded from {hazard.get('severity')} to {new_h[hid].get('severity')}",
                     where)
    for hid in sorted(set(new_h) - set(old_h)):
        checker.report.changes.append({"change": "hazard_added", "id": hid, "type": new_h[hid].get("severity")})
    old_d = {(d.get("component"), d.get("guide_word")) for d in base.get("dismissed") or []}
    for d in now.get("dismissed") or []:
        if (d.get("component"), d.get("guide_word")) not in old_d:
            checker.report.changes.append({"change": "hazard_dismissed",
                                           "id": f"{d.get('component') or 'system'}:{d.get('guide_word')}"})
    old_i = {i.get("id"): i for i in base.get("invariants", []) or []}
    new_i = {i.get("id"): i for i in now.get("invariants", []) or []}
    for iid, inv in old_i.items():
        if iid not in new_i:
            weakened(f"invariant {iid} removed ('{inv.get('statement')}')", where)
            continue
        before, after = inv.get("verify"), new_i[iid].get("verify")
        if METHOD_STRENGTH.get(after, 0) < METHOD_STRENGTH.get(before, 0):
            weakened(f"invariant {iid} verification weakened from {before} to {after}", where)
        if inv.get("statement") != new_i[iid].get("statement"):
            weakened(f"invariant {iid} statement changed", where)
    for iid in sorted(set(new_i) - set(old_i)):
        checker.report.changes.append({"change": "invariant_added", "id": iid, "type": new_i[iid].get("verify")})
    # decisions and assumption reviews are human calls: list them for the reviewer
    old_components = {c["id"]: c for ct in base.get("containers", []) or [] for c in ct.get("components", [])}
    for container in now.get("containers", []):
        for comp in container.get("components", []):
            old = old_components.get(comp["id"], {})
            old_answers = {d.get("question"): d.get("answer") for d in old.get("decisions", []) or []}
            for decision in comp.get("decisions", []) or []:
                if decision.get("answer") and decision.get("answer") != old_answers.get(decision.get("question")):
                    checker.report.changes.append({"change": "decision_made", "id": comp["id"],
                                                   "type": decision.get("question")})
            old_states = {a.get("text"): a.get("status") for a in old.get("assumptions", []) or []}
            for assumption in comp.get("assumptions", []) or []:
                if assumption.get("status") != "proposed" and old_states.get(assumption.get("text")) != assumption.get("status"):
                    checker.report.changes.append({"change": f"assumption_{assumption.get('status')}",
                                                   "id": comp["id"], "type": assumption.get("text")})


# ------------------------------------------------------------------ ruff / tests / protected files


def _flatten(data: dict, prefix: str = "") -> dict[str, object]:
    flat: dict[str, object] = {}
    for key, value in data.items():
        name = f"{prefix}{key}"
        if isinstance(value, dict) and key != "per-file-ignores":
            flat.update(_flatten(value, f"{name}."))
        else:
            flat[name] = value
    return flat


def _compare_ruff(root: Path, commit: str, weakened) -> None:  # noqa: ANN001
    if tomllib is None:
        return
    for rel, section in (("ruff.toml", None), ("pyproject.toml", ("tool", "ruff"))):
        before_text = _show(root, commit, rel)
        path = root / rel
        if before_text is None or not path.is_file():
            continue
        try:
            before, after = tomllib.loads(before_text), tomllib.loads(path.read_text("utf-8"))
        except tomllib.TOMLDecodeError:
            continue
        for key in section or ():
            before, after = before.get(key, {}), after.get(key, {})
        _compare_ruff_tables(_flatten(before), _flatten(after), rel, weakened)


def _compare_pytest(root: Path, commit: str, weakened) -> None:
    """The test settings in pyproject.toml are a guard (pytest.ini is a protected file)."""
    before_text = _show(root, commit, "pyproject.toml")
    path = root / "pyproject.toml"
    if tomllib is None or before_text is None or not path.is_file():
        return
    try:
        before, after = tomllib.loads(before_text), tomllib.loads(path.read_text("utf-8"))
    except tomllib.TOMLDecodeError:
        return
    section = lambda data: data.get("tool", {}).get("pytest")
    if section(before) is not None and section(before) != section(after):
        weakened("pytest settings ([tool.pytest.ini_options]) changed; needs architect approval",
                 "pyproject.toml")


def _compare_ruff_tables(before: dict, after: dict, where: str, weakened) -> None:  # noqa: ANN001
    for key in sorted(set(before) | set(after)):
        old, new = before.get(key), after.get(key)
        leaf = key.rsplit(".", 1)[-1]
        if leaf in ("select", "extend-select"):
            for code in sorted(set(old or []) - set(new or [])):
                weakened(f"ruff: '{code}' removed from {key}", where)
        elif leaf in ("ignore", "extend-ignore", "unfixable", "exclude", "extend-exclude"):
            for code in sorted(set(new or []) - set(old or [])):
                weakened(f"ruff: '{code}' added to {key}", where)
        elif leaf == "per-file-ignores":
            for pattern, codes in (new or {}).items():
                for code in sorted(set(codes) - set((old or {}).get(pattern, []))):
                    weakened(f"ruff: '{code}' ignored for '{pattern}'", where)
        elif leaf in LOOSER_WHEN_HIGHER and isinstance(new, (int, float)):
            if old is None or new > old:
                weakened(f"ruff: {key} relaxed from {old} to {new}", where)


def _frozen_growth(root: Path, commit: str, weakened) -> None:  # noqa: ANN001
    """Freezing more violations hides them: a guard change."""
    import json
    from collections import Counter

    from archvow.freeze import FROZEN_REL, fingerprint, load

    before_text = _show(root, commit, FROZEN_REL)
    before = Counter(fingerprint(i) for i in json.loads(before_text).get("frozen", [])) if before_text else Counter()
    for (code, file, message), count in sorted((load(root) - before).items()):
        weakened(f"{count} more frozen {code} violation(s) in {file}: {message}", FROZEN_REL)


def _deleted_tests(root: Path, commit: str, weakened) -> None:  # noqa: ANN001
    try:
        deleted = _git(root, "diff", "--name-only", "--diff-filter=D", commit, "--", "tests").split()
    except GitError:
        return
    for rel in deleted:
        weakened("test file deleted", rel)


EVIDENCE_KINDS = ("decision", "rule", "invariant", "example")


def _proven(tests: list) -> dict[tuple[str, str, str], list]:
    """(file or '', kind, value) -> the tests, not skipped, that are its evidence. Decisions and rules
    count in their own test file (a decision number means nothing elsewhere); invariants and examples
    anywhere."""
    from archvow.evidence import mark_values

    found: dict[tuple[str, str, str], list] = {}
    for test in tests:
        for kind in EVIDENCE_KINDS:
            for value in mark_values(test.marks, kind):
                key = (test.file if kind in ("decision", "rule") else "", kind, value)
                found.setdefault(key, []).append(test)
    return found


def _lost_evidence(checker: _Checker, root: Path, commit: str, weakened) -> None:
    """An item of the spec that had a marked test on the base and has none now - the test deleted, its mark
    removed, or the test skipped: the evidence disappeared (an agent's shortcut when a test fails)."""
    from archvow.evidence import marked_in, marked_tests

    try:
        listed = _git(root, "ls-tree", "-r", "--name-only", commit, "--", "tests").split()
    except GitError:
        return
    base = [t for rel in listed if rel.endswith(".py") for t in marked_in(_show(root, commit, rel) or "", rel)]
    before = _proven([t for t in base if not t.skipped])
    tests_now = marked_tests(root)
    after = _proven([t for t in tests_now if not t.skipped])
    skipped_now = _proven([t for t in tests_now if t.skipped])
    data = checker.manifest
    owner = {mf.test_path(c): c for ct in data.get("containers", []) for c in ct.get("components", [])}
    rules = {r.get("id", "").upper() for r in data.get("project_rules") or []}
    invariants = {str(i.get("id", "")).upper() for i in data.get("invariants") or []}
    examples = {str(e.get("name", "")).upper(): c["id"] for ct in data.get("containers", [])
                for c in ct.get("components", []) for e in c.get("examples") or []}
    for (file, kind, value), tests in sorted(before.items()):
        if (file, kind, value) in after or (file and not (root / file).is_file()):
            continue  # still proven, or its whole file was deleted (reported above)
        if kind == "decision":
            comp = owner.get(file)
            if comp is None or not value.isdigit() or int(value) > len(comp.get("decisions") or []):
                continue  # the decision itself is gone: the spec change says so
            label = f"decision {value} of {comp['id']}"
        elif kind == "rule":
            if value not in rules:
                continue
            label = f"rule {value}"
        elif kind == "invariant":
            if value not in invariants:
                continue
            label = value
        else:
            if value not in examples:
                continue
            label = f"example {value} of {examples[value]}"
        was = tests[0]
        state = "is skipped now" if (file, kind, value) in skipped_now else "is gone, or no longer marked"
        weakened(f"{label} lost its evidence: its test {was.name} ({was.file} on the base) {state} -> fix the code "
                 "and keep the test; a test that is really wrong changes with an architect's approval", was.file if (root / was.file).is_file() else file
                 or was.file, 0)


def _protected_files(checker: _Checker, root: Path, commit: str, weakened) -> None:  # noqa: ANN001
    paths: list[str] = []
    approved = mf.instructed_tools(checker.manifest)
    for container in checker.manifest.get("containers", []):
        try:
            data = load_template(mf.template_name(container)[0], root).data
        except TemplateError:
            continue
        paths += data.get("protected_paths", [])
        # instruction files of approved assistants (including company tools) are guards too
        paths += [rel for tool, rel in (data.get("ai_tool_instructions") or {}).items() if tool in approved]
    if not paths:
        return
    try:
        changed = _git(root, "diff", "--name-only", commit, "--", *sorted(set(paths))).split()
        untracked = _git(root, "ls-files", "--others", "--exclude-standard", "--", *sorted(set(paths))).split()
    except GitError:
        return
    for rel in sorted(set(changed) | set(untracked)):
        weakened("protected guard file changed; needs architect approval", rel)


def _new_suppressions(checker: _Checker, root: Path, commit: str) -> None:
    try:
        diff = _git(root, "diff", "-U0", "--no-color", commit, "--", "*.py")
        untracked = _git(root, "ls-files", "--others", "--exclude-standard", "--", "*.py").split()
    except GitError:
        return
    file = ""
    line = 0
    for text in diff.splitlines():
        if text.startswith("+++ "):
            file = text[6:] if text.startswith("+++ b/") else ""
        elif text.startswith("@@"):
            match = HUNK_RE.match(text)
            line = int(match.group(1)) if match else 0
        elif text.startswith("+") and file:
            if SUPPRESSION_RE.search(text):
                checker.add("ARCH021", f"new suppression: {text[1:].strip()}", file, line)
            line += 1
    for rel in untracked:
        for number, text in enumerate((root / rel).read_text("utf-8").splitlines(), start=1):
            if SUPPRESSION_RE.search(text):
                checker.add("ARCH021", f"new suppression: {text.strip()}", rel, number)
