"""The spec on disk: one vow for the project, one vow per component, in the .vow format.

Layout:

    .archvow/spec.vow                      the project's vow
        system: {name, description}
        containers (container <id>: template "name@version", package, path)   # deployables (C4 level 2)
        rules: {CODE: {severity: error|warning|off, ...}}               # check severity overrides
        language, mode, families, compliance, ai_tools, reviewers, dependencies, init_answers,
        project rules (R1, R2...), third parties, hazards/invariants/dismissed of the whole system
    .archvow/components/<id>/spec.vow      one component's vow (C4 level 3, one Python module)
        type, layer, module, spec (written `ticket`), description, uses, symbols, decisions, columns...,
        container (only when the project has several), hazards (H1, H2...), invariants (INV1...),
        dismissed (its "not applicable" safety questions)
    .archvow/spec.md, .archvow/components/<id>/spec.md   generated from the vows (docs.py)

The .vow syntax is in vowfile.py. In memory, `load` returns ONE dict, the same shape every module
has always used: containers hold their components, and hazards, invariants and dismissals are
top-level lists carrying their `component`. Hazard and invariant ids are qualified there -
`clean_orders.H1`, `clean_orders.INV1` (`system.H1` for the whole system) - and stored short (`H1`)
in the component's own file. `save` splits the dict back into the files and writes only the ones
that changed.

A template question nobody answered yet is stored as `template_question <hash of its text>`
and read back with the template's current words; an answered question keeps its own words.

"""

from __future__ import annotations

import copy
import functools
import hashlib
import re
import subprocess
from pathlib import Path

import yaml

from archvow import vowfile

ARCHVOW_DIR = Path(".archvow")
PROJECT_REL = ARCHVOW_DIR / "spec.vow"
COMPONENTS_REL = ARCHVOW_DIR / "components"
COMPONENT_FILE = "spec.vow"
CARD_FILE = "spec.md"  # the spec card generated next to each spec.vow (docs.py)
MANIFEST_REL = PROJECT_REL  # where project-level findings point
SCHEMA_VERSION = 2
SYSTEM = "system"  # the scope of hazards and invariants of the whole system (no component)
ITEM_ID_RE = re.compile(r"^(?P<scope>[a-z][a-z0-9_]*)\.(?P<kind>H|INV)(?P<n>\d+)$", re.IGNORECASE)
COMPONENT_ITEMS = ("hazards", "invariants", "dismissed")

PROJECT_HEADER = (
    "# archvow vow of the project - what every component must follow: mode, checks, approved AI tools and\n"
    "# packages, rules R1, R2... (`archvow show` reads one component; `.archvow/spec.md` shows the whole project).\n"
    "# Never edit by hand: archvow init <package> --force -a <answer>=..., archvow rule add, archvow dependency\n"
    "# add. Set by hand, by an architect, reviewed in the merge request: only `rules` (severities and limits),\n"
    "# `allowed_paths`, `dependencies_by_path` and `layer_paths`. Format: docs/vow-format.md of archvow.\n"
)
COMPONENT_HEADER = (
    "# archvow vow of {id} - what it must be and do; archvow check holds the code to it.\n"
    "# Read: archvow show {id}. Change: archvow specify {id}. Never edit by hand.\n"
)


class ManifestError(Exception):
    """Raised when the spec cannot be found or used."""


def is_project(root: Path) -> bool:
    return (root / PROJECT_REL).is_file()


def find_root(start: Path) -> Path:
    """Walk up from `start` to the directory holding .archvow/spec.vow."""
    current = start.resolve()
    for candidate in (current, *current.parents):
        if (candidate / PROJECT_REL).is_file():
            return candidate
    raise ManifestError(f"no {PROJECT_REL.as_posix()} found in {start} or its parents")


_LOADER = getattr(yaml, "CSafeLoader", yaml.SafeLoader)  # libyaml when available: same result, much faster


@functools.lru_cache(maxsize=1024)
def _parse(text: str) -> object:
    return yaml.load(text, Loader=_LOADER)  # noqa: S506 - a safe loader


def parse_yaml(text: str) -> object:
    """Parse YAML safely. A command reads the same files many times: the parse is cached by
    content (never stale) and every caller gets its own copy to change."""
    return copy.deepcopy(_parse(text))


# ------------------------------------------------------------------ ids


def qualify(scope: str | None, short: str) -> str:
    """'H1' of clean_orders -> 'clean_orders.H1' (already qualified ids are kept)."""
    return short if "." in str(short) else f"{scope or SYSTEM}.{short}"


def shorten(scope: str | None, item_id: str) -> str:
    """'clean_orders.H1' in clean_orders' own file -> 'H1' (another component's id stays whole)."""
    prefix = f"{scope or SYSTEM}."
    return item_id[len(prefix):] if str(item_id).startswith(prefix) else item_id


def next_item_id(items: list[dict], scope: str | None, kind: str) -> str:
    """The next hazard (kind H) or invariant (INV) id of one component: clean_orders.H3."""
    scope = scope or SYSTEM
    numbers = [int(m.group("n")) for i in items if (m := ITEM_ID_RE.match(str(i.get("id", ""))))
               and m.group("scope") == scope and m.group("kind").upper() == kind]
    return f"{scope}.{kind}{(max(numbers) + 1) if numbers else 1}"


def normalise_item_id(words: str | list[str]) -> str:
    """'clean_orders H1', 'clean_orders.h1' or ['clean_orders', 'H1'] -> 'clean_orders.H1'."""
    text = " ".join(words) if isinstance(words, list) else str(words)
    parts = text.replace(".", " ").split()
    if len(parts) == 2 and re.fullmatch(r"(?i)(H|INV)\d+", parts[1]):
        return f"{parts[0]}.{parts[1].upper()}"
    return text.strip()


# ------------------------------------------------------------------ template questions


def question_key(text: str) -> str:
    return hashlib.sha256(str(text).encode("utf-8")).hexdigest()[:12]


def _template_texts(project: dict, root: Path | None) -> dict[str, str]:
    """hash -> current words, for every question the project's template asks (reworded ones too)."""
    from archvow.templates import TemplateError, edge_case_text, load_template

    containers = project.get("containers") or []
    language = project.get("language") or "en"
    texts: dict[str, str] = {}
    for container in containers:
        try:
            template = load_template(template_name(container)[0], root, language=language)
        except (TemplateError, KeyError):
            continue

        def walk(node: object) -> None:
            if isinstance(node, dict):
                for key, value in node.items():
                    if key == "edge_cases" and isinstance(value, list):
                        for item in value:
                            text = edge_case_text(item)
                            texts.setdefault(question_key(text), text)
                    else:
                        walk(value)
            elif isinstance(node, list):
                for item in node:
                    walk(item)

        walk(template.data)
        reworded = template.data.get("reworded_questions") or {}
        for old in reworded:
            new, seen = old, set()
            while new in reworded and new not in seen:  # follow chains of rewordings
                seen.add(new)
                new = reworded[new]
            texts.setdefault(question_key(old), new)
    return texts


# ------------------------------------------------------------------ load


def load(root: Path) -> dict:
    """The whole spec as one dict."""
    if not is_project(root):
        raise ManifestError(f"{root / PROJECT_REL} does not exist")
    project_text = (root / PROJECT_REL).read_text(encoding="utf-8")
    components = {p.name: (p / COMPONENT_FILE).read_text(encoding="utf-8") for p in _component_files(root)}
    # reading is cheap, assembling is not: the result is cached by the files' content (never stale)
    key = hashlib.sha256("\0".join([str(root.resolve()), project_text,
                                     *(f"{k}\0{v}" for k, v in components.items())]).encode("utf-8")).digest()
    cached = _LOADED.get(str(root.resolve()))
    if cached is None or cached[0] != key:
        cached = (key, assemble(project_text, components, root))
        _LOADED[str(root.resolve())] = cached
    return copy.deepcopy(cached[1])


_LOADED: dict[str, tuple[bytes, dict]] = {}


def _component_files(root: Path) -> list[Path]:
    folder = root / COMPONENTS_REL
    if not folder.is_dir():
        return []
    return sorted(p for p in folder.iterdir() if (p / COMPONENT_FILE).is_file())


def read_vow(text: str, label: str, kind: str) -> tuple[str | None, dict]:
    """One .vow file of this kind -> (the name on its first line, its data)."""
    try:
        found, name, data = vowfile.loads(text, label)
    except vowfile.VowError as exc:
        raise ManifestError(str(exc)) from None
    if found != kind:
        raise ManifestError(f"{label}: a vow of a {found}, where archvow expects the vow of a {kind}")
    return name, data


def assemble(project_text: str, component_texts: dict[str, str], root: Path | None) -> dict:
    """Project vow + component vows -> the one in-memory dict."""
    data = {"schema_version": SCHEMA_VERSION, **read_vow(project_text, PROJECT_REL.as_posix(), "project")[1]}
    data.setdefault("containers", [])
    data.setdefault("rules", {})
    for name in COMPONENT_ITEMS:  # the whole system's own items carry no component
        items = data.get(name) or []
        for item in items:
            item.setdefault("component", None)
            _expand(item, None)
        data[name] = items
    by_container = {c["id"]: c for c in data["containers"]}
    for container in data["containers"]:
        container["components"] = []
    texts: dict[str, str] | None = None
    comps = []
    for folder, text in component_texts.items():
        label = (COMPONENTS_REL / folder / COMPONENT_FILE).as_posix()
        name, comp = read_vow(text, label, "component")
        if name not in (None, folder):
            raise ManifestError(f"{label}: the vow of `{name}` in the folder of `{folder}` - the folder "
                                "is named after its component")
        comp = {"id": folder, **comp}
        comp.setdefault("id", folder)
        for name in COMPONENT_ITEMS:
            for item in comp.pop(name, None) or []:
                item = {"component": comp["id"], **item}
                _expand(item, comp["id"])
                data.setdefault(name, []).append(item)
        for decision in comp.get("decisions") or []:
            if "template_question" in decision:
                if texts is None:
                    texts = _template_texts(data, root)
                ref = decision.pop("template_question")
                decision["question"] = texts.get(str(ref), f"(a question the template no longer asks: {ref})")
                decision.setdefault("answer", None)
        comps.append(comp)
    comps.sort(key=lambda c: (str(c.get("layer", "")), str(c["id"])))
    for comp in comps:
        owner = by_container.get(comp.pop("container", None)) or (data["containers"] or [None])[0]
        if owner is None:
            raise ManifestError(f"component {comp['id']} belongs to no container")
        owner["components"].append(_order_decision_keys(comp))
    inherit_type_answers(data)
    for name in ("hazards", "invariants"):
        data[name] = sorted(data.get(name) or [], key=_item_order)
    data["dismissed"] = data.get("dismissed") or []
    if not data["dismissed"]:
        data.pop("dismissed")
    return data


TYPE_ORIGIN = "type"  # a decision answered once for every component of a type (never saved in the component)


def inherit_type_answers(data: dict) -> None:
    """The architects answer a question once for a type (`type_answers` of the project vow): every
    component of that type with that question still open gets the answer, marked origin "type". A
    component's own answer always wins; `split` writes the inherited ones back as open."""
    shared = {(str(a.get("type")), str(a.get("question"))): a for a in data.get("type_answers") or []}
    if not shared:
        return
    for container in data.get("containers") or []:
        for comp in container.get("components") or []:
            for decision in comp.get("decisions") or []:
                if str(decision.get("answer") or "").strip():
                    continue
                found = shared.get((str(comp.get("type")), str(decision.get("question"))))
                if found:
                    decision["answer"] = found.get("answer")
                    decision.update({k: found[k] for k in ("by", "on") if k in found})
                    decision["origin"] = TYPE_ORIGIN


def _order_decision_keys(comp: dict) -> dict:
    """Decisions read back as {question, answer, ...}: the order every module has always printed."""
    for i, decision in enumerate(comp.get("decisions") or []):
        if "question" in decision:
            comp["decisions"][i] = {"question": decision["question"], "answer": decision.get("answer"),
                                    **{k: v for k, v in decision.items() if k not in ("question", "answer")}}
    return comp


def _item_order(item: dict) -> tuple:
    match = ITEM_ID_RE.match(str(item.get("id", "")))
    if not match:
        return ("", 0, str(item.get("id")))
    return (match.group("scope"), int(match.group("n")), "")


def _expand(item: dict, scope: str | None) -> None:
    if "id" in item:
        item["id"] = qualify(scope, item["id"])
    if item.get("mitigates"):
        item["mitigates"] = [qualify(scope, h) for h in item["mitigates"]]


# ------------------------------------------------------------------ save


def split(data: dict, root: Path | None) -> tuple[str, dict[str, str]]:
    """The one in-memory dict -> (project vow text, {component id: its vow text})."""
    data = copy.deepcopy(data)
    data["schema_version"] = SCHEMA_VERSION
    several = len(data.get("containers") or []) > 1
    owned: dict[str, dict[str, list]] = {}
    system: dict[str, list] = {}
    known = {c["id"] for container in data.get("containers") or [] for c in container.get("components", [])}
    for name in COMPONENT_ITEMS:
        for item in data.pop(name, None) or []:
            scope = item.get("component")
            item = {k: v for k, v in item.items() if k != "component"} if scope in known else dict(item)
            if scope in known:
                _shorten(item, scope)
                owned.setdefault(scope, {}).setdefault(name, []).append(item)
            else:
                item.pop("component", None) if scope is None else None
                _shorten(item, None)
                system.setdefault(name, []).append(item)
    texts_of: dict[str, dict[str, str]] = {}  # per container: its template's questions
    components: dict[str, str] = {}
    containers = []
    for container in data.get("containers") or []:
        comps = container.pop("components", None) or []
        containers.append(container)
        for comp in comps:
            comp = dict(comp)
            if several:
                comp["container"] = container["id"]
            decisions = []
            for decision in comp.get("decisions") or []:
                if decision.get("origin") == TYPE_ORIGIN:  # the project's answer: not the component's own
                    decision = {"question": decision.get("question", ""), "answer": None}
                if decision.get("answer") is None and set(decision) <= {"question", "answer"}:
                    if container["id"] not in texts_of:
                        texts_of[container["id"]] = _template_texts(data | {"containers": [container]}, root)
                    texts = texts_of[container["id"]]
                    key = question_key(decision.get("question", ""))
                    if texts.get(key) == decision.get("question"):
                        decisions.append({"template_question": key})
                        continue
                decisions.append(decision)
            if "decisions" in comp:
                comp["decisions"] = decisions
            for name in COMPONENT_ITEMS:
                if owned.get(comp["id"], {}).get(name):
                    comp[name] = owned[comp["id"]][name]
            cid = comp.pop("id")
            components[cid] = vowfile.dumps("component", comp, name=cid,
                                            comment=COMPONENT_HEADER.format(id=cid))
    project = {k: v for k, v in data.items() if k != "containers"}
    ordered = {"system": project.pop("system", {}), "containers": containers}
    ordered.update({k: v for k, v in project.items() if k != "schema_version"})
    for name, items in system.items():
        ordered[name] = items
    return vowfile.dumps("project", ordered, comment=PROJECT_HEADER), components


def _shorten(item: dict, scope: str | None) -> None:
    if "id" in item:
        item["id"] = shorten(scope, item["id"])
    if item.get("mitigates"):
        item["mitigates"] = [shorten(scope, h) for h in item["mitigates"]]


LAST_CHANGED: set[str] = set()  # component ids whose vow changed in the last save ("*": the project's)


def save(root: Path, data: dict) -> Path:
    """Write the spec; only files whose text changes are written. Returns the project vow path."""
    project_text, components = split(data, root)
    changed: set[str] = set()
    path = root / PROJECT_REL
    path.parent.mkdir(parents=True, exist_ok=True)
    if _write_if_changed(path, project_text):
        changed.add("*")
    folder = root / COMPONENTS_REL
    for cid, text in components.items():
        if _write_if_changed(folder / cid / COMPONENT_FILE, text):
            changed.add(cid)
    if folder.is_dir():
        for stale in folder.iterdir():
            if stale.is_dir() and stale.name not in components and (stale / COMPONENT_FILE).is_file():
                (stale / COMPONENT_FILE).unlink()
                changed.add(stale.name)
                if not any(p for p in stale.iterdir() if p.name != CARD_FILE):
                    for p in stale.iterdir():
                        p.unlink()
                    stale.rmdir()
    LAST_CHANGED.clear()
    LAST_CHANGED.update(changed)
    _LOADED.pop(str(root.resolve()), None)
    return path


def _write_if_changed(path: Path, text: str) -> bool:
    try:
        if path.read_text(encoding="utf-8") == text:
            return False
    except OSError:
        pass
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8", newline="\n")
    return True


def where(component_id: str | None) -> str:
    """The file a finding about one component (or the project, None) points to."""
    if not component_id:
        return PROJECT_REL.as_posix()
    return (COMPONENTS_REL / component_id / COMPONENT_FILE).as_posix()


def spec_files(root: Path) -> list[str]:
    """The vow files of the project, repository-relative (project first)."""
    return [PROJECT_REL.as_posix(), *[(COMPONENTS_REL / p.name / COMPONENT_FILE).as_posix()
                                      for p in _component_files(root)]]


# ------------------------------------------------------------------ Git history


def _git(root: Path, *args: str, stdin: str | None = None) -> str | None:
    try:
        done = subprocess.run(["git", "-C", str(root), *args], capture_output=True, text=True, input=stdin,
                              check=False, encoding="utf-8", errors="replace")
    except FileNotFoundError:
        return None
    return done.stdout if done.returncode == 0 else None


def load_at(root: Path, commit: str) -> dict | None:
    """The spec as it was at `commit`; None when archvow was not there yet."""
    listing = _git(root, "ls-tree", "-r", "--name-only", commit, "--", ARCHVOW_DIR.as_posix())
    if listing is None:
        return None
    names = set(listing.split("\n"))
    if PROJECT_REL.as_posix() not in names:
        return None
    prefix = COMPONENTS_REL.as_posix() + "/"
    component_paths = sorted(n for n in names if n.startswith(prefix) and n.endswith("/" + COMPONENT_FILE)
                             and n.count("/") == 3)
    texts = _cat(root, commit, [PROJECT_REL.as_posix(), *component_paths])
    components = {p.split("/")[2]: texts.get(p, "") for p in component_paths}
    return assemble(texts.get(PROJECT_REL.as_posix(), ""), components, root)


def _cat(root: Path, commit: str, paths: list[str]) -> dict[str, str]:
    """Several files at one commit, with one `git cat-file --batch`."""
    if not paths:
        return {}
    try:
        done = subprocess.run(["git", "-C", str(root), "cat-file", "--batch"], capture_output=True,
                              input="".join(f"{commit}:{p}\n" for p in paths).encode("utf-8"), check=False)
    except FileNotFoundError:
        return {}
    out, pos, result = done.stdout, 0, {}
    for path in paths:
        end = out.index(b"\n", pos)
        header = out[pos:end].decode("utf-8", "replace").split()
        pos = end + 1
        if len(header) < 3 or header[1] == "missing":
            continue
        size = int(header[2])
        result[path] = out[pos:pos + size].decode("utf-8", "replace")
        pos += size + 1
    return result


# ------------------------------------------------------------------ helpers


def container(data: dict, container_id: str | None) -> dict:
    containers = data.get("containers", [])
    if container_id is None:
        if len(containers) != 1:
            ids = ", ".join(c["id"] for c in containers)
            raise ManifestError(f"several containers ({ids}); pass --container")
        return containers[0]
    for item in containers:
        if item["id"] == container_id:
            return item
    raise ManifestError(f"unknown container '{container_id}'")


def name_values(name: str) -> dict[str, str]:
    """The placeholders a component type may use: {name} orders_clean, {NAME} ORDERS_CLEAN,
    {Name} OrdersClean (a class name)."""
    return {"name": name, "NAME": name.upper(), "Name": "".join(p.capitalize() for p in name.split("_"))}


def test_path(component: dict) -> str:
    """Where a component's test lives: tests/<layer>/[<group>/]test_<id>.py."""
    group = f"{component['group']}/" if component.get("group") else ""
    return f"tests/{component['layer']}/{group}test_{component['id']}.py"


def source_path(container_data: dict, component: dict) -> str:
    """The component's file: <container path>/<layer>/[<group>/]<id>.py."""
    return f"{container_data['path']}/" + "/".join(component["module"].split(".")[1:]) + ".py"


def hazards(data: dict) -> list[dict]:
    """The hazards: what must never happen (dismissed safety questions are not hazards)."""
    return list(data.get("hazards", []) or [])


def dismissals(data: dict) -> list[dict]:
    """Safety questions answered "not applicable", with the reason (`archvow hazard dismiss`)."""
    return list(data.get("dismissed") or [])


def answered_safety(data: dict) -> set[tuple[str | None, str | None]]:
    """(component, guide word) pairs whose safety question has an answer: a hazard or a dismissal."""
    return ({(h.get("component"), h.get("guide_word")) for h in data.get("hazards", []) or []}
            | {(d.get("component"), d.get("guide_word")) for d in data.get("dismissed") or []})


def instructed_tools(data: dict) -> list[str]:
    """AI tools that get instructions and may have their files here: the approved assistants
    (they write code) and the approved reviewers (they only write review reports)."""
    tools = [*(data.get("ai_tools") or []), *(data.get("reviewers") or [])]
    return [t for t in dict.fromkeys(tools) if t != "none"]


def template_name(container_data: dict) -> tuple[str, str | None]:
    """Split 'name@version' into (name, version)."""
    ref = container_data["template"]
    name, _, version = ref.partition("@")
    return name, version or None
