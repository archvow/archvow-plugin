"""`archvow workspace --json`: everything an editor shows of a project, in one process - the spec (`show --json`),
each feature's view (`show <feature> --json`), each component's view (`show <component> --json`), the build plan (`next --json`), the findings (`check --json`),
the briefs (`brief show --json`), the templates and agents (`catalog --json`), in the very shapes those
commands print, and the project's templates with their state (3.0), the first steps of a new project (2.1).
`--since <digest>`: when nothing changed since that answer, only `{"unchanged": true, "digest": ...}`.
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

from archvow import __version__, drafts, skills
from archvow.cli.args import Builder
from archvow.cli.commands.brief import brief_status
from archvow.cli.commands.catalog import catalog_parts, catalog_templates
from archvow.cli.commands.plan import next_rows
from archvow.cli.console import style as ui
from archvow.cli.output import as_json, checked, project_root
from archvow.foundation import walk
from archvow.foundation.git import git_or_none
from archvow.foundation.hashing import parts_digest, tree_state
from archvow.model import drafted, store
from archvow.privacy import personal_flow
from archvow.review import approved_reviewers
from archvow.templating import copies
from archvow.templating import store as template_store
from archvow.views.component import component_view
from archvow.views.feature_doc import feature_view
from archvow.views.first_steps import first_steps

TOOL_CACHES = {".venv", ".tox", ".nox", ".mypy_cache", ".pytest_cache", ".ruff_cache", ".hypothesis"}  # never read


def workspace_digest(root: Path) -> str:
    """What the answer depends on: archvow's version, the project's files (its vows, its templates, its code - all of a
    container, as check reads it -, its tests; never a virtualenv or a tool's cache) and Git's HEAD and index.
    The same digest: the same answer."""
    containers = [str(c.get("path") or "") for c in store.load(root).get("containers") or []]
    git = git_or_none(root, "rev-parse", "HEAD", "--git-path", "index") or ""  # the commits ARCH053 reads
    index = root / git.splitlines()[-1] if git.strip() else None
    staged = f"{index.stat().st_mtime_ns}:{index.stat().st_size}" if index is not None and index.is_file() else ""
    unread = walk.folders(root, tuple(containers))  # what check reads: all of a container, and outside it every
    files = tree_state(root, {"__pycache__", *TOOL_CACHES}, keep=containers,  # folder but those holding no code
                       skip_dir=lambda rel: not rel.startswith(".archvow") and unread.holds_no_code(rel))
    data = store.load(root)  # Draft with AI, the skill runs and the reviewers: which commands are installed here
    installed = ",".join(f"{kind}:{t['name']}" for kind, names in (("draft", None), ("skill", None),
                         ("review", approved_reviewers(data))) for t in drafts.tools(root, data, kind, names) if t["installed"])
    return parts_digest([("archvow", __version__.encode()), ("project", files.encode()), ("git", f"{git}{staged}".encode()),
                         ("ai tools", installed.encode())])


def workspace(args: argparse.Namespace, root: Path) -> dict[str, Any]:
    """The whole project as the editor reads it, the check run once for every component."""
    data = store.load(root)
    report = checked(args, root)
    ids = [c["id"] for container in data.get("containers", []) for c in container.get("components", [])]
    rows, _, runs = next_rows(root, None, report)  # the same check, not a second run
    flows = personal_flow(root, data)  # once for the project, not once per component
    return {"project": data,
            "features": {f["name"]: feature_view(root, data, f["name"], report) for f in data.get("features") or []},
            "components": {cid: component_view(root, data, cid, report, flows, runs) for cid in ids},
            "next": rows,
            "check": report.to_dict(),
            "briefs": brief_status(root, data),
            "catalog": catalog_parts(root, catalog_templates(root)),
            "templates": template_states(root, data),
            "first_steps": first_steps(root, data, report, rows),
            # 3.4: what archvow may start itself (ai_runs); each says why not here, with or without a sandbox
            "ai_runs": drafted.runs(data),
            "ai_drafts": {"on": drafts.on(data), "why_not": drafts.allowed(root, data), "tools": drafts.tools(root, data)},
            # 3.3: the skills archvow runs (draft-spec, clarify, analyze), and the approved reviewers
            "ai_skills": {"on": skills.on(data), "why_not": skills.allowed(root, data), "runs": list(skills.RUNS),
                          "tools": drafts.tools(root, data, "skill")},
            "reviewers": drafts.tools(root, data, "review", approved_reviewers(data))}


def template_states(root: Path, data: dict[str, Any]) -> list[dict[str, Any]]:
    """The project's templates as the editor lists them, bases first: each with where it came from and whether its
    copy is what init / `template update` wrote (`changed`: ARCH060); then its own additions (.archvow/template/)."""
    changed = dict(copies.changed_by_hand(root, data))
    recorded = copies.recorded(data)
    found = [{**template_store.meta(folder).summary(), "source": (recorded.get(name) or {}).get("source", ""),
              "state": "changed" if name in changed else "ok", "why": changed.get(name, "")}
             for name, folder in copies.project_copies(root).items()]
    found += [{"name": name, "version": None, "source": "", "state": "changed", "why": why}
              for name, why in changed.items() if name not in copies.project_copies(root)]
    own = copies.own_folder(root)
    if own is not None:
        found.append({"name": template_store.OWN_NAME, "version": None, "source": template_store.OWN.as_posix(),
                      "state": "ok", "why": "", "agents": sorted(p.parent.name for p in own.glob("agents/*/agent.yaml")),
                      "rule_families": sorted(p.stem for p in own.glob("rules/*.yaml"))})
    return found


def cmd_workspace(args: argparse.Namespace) -> int:
    root = project_root(args)
    digest = workspace_digest(root)
    if args.since and args.since == digest:
        found: dict[str, Any] = {"unchanged": True, "digest": digest}
    else:
        found = {"digest": digest, **workspace(args, root)}
    if args.json:
        print(as_json(found))
        return 0
    if found.get("unchanged"):
        print(ui.ok("Nothing changed since that answer") + ui.dim(f"  (digest {digest})"))
        return 0
    errors = sum(v["severity"] == "error" for v in found["check"]["violations"])
    print(f"{len(found['components'])} components, {len(found['next'])} in the build plan, "
          f"{len(found['check']['violations'])} findings ({errors} errors)" + ui.dim(f"  (digest {digest})"))
    print(ui.dim("  for an editor or a script: archvow workspace --json (--since <digest>: only if something changed)"))
    return 0


def declare_workspace(b: Builder) -> None:
    """`archvow workspace`: its parser."""
    p = b.command("workspace", cmd_workspace, "everything an editor shows of the project, in one call (for tools)",
                  True, examples="""
        archvow workspace --json                  # the spec, every component, next, check, briefs, templates
        archvow workspace --json --since 4f2a9c0d1e3b   # only {"unchanged": true} when nothing changed
        """)
    p.add_argument("--since", metavar="DIGEST",
                   help="the digest of an earlier answer: when nothing changed since, print only "
                        "{\"unchanged\": true, \"digest\": ...}")
