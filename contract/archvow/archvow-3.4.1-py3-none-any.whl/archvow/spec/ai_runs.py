"""`ai_runs` (3.4): the AI work archvow may start itself, one answer in place of 3.2's `ai_drafts` and 3.3's `ai_skills`."""

from __future__ import annotations

from typing import Any

from archvow.foundation.errors import SpecError
from archvow.model import drafted
from archvow.templates import Template

OLD_RUNS = ("ai_drafts", "ai_skills")  # 3.2 / 3.3 yes-no answers, one list since 3.4: ai_runs


def one_ai_runs(template: Template, answers: dict[str, Any], kept: dict[str, Any] | None) -> None:
    """With a template that asks `ai_runs`: a 3.2 / 3.3 project's `ai_drafts` and `ai_skills` become it, the same AI
    work; given again with -a, said so. A project whose templates are not updated yet keeps its old answers."""
    if not any(q.get("id") == "ai_runs" for q in template.data.get("questions", [])):
        return
    before = (kept or {}).get("init_answers") or {}
    given = [k for k in OLD_RUNS if k in answers and answers[k] != before.get(k)]
    if given:
        raise SpecError(f"{', '.join(given)}: one answer since archvow 3.4, ai_runs - the AI work archvow may start "
                        "itself", hint="e.g. -a ai_runs=drafts,skills (or drafts, skills, none)")
    if kept is not None and "ai_runs" not in answers and any(k in before for k in OLD_RUNS):
        answers["ai_runs"] = ",".join(drafted.runs(kept) or ["none"])
    if kept is not None and answers.get("ai_runs") == "" and kept.get("ai_runs") == []:
        answers["ai_runs"] = "none"  # ai_runs []: archvow starts no AI
    for old in OLD_RUNS:
        answers.pop(old, None)


def store_runs(data: dict[str, Any], context: dict[str, Any]) -> None:
    """`ai_runs` in project.vow, right after `ai_tools`: which assistants, and what archvow starts with them."""
    if "ai_runs" not in context:
        return
    data["ai_runs"] = [r for r in context["ai_runs"] or [] if r != "none"]  # `none`: archvow starts no AI
    value = data.pop("ai_runs")
    if "ai_tools" not in data:
        data["ai_runs"] = value
        return
    tail = list(data)[list(data).index("ai_tools") + 1:]
    moved = {k: data.pop(k) for k in tail}
    data["ai_runs"] = value
    data.update(moved)
