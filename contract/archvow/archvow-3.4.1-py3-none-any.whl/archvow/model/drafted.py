"""An answer saved from an AI draft (3.2): `drafted_with <tool>` and `draft edited|unchanged` beside its `by` and `on`.

The answer is the person's - they read the draft and saved it (archvow draft, then --drafted-with). These two keys
only say where it came from, for the reader of show, doc and the merge request's spec changes.
"""

from __future__ import annotations

from typing import Any

RUNS = ("drafts", "skills")  # the AI work archvow may start itself (`ai_runs` in project.vow, 3.4)


def runs(data: dict[str, Any]) -> list[str]:
    """What archvow may start itself with the project's AI assistants: `ai_runs [drafts, skills]` in project.vow (3.4),
    [] by default in mode strict, both in guided and free. A project from 3.2 / 3.3 still has `ai_drafts` and
    `ai_skills` yes/no in its init answers: read the same way until `archvow init <package> --force` writes ai_runs."""
    given = data.get("ai_runs")
    if given is not None:
        items = given if isinstance(given, list) else str(given).split(",")
        return [r for r in RUNS if r in {str(i).strip() for i in items}]
    answers = data.get("init_answers") or {}
    default = str(data.get("mode") or "strict") != "strict"
    old = {"drafts": answers.get("ai_drafts"), "skills": answers.get("ai_skills")}
    return [r for r in RUNS if (default if old[r] is None else str(old[r]) == "yes")]


def on(data: dict[str, Any], what: str = "drafts") -> bool:
    """Whether archvow may start the AI for `drafts` (archvow draft) or `skills` (archvow skill)."""
    return what in runs(data)


def marks(data: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Every saved answer that came from an AI draft, by where it is ('sales.config decision 2'): the entry itself."""
    out: dict[str, dict[str, Any]] = {}
    for container in data.get("containers") or []:
        for comp in container.get("components") or []:
            for number, entry in enumerate(comp.get("decisions") or [], 1):
                if isinstance(entry, dict) and entry.get("drafted_with"):
                    out[f"{comp.get('id')} decision {number}"] = entry
            for key, entry in sorted((comp.get("answers") or {}).items()):
                if isinstance(entry, dict) and entry.get("drafted_with"):
                    out[f"{comp.get('id')} answer {key}"] = entry
    for entry in data.get("hazards") or []:
        if isinstance(entry, dict) and entry.get("drafted_with"):
            out[f"hazard {entry.get('id')}"] = entry
    return out


def mark(entry: dict[str, Any], tool: str | None, unchanged: bool = False) -> None:
    """Record on a saved answer that it came from an AI draft (or that it no longer does)."""
    entry.pop("drafted_with", None)
    entry.pop("draft", None)
    if tool:
        entry["drafted_with"] = tool
        entry["draft"] = "unchanged" if unchanged else "edited"


def note(entry: dict[str, Any]) -> str:
    """' (AI draft by claude-code, edited)', or '' for an answer a person wrote."""
    if not entry.get("drafted_with"):
        return ""
    return f" (AI draft by {entry['drafted_with']}, {entry.get('draft') or 'edited'})"


def view(entry: dict[str, Any]) -> dict[str, Any]:
    """What the IDEs read: {'drafted': {'tool': ..., 'edited': ...}} or {}."""
    if not entry.get("drafted_with"):
        return {}
    return {"drafted": {"tool": entry["drafted_with"], "edited": entry.get("draft") != "unchanged"}}
