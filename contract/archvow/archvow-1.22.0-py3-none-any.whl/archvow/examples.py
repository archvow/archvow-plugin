"""Business examples: "given this input, we expect this result", from the business team, locked.

The data lives in files, never in the vow:

    tests/examples/<component>/<example>/input/<one file per source>     e.g. sales.csv
    tests/examples/<component>/<example>/expected/<one file per output>  e.g. revenue.csv
    tests/examples/<component>/<example>/scenario.feature                optional: the case in words
    tests/examples/<component>/<example>/actual/<one file per output>    written by the test at each run

A person records an example with `archvow example add <component> <example> [-s <ticket>] [--from
<brief>#<section>]`: archvow checks the files (text formats only, small, no real-looking identifier: the
TST002/TST003 checks) and stores in the component's vow the example's name, ticket, the rule it shows (the
`Rule:` line of its scenario), the brief section it is drawn from, who and when, and a **fingerprint** of
its files. The fingerprint is the lock: an AI that changes `expected/` to make its test pass fails `archvow
check` (ARCH055), whatever the editor. When the business team changes an expected result, a person replaces
the files and runs `example add` again.

`actual/` is what the component really gave at the last run: the example's test writes it, with the same
file names as `expected/`. It is not locked (outside the fingerprint) and not committed (gitignored).

**The test decides, archvow shows.** Whether an example passes is the verdict of its marked test in the
JUnit report `test-results.xml` (`make test` and the generated CI write it): a test may round, ignore the
order of rows or allow a tolerance, which archvow cannot know. archvow only compares the TEXTS of `actual/`
and `expected/`, by kind of file, to show where they differ; it never reads a value as a number or a date.

Only the component types whose template says `examples: true` take examples (a job, a transformation,
a router...: input in, output out). Each example needs a test marked `@pytest.mark.example("<name>")`
(ARCH056), of the same kind as the type's tests: a job's or a router's example runs in the slower
integration run.
"""

from __future__ import annotations

import csv
import difflib
import hashlib
import io
import json
import re
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING

from archvow import manifest as mf
from archvow.specs import SpecError

if TYPE_CHECKING:
    from archvow.check import _Checker
    from archvow.templates import Template

FOLDER = "tests/examples"
PARTS = ("input", "expected")
ACTUAL = "actual"  # written by the example's test at each run; not locked, gitignored
GITIGNORE = ["# archvow: what each business example's test really gave at its last run (local)",
             "tests/examples/*/*/actual/"]
REPORT = "test-results.xml"  # pytest's JUnit report: make test and the generated CI write it
SCENARIO = "scenario.feature"  # optional: the example in Given/When/Then words, locked with its files
SCENARIO_MAX_LINES = 30
# Gherkin keywords, English and French (`# language: fr`): what a scenario file is checked for, never run
GHERKIN = {"feature": ("Feature:", "Fonctionnalité:"), "rule": ("Rule:", "Règle:"),
           "scenario": ("Scenario:", "Example:", "Scénario:", "Exemple:"),
           "given": ("Given ", "Soit ", "Étant donné "), "when": ("When ", "Quand ", "Lorsque "),
           "then": ("Then ", "Alors ")}
NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]*$")
# How a file is shown and compared, by its extension (the formats TST003 accepts, testdata.TEXT)
KINDS = {".csv": "table", ".tsv": "table", ".jsonl": "records", ".ndjson": "records", ".json": "document",
         ".yaml": "document", ".yml": "document", ".txt": "text", ".md": "text", ".xml": "text"}
TABLE_KINDS = ("table", "records")
CARD_MAX_LINES = 20  # a file printed on the spec card: at most this many lines and bytes, else its path
CARD_MAX_BYTES = 4096
SHOW_MAX_DIFFERENCES = 10  # archvow show: at most this many differences per file


def folder(component_id: str, name: str) -> str:
    return f"{FOLDER}/{component_id}/{name}"


def level(template: Template, comp: dict) -> str | None:
    """'unit' or 'integration' (the kind of the type's own tests) when the type takes examples, else None."""
    ctype = template.type_of(comp)
    if not ctype.get("examples"):
        return None
    return "integration" if ctype.get("test") == "integration" else "unit"


def types_with_examples(template: Template) -> list[str]:
    return [name for name, ctype in template.component_types.items() if ctype.get("examples")]


def _files(base: Path) -> list[Path]:
    return sorted(p for p in base.rglob("*") if p.is_file()) if base.is_dir() else []


def files_of(root: Path, rel: str) -> dict[str, list[Path]]:
    """{'input': [...], 'expected': [...]} - the files under each part, sorted."""
    return {part: _files(root / rel / part) for part in PARTS}


def fingerprint(root: Path, rel: str) -> str | None:
    """sha256 (12 characters) of the paths and contents of input/, expected/ and scenario.feature, line
    endings as LF so a Windows checkout gives the same value. None when a part is missing or empty.
    actual/ is never part of it: the test rewrites it at each run."""
    found = files_of(root, rel)
    if not all(found.values()):
        return None
    digest = hashlib.sha256()
    scenario = root / rel / SCENARIO
    for path in [*(p for part in PARTS for p in found[part]), *([scenario] if scenario.is_file() else [])]:
        digest.update(path.relative_to(root / rel).as_posix().encode("utf-8") + b"\0")
        digest.update(path.read_bytes().replace(b"\r\n", b"\n") + b"\0")
    return digest.hexdigest()[:12]


def scenario_text(root: Path, rel: str) -> str | None:
    """The example's scenario.feature, when it has one."""
    path = root / rel / SCENARIO
    return path.read_text(encoding="utf-8", errors="replace").strip() if path.is_file() else None


def _scenario_lines(text: str) -> list[str]:
    return [line.strip() for line in text.splitlines() if line.strip() and not line.strip().startswith("#")]


def scenario_rule(text: str | None) -> str | None:
    """The value of the scenario's `Rule:` line (`Règle:` in French): the id of the rule it shows."""
    for line in _scenario_lines(text or ""):
        for word in GHERKIN["rule"]:
            if line.startswith(word):
                return line[len(word):].strip() or None
    return None


def scenario_problems(text: str, name: str) -> list[str]:
    """What is wrong with the shape of a scenario.feature: one Scenario, its Given/When/Then lines, short,
    at most one Rule: line."""
    lines = _scenario_lines(text)
    count = {key: sum(1 for line in lines if line.startswith(words)) for key, words in GHERKIN.items()}
    issues = []
    if len(text.splitlines()) > SCENARIO_MAX_LINES:
        issues.append(f"{name}: over {SCENARIO_MAX_LINES} lines - one scenario, its Given/When/Then lines")
    if count["feature"] > 1 or count["scenario"] != 1:
        issues.append(f"{name}: one Scenario (at most one Feature) - found {count['scenario']} scenario(s)")
    if count["rule"] > 1:
        issues.append(f"{name}: at most one Rule: line (the rule or invariant the example shows) - found "
                      f"{count['rule']}")
    missing = [k.capitalize() for k in ("given", "when", "then") if not count[k]]
    if missing:
        issues.append(f"{name}: no {', '.join(missing)} line - a scenario says what is given, what runs, what results")
    return issues


def problems(root: Path, rel: str, max_kb: int, max_rows: int) -> list[str]:
    """What stops archvow from recording the files: the parts, the formats, the size, real-looking data."""
    from archvow.testdata import TEXT, identifiers

    found = files_of(root, rel)
    issues = [f"{rel}/{part}/ is missing or empty" for part in PARTS if not found[part]]
    for path in (p for part in PARTS for p in found[part]):
        name = path.relative_to(root).as_posix()
        if path.suffix.lower() not in TEXT:
            issues.append(f"{name}: an example is text ({', '.join(sorted(TEXT))}) - export a binary extract as CSV "
                          "or JSON, with invented values")
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        if len(path.read_bytes()) > max_kb * 1024 or text.count("\n") > max_rows:
            issues.append(f"{name}: over {max_kb} KB or {max_rows} rows - an example is a few rows that show the "
                          "case (a real extract is big)")
        issues += [f"{name}: {found_id} looks real (TST002) - invent it (e.g. name@example.com)"
                   for found_id in identifiers(text)]
    scenario = scenario_text(root, rel)
    if scenario is not None:
        name = f"{rel}/{SCENARIO}"
        issues += scenario_problems(scenario, name)
        issues += [f"{name}: {found_id} looks real (TST002) - invent it (e.g. name@example.com)"
                   for found_id in identifiers(scenario)]
    return issues


def _component(data: dict, component_id: str) -> tuple[dict, dict]:
    from archvow.specs import find_component

    return find_component(data, component_id)


def _template(root: Path, container: dict) -> Template:
    from archvow.templates import load_template

    return load_template(mf.template_name(container)[0], root)


def rule_id(data: dict, comp: dict, value: str) -> str:
    """The id a `Rule:` line names, checked: an invariant of this component (INV1 or <component>.INV1) or a
    project rule that applies to it (R2)."""
    from archvow.specs import rules_for

    wanted = value.strip()
    invariants = [str(i.get("id")) for i in data.get("invariants") or [] if str(i.get("id", "")).startswith(comp["id"] + ".")]
    rules = [str(r.get("id")) for r in rules_for(data, comp)]
    full = f"{comp['id']}.{wanted.upper()}" if re.fullmatch(r"(?i)INV\d+", wanted) else wanted
    if re.fullmatch(r"(?i)[a-z][a-z0-9_]*\.INV\d+", full):
        head, _, tail = full.rpartition(".")
        full = f"{head}.{tail.upper()}"
    elif re.fullmatch(r"(?i)R\d+", full):
        full = full.upper()
    if full in invariants or full in rules:
        return full
    known = ", ".join([*invariants, *rules]) or "none yet (archvow invariant add, archvow rule add)"
    raise SpecError(f"Rule: {value}: not an invariant of {comp['id']} nor a project rule that applies to it "
                    f"(its ids: {known})")


def add(root: Path, component_id: str, name: str, ticket: str | None = None, source: dict | None = None) -> dict:
    """Record (or accept again) the example whose files are in tests/examples/<component>/<name>/."""
    from archvow.check import DEFAULT_PARAMS
    from archvow.specs import stamp

    data = mf.load(root)
    container, comp = _component(data, component_id)
    template = _template(root, container)
    if level(template, comp) is None:
        allowed = ", ".join(types_with_examples(template)) or "none in this template"
        raise SpecError(f"a {comp['type']} takes no examples (input in, output out): they go on {allowed}")
    if not NAME_RE.fullmatch(name):
        raise SpecError(f"example name '{name}': letters, digits, - and _ only, e.g. FATTRIB-012-negative-quantity")
    if ticket:
        from archvow.branches import check_ticket

        check_ticket(data, ticket.strip())
    rel = folder(component_id, name)
    params = DEFAULT_PARAMS["TST003"]
    issues = problems(root, rel, params["max_kb"], params["max_rows"])
    if issues:
        raise SpecError("the example cannot be recorded:\n  " + "\n  ".join(issues))
    named = scenario_rule(scenario_text(root, rel))
    rule = rule_id(data, comp, named) if named else None
    examples = comp.setdefault("examples", [])
    old = next((e for e in examples if e.get("name") == name), None)
    kept_ticket = ticket.strip() if ticket else (old or {}).get("ticket")
    kept_source = source or (old or {}).get("source")  # recorded again without --from: it keeps its brief
    entry = {"name": name, **({"ticket": kept_ticket} if kept_ticket else {}), **({"rule": rule} if rule else {}),
             **({"source": kept_source} if kept_source else {}), "fingerprint": fingerprint(root, rel), **stamp(root)}
    if old is not None:
        examples[examples.index(old)] = entry
    else:
        examples.append(entry)
    mf.save(root, data)
    return {**entry, "replaced": old is not None, "folder": rel, "level": level(template, comp)}


def remove(root: Path, component_id: str, name: str) -> dict:
    data = mf.load(root)
    _, comp = _component(data, component_id)
    examples = comp.get("examples") or []
    found = next((e for e in examples if e.get("name") == name), None)
    if found is None:
        known = ", ".join(e.get("name", "?") for e in examples) or "none"
        raise SpecError(f"'{component_id}' has no example '{name}' (its examples: {known})")
    comp["examples"] = [e for e in examples if e is not found]
    if not comp["examples"]:
        del comp["examples"]
    mf.save(root, data)
    return {**found, "folder": folder(component_id, name)}


# ------------------------------------------------------------------ reading and comparing the files


def kind_of(path: Path | str) -> str:
    """table (.csv, .tsv), records (.jsonl, .ndjson), document (.json, .yaml), text (.txt, .md, .xml...)."""
    return KINDS.get(Path(path).suffix.lower(), "text")


def raw_text(path: Path) -> str:
    """The file as text: UTF-8 (a byte that is not shows as �), without a BOM, line endings as LF."""
    data = path.read_bytes()
    if data.startswith(b"\xef\xbb\xbf"):
        data = data[3:]
    return data.decode("utf-8", errors="replace").replace("\r\n", "\n").replace("\r", "\n")


def _cell(value: object) -> str:
    return value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, sort_keys=True)


def content(path: Path) -> dict:
    """How archvow shows a file: {kind, header, rows} for a table or records (rows: lists of texts), {kind,
    lines} for a document or a text. A file that cannot be read in its kind is shown as text, with a note."""
    kind = kind_of(path)
    text = raw_text(path)
    if kind == "table":
        try:
            rows = list(csv.reader(io.StringIO(text), delimiter="\t" if path.suffix.lower() == ".tsv" else ",",
                                   strict=True))
        except csv.Error as exc:
            return {"kind": "text", "lines": text.splitlines(), "note": f"not valid CSV ({exc}): compared as text"}
        rows = [r for r in rows if r]
        return {"kind": kind, "header": rows[0] if rows else [], "rows": rows[1:]}
    if kind == "records":
        try:
            records = [json.loads(line) for line in text.splitlines() if line.strip()]
            if not all(isinstance(r, dict) for r in records):
                raise ValueError("a line is not a JSON object")
        except ValueError as exc:
            return {"kind": "text", "lines": text.splitlines(), "note": f"not valid JSON Lines ({exc}): compared as text"}
        header: list[str] = []
        for record in records:
            header += [k for k in record if k not in header]
        return {"kind": kind, "header": header,
                "rows": [[_cell(r[k]) if k in r else "" for k in header] for r in records]}
    if kind == "document":
        try:
            if path.suffix.lower() == ".json":
                shown = json.dumps(json.loads(text), ensure_ascii=False, sort_keys=True, indent=2)
            else:
                import yaml

                shown = yaml.safe_dump(yaml.safe_load(text), allow_unicode=True, sort_keys=True,
                                       default_flow_style=False).rstrip("\n")
        except Exception as exc:  # noqa: BLE001 - any parser error: shown and compared as text
            what = "JSON" if path.suffix.lower() == ".json" else "YAML"
            return {"kind": "text", "lines": text.splitlines(), "note": f"not valid {what} ({str(exc).splitlines()[0]}):"
                    " compared as text"}
        return {"kind": kind, "lines": shown.splitlines()}
    return {"kind": "text", "lines": text.splitlines()}


def _pairs(ops: list[tuple], left: list, right: list, pair: bool = True) -> list[dict]:
    """difflib opcodes as rows: same, missing (only in expected), extra (only in actual), changed (a row of a
    table against the row in its place; lines of a document or a text are never paired: - then +)."""
    out: list[dict] = []
    for tag, i1, i2, j1, j2 in ops:
        if tag == "equal":
            out += [{"op": "same", "expected": left[i], "actual": right[j]} for i, j in zip(range(i1, i2), range(j1, j2))]
            continue
        lefts, rights = list(range(i1, i2)), list(range(j1, j2))
        common = min(len(lefts), len(rights)) if tag == "replace" and pair else 0
        out += [{"op": "changed", "expected": left[i], "actual": right[j]} for i, j in zip(lefts[:common], rights[:common])]
        out += [{"op": "missing", "expected": left[i], "actual": None} for i in lefts[common:]]
        out += [{"op": "extra", "expected": None, "actual": right[j]} for j in rights[common:]]
    return out


def compare_file(name: str, expected: Path | None, actual: Path | None) -> dict:
    """One output file of an example: expected/<name> against actual/<name>, as texts, by kind.
    {name, kind, state: same | differs | missing (not in actual/) | extra (only in actual/), differences,
    header?, rows: [{op, expected, actual, cells?}], note?}"""
    if actual is None or expected is None:
        present = content(expected or actual)  # type: ignore[arg-type]
        side = "expected" if actual is None else "actual"
        rows = present.get("rows") if present["kind"] in TABLE_KINDS else present.get("lines")
        return {"name": name, "kind": present["kind"], "state": "missing" if actual is None else "extra",
                "differences": len(rows or []) or 1, **({"header": {side: present["header"]}} if "header" in present else {}),
                "rows": [{"op": "missing" if actual is None else "extra", side: r,
                          "expected" if side == "actual" else "actual": None} for r in rows or []],
                **({"note": present["note"]} if present.get("note") else {})}
    left, right = content(expected), content(actual)
    note = left.get("note") or right.get("note")
    if left["kind"] in TABLE_KINDS and right["kind"] in TABLE_KINDS:
        rows = _pairs(difflib.SequenceMatcher(None, [tuple(r) for r in left["rows"]],
                                              [tuple(r) for r in right["rows"]], autojunk=False).get_opcodes(),
                      left["rows"], right["rows"])
        for row in rows:
            if row["op"] == "changed":
                size = max(len(row["expected"]), len(row["actual"]))
                row["cells"] = [i for i in range(size) if (row["expected"][i:i + 1] or [None]) != (row["actual"][i:i + 1] or [None])]
        header = {"expected": left["header"], "actual": right["header"]}
        differences = sum(1 for r in rows if r["op"] != "same") + (left["header"] != right["header"])
        return {"name": name, "kind": left["kind"], "state": "differs" if differences else "same",
                "differences": differences, "header": header, "rows": rows, **({"note": note} if note else {})}
    left_lines = left.get("lines") if "lines" in left else raw_text(expected).splitlines()
    right_lines = right.get("lines") if "lines" in right else raw_text(actual).splitlines()
    rows = _pairs(difflib.SequenceMatcher(None, left_lines, right_lines, autojunk=False).get_opcodes(),
                  left_lines, right_lines, pair=False)
    differences = sum(1 for r in rows if r["op"] != "same")
    return {"name": name, "kind": left["kind"] if left["kind"] == right["kind"] else "text",
            "state": "differs" if differences else "same", "differences": differences, "rows": rows,
            **({"note": note} if note else {})}


def outcome(root: Path, rel: str) -> dict:
    """What the last run gave: {actual: bool, on: when actual/ was written, files: [compare_file...]}."""
    expected_dir, actual_dir = root / rel / "expected", root / rel / ACTUAL
    expected = {p.relative_to(expected_dir).as_posix(): p for p in _files(expected_dir)}
    actual = {p.relative_to(actual_dir).as_posix(): p for p in _files(actual_dir)}
    if not actual:
        return {"actual": False, "files": [{"name": n, "kind": kind_of(n), "state": "no_actual", "differences": 0,
                                            "rows": []} for n in sorted(expected)]}
    newest = max(p.stat().st_mtime for p in actual.values())
    return {"actual": True, "on": datetime.fromtimestamp(newest).strftime("%Y-%m-%d %H:%M"),
            "files": [compare_file(n, expected.get(n), actual.get(n)) for n in sorted(set(expected) | set(actual))]}


def verdicts(root: Path) -> tuple[dict[str, str], str] | None:
    """The verdict of each example's marked test in test-results.xml: {EXAMPLE NAME: passed | failed |
    skipped}, and when the report was written. None without a report."""
    from archvow.evidence import mark_values, marked_tests, report_cases, state_of

    report = root / REPORT
    if not report.is_file():
        return None
    cases = report_cases(report)
    if cases is None:
        return None
    rank = {"passed": 0, "not run": 1, "skipped": 2, "failed": 3}
    found: dict[str, str] = {}
    for test in marked_tests(root):
        for name in mark_values(test.marks, "example"):
            state = state_of(test, cases)
            found[name] = max(found.get(name, "passed"), state, key=rank.__getitem__) if name in found else state
    return found, datetime.fromtimestamp(report.stat().st_mtime).strftime("%Y-%m-%d %H:%M")


RESULTS = {"passed": "passing", "failed": "failing", "skipped": "skipped", "not run": "not_run"}


def view(root: Path, comp: dict, template: Template | None, marks: set[str],
         report: tuple[dict[str, str], str] | None = None) -> list[dict]:
    """The component's examples as show prints them: name, ticket, rule, source, level, folder, test marked,
    the test's verdict (result), what actual/ holds against expected/ (files), who/when."""
    kind = level(template, comp) if template else None
    rows = []
    for e in comp.get("examples") or []:
        rel = folder(comp["id"], e["name"])
        tested = e["name"].upper() in marks
        if not tested:
            result = "no_test"
        elif report is None:
            result = "not_run"
        else:
            result = RESULTS.get(report[0].get(e["name"].upper(), "not run"), "not_run")
        last = outcome(root, rel)
        rows.append({"name": e["name"], **({"ticket": e["ticket"]} if e.get("ticket") else {}),
                     **({"rule": e["rule"]} if e.get("rule") else {}),
                     **({"source": e["source"]} if e.get("source") else {}), "level": kind, "folder": rel,
                     "tested": tested, "unchanged": fingerprint(root, rel) == e.get("fingerprint"),
                     "result": result, **({"run_on": report[1]} if report and result != "no_test" else {}),
                     "actual": last["actual"], **({"actual_on": last["on"]} if last.get("on") else {}),
                     "files": last["files"],
                     **({"scenario": text} if (text := scenario_text(root, rel)) else {}),
                     "by": e.get("by"), "on": str(e.get("on"))[:10]})
    return rows


def marked(root: Path) -> set[str]:
    """Every example name a test marks (upper case), wherever the test file is."""
    from archvow.evidence import mark_values, marked_tests

    return {v for t in marked_tests(root) for v in mark_values(t.marks, "example")}


def card_file(path: Path) -> list[str] | None:
    """A small input/ or expected/ file as the spec card prints it (Markdown lines): a table for a table or
    records, a fenced block for a document or a text. None when it is too big for the card."""
    data = path.read_bytes()
    if len(data) > CARD_MAX_BYTES or raw_text(path).count("\n") > CARD_MAX_LINES:
        return None
    shown = content(path)
    if shown["kind"] in TABLE_KINDS:
        def line(cells: list[str]) -> str:
            return "| " + " | ".join(c.replace("|", "\\|").replace("\n", " ") for c in cells) + " |"
        header = shown["header"] or [""]
        return [line(header), "|" + "---|" * len(header), *(line(r) for r in shown["rows"])]
    fence = {".json": "json", ".yaml": "yaml", ".yml": "yaml", ".xml": "xml"}.get(path.suffix.lower(), "text")
    return [f"```{fence}", *shown["lines"], "```"]


def run_examples(checker: _Checker) -> None:
    """ARCH055: an example's files are the ones recorded; ARCH056: each example of a coded component has a
    marked test."""
    from archvow.evidence import unreadable_tests
    from archvow.proposals import mode

    root = checker.root
    strict = mode(checker.manifest) == "strict" or checker.complete
    names: set[str] | None = None
    planned = {s.component for s in checker.report.statuses if s.status == "planned"}
    coded = {s.component for s in checker.report.statuses} - planned  # a test is due once the code exists
    for container in checker.manifest.get("containers", []):
        for comp in container.get("components", []):
            for example in comp.get("examples") or []:
                name = example.get("name", "?")
                rel = folder(comp["id"], name)
                where = mf.where(comp["id"])
                now = fingerprint(root, rel)
                again = f"archvow example add {comp['id']} {name}"
                if now is None:
                    checker.add("ARCH055", f"example {name} of {comp['id']}: {rel}/ has no input/ or expected/ "
                                f"files any more -> put them back, or a person runs archvow example remove "
                                f"{comp['id']} {name}", where)
                elif now != example.get("fingerprint"):
                    checker.add("ARCH055", f"example {name} of {comp['id']}: the files in {rel}/ changed since "
                                f"{example.get('by', '?')} recorded them -> put them back (git checkout -- {rel}), "
                                f"or a person checks them with the business team and runs {again}", where)
                if comp["id"] not in coded:
                    continue
                if names is None:
                    names = marked(root)
                if name.upper() not in names:
                    unreadable = unreadable_tests(root)
                    hint = (f" ({', '.join(unreadable)} {'is' if len(unreadable) == 1 else 'are'} not UTF-8: "
                            "its marks cannot be read - save it as UTF-8)") if unreadable else ""
                    checker.add("ARCH056", f"example {name} of {comp['id']} has no test marked "
                                f"@pytest.mark.example(\"{name}\"){hint} -> write the test that reads {rel}/input/, "
                                f"writes what the component gives to {rel}/{ACTUAL}/ and compares it with "
                                f"{rel}/expected/", where, escalate=strict)
