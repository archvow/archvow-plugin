"""Test data (TST): tests never touch real data.

* TST001 - a test reads nothing outside tests/: no database or cloud URL, no Spark table, no
  absolute path. Data is built in the test, or read from a small file under tests/.
* TST002 - test data holds no real-looking identifier: e-mail addresses outside the reserved
  example domains, IBANs with a valid checksum, card numbers passing the Luhn check, French
  social security numbers (NIR) with a valid key, phone numbers.
  The same check runs on the briefs (briefs/): they are often pasted from real cases.
* TST003 - no binary extract (Parquet, Avro, ORC, Excel, databases) under tests/, and text data
  files stay small (a real extract is big).

None of this proves a value typed by hand is not a real person's; it closes the usual roads.
"""

from __future__ import annotations

import ast
import re
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from archvow.check import _Checker

SKIP_DIRS = {"venv", "env", "build", "dist", "node_modules", "__pycache__", "site-packages", "spark-warehouse"}
CLOUD_RE = re.compile(r"^(s3a?|s3n|abfss?|wasbs?|gs|hdfs|dbfs|adl|oci)://|^dbfs:/", re.I)
DB_RE = re.compile(r"^(jdbc:)?(postgres(ql)?|mysql|mariadb|oracle|sqlserver|mssql|db2|mongodb(\+srv)?|redis|"
                   r"snowflake|teradata|hive2?)[a-z0-9+]*:(//)?(?P<rest>.*)$", re.I)
LOCAL_HOSTS = ("localhost", "127.0.0.1", "0.0.0.0", "::1", "host.docker.internal")
READ_CALLS = {"load", "csv", "parquet", "json", "orc", "text", "table", "jdbc", "open", "read_csv",
              "read_parquet", "read_json", "read_excel", "Path", "listdir", "glob"}
REAL_TABLE_CALLS = {"table", "jdbc"}
BINARY = {".parquet", ".avro", ".orc", ".xlsx", ".xls", ".db", ".sqlite", ".sqlite3", ".feather", ".pkl",
          ".pickle", ".dump", ".bak"}
TEXT = {".csv", ".tsv", ".json", ".jsonl", ".ndjson", ".txt", ".md", ".xml", ".yaml", ".yml"}
EMAIL_RE = re.compile(r"\b[A-Za-z0-9._%+-]+@([A-Za-z0-9-]+\.)+[A-Za-z]{2,}\b")
FAKE_DOMAINS = ("example.com", "example.org", "example.net", "example.fr", "test", "invalid", "localhost",
                "example")
IBAN_RE = re.compile(r"\b[A-Z]{2}[0-9]{2}(?: ?[A-Z0-9]{4}){2,7}(?: ?[A-Z0-9]{1,4})?\b")
CARD_RE = re.compile(r"\b(?:[0-9][ -]?){12,18}[0-9]\b")
NIR_RE = re.compile(r"\b[12] ?[0-9]{2} ?(?:0[1-9]|1[0-2]|[2-9][0-9]) ?(?:[0-9]{2}|2A|2B) ?[0-9]{3} ?[0-9]{3} ?"
                    r"[0-9]{2}\b")
PHONE_RE = re.compile(r"(?:\+[1-9][0-9]{0,2}[ .-]?[1-9](?:[ .-]?[0-9]{2}){4}|\b0[1-9](?:[ .-][0-9]{2}){4})\b")


def _files(tests: Path) -> list[Path]:
    if not tests.is_dir():
        return []
    return [p for p in sorted(tests.rglob("*")) if p.is_file()
            and not any(part.startswith(".") or part in SKIP_DIRS for part in p.relative_to(tests).parts[:-1])]


def run_testdata(checker: _Checker) -> None:
    root = checker.root
    _check_briefs(checker)
    max_kb, max_rows = checker.param("TST003", "max_kb"), checker.param("TST003", "max_rows")
    for path in _files(root / "tests"):
        rel = path.relative_to(root).as_posix()
        suffix = path.suffix.lower()
        if suffix in BINARY:
            checker.add("TST003", f"{rel}: binary data in tests (a real extract?) - build the rows in the "
                        "test, or keep a small CSV/JSON file of invented values", rel)
        elif suffix == ".py":
            _check_python(checker, path, rel)
        elif suffix in TEXT:
            text = path.read_text(encoding="utf-8", errors="replace")
            size_kb, rows = len(text.encode("utf-8")) // 1024, text.count("\n")
            if size_kb > max_kb or rows > max_rows:
                checker.add("TST003", f"{rel}: {size_kb} KB, {rows} lines (max {max_kb} KB, {max_rows} lines) - "
                            "test data is small and invented, not an extract", rel)
            for number, line in enumerate(text.splitlines(), 1):
                for found in identifiers(line):
                    checker.add("TST002", f"{rel}: {found} looks real - use invented values "
                                "(name@example.com, FR76 3000 6000 0112 3456 7890 189...)", rel, number)


def _check_briefs(checker: _Checker) -> None:
    """Briefs are written by people and often pasted from real cases: the same identifiers as test data."""
    from archvow.briefs import brief_files

    for path in brief_files(checker.root, checker.manifest):
        rel = path.relative_to(checker.root).as_posix()
        for number, line in enumerate(path.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
            for found in identifiers(line):
                checker.add("TST002", f"{rel}: {found} looks real - a brief holds invented values "
                            "(name@example.com...)", rel, number)


def _check_python(checker: _Checker, path: Path, rel: str) -> None:
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"))
    except (OSError, SyntaxError, UnicodeDecodeError):
        return
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            name = node.func.attr if isinstance(node.func, ast.Attribute) else getattr(node.func, "id", "")
            if name in REAL_TABLE_CALLS and isinstance(node.func, ast.Attribute):
                checker.add("TST001", f".{name}(...) reads a real table: build a DataFrame in the test "
                            "(spark.createDataFrame) instead", rel, node.lineno)
                continue
            if name in READ_CALLS:
                for arg in node.args[:1]:
                    if isinstance(arg, ast.Constant) and isinstance(arg.value, str) and arg.value.startswith("/") \
                            and not arg.value.startswith("/tmp"):
                        checker.add("TST001", f"'{arg.value}': a test reads only files under tests/ (or "
                                    "tmp_path)", rel, node.lineno)
        elif isinstance(node, ast.Constant) and isinstance(node.value, str):
            problem = _remote_source(node.value)
            if problem:
                checker.add("TST001", f"'{_short(node.value)}': {problem}", rel, node.lineno)
            else:
                for found in identifiers(node.value):
                    checker.add("TST002", f"{found} looks real - use invented values (name@example.com...)",
                                rel, node.lineno)


def _remote_source(text: str) -> str:
    value = text.strip()
    if CLOUD_RE.match(value):
        return "cloud storage in a test - copy a few invented rows under tests/"
    match = DB_RE.match(value)
    if match and not any(host in match.group("rest") for host in LOCAL_HOSTS) and ":memory:" not in value:
        return "a real database in a test - use an in-memory database or a local test container"
    return ""


def _short(text: str) -> str:
    return text if len(text) <= 60 else text[:57] + "..."


def identifiers(text: str) -> list[str]:
    """Real-looking personal identifiers in a text: what TST002 reports."""
    found = []
    for match in EMAIL_RE.finditer(text):
        domain = match.group(0).rsplit("@", 1)[1].lower()
        if not any(domain == d or domain.endswith("." + d) for d in FAKE_DOMAINS):
            found.append(f"e-mail {match.group(0)}")
    ibans = [m for m in IBAN_RE.finditer(text)]
    for match in ibans:
        if _iban_ok(match.group(0)):
            found.append(f"IBAN {match.group(0)}")
    inside = lambda m: any(i.start() <= m.start() and m.end() <= i.end() for i in ibans)  # noqa: E731
    for match in NIR_RE.finditer(text):
        if _nir_ok(match.group(0)):
            found.append(f"social security number {match.group(0)}")
    for match in CARD_RE.finditer(text):
        digits = re.sub(r"\D", "", match.group(0))
        if 13 <= len(digits) <= 19 and _luhn_ok(digits) and len(set(digits)) > 2 and not inside(match):
            found.append(f"card number {match.group(0)}")
    for match in PHONE_RE.finditer(text):
        if not inside(match):
                found.append(f"phone number {match.group(0)}")
    return found


TEST_IBANS = {"FR7630006000011234567890189", "DE89370400440532013000", "GB82WEST12345698765432"}


def _iban_ok(text: str) -> bool:
    iban = text.replace(" ", "")
    if iban in TEST_IBANS or not 15 <= len(iban) <= 34:
        return False
    moved = iban[4:] + iban[:4]
    try:
        return int("".join(str(int(c, 36)) for c in moved)) % 97 == 1
    except ValueError:
        return False


def _luhn_ok(digits: str) -> bool:
    total = 0
    for index, char in enumerate(reversed(digits)):
        value = int(char) * (2 if index % 2 else 1)
        total += value - 9 if value > 9 else value
    return total % 10 == 0


def _nir_ok(text: str) -> bool:
    nir = text.replace(" ", "")
    body, key = nir[:13], nir[13:]
    body = body.replace("2A", "19").replace("2B", "18")
    try:
        return 97 - int(body) % 97 == int(key)
    except ValueError:
        return False
