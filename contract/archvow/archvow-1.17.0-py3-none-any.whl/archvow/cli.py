"""archvow - architecture specifications for AI-written code, and the guards that enforce them.

archvow never writes source code. It writes the spec (what must exist, what must never
happen, which decisions are made) and verifies that the code follows it.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import textwrap
from pathlib import Path

from archvow import __version__, docs, freeze, specs, ui
from archvow import manifest as mf
from archvow.audit import render_audit, run_audit
from archvow.baseline import GitError
from archvow.check import Report, run_check
from archvow.prompt import plan_next, plan_with_budget, render_clarify, render_prompt, situation
from archvow.specdiff import render, spec_diff
from archvow.specs import SpecError
from archvow.templates import (
    Template,
    TemplateError,
    check_layer_names,
    discover,
    load_template,
    scaffold_custom_template,
)


def _root(args: argparse.Namespace) -> Path:
    return mf.find_root(Path(args.root) if args.root else Path.cwd())


def _print(args: argparse.Namespace, payload: object, text: str, success: bool = False) -> None:
    if getattr(args, "json", False):
        print(json.dumps(payload, indent=2))
    elif success:
        first, _, rest = text.partition("\n")
        print(ui.ok(first) + ("\n" + rest if rest else ""))
    else:
        print(text)


def _after_change(root: Path) -> None:
    """Regenerate what a spec change can alter: the touched components' specs, the project's spec."""
    changed = set(mf.LAST_CHANGED)
    mf.LAST_CHANGED.clear()
    docs.generate(root, changed or None)
    _protected_branch_warning(root)


def _protected_branch_warning(root: Path) -> None:
    """A spec change on main or develop cannot be committed there (gitflow): say so now, not at the commit.
    The first commit of a repository is made on main."""
    import os
    import subprocess

    protected = os.environ.get("ARCHVOW_PROTECTED_BRANCHES", "main develop").split()
    def git(*words: str) -> str:
        done = subprocess.run(["git", "-C", str(root), *words], capture_output=True, text=True,
                              encoding="utf-8", errors="replace", check=False)
        return done.stdout.strip() if done.returncode == 0 else ""
    branch = git("symbolic-ref", "--short", "-q", "HEAD") if protected else ""
    if branch in protected and git("rev-parse", "-q", "--verify", "HEAD"):
        from archvow.branches import ticket_example

        ticket = ticket_example((mf.load(root).get("init_answers") or {}).get("ticket_pattern"), 1)
        print(ui.warn(f"You are on {branch}: this spec change cannot be committed here (gitflow). Take it to a "
                      f"branch now: git switch -c feature/{ticket}-<short-name> develop"), file=sys.stderr)


def _current_branch(root: Path) -> str:
    import subprocess

    done = subprocess.run(["git", "-C", str(root), "symbolic-ref", "--short", "-q", "HEAD"], capture_output=True,
                          text=True, encoding="utf-8", errors="replace", check=False)
    return done.stdout.strip() if done.returncode == 0 else ""


def _to_change(command: str) -> str:
    """The line under a confirmation: the command that changes what was just recorded."""
    return "\n" + ui.dim(f"  to change it: {command}")


def _source(root: Path, args: argparse.Namespace) -> dict | None:
    """--from briefs/x.md#section: where an item comes from (file, section, hash of its text)."""
    from archvow.briefs import BriefError, source

    if not getattr(args, "source", None):
        return None
    try:
        return source(root, args.source)
    except BriefError as exc:
        raise SpecError(f"--from: {exc}") from exc


# ------------------------------------------------------------------ project


def cmd_catalog(args: argparse.Namespace) -> int:
    try:
        root = _root(args)
    except mf.ManifestError:
        root = None
    loaded = [t for t in (load_template(name, root) for name in sorted(discover(root)))
              if not t.data.get("abstract")]  # a shared base is extended, never used directly
    templates = [template.summary() for template in loaded]
    if args.json:
        print(json.dumps({"templates": templates}, indent=2))
        return 0
    for template, t in zip(loaded, templates, strict=True):
        chain = f" (extends {' -> '.join(t['extends'])})" if t["extends"] else ""
        print(ui.title(f"{t['name']}@{t['version']}") + f"  [{t['language']} / {t['kind']} / {t['style']}]{chain}")
        print(f"    {t['description']}")
        print("  component types (archvow component add TYPE NAME):")
        for key, ct in t["component_types"].items():
            if ct["addable"]:
                print(f"    - {key:<15} -> {ct['layer']:<15} {ct['description']}")
        print(f"  init answers (archvow init NAME -t {t['name']} -a KEY=VALUE):")
        print(textwrap.indent(answers_help(template), "  "))
    return 0


def cmd_init(args: argparse.Namespace) -> int:
    answers = dict(item.split("=", 1) for item in args.answer or [])
    root = Path(args.dir or ".").resolve()
    keep = args.force and mf.is_project(root) and specs.spec_committed(root)
    if not keep and not args.no_input and sys.stdin.isatty() and sys.stdout.isatty():
        ui.setup_line_editing()
        answers = specs.ask_answers(load_template(args.template or DEFAULT_TEMPLATE, root), answers)
    written = specs.init_project(root, args.template, args.package, args.description, answers,
                                 src=args.src, force=args.force)
    if args.adopt:
        _adopt(root)
    docs.generate(root)
    template = mf.template_name(mf.load(root)["containers"][0])[0]
    if keep:
        print(ui.ok(f"Rewrote the generated files of {root} from template {template}")
              + ui.dim(f"  ({len(written)} files)"))
        print(ui.ok("Kept the committed spec: components, decisions, hazards and invariants are unchanged"))
        print(ui.dim(f"  to change an answer: archvow init {args.package} --force -a <question>=<answer>"))
        print(ui.warn("Review with `git diff` before committing: changed guard files need the architects' "
                      "approval (archvow check --base)"))
        _auto_approve_reminder(root)
        _register_reminder(root)
        _unseen_reminder(root)
        return 0
    print(ui.logo(f"archvow {__version__} - {template}") + "\n")
    print(ui.ok(f"archvow initialised in {root}") + ui.dim(f"  ({len(written)} files, no source folders created)"))
    results = [] if args.no_git else [specs.init_git(root)]
    results.append(specs.enable_git_hooks(root))
    for level, message in results:
        if message:
            print(ui.ok(message) if level == "ok" else ui.warn(message))
    steps = specs.next_steps(template, root, answers)
    if steps:
        print("\n" + ui.steps(steps))
    _auto_approve_reminder(root)
    _register_reminder(root)
    _unseen_reminder(root)
    print("\n" + ui.title("Next"))
    print("  1. " + ui.code('archvow component add <type> <name> -d "..."') + ui.dim("   declare what must exist"))
    print("  2. " + ui.code("archvow specify") + ui.dim("                        answer its questions, say what must never happen"))
    print(ui.dim("  The whole flow, step by step: README.md - every command and option: archvow --help"))
    print(ui.dim(f"  to change an answer: archvow init {args.package} --force -a <question>=<answer>  "
                 "(e.g. -a rules=ARCH,GDPR)"))
    return 0


def _adopt(root: Path) -> None:
    """init --adopt: propose `layer_paths` for the existing code, write it, show it."""
    from archvow import adopt

    data = mf.load(root)
    template = load_template(mf.template_name(data["containers"][0])[0], root)
    proposal, unmapped = adopt.propose(root, data, template)
    adopt.write(root, proposal, list(template.layer_names))
    print(ui.title("Adopting the existing code") + ui.dim("  - files stay where they are"))
    if proposal:
        print(ui.ok("layer_paths proposed from folder and file names - review it in .archvow/spec.vow "
                    "(the architects approve it in the merge request):"))
        width = max(len(layer) for layer in proposal)
        for layer in template.layer_names:
            for path in proposal.get(layer, []):
                print(f"  {ui.code(layer.ljust(width))}  {path}")
    else:
        print(ui.dim("  no file to map: every Python file is in a layer folder or mapped already"))
    if unmapped:
        folders: dict[str, int] = {}
        for rel in unmapped:
            folders[rel.rsplit("/", 1)[0]] = folders.get(rel.rsplit("/", 1)[0], 0) + 1
        names = [f"{rel.rsplit('/', 1)[0]}/ ({folders[rel.rsplit('/', 1)[0]]} files)"
                 if folders[rel.rsplit("/", 1)[0]] > 1 else rel for rel in unmapped]
        names = list(dict.fromkeys(names))
        shown = ", ".join(names[:12]) + (f" and {len(names) - 12} more" if len(names) > 12 else "")
        print(ui.warn(f"Not mapped (no name archvow knows): {shown} - an architect maps them in `layer_paths` "
                      "of .archvow/spec.vow, or leaves them out of the layers"))
    print(ui.dim("  then: archvow check (the code rules run on every file), archvow freeze (today's violations "
                 "are accepted, new ones fail), and one module at a time:"))
    print("  " + ui.code(f'archvow component add <type> <name> -d "..." --file {mf.load(root)["containers"][0]["path"]}/<module>.py'))


def _auto_approve_reminder(root: Path) -> None:
    """auto_approve yes: the approved assistants that keep their permissions outside the project."""
    lines = specs.auto_approve_notes(root)
    if lines:
        print(ui.warn("AI auto-approval: these assistants read their permissions outside the project; each "
                      "developer adds the safe commands once:"))
        for line in lines:
            print("  " + ui.dim(line))


def _unseen_reminder(root: Path) -> None:
    """The approved assistants archvow cannot always see: it cannot check their sandbox or YOLO mode."""
    from archvow.agent import tool_data, unseen

    data = mf.load(root)
    for tool, where in unseen(tool_data(root, data), list(data.get("ai_tools") or [])):
        print(ui.warn(f"archvow cannot see {tool} {where}: its sandbox and YOLO mode are not checked "
                      "(docs: agent security)"))


def _register_reminder(root: Path) -> None:
    """After init, with DORA on: what to record before the first commit passes (DORA003)."""
    from archvow.dora import unregistered

    names = unregistered(root, mf.load(root))
    if names:
        print(ui.warn("DORA: before the first commit, record who supplies these packages and their licence "
                      "(the third-party register, DORA003):"))
        for name in names:
            print("  " + ui.code(f'archvow dependency add {name} --supplier "..." --licence "..." '
                                 "--criticality critical|important|minor"))


def cmd_component_add(args: argparse.Namespace) -> int:
    root = _root(args)
    uses = [u.strip() for u in (args.uses or "").split(",") if u.strip()]
    entry = specs.add_component(root, args.type, args.name, args.description, spec=args.spec,
                                uses=uses, signature=args.signature, container_id=args.container,
                                group=args.group, routes=args.route, source=_source(root, args), kind=args.kind,
                                file=args.file)
    _after_change(root)
    kind = f" ({entry['kind']})" if entry.get("kind") else ""
    text = (f"Specified {entry['type']}{kind} '{entry['id']}' ({mf.source_path(mf.container(mf.load(root), args.container), entry)}).\n"
            f"Its spec: .archvow/components/{entry['id']}/spec.md\n"
            f"Next: archvow specify {entry['id']}  (everything about it: archvow show {entry['id']})"
            + _to_change(f"archvow component edit {entry['id']} -d \"...\""))
    _print(args, entry, text, success=True)
    return 0


def cmd_component_edit(args: argparse.Namespace) -> int:
    root = _root(args)
    uses = None if args.uses is None else [u.strip() for u in args.uses.split(",") if u.strip()]
    owners = None if args.owners is None else args.owners.replace(",", " ").split()
    if all(v is None for v in (args.description, args.spec, uses, args.signature, args.group, args.route,
                               args.source, owners)):
        raise SpecError("nothing to change: pass -d, -s, -u, -g, --route, --signature, --owners and/or --from")
    before = specs.find_component(mf.load(root), args.component)
    comp = specs.edit_component(root, args.component, description=args.description, spec=args.spec,
                                uses=uses, signature=args.signature, group=args.group, routes=args.route,
                                source=_source(root, args), owners=owners)
    if before[1]["module"] != comp["module"] and not args.json:  # moved to another group: move the files too
        old_file = mf.source_path(before[0], before[1])
        new_file = mf.source_path(before[0], comp)
        print(ui.warn(f"Move the files too: git mv {old_file} {new_file}; git mv {mf.test_path(before[1])} "
                      f"{mf.test_path(comp)} (and fix the imports that name the old module)"))
    _after_change(root)
    _print(args, comp, f"Updated the spec of '{comp['id']}'. Commit .archvow/ with the code that follows it."
           + _to_change(f"archvow component edit {comp['id']} -d \"...\""), success=True)
    return 0


def cmd_component_remove(args: argparse.Namespace) -> int:
    """archvow component remove <component>: with its decisions, hazards and invariants."""
    root = _root(args)
    target = args.component
    if specs.ITEM_ID.match(target):
        kind, item = specs.find_item(mf.load(root), target)
        raise SpecError(f"{target} is {_a(kind)}: archvow {kind} remove {item['id']}")
    data = mf.load(root)
    _, comp = specs.find_component(data, target)
    hazards = [h["id"] for h in mf.hazards(data) if h.get("component") == target]
    invariants = [i["id"] for i in data.get("invariants", []) or [] if i.get("component") == target]
    _confirm(args, f"remove the component {target}, its {_count(len(comp.get('decisions') or []), 'decision')}, "
                   f"{_count(len(hazards), 'hazard')} and {_count(len(invariants), 'invariant')}")
    removed = specs.remove_component(root, target)
    from archvow import proposals as ai

    ai.drop_component(root, target)
    extra = ""
    if removed["hazards"] or removed["invariants"]:
        extra = f" Also removed hazards {removed['hazards']} and invariants {removed['invariants']}."
    text = (f"Removed '{removed['component']}' from the spec.{extra} Delete its file and test too: "
            "`archvow check` reports them until you do.")
    _after_change(root)
    _print(args, removed, text, success=True)
    return 0


def _a(noun: str) -> str:
    return ("an " if noun[0] in "aeiou" else "a ") + noun


ITEM_TEXT = {"hazard": lambda h: f"{h['id']} ({h['severity']}, {h.get('component') or 'system'}): "
                                 f"{h.get('description')}",
             "invariant": lambda i: f"{i['id']} ({i.get('component') or 'system'}): {i.get('statement')}"
                                    + (f" - prevents {', '.join(i['mitigates'])}" if i.get("mitigates") else ""),
             "rule": lambda r: f"{r['id']} ({specs.rule_scope(r)}): {r.get('text')}"}


def _remove_item(args: argparse.Namespace, expected: str) -> int:
    """archvow hazard|invariant|rule remove <id>: says what goes, asks, removes."""
    root = _root(args)
    data = mf.load(root)
    wanted = mf.normalise_item_id([args.id, *([args.more] if getattr(args, "more", None) else [])])
    if not specs.ITEM_ID.match(wanted):
        example = {"hazard": "clean_orders H1", "invariant": "clean_orders INV1", "rule": "R1"}[expected]
        raise SpecError(f"usage: archvow {expected} remove {example} (its id, as archvow show prints it)")
    kind, item = specs.find_item(data, wanted)
    if kind != expected:
        raise SpecError(f"{item['id']} is {_a(kind)}: archvow {kind} remove {item['id']}")
    if kind == "invariant":
        specs.check_invariant_removable(data, item)  # refused before asking anything
    what = ITEM_TEXT[kind](item)
    _confirm(args, f"remove {kind} {what}")
    removed = {"hazard": specs.remove_hazard, "invariant": specs.remove_invariant,
               "rule": specs.remove_rule}[kind](root, item["id"])
    text = f"Removed {what}"
    if kind == "hazard" and removed.get("unlinked"):
        text += (f"\n  {', '.join(removed['unlinked'])} no longer "
                 f"{'points' if len(removed['unlinked']) == 1 else 'point'} to it")
    _after_change(root)
    _print(args, removed, text, success=True)
    return 0


def cmd_hazard_remove(args: argparse.Namespace) -> int:
    """archvow hazard remove <component> H1 | <component> S<n> (undo a "not applicable")."""
    if args.question is None or re.fullmatch(r"(?i)(H|INV)\d+", args.question):
        args.more = args.question
        return _remove_item(args, "hazard")
    if not re.fullmatch(r"[Ss]\d+", args.question):
        raise SpecError(f"usage: archvow hazard remove {args.id} S<n> (a safety question marked not applicable)")
    root = _root(args)
    component, which = args.id, args.question.upper()
    entry = next((d for d in mf.load(root).get("dismissed") or [] if d.get("component") == component), None)
    _confirm(args, f"reopen safety question {which} of {component}"
                   + (f" (not applicable: \"{entry.get('rationale')}\")" if entry else ""))
    removed = specs.reopen_safety_question(root, component, which)
    _after_change(root)
    _print(args, removed, f"Safety question {which} of {component} is open again: archvow show {component}",
           success=True)
    return 0


def cmd_invariant_remove(args: argparse.Namespace) -> int:
    return _remove_item(args, "invariant")


def cmd_rule_remove(args: argparse.Namespace) -> int:
    return _remove_item(args, "rule")


def cmd_question_remove(args: argparse.Namespace) -> int:
    """archvow question remove <component> <n>: a question a person added, with its answer if any."""
    root = _root(args)
    _, comp = specs.find_component(mf.load(root), args.component)
    decisions = comp.get("decisions", []) or []
    question = decisions[args.number - 1]["question"] if 1 <= args.number <= len(decisions) else "?"
    _confirm(args, f"remove question {args.number} of {args.component}: {question}")
    removed = specs.remove_question(root, args.component, args.number)
    from archvow import proposals as ai

    ai.renumber(root, args.component, args.number)
    _after_change(root)
    _print(args, removed, f"Removed question {args.number} of {args.component}: {removed['question']}",
           success=True)
    return 0


def _confirm(args: argparse.Namespace, what: str) -> None:
    """Every removal says exactly what goes; a person confirms it (or passes --yes in a script)."""
    if args.yes:
        return
    if not (sys.stdin.isatty() and sys.stdout.isatty()):
        raise SpecError(f"{what}: no terminal to confirm it - add --yes")
    if input(f"{what}? [y/N] ").strip().lower() not in ("y", "yes", "o", "oui"):
        raise SpecError("nothing removed")


# ------------------------------------------------------------------ decisions and assumptions


def cmd_decision_make(args: argparse.Namespace) -> int:
    """archvow decision make <component> <n>[,<n>...] ["answer"]: answer questions by number (or P1, O2...)."""
    from archvow import questions

    root = _root(args)
    if args.type or args.unset:
        return _decision_for_type(args, root)
    if args.question is None:
        raise SpecError(f"give the question's number: archvow decision make {args.component} <number> [\"...\"] "
                        f"(archvow show {args.component} lists them)")
    numbers = args.question.replace(" ", "").split(",")
    if not all(n.isdigit() or questions.is_key(n) for n in numbers):
        raise SpecError(f"'{args.question}' is not a question number (archvow show {args.component} lists them); "
                        f"a new question with its answer: archvow decision add {args.component} \"<question>\" "
                        "\"<answer>\"")
    if all(questions.is_key(n) for n in numbers):  # P1, O2, C1: personal data, operations, company
        if args.answer is None:
            raise SpecError(f"give the answer: archvow decision make {args.component} {args.question} \"...\"")
        answered = [questions.answer(root, args.component, n, args.answer) for n in numbers]
        _after_change(root)
        text = "\n".join(f"Decision made ({q['key']}): {q['question']}\n  -> {q['answer']}"
                         + _to_change(f"archvow decision make {args.component} {q['key']} \"...\"") for q in answered)
        _print(args, answered[0] if len(answered) == 1 else answered, text, success=True)
        return 0
    if args.answer is None:  # no text: the template's suggestion, question by question
        data = mf.load(root)
        decisions = []
        for n in numbers:
            suggested = specs.suggested_answer(root, data, args.component, int(n)) if n.isdigit() else None
            if suggested is None:
                raise SpecError(f"question {n} of {args.component} has no suggested answer: give yours "
                                f"(archvow decision make {args.component} {n} \"...\")")
            decisions.append(specs.decide(root, args.component, int(n), suggested))
    else:  # one answer, or the same answer to several questions
        decisions = [specs.decide(root, args.component, int(n), args.answer) for n in numbers]
    from archvow import proposals as ai

    for n in numbers:  # a person's answer replaces what the AI proposed
        ai.take(root, args.component, int(n))
    _after_change(root)
    origin = "suggested" if args.answer is None else "your own"
    text = "\n".join(f"Decision made ({origin}): {d['question']}\n  -> {d['answer']}"
                     + _to_change(f"archvow decision make {args.component} {n} \"...\"")
                     for n, d in zip(numbers, decisions))
    _print(args, decisions[0] if len(decisions) == 1 else decisions, text, success=True)
    return 0


def _decision_for_type(args: argparse.Namespace, root: Path) -> int:
    """archvow decision make --type <type> <n> ["answer"] | --unset: one answer for every component of a type.
    The positionals shift: what argparse read as the component is the number, as the number the answer."""
    if not args.type:
        raise SpecError("--unset goes with --type: archvow decision make --type <type> <number> --unset")
    number, answer = args.component, args.question
    if args.answer is not None or not str(number).isdigit():
        raise SpecError(f"archvow decision make --type {args.type} <number> [\"<answer>\"] - one question at a time, "
                        "by its number in archvow show of a component of that type")
    if args.unset:
        if answer is not None:
            raise SpecError("--unset takes no answer")
        done = specs.unset_for_type(root, args.type, int(number))
        _after_change(root)
        text = (f"Question {number} of every {args.type} is no longer answered for the whole type: "
                f"{done['question']}\n  each one answers it on its own: "
                + (", ".join(done["components"]) or "no component of that type yet")
                + _to_change(f"archvow decision make --type {args.type} {number} \"...\""))
        _print(args, done, text, success=True)
        return 0
    entry = specs.decide_for_type(root, args.type, int(number), answer)
    _after_change(root)
    origin = "suggested" if answer is None else "your own"
    lines = [f"Decision made for every {args.type} ({origin}): {entry['question']}", f"  -> {entry['answer']}",
             "  takes it: " + (", ".join(entry["components"]) or "no component of that type yet")
             + f" - and every {args.type} added later"]
    if entry["own"]:
        lines.append("  keeps its own answer: " + ", ".join(entry["own"]))
    text = "\n".join(lines) + _to_change(f"archvow decision make --type {args.type} {number} \"...\" (or --unset)")
    _print(args, entry, text, success=True)
    return 0


def cmd_decision_propose(args: argparse.Namespace) -> int:
    """archvow decision propose <c> <n> "answer": the AI's answer, for a person to review (mode guided/free)."""
    from archvow.proposals import ProposalError, propose

    root = _root(args)
    if not args.question.isdigit():
        raise SpecError("decision propose answers a question by its number (archvow show lists them)")
    try:
        entry = propose(root, args.component, int(args.question), args.answer)
    except ProposalError as exc:
        raise SpecError(str(exc)) from exc
    _after_change(root)
    _print(args, entry, f"Proposed (by the AI, not reviewed yet): {entry['question']}\n  -> {entry['answer']}\n"
                        f"A person reviews it: archvow decision accept {args.component} {args.question}"
                        + _to_change(f"archvow decision make {args.component} {args.question} \"...\""), success=True)
    return 0


def cmd_decision_accept(args: argparse.Namespace) -> int:
    """archvow decision accept <c> <n>: a person accepts what the AI proposed; it joins the component's vow."""
    from archvow.proposals import ProposalError, accept

    root = _root(args)
    try:
        decision = accept(root, args.component, args.number)
    except ProposalError as exc:
        raise SpecError(str(exc)) from exc
    _after_change(root)
    _print(args, decision, f"Decision made (proposed by the AI, accepted): {decision['question']}\n"
                           f"  -> {decision['answer']}"
                           + _to_change(f"archvow decision make {args.component} {args.number} \"...\""), success=True)
    return 0


def cmd_decision_add(args: argparse.Namespace) -> int:
    """archvow decision add <component> "question" "answer": a question the template does not ask, decided."""
    from archvow import questions

    root = _root(args)
    numbers = args.question.replace(" ", "").split(",")
    if all(n.isdigit() or questions.is_key(n) for n in numbers):
        raise SpecError(f"question {args.question} exists: archvow decision make {args.component} {args.question} "
                        "\"<answer>\"")
    decision = specs.decide(root, args.component, args.question, args.answer, source=_source(root, args))
    number = len(specs.find_component(mf.load(root), args.component)[1]["decisions"])
    _after_change(root)
    _print(args, decision, f"Decision made (your own): {decision['question']}\n  -> {decision['answer']}"
           + _to_change(f"archvow decision make {args.component} {number} \"...\""), success=True)
    return 0


def cmd_column_set(args: argparse.Namespace) -> int:
    """archvow column set <component> <names> personal|special|none, or --removes / --pseudonymises."""
    from archvow.privacy import classify

    root = _root(args)
    result = classify(root, args.component, args.names.split(","), args.kind, removes=args.removes,
                      pseudonymises=args.pseudonymises)
    _after_change(root)
    if "columns" in result:
        text = "\n".join(f"{args.component}.{n}: {k}" for n, k in result["columns"].items()) + _to_change(
            f"archvow column set {args.component} {','.join(result['columns'])} personal|special|none")
    else:
        key = "removes" if args.removes else "pseudonymises"
        text = f"{args.component} {key} {', '.join(result[key])} before the data is written"
    _print(args, result, text, success=True)
    return 0


def cmd_dependency_add(args: argparse.Namespace) -> int:
    from archvow.dora import add_dependency

    root = _root(args)
    entry = add_dependency(root, args.name, args.supplier, args.licence, args.criticality)
    _after_change(root)
    _print(args, entry, f"Registered {entry['name']}: {entry['supplier']}, {entry['licence']}, "
                        f"{entry['criticality']}"
           + _to_change(f"archvow dependency remove {entry['name']}, then dependency add again"), success=True)
    return 0


def cmd_dependency_remove(args: argparse.Namespace) -> int:
    from archvow.dora import remove_dependency

    root = _root(args)
    entry = remove_dependency(root, args.name)
    _after_change(root)
    _print(args, entry, f"Removed {entry['name']} from the register", success=True)
    return 0


def cmd_example_add(args: argparse.Namespace) -> int:
    """archvow example add <component> <example> [-s <ticket>]: record (or accept again) a business example."""
    from archvow import examples

    root = _root(args)
    entry = examples.add(root, args.component, args.name, args.spec)
    _after_change(root)
    verb = "Accepted the new files of" if entry["replaced"] else "Recorded"
    test = f'@pytest.mark.example("{entry["name"]}")' + (" and @pytest.mark.integration"
                                                          if entry["level"] == "integration" else "")
    _print(args, entry, f"{verb} example {entry['name']} of {args.component} ({entry['folder']}/, "
                        f"fingerprint {entry['fingerprint']})\n"
                        + ui.dim(f"  its test reads input/, compares with expected/, and is marked {test}")
           + _to_change(f"replace its files, then archvow example add {args.component} {entry['name']} again"),
           success=True)
    return 0


def cmd_example_remove(args: argparse.Namespace) -> int:
    from archvow import examples

    root = _root(args)
    _confirm(args, f"remove example {args.name} of {args.component} from the spec (its files stay)")
    entry = examples.remove(root, args.component, args.name)
    _after_change(root)
    _print(args, entry, f"Removed example {entry['name']} of {args.component} from the spec; its files stay in "
                        f"{entry['folder']}/ (delete them, or add the example again)", success=True)
    return 0


def cmd_changes(args: argparse.Namespace) -> int:
    from archvow.changes import changes_report, render_changes, to_json

    root = _root(args)
    try:
        rows = changes_report(root, args.start, args.end)
    except GitError as exc:
        raise SpecError(str(exc)) from exc
    print(to_json(rows) if args.json else render_changes(rows, args.start, args.end, args.markdown), end="")
    return 0


def cmd_rule_add(args: argparse.Namespace) -> int:
    """archvow rule add <components> "text" | --type T "text" | --all "text"."""
    root = _root(args)
    words = args.words
    if args.type or args.all:
        if len(words) != 1:
            raise SpecError('with --type or --all, give only the rule: archvow rule add --all "..."')
        rule = specs.add_rule(root, words[0], type_name=args.type, all_components=args.all,
                              source=_source(root, args))
    else:
        if len(words) != 2:
            raise SpecError('usage: archvow rule add <component>[,<component>...] "the rule" '
                            '(or --type <type> / --all)')
        components = [c.strip() for c in words[0].split(",") if c.strip()]
        rule = specs.add_rule(root, words[1], components=components, source=_source(root, args))
    _after_change(root)
    _print(args, rule, f"Recorded {rule['id']} ({specs.rule_scope(rule)}): {rule['text']}\n"
                       "Each component it applies to implements it, with a test."
           + _to_change(f"archvow rule edit {rule['id']} \"...\""), success=True)
    return 0


def cmd_rule_edit(args: argparse.Namespace) -> int:
    root = _root(args)
    rule = specs.edit_rule(root, args.id, args.text)
    _after_change(root)
    _print(args, rule, f"Changed {rule['id']} ({specs.rule_scope(rule)}): {rule['text']}"
           + _to_change(f"archvow rule edit {rule['id']} \"...\""), success=True)
    return 0


def cmd_brief_accept(args: argparse.Namespace) -> int:
    """archvow brief accept <file>[#section]: the brief changed, the items drawn from it were reviewed."""
    from archvow.briefs import BriefError, accept

    root = _root(args)
    try:
        stamped = accept(root, args.brief)
    except BriefError as exc:
        raise SpecError(str(exc)) from exc
    _after_change(root)
    _print(args, {"brief": args.brief, "items": stamped},
           f"Recorded the current text of {args.brief} for {', '.join(stamped)}", success=True)
    return 0


def cmd_question_add(args: argparse.Namespace) -> int:
    root = _root(args)
    entry = specs.ask(root, args.component, args.question, source=_source(root, args))
    number = len(specs.find_component(mf.load(root), args.component)[1]["decisions"])
    _after_change(root)
    _print(args, entry, f"Open question {number} recorded for {args.component}: {entry['question']}\n"
                        f"A person answers it: archvow decision make {args.component} {number} \"...\""
           + _to_change(f"archvow question remove {args.component} {number}, then question add again"),
           success=True)
    return 0


def cmd_assumption_add(args: argparse.Namespace) -> int:
    root = _root(args)
    entry = specs.assume(root, args.component, args.text)
    _after_change(root)
    _print(args, entry, f"Assumption recorded as proposed; CI blocks {args.component} until a person "
           f"accepts it (archvow assumption accept {args.component} <n>, or reject).", success=True)
    return 0


def cmd_assumption_review(args: argparse.Namespace, status: str) -> int:
    root = _root(args)
    entry = specs.review_assumption(root, args.component, args.number, status)
    _after_change(root)
    other = "reject" if status == "accepted" else "accept"
    _print(args, entry, f"Assumption {status}: {entry['text']}"
           + _to_change(f"archvow assumption {other} {args.component} {args.number}"), success=True)
    return 0


# ------------------------------------------------------------------ safety analysis


SEVERITY_HELP = """\
severities - how bad it would be:
  critical  data lost, or wrong results that cannot be undone (needs a property test or stronger)
  high      wrong results reach users (needs an invariant with a test)
  medium    a delay or a re-run, no wrong data
  low       noticed and fixed without harm"""


def safety_worksheet(root: Path, only: str | None = None) -> list[dict]:
    """Every safety question of every component (or of one), numbered, with its answer if any:
    the hazards (and the invariants that prevent them) or the dismissal; open ones carry the
    template's suggestion."""
    data = mf.load(root)
    if only:
        specs.find_component(data, only)
    hazards: dict[tuple, list[dict]] = {}
    for h in mf.hazards(data):
        hazards.setdefault((h.get("component"), h.get("guide_word")), []).append(h)
    dismissed = {(d.get("component"), d.get("guide_word")): d for d in mf.dismissals(data)}
    prevented: dict[str, list[dict]] = {}
    for inv in data.get("invariants", []) or []:
        for hid in inv.get("mitigates", []) or []:
            prevented.setdefault(hid, []).append({k: inv.get(k) for k in ("id", "statement", "verify")})
    sheet = []
    for container in data["containers"]:
        template = load_template(mf.template_name(container)[0], root)
        words = template.data.get("guide_words", {}) or {}
        for comp in container.get("components", []):
            if only and comp["id"] != only:
                continue
            questions = []
            for number, word in enumerate(specs.safety_questions(template, comp), 1):
                key = (comp["id"], word)
                item = {"number": number, "guide_word": word, "question": words.get(word, word),
                        "status": "answered" if key in hazards or key in dismissed else "open"}
                suggestion = specs.safety_suggestion(template, data, comp, word)
                if key in hazards:  # the template's words, or the team's own (compared, nothing stored)
                    item["hazards"] = [{**{k: h.get(k) for k in ("id", "severity", "description")},
                                        "suggested": h.get("description") == suggestion.get("hazard"),
                                        "prevented_by": prevented.get(h["id"], [])} for h in hazards[key]]
                elif key in dismissed:
                    item["dismissed"] = dismissed[key].get("rationale", "")
                else:
                    item["suggestion"] = suggestion
                questions.append(item)
            if questions:
                sheet.append({"component": comp["id"], "type": comp["type"], "questions": questions})
    return sheet


def _print_question(q: dict) -> None:
    print(f" S{q['number']:<2} {ui.mark('done' if q['status'] == 'answered' else 'open')} {q['question']}")
    for h in q.get("hazards", []):
        origin = "suggested" if h.get("suggested") else "your own"
        print(ui.dim(f"       {h['id']} {h['severity']} ({origin}): {h['description']}"))
        for inv in h["prevented_by"]:
            tested = "" if "tested" not in inv else " - tested" if inv["tested"] else " - not tested yet"
            print(ui.dim(f"       <- prevented by {inv['id']}: {inv['statement']}{tested}"))
        if not h["prevented_by"] and h["severity"] in ("critical", "high"):
            print(ui.dim("       <- prevented by nothing yet"))
    if "dismissed" in q:
        print(ui.dim(f"       not applicable: {q['dismissed']}"))
    suggestion = q.get("suggestion") or {}
    if suggestion.get("decision"):
        d = suggestion["decision"]
        print(ui.dim(f"       already made in decision {d['number']}: {d['answer']}"))
    if suggestion.get("hazard"):
        print(ui.dim(f"       suggested hazard: {suggestion['hazard']}"))
    if suggestion.get("invariant"):
        print(ui.dim(f"       suggested invariant: {suggestion['invariant']}"))


def _component_view(root: Path, data: dict, cid: str, report: Report, flows: dict | None = None) -> dict:
    """Everything about one component: decisions, rules, columns and personal data,
    P/O/C questions, safety, assumptions, status."""
    from archvow.privacy import code_columns, personal_flow
    from archvow.questions import component_questions, templates_of

    container, comp = specs.find_component(data, cid)
    flows = personal_flow(root, data) if flows is None else flows
    template = templates_of(root, data).get(container["id"])
    ctype = template.type_of(comp) if template else {}
    classified = comp.get("columns") or {}
    in_code = [n for n, _ in code_columns(root / mf.source_path(container, comp), ctype["columns"])] \
        if ctype.get("columns") else []
    columns = [{"name": n, "class": classified.get(n), "in_code": n in in_code}
               for n in [*classified, *[c for c in in_code if c not in classified]]]
    status = next((c for c in report.components if c.component == cid), None)
    suggested = template.suggested_answers(comp) if template else {}
    from archvow.check import missing_contracts

    by_id = {c["id"]: c for c in container.get("components", [])}
    missing = missing_contracts(comp, ctype, by_id)
    from archvow import proposals as ai

    proposed = ai.by_question(root)
    decisions = [{"number": n, "question": d["question"], "answer": d.get("answer") or None,
                  "suggested": suggested.get(d["question"]),
                  **({"by": d.get("by"), "on": str(d.get("on"))[:10]} if d.get("answer") and d.get("by") else {}),
                  "proposed": None if d.get("answer") else (proposed.get((cid, n)) or {}).get("answer"),
                  **({"origin": d["origin"]} if d.get("origin") else {})}
                 for n, d in enumerate(comp.get("decisions", []) or [], 1)]
    rules = [{"id": r["id"], "text": r["text"], "scope": specs.rule_scope(r)} for r in specs.rules_for(data, comp)]
    tested = {i["id"]: i.get("verified") for i in report.invariants}
    sheet = safety_worksheet(root, cid)
    safety = sheet[0]["questions"] if sheet else []
    for q in safety:
        for h in q.get("hazards", []):
            for inv in h["prevented_by"]:
                inv["tested"] = bool(tested.get(inv["id"]))
    questions = component_questions(root, data, comp, template, flows) if template else []
    from archvow.tasks import summary, tasks_for

    tasks = tasks_for(root, data, comp, template, report, questions) if template else []
    from archvow.runline import run_lines

    run = next((r for r in run_lines(data, templates_of(root, data), report) if r["component"] == cid), None)
    from archvow.privacy import known_columns

    known = [{"component": c, "columns": names} for c, names in known_columns(root, container, comp, template)]
    from archvow import locate

    return {"component": cid, "type": comp["type"], **({"kind": comp["kind"]} if comp.get("kind") else {}),
            "layer": comp.get("layer"), "known_columns": known,
            "description": comp.get("description", ""), **({"owners": comp["owners"]} if comp.get("owners") else {}),
            **({"source": comp["source"]} if comp.get("source") else {}),
            "uses": list(comp.get("uses") or []), "used_by": locate.used_by(data, cid),
            "evidence": locate.evidence(root, data, comp), "examples": _examples_view(root, comp, template),
            "status": status.status if status else "planned", "decisions": decisions, "rules": rules,
            "missing": missing,
            "columns": columns, "declares_columns": bool(ctype.get("columns")), "personal": flows.get(cid, {}),
            "questions": questions,
            "safety": safety, "assumptions": [{"number": n, **a} for n, a in enumerate(comp.get("assumptions", []) or [], 1)],
            "tasks": [{**t.as_dict(), "summary": summary(t)} for t in tasks], **({"run": run} if run else {})}


def _examples_view(root: Path, comp: dict, template) -> list[dict]:
    from archvow import examples

    return examples.view(root, comp, template, examples.marked(root)) if comp.get("examples") else []


def _count(number: int, noun: str) -> str:
    """'1 decision', '3 decisions', '0 other items'."""
    return f"{number} {noun}" + ("" if number == 1 else "s")


def _open_counts(view: dict) -> tuple[int, int, int]:
    """Decisions to make, open safety questions, other open items (P/O/C, columns)."""
    others = sum(1 for q in view["questions"] if not q["answer"]) + sum(1 for c in view["columns"] if not c["class"])
    return (sum(1 for d in view["decisions"] if not d["answer"] and not d.get("proposed")),
            sum(1 for q in view["safety"] if q["status"] == "open"), others)


def cmd_show(args: argparse.Namespace) -> int:
    root = _root(args)
    data = mf.load(root)
    if args.json and not args.component:
        print(json.dumps(data, indent=2))
        return 0
    if not args.component:
        print("archvow show <component> shows one component (archvow show <component> H1: one of its hazards)\n"
              + ui.dim("The whole project, in build order: archvow next - on one page: .archvow/spec.md"))
        return 0
    from archvow import locate

    if locate.is_path(args.component, root):
        return _show_file(args, root, data)
    wanted = mf.normalise_item_id([args.component, *([args.item] if args.item else [])])
    if args.item and not specs.ITEM_ID.match(wanted):
        raise SpecError(f"usage: archvow show {args.component} H1 (or INV1): one of its hazards or invariants")
    report = run_check(root)
    if specs.ITEM_ID.match(wanted):
        item = _item_view(root, data, wanted, report)
        if args.json:
            print(json.dumps(item, indent=2))
        else:
            _print_item(item)
        return 0
    view = _component_view(root, data, args.component, report)
    if args.json:
        print(json.dumps(view, indent=2))
        return 0
    _print_component(view)
    return 0


def _show_file(args: argparse.Namespace, root: Path, data: dict) -> int:
    """`archvow show <file>[:<line>]`: the component that owns a file, read from the defect's side."""
    from archvow import locate

    if args.item:
        raise SpecError(f"usage: archvow show {args.component} (a file, or file:line) - no second word")
    rel, line = locate.resolve(root, args.component)
    cid, role = locate.owner(root, data, rel)
    if cid is None:
        message = locate.not_in_a_component(rel, data)
        if args.json:
            print(json.dumps({"file": rel, "line": line, "component": None, "hint": message}, indent=2))
        else:
            print(ui.warn(message))
        return 0
    view = {"file": rel, "role": role, **({"line": line} if line else {}),
            **_component_view(root, data, cid, run_check(root))}
    if line:
        symbol = locate.enclosing(root / rel, line)
        if symbol:
            symbol["called_by"] = locate.callers(root, symbol["name"]) if role == "code" else []
        view["symbol"] = symbol
    if args.json:
        print(json.dumps(view, indent=2))
        return 0
    _print_file_header(view)
    _print_component(view)
    return 0


def _print_file_header(view: dict) -> None:
    where = f"{view['file']}:{view['line']}" if view.get("line") else view["file"]
    role = "the test file of" if view["role"] == "test" else "code of"
    print(ui.code(where) + f" - {role} {view['component']}")
    symbol = view.get("symbol")
    if symbol:
        what = f"{symbol['kind']} {symbol['name']}" + ("" if symbol["public"] else " (a helper)")
        print(ui.dim(f"  inside {what}, line {symbol['line']}"))
        if view["role"] == "code":
            callers = symbol["called_by"]
            print(ui.dim(f"  tests calling {symbol['name']} by name: {', '.join(callers)}" if callers else
                         f"  no test calls {symbol['name']} by name (found by name only: through another "
                         "function it is not seen)"))
    elif view.get("line"):
        print(ui.dim("  outside any function or class (module level)"))
    print()


def _item_view(root: Path, data: dict, item_id: str, report: Report) -> dict:
    """One hazard, invariant or rule, with what it is linked to."""
    kind, item = specs.find_item(data, item_id)
    view = {"kind": kind, **item}
    tested = {i["id"]: i.get("verified") for i in report.invariants}
    if kind == "hazard":
        view["prevented_by"] = [{"id": i["id"], "statement": i.get("statement"), "tested": bool(tested.get(i["id"]))}
                                for i in data.get("invariants", []) or [] if item["id"] in (i.get("mitigates") or [])]
    elif kind == "invariant":
        by_id = {h["id"]: h for h in data.get("hazards", []) or []}
        view["prevents"] = [{"id": h, "severity": by_id[h].get("severity"), "description": by_id[h].get("description")}
                            for h in item.get("mitigates") or [] if h in by_id]
        view["tested"] = bool(tested.get(item["id"]))
    else:
        view["applies_to"] = [c["id"] for container in data["containers"] for c in container.get("components", [])
                              if specs.rule_applies(item, c)]
    return view


def _print_item(view: dict) -> None:
    who = ui.dim(f"recorded by {view.get('by', '?')} on {str(view.get('on', '?'))[:10]}")
    if view["kind"] == "hazard":
        print(ui.title(f"{view['id']} {view['severity']}") + f" ({view.get('component') or 'system'}, "
              f"{view.get('guide_word')}): {view.get('description')}")
        for inv in view["prevented_by"]:
            print(ui.dim(f"  <- prevented by {inv['id']}: {inv['statement']}"
                         + (" - tested" if inv["tested"] else " - not tested yet")))
        if not view["prevented_by"]:
            print(ui.dim("  <- prevented by nothing yet"))
    elif view["kind"] == "invariant":
        print(ui.title(view["id"]) + f" ({view.get('component') or 'system'}): {view.get('statement')}")
        for h in view["prevents"]:
            print(ui.dim(f"  prevents {h['id']} ({h['severity']}): {h['description']}"))
        print(ui.dim(f"  tested: {'yes' if view['tested'] else 'not yet'} ({view.get('verify', '?')})"))
    else:
        print(ui.title(view["id"]) + f" ({specs.rule_scope(view)}): {view.get('text')}")
        print(ui.dim(f"  applies to: {', '.join(view['applies_to']) or 'no component yet'}"))
    print("  " + who)


def _print_component(view: dict) -> None:
    cid = view["component"]
    to_make, safety, others = _open_counts(view)
    kind = f", {view['kind']}" if view.get("kind") else ""
    print(ui.title(f"{cid} ({view['type']}{kind})") + f" - {view['description']}")
    owned = f" - owners: {' '.join(view['owners'])} (and the architects)" if view.get("owners") else ""
    print(ui.dim(f"status: {view['status']} - open: {_count(to_make, 'decision')} to make, "
                 f"{_count(safety, 'safety question')}, {_count(others, 'other item')}{owned}"))
    if view.get("source"):
        print(ui.dim(f"drawn from: {view['source'].get('file', '')}"
                     + (f"#{view['source']['section']}" if view["source"].get("section") else "")))
    links = [f"uses {', '.join(view['uses'])}" if view.get("uses") else "",
             f"used by {', '.join(view['used_by'])}" if view.get("used_by") else ""]
    if any(links):
        print(ui.dim(" - ".join(x for x in links if x)))
    print()
    from archvow.privacy import columns_line

    known = columns_line([(k["component"], k["columns"]) for k in view.get("known_columns", [])], cid)
    if known:  # the names its questions are about
        print(ui.dim(known + "\n"))
    for needed in view.get("missing", []):
        print(ui.warn(f"uses no {needed}: archvow component add {needed} <name> -d \"...\", then archvow component edit {cid} -u <name>_{needed}"))
    print(ui.title("Decisions") + ui.dim(f" - {len(view['decisions']) - to_make} of {len(view['decisions'])} "
                                          f"made  -> archvow decision make {cid} <n> [\"answer\"]"))
    for d in view["decisions"]:
        print(f" {d['number']:>3}. {ui.mark('done' if d['answer'] else 'open')} {d['question']}")
        if d["answer"]:
            origin = "" if not d["suggested"] else " (suggested)" if d["answer"] == d["suggested"] else " (your own)"
            origin = " (proposed by the AI, accepted)" if d.get("origin") == "ai" else origin
            if d.get("origin") == mf.TYPE_ORIGIN:
                origin = f" (project answer, every {view['type']})"
            who = f"  - {d['by']}, {d['on']}" if view.get("file") and d.get("by") else ""
            print(ui.dim(f"        ->{origin} {d['answer']}{who}"))
        elif d.get("proposed"):
            print(ui.warn(f"        proposed by the AI, not reviewed: {d['proposed']}") +
                  ui.dim(f"  -> archvow decision accept {cid} {d['number']}"))
        elif d["suggested"]:
            print(ui.dim(f"        suggested: {d['suggested']}"))
    if view["rules"]:
        print("\n" + ui.title("Rules") + ui.dim(f"  -> archvow rule add {cid} \"...\" | rule edit R<n> \"...\" | "
                                              "rule remove R<n>"))
        for r in view["rules"]:
            scope = "" if r["scope"] == cid else ui.dim(f"  ({r['scope']})")
            print(f"  {r['id']:>3}. {r['text']}{scope}")
    _print_examples(view)
    if view.get("file"):
        _print_evidence(view)
    _print_personal(view)
    sets: dict[str, list] = {}
    for q in view["questions"]:
        sets.setdefault(q["title"], []).append(q)
    for title, questions in sets.items():
        done = sum(1 for q in questions if q["answer"])
        print("\n" + ui.title(title) + ui.dim(f" - {done} of {len(questions)} answered  -> archvow decision make "
                                             f"{cid} {questions[0]['set']}<n> \"...\""))
        for q in questions:
            print(f" {q['key']:<4} {ui.mark('done' if q['answer'] else 'open')} {q['question']}")
            if q["answer"]:
                print(ui.dim(f"        -> {q['answer']}"))
    if view["safety"]:
        print("\n" + ui.title("Safety") + ui.dim(f" - {len(view['safety']) - safety} of {len(view['safety'])} "
                                                f"answered  -> archvow hazard add {cid} S<n> {'|'.join(specs.SEVERITIES)} "
                                                '["what must never happen"]'))
        for q in view["safety"]:
            _print_question(q)
    pending = [a for a in view["assumptions"] if a.get("status") != "accepted"]
    if view["assumptions"]:
        print("\n" + ui.title("Assumptions made while coding"))
        for a in view["assumptions"]:
            print(f" {a['number']:>3}. {ui.mark('done' if a.get('status') == 'accepted' else 'open')} "
                  f"[{a.get('status', 'proposed')}] {a['text']}")
        if pending:
            print(ui.dim(f"  -> a person runs archvow assumption accept {cid} <n> (or reject)"))
    tasks = view.get("tasks") or []
    if tasks:
        done = sum(1 for t in tasks if t["done"])
        print("\n" + ui.title("Tasks") + ui.dim(f" - {done} of {len(tasks)} done  -> archvow prompt {cid} "
                                               "(the next one), or --task <n>"))
        for t in tasks:
            print(f"  {t['task']:>3} {ui.mark('done' if t['done'] else 'open')} {t['summary']}")
        if len(tasks) > 3:
            print(ui.dim("  more than 3 tasks: splitting the component may be clearer (archvow component add ...)"))
    print()
    left = next((t["task"] for t in tasks if not t["done"]), None)
    if to_make or safety or others:
        print(ui.code(f"Next: archvow specify {cid}"))
    elif tasks and left is None:
        print(ui.code(f"Done: every task of {cid} is built and tested"))
    else:
        what = f"task {left} - " if left else ""
        print(ui.code(f"Next: implement {what}archvow prompt {cid} (or tell the AI: implement {cid})"))
    if view.get("run"):  # an entry point: how to try it on a laptop, or what it still needs
        print(ui.ok(view["run"]["line"]) if view["run"]["ready"] else ui.warn(view["run"]["line"]))


def _print_examples(view: dict) -> None:
    """The business examples: input -> expected, locked by their fingerprint, each with its marked test."""
    rows = view.get("examples") or []
    if not rows:
        return
    cid = view["component"]
    tested = sum(1 for e in rows if e["tested"])
    print("\n" + ui.title("Examples") + ui.dim(f" - {tested} of {len(rows)} with a marked test  -> archvow example "
                                               f"add {cid} <example> | example remove {cid} <example>"))
    for e in rows:
        ticket = f" ({e['ticket']})" if e.get("ticket") else ""
        state = "" if e["unchanged"] else ui.warn("  files changed since recorded (ARCH055)")
        print(f"  {ui.mark('done' if e['tested'] and e['unchanged'] else 'open')} {e['name']}{ticket}  "
              + ui.dim(f"{e['folder']}/ - {e['level']}, by {e.get('by') or '?'}, {e.get('on')}") + state)


def _print_evidence(view: dict) -> None:
    """With show <file>: the test that is the evidence of each decision, rule and invariant."""
    rows = view.get("evidence") or []
    if not rows:
        return
    untested = [r["item"] for r in rows if not r["tests"]]
    print("\n" + ui.title("Evidence") + ui.dim(f" - {len(rows) - len(untested)} of {len(rows)} with a marked test"))
    for r in rows:
        if r["tests"]:
            print(f"  {r['item']:<22} " + ui.dim(", ".join(r["tests"])))
    if untested:
        print(ui.dim(f"  no marked test yet: {', '.join(untested)}"))


def _print_personal(view: dict) -> None:
    """Columns of a schema/model (classified or not), and the personal columns a component handles."""
    cid = view["component"]
    if view["declares_columns"]:
        unclassified = [c for c in view["columns"] if not c["class"]]
        print("\n" + ui.title("Columns") + ui.dim(f" - {len(view['columns']) - len(unclassified)} of "
                                                 f"{len(view['columns'])} classified  -> archvow column set {cid} "
                                                 "<name,...> personal|special|none"))
        for c in view["columns"]:
            where = "" if c["in_code"] or view["status"] == "planned" else ui.dim("  (not in the code)")
            print(f"  {ui.mark('done' if c['class'] else 'open')} {c['name']:<24} {c['class'] or 'not classified'}{where}")
        if not view["columns"]:
            print(ui.dim("  none yet: classified from the code once it exists, or ahead with archvow column set"))
    personal = view["personal"]
    if personal.get("handles") and not view["declares_columns"]:
        listed = ", ".join(f"{n} ({k})" for n, k in personal["handles"].items())
        print("\n" + ui.title("Personal data") + f" - handles {listed}")
        if personal.get("writes"):
            print(ui.dim(f"  writes: {', '.join(personal['writes'])}"
                         + (f"; pseudonymised before: {', '.join(personal['pseudonymised'])}"
                            if personal.get("pseudonymised") else "")))
        if personal.get("removed"):
            print(ui.dim(f"  removed before the write: {', '.join(personal['removed'])}"))


def _open_items(root: Path, only: str | None) -> list[dict]:
    """Everything still to specify, in order: decisions to make, then safety questions."""
    data = mf.load(root)
    if only:
        specs.find_component(data, only)
    items = []
    for container in data["containers"]:
        template = load_template(mf.template_name(container)[0], root)
        for comp in container.get("components", []):
            if only and comp["id"] != only:
                continue
            suggested = template.suggested_answers(comp)
            from archvow import proposals as ai

            proposed = ai.by_question(root)
            for n, d in enumerate(comp.get("decisions", []) or [], 1):
                if not (d.get("answer") or "").strip():
                    items.append({"kind": "decision", "component": comp["id"], "number": n,
                                  "question": d["question"], "suggested": suggested.get(d["question"]),
                                  "proposed": (proposed.get((comp["id"], n)) or {}).get("answer"),
                                  "command": f'archvow decision make {comp["id"]} {n} "..."'})
    from archvow.privacy import personal_flow

    report = run_check(root)
    flows = personal_flow(root, data)
    for container in data["containers"]:
        for comp in container.get("components", []):
            if only and comp["id"] != only:
                continue
            view = _component_view(root, data, comp["id"], report, flows)
            for c in view["columns"]:
                if not c["class"]:
                    items.append({"kind": "column", "component": comp["id"], "column": c["name"],
                                  "label": c["name"], "question": "personal, special (GDPR art. 9) or none?",
                                  "command": f"archvow column set {comp['id']} {c['name']} personal|special|none"})
            for q in view["questions"]:
                if not q["answer"]:
                    items.append({"kind": "question", "component": comp["id"], "key": q["key"],
                                  "label": q["key"], "question": q["question"],
                                  "command": f'archvow decision make {comp["id"]} {q["key"]} "..."'})
    for sheet in safety_worksheet(root, only):
        for q in sheet["questions"]:
            if q["status"] == "open":
                items.append({"kind": "safety", "component": sheet["component"], **q,
                              "command": f"archvow hazard add {sheet['component']} S{q['number']} <severity>  "
                                         f"|  archvow hazard dismiss {sheet['component']} S{q['number']} \"why\""})
    return items


def cmd_specify(args: argparse.Namespace) -> int:
    root = _root(args)
    if not (sys.stdin.isatty() and sys.stdout.isatty()):
        target = args.component or "<component>"
        raise SpecError(f"specify asks questions in a terminal; to see what is open: archvow show {target}")
    data = mf.load(root)
    say = _speaker(data)
    items = _open_items(root, args.component)
    if not items:
        print(ui.ok(say("Nothing left to specify.") + ("" if args.component else say(" Next: archvow next"))))
        return 0
    ui.setup_line_editing()  # arrows, Home/End, Up for earlier answers, Tab for the suggestion
    print(ui.dim(say("{count} item(s) to specify", count=len(items)))
          + " (" + _keys(say, *EDIT_KEYS, ("s", "skip"), ("q", "quit")) + ")")
    steps = {"decision": _specify_decision, "question": _specify_decision, "column": _specify_column,
             "safety": _specify_safety}
    components = {c["id"]: c for container in data["containers"] for c in container.get("components", [])}
    shown = None
    try:
        for number, item in enumerate(items, 1):
            if item["component"] != shown:  # the component, once, before its items
                shown = item["component"]
                comp = components.get(shown) or {}
                kind = f", {comp['kind']}" if comp.get("kind") else ""
                print("\n" + ui.title(f"{shown} ({comp.get('type', '?')}{kind})")
                      + ui.dim(f" - {comp.get('description', '')}"))
                known = _known_columns_line(root, data, shown)
                if known:
                    print(ui.dim(known))
            print("\n" + ui.dim(f"  {number}/{len(items)}"), end=" ")
            if not steps[item["kind"]](root, item, say):
                break
    except (KeyboardInterrupt, EOFError):  # Ctrl+C or Ctrl+D: stop like q, what was answered stays
        print("\n" + ui.error(say("stopped - the answers given before are saved (what is still open: "
                                         "archvow show {target})", target=args.component or "<component>")))
        return 130
    finally:
        _after_change(root)  # the views follow every answer recorded, even when stopped
    return 0


def _known_columns_line(root: Path, data: dict, cid: str) -> str:
    from archvow.privacy import columns_line, known_columns
    from archvow.questions import templates_of

    container, comp = specs.find_component(data, cid)
    found = known_columns(root, container, comp, templates_of(root, data).get(container["id"]))
    return columns_line(found, cid)


def _speaker(data: dict):
    """What `specify` says, in the project's language (commands and keywords stay as they are)."""
    from archvow.i18n import tr

    language = data.get("language") or "en"
    return lambda message, /, **values: tr(language, message, **values)


def _keys(say, *pairs: tuple[str, str]) -> str:
    """'Enter: suggestion - Tab: edit - q: quit': each key in colour, its words in the language."""
    return " - ".join(f"{ui.code(say(key))}{say(': ')}{say(words)}" for key, words in pairs)


EDIT_KEYS = (("Enter", "suggestion"), ("Tab", "edit"))  # with a suggestion: Enter takes it, Tab puts it in the line


def _prompt(say, label: str, suggestion: str | None = None, keys: str = "") -> str:
    """'  what must never happen (hazard)? [the suggestion] (keys): ' - the suggestion greyed."""
    shown = " " + ui.hint(f"[{suggestion}]") if suggestion else ""
    return f"  {label}{shown}" + (f" ({keys})" if keys else "") + say(": ")


def _specify_decision(root: Path, item: dict, say) -> bool:
    """A decision to make (1, 2...) or a P/O/C question (P1, O2...): one answer."""
    from archvow.questions import answer as answer_question

    label = (say("vow question {key}", key=item["key"]) if item.get("key")
             else say("spec decision {n}", n=item["number"]))
    print(ui.label(label, "question" if item.get("key") else "decision"))
    print(ui.question(item["question"], indent=2))
    suggested = item.get("suggested")
    if item.get("proposed"):  # the review of what the AI chose: Enter accepts it
        suggested = item["proposed"]
        print(ui.warn("  " + say("proposed by the AI: {answer}", answer=suggested)))
    keys = (_keys(say, *EDIT_KEYS, ("s", "skip"), ("q", "quit")) if suggested
            else _keys(say, ("Enter", "skip"), ("q", "quit")))
    answer = ui.ask(_prompt(say, say("answer"), None if item.get("proposed") else suggested, keys), suggested).strip()
    if answer.lower() == "q":
        return False
    if suggested and not answer:
        answer = suggested
    elif answer.lower() == "s" and suggested:
        answer = ""
    if answer:
        try:
            from archvow import proposals as ai

            if item.get("key"):
                answer_question(root, item["component"], item["key"], answer)
            elif item.get("proposed") and answer == item["proposed"]:
                ai.accept(root, item["component"], item["number"])
            else:
                specs.decide(root, item["component"], item["number"], answer)
                ai.take(root, item["component"], item["number"])
            which = item.get("key") or item["number"]
            origin = say(" (suggested)") if answer == suggested else say(" (your own)") if suggested else ""
            print(ui.ok(say("decision made") + origin + say(": ") + answer)
                  + _say_change(say, f"archvow decision make {item['component']} {which} \"...\""))
        except SpecError as error:
            print(ui.warn(str(error)))
    return True


def _say_change(say, command: str) -> str:
    return "\n" + ui.dim("  " + say("to change it: {command}", command=command))


def _specify_column(root: Path, item: dict, say) -> bool:
    from archvow.privacy import classify

    print(ui.label(say("column {name}", name=item["column"]), "question"))
    print(ui.question(say("personal, special (health, religion, biometrics... GDPR art. 9) or none?"), indent=2))
    while True:
        choice = ui.ask("  (" + _keys(say, ("p", "personal"), ("s", "special"), ("n", "none"), ("Enter", "skip"),
                                      ("q", "quit")) + ")" + say(": ")).strip().lower()
        if choice in ("", "q", "p", "s", "n"):
            break
    if choice == "q":
        return False
    if choice:
        kind = {"p": "personal", "s": "special", "n": "none"}[choice]
        classify(root, item["component"], [item["column"]], kind)
        print(ui.ok(f"{item['column']}: {kind}")
              + _say_change(say, f"archvow column set {item['component']} {item['column']} personal|special|none"))
    return True


def _specify_safety(root: Path, item: dict, say) -> bool:
    """One vow question: what must never happen (the hazard), then what is always true so it cannot
    happen (the invariant). Each suggestion appears once, greyed, in the prompt that answers it; the
    hazard is recorded high (it needs an invariant, a plain test of it is enough); `archvow hazard
    add` sets another severity."""
    print(ui.label(say("vow question S{n}", n=item["number"]), "question"))
    print(ui.question(situation(item["question"]), indent=2))
    suggestion = item.get("suggestion") or {}
    if suggestion.get("decision"):
        d = suggestion["decision"]
        print(ui.dim("  " + say("already made in decision {number}: {answer}", number=d["number"], answer=d["answer"])))
    hazard = suggestion.get("hazard") or None
    keys = _keys(say, *(EDIT_KEYS if hazard else ()), ("n", "not applicable"), ("s", "skip"), ("q", "quit"))
    text = ""
    while not text:
        text = ui.ask(_prompt(say, say("what must never happen (hazard)?"), hazard, keys), hazard).strip()
        if text.lower() in ("q", "s", "n"):
            break
        text = text or hazard or ""
    if text.lower() == "q":
        return False
    if text.lower() == "s":
        return True
    try:
        if text.lower() == "n":
            reason = ""
            while not reason:
                reason = ui.ask(_prompt(say, say("why it cannot happen here"))).strip()
            specs.dismiss_question(root, item["component"], str(item["number"]), reason)
            print(ui.ok(say("not applicable: {reason}", reason=reason))
                  + _say_change(say, f"archvow hazard remove {item['component']} S{item['number']}"))
            return True
        proposal = suggestion.get("invariant") or None
        keys = _keys(say, *(EDIT_KEYS if proposal else ()), ("s", "skip"), ("q", "quit"))
        statement = ui.ask(_prompt(say, say("how is it prevented (invariant)?"), proposal, keys), proposal).strip()
        if statement.lower() == "q":
            return False
        statement = None if statement.lower() == "s" else (statement or proposal)
        entry = specs.add_hazard(root, text, guide_word=str(item["number"]), severity="high",
                                 component=item["component"])
        invariant = (specs.add_invariant(root, statement, mitigates=[entry["id"]], component=item["component"])
                     if statement else None)
        print(ui.ok(say("{id} recorded: {text}", id=entry["id"], text=entry["description"])))
        if invariant:
            print(ui.dim("  " + say("prevented by {id}: {statement}", id=invariant["id"], statement=invariant["statement"])))
        else:
            print(ui.warn("  " + say("It needs an invariant: {command}",
                                     command=f"archvow invariant add {item['component']} \"...\" --prevents {entry['id']}")))
        both = f", invariant remove {invariant['id']}, then add them again" if invariant else ", then hazard add again"
        print(_say_change(say, f"archvow hazard remove {entry['id']}{both}").lstrip("\n"))
    except SpecError as error:
        print(ui.warn(str(error)))
    return True


TESTED_BY = {"example_test": 'a test marked @pytest.mark.invariant("{id}")',
             "property_test": 'a Hypothesis @given test marked @pytest.mark.invariant("{id}")',
             "runtime": "a guard in the component's file marked  # archvow: enforces[{id}]"}


def _record_hazard(root: Path, component: str | None, question: str, severity: str,
                   description: str | None) -> tuple[dict, dict | None, dict]:
    """A hazard; without a description, the suggested one and, for a critical or high hazard,
    the suggested invariant that prevents it. Returns the suggestion too."""
    _, suggestion = specs.suggestion_for(root, component, question)
    entry = specs.add_hazard(root, description, guide_word=question, severity=severity, component=component)
    invariant = None
    if description is None and severity in ("critical", "high") and suggestion.get("invariant"):
        invariant = specs.add_invariant(root, suggestion["invariant"], mitigates=[entry["id"]], component=component)
    return entry, invariant, suggestion


def _hazard_text(entry: dict, invariant: dict | None, target: str, suggestion: dict) -> str:
    origin = "the suggested hazard" if entry["description"] == suggestion.get("hazard") else "your own text"
    text = f"Recorded {entry['id']} ({entry['severity']}) - {origin}: {entry['description']}"
    if invariant:
        mine = "" if invariant["statement"] == suggestion.get("invariant") else " (your own)"
        text += f"\n  prevented by {invariant['id']}{mine}: {invariant['statement']}" + _tested_by(invariant)
    elif entry["severity"] in ("critical", "high"):
        text += (f"\nA {entry['severity']} hazard needs an invariant (what is always true, so it cannot happen): "
                 f"archvow invariant add {target} \"...\" --prevents {entry['id']}")
        if suggestion.get("invariant"):
            text += "\n" + ui.dim(f"  the suggested one: \"{suggestion['invariant']}\"")
    both = f", invariant remove {invariant['id']}, then add them again" if invariant else ", then hazard add again"
    return text + _to_change(f"archvow hazard remove {entry['id']}{both}")


def _tested_by(invariant: dict) -> str:
    how = TESTED_BY.get(invariant.get("verify"))
    return f"\n  tested by: {how.format(id=invariant['id'])}" if how else ""


def cmd_hazard_add(args: argparse.Namespace) -> int:
    root = _root(args)
    component = None if args.component == "system" else args.component
    entry, invariant, suggestion = _record_hazard(root, component, args.guide_word, args.severity, args.description)
    _after_change(root)
    payload = {**entry, "invariant": invariant} if invariant else entry
    _print(args, payload, _hazard_text(entry, invariant, args.component, suggestion), success=True)
    return 0


def cmd_hazard_dismiss(args: argparse.Namespace) -> int:
    root = _root(args)
    component = None if args.component == "system" else args.component
    questions = [q.strip() for q in args.guide_word.split(",") if q.strip()]
    entries = [specs.dismiss_question(root, component, q, args.rationale) for q in questions]
    _after_change(root)
    text = "\n".join(f"Not applicable ({e['guide_word']}): {e['rationale']}"
                     + (_to_change(f"archvow hazard remove {component} S{_safety_number(root, component, e)}")
                        if component else "") for e in entries)
    _print(args, entries[0] if len(entries) == 1 else entries, text, success=True)
    return 0


def _safety_number(root: Path, component: str, entry: dict) -> int:
    """The number `archvow show` gives a safety question (S2), from its guide word."""
    container, comp = specs.find_component(mf.load(root), component)
    words = specs.safety_questions(load_template(mf.template_name(container)[0], root), comp)
    return words.index(entry["guide_word"]) + 1


def cmd_invariant_add(args: argparse.Namespace) -> int:
    root = _root(args)
    component = None if args.component == "system" else args.component
    prevents = [m.strip() for m in (args.prevents or "").split(",") if m.strip()]
    entry = specs.add_invariant(root, args.statement, verify=args.verify, mitigates=prevents,
                                component=component, evidence=args.evidence, rule=args.rule)
    _after_change(root)
    text = (f"Recorded {entry['id']}, prevents {', '.join(entry['mitigates'])}: {entry['statement']}"
            + _tested_by(entry) + _to_change(f"archvow invariant remove {entry['id']}, then invariant add again"))
    _print(args, entry, text, success=True)
    return 0


# ------------------------------------------------------------------ AI hand-off and verification


def cmd_prompt(args: argparse.Namespace) -> int:
    root = _root(args)
    text = render_clarify(root, args.component) if args.clarify else render_prompt(root, args.component,
                                                                                    task=args.task)
    print(text, end="")
    if sys.stderr.isatty():  # for the person who runs it; the AI reads stdout only
        from archvow.prompt import tokens

        print(ui.dim(f"~{tokens(text):,} tokens"), file=sys.stderr)
    return 0


def cmd_freeze(args: argparse.Namespace) -> int:
    root = _root(args)
    count = freeze.write(root, run_check(root, raw=True))
    _print(args, {"frozen": count, "file": freeze.FROZEN_REL},
           f"Froze {count} existing violation(s) in {freeze.FROZEN_REL}. Commit it: from now on "
           "only new violations fail. Fix frozen ones over time and run `archvow freeze` again.", success=True)
    return 0


def cmd_audit(args: argparse.Namespace) -> int:
    rows = run_audit(_root(args))
    _print(args, rows, render_audit(rows))
    return 1 if args.strict and any(r["flags"] for r in rows) else 0


def cmd_diff(args: argparse.Namespace) -> int:
    root = _root(args)
    try:
        changes = spec_diff(root, args.base)
    except GitError as exc:
        raise SpecError(f"cannot compare with '{args.base}': {exc}") from exc
    if args.json:
        print(json.dumps(changes, indent=2))
    else:
        print(render(changes, markdown=args.markdown), end="")
    return 0


def _guard_notes(root: Path) -> dict[str, list[str]]:
    """Per component, what `next` adds to its line: decisions the AI proposed, assumptions nobody
    reviewed yet (they block the commit, ARCH034), critical/high hazards nothing prevents yet,
    invariants of written code that no test checks yet."""
    from archvow import proposals as ai

    data = mf.load(root)
    notes: dict[str, list[str]] = {}
    proposed: dict[str, int] = {}
    for p in ai.load(root):
        proposed[p["component"]] = proposed.get(p["component"], 0) + 1
    hazards, invariants = mf.hazards(data), data.get("invariants", []) or []
    report = run_check(root) if hazards or invariants else None
    guarded = {h for inv in invariants for h in inv.get("mitigates", []) or []}
    untested = {i["id"] for i in report.invariants if not i.get("verified")} if report else set()
    coded = {c.component for c in report.components if c.status != "planned"} if report else set()
    for container in data.get("containers", []):
        for comp in container.get("components", []):
            cid = comp["id"]
            unguarded = sum(1 for h in hazards if h.get("component") == cid
                            and h["severity"] in ("critical", "high") and h["id"] not in guarded)
            weak = sum(1 for i in invariants if i.get("component") == cid and i["id"] in untested) if cid in coded else 0
            assumed = sum(1 for a in comp.get("assumptions", []) or [] if a.get("status", "proposed") == "proposed")
            found = [f"{proposed[cid]} proposed by the AI" if proposed.get(cid) else "",
                     f"{assumed} assumption(s) to review -> archvow show {cid}" if assumed else "",
                     f"{unguarded} hazard(s) prevented by nothing" if unguarded else "",
                     f"{weak} invariant(s) not tested" if weak else ""]
            if any(found):
                notes[cid] = [n for n in found if n]
    return notes


def _task_tokens(root: Path, component: str) -> int | None:
    """About how many tokens the AI reads for a component's task (its committed spec.md)."""
    from archvow.prompt import tokens

    try:
        return tokens((root / mf.COMPONENTS_REL / component / mf.CARD_FILE).read_text(encoding="utf-8"))
    except OSError:
        return None


def cmd_next(args: argparse.Namespace) -> int:
    root = _root(args)
    rows, budget, runs = plan_with_budget(root, args.base)
    notes = _guard_notes(root)
    listed = {r["component"] for r in rows}
    data = mf.load(root)
    for container in data.get("containers", []):  # done components that still have a guard to fix
        for comp in container.get("components", []):
            if comp["id"] in notes and comp["id"] not in listed:
                rows.append({"component": comp["id"], "type": comp["type"], "readiness": "coded"})
    for r in rows:
        if r["component"] in notes:
            r["notes"] = notes[r["component"]]
        size = _task_tokens(root, r["component"])
        if size is not None:
            r["tokens"] = size  # what the AI reads for it: its spec.md (ARCH044 warns over the limit)

    def line(r: dict) -> str:
        state = "ready" if r["readiness"].startswith("ready") else "blocked" if r["readiness"].startswith("blocked") else "wait"
        hint = f"  -> archvow specify {r['component']}" if state == "blocked" else ""
        extra = ui.warn(" - " + ", ".join(r["notes"])) if r.get("notes") else ""
        size = ui.dim(f"  ~{r['tokens']:,} tokens") if state == "ready" and r.get("tokens") else ""
        return (f"{ui.mark(state)} {r['component']:<28} {r['type']:<15} {r['readiness']}"
                + (f" ({r['started']})" if r.get("started") else "") + extra + size + ui.dim(hint))

    header = ui.dim(f"  {'component':<28} {'type':<15} status") if rows else ""  # type: archvow catalog lists them
    text = "\n".join([header, *(line(r) for r in rows)]) if rows else (
        "Nothing planned. Add components with `archvow component add`.")
    sheet = safety_worksheet(root)
    total = sum(len(c["questions"]) for c in sheet)
    done = sum(q["status"] == "answered" for c in sheet for q in c["questions"])
    if rows and done < total:
        text += f"\n\nSafety: {done} of {total} questions answered" + ui.dim("  -> archvow specify")
    if args.base and budget is None:
        text += f"\n{ui.warn(f'Change budget unknown: cannot compare with {args.base!r} (a branch or ref that exists).')}"
    elif budget:
        size = (f"Change budget against {budget['base']}: {budget['files']}/{budget['max_files']} files, "
                f"{budget['added_lines']}/{budget['max_added_lines']} lines added (ARCH022).")
        here = _current_branch(root) or "<this branch>"
        text += "\n\n" + (ui.warn(size + " Full: stop here - commit and open the merge request. To go on "
                                  f"before it is merged, start the next branch from this one (git switch -c "
                                  f"feature/<ticket>-<short-name> {here}) and run archvow next --base {here}: "
                                  "only the new work counts.") if budget["full"] else size)
    if runs:  # how to try it on a laptop, or what it still needs (never a deployment command)
        text += "\n\n" + "\n".join(ui.ok(r["line"]) if r["ready"] else ui.warn(r["line"]) for r in runs)
    _print(args, {"components": rows, "budget": budget} if args.base else rows, text)
    return 0


def cmd_check(args: argparse.Namespace) -> int:
    root = _root(args)
    if args.file and not args.stdin and not Path(args.file).is_file():
        raise SpecError(f"--file {args.file}: no such file (for an unsaved buffer, add --stdin)")
    content = sys.stdin.read() if args.stdin else None
    report = run_check(root, Path(args.file) if args.file else None, content,
                       base=args.base, accept_weakening=args.accept_weakening, complete=args.complete,
                       test_report=Path(args.test_report) if args.test_report else None)
    if args.json:
        print(json.dumps(report.to_dict(), indent=2))
    else:
        quiet = [] if args.all else [v for v in report.violations if v.code in ("ARCH035", "ARCH038")]
        for v in report.violations:
            if v in quiet:
                continue
            where = f"{v.file}:{v.line}:{v.col}:" if v.line else f"{v.file}:"
            print(f"{ui.dim(where)} {ui.severity(v.severity, f'{v.code} [{v.severity}]')} {v.message}")
        for c in report.changes:
            print(f"architecture change: {c['change']} {c['id']}" + (f" ({c['type']})" if c.get("type") else ""))
            if c["change"] == "contract_changed":
                print(ui.dim("  review the components that use it: " + (", ".join(c["users"]) or "none")
                             + " (their code and their tests may need to follow)"))
            if c["change"] == "example_changed":
                print(ui.dim(f"  example {c['example']}: new files accepted by {c.get('by') or '?'} - the reviewers "
                             "compare them with the ticket"))
        counts: dict[str, int] = {}
        for comp in report.components:
            counts[comp.status] = counts.get(comp.status, 0) + 1
        open_safety = [v for v in quiet if v.code == "ARCH035"]
        if open_safety:
            done, total = report.safety.get("answered", 0), report.safety.get("total", 0)
            print(ui.warn(f"Safety: {done} of {total} questions answered ({len(open_safety)} open, ARCH035): "
                          "`archvow show <component>` lists them, `archvow check --all` shows each one."))
        unmarked = [v for v in quiet if v.code == "ARCH038"]
        if unmarked:
            print(ui.warn(f"Tests: {len(unmarked)} coded component(s) with decisions or rules no test is marked "
                          "with (ARCH038): `archvow check --all` lists them."))
        if report.frozen:
            print(ui.dim(f"{len(report.frozen)} frozen violation(s) ignored ({freeze.FROZEN_REL})."))
        if report.stale_frozen:
            print(ui.warn(f"{len(report.stale_frozen)} frozen violation(s) are fixed: run `archvow freeze` "
                          "to shrink the list."))
        order = ["planned", "implemented", "tested", "verified", "drift"]
        by_rule = report.counts()
        if len(by_rule) > 1:
            print("\n" + ui.dim("By rule: " + "  ".join(f"{code} {n}" for code, n in by_rule.items())))
        progress = ", ".join(f"{counts[k]} {k}" for k in order if k in counts) or "no components"
        summary = (f"{len(report.errors)} error(s), {len(report.violations) - len(report.errors)} "
                   f"warning(s). Components: {progress}.")
        print()
        print(ui.ok(summary) if not report.errors else ui.error(summary))
    return 1 if report.errors else 0


def cmd_ai_review(args: argparse.Namespace) -> int:
    from archvow.review import ReviewError, run

    root = _root(args)
    try:
        outcome = run(root, args.base, acknowledged=args.acknowledged,
                      echo=(lambda _text: None) if args.json else (lambda text: print(ui.dim(text))))
    except ReviewError as exc:
        raise SpecError(str(exc)) from exc
    failed = outcome["status"] in ("high", "failed")
    if args.json:
        print(json.dumps(outcome, indent=2))
        return 1 if failed else 0
    for finding in outcome["findings"]:
        line = f"{finding['severity']:<6} {finding['text']}"
        print(ui.severity("error", line) if finding["severity"] == "HIGH" else
              ui.severity("warning", line) if finding["severity"] == "MEDIUM" else line)
    if outcome["findings"]:
        print()
    message = outcome["message"]
    if failed:
        print(ui.error(message))
    elif outcome["status"] in ("passed", "nothing"):
        print(ui.ok(message))
    else:
        print(ui.warn(message))
    return 1 if failed else 0


def cmd_completion(args: argparse.Namespace) -> int:
    """archvow completion zsh|bash|powershell: the script that makes Tab complete archvow; with --install,
    written to ~/.archvow-completion.<ext> and loaded by one line in the shell's startup file."""
    from archvow.completion import install, script

    if not args.install:
        print(script(args.shell), end="")
        return 0
    for line in install(args.shell):
        print(ui.ok(line))
    print(ui.dim("  open a new terminal, then: archvow sp<Tab>"))
    return 0


def cmd_doctor(args: argparse.Namespace) -> int:
    from archvow.doctor import as_dicts, render, run_doctor

    start = Path(args.root) if args.root else Path.cwd()
    findings = run_doctor(start)
    if args.json:
        print(json.dumps(as_dicts(findings), indent=2))
    else:
        try:
            mf.find_root(start)
            known = True
        except mf.ManifestError:
            known = False
        print(render(findings, known))
    return 1 if any(f.status == "fail" for f in findings) else 0


def cmd_docs(args: argparse.Namespace) -> int:
    root = _root(args)
    if args.check:
        problems = docs.check_views(root)
        for problem in problems:
            print(f".archvow/ specs: {problem}")
        if problems:
            print("Run `archvow docs` and commit the result (never edit these files by hand).")
            return 1
        print("The specs are up to date with the vows.")
        return 0
    for path in docs.generate(root):
        print(f"wrote {path.relative_to(root)}")
    return 0


def _split_list(text: str | None) -> list[str]:
    return [item.strip() for item in (text or "").replace(" ", ",").split(",") if item.strip()]


def _template_settings(args: argparse.Namespace, root: Path | None) -> dict:
    """What `template new` writes as settings: from the options, or asked in a terminal."""
    base = load_template(args.extends, root)
    given = args.description or args.answer or args.allowed_paths or args.verbatim_folders or args.layer
    if not given and not args.no_input and sys.stdin.isatty() and sys.stdout.isatty():
        ui.setup_line_editing()
        print(ui.dim("Enter skips a question."))
        args.description = ui.ask(f"  description [Custom variant of {args.extends}.]: ").strip() or None
        print(ui.dim(f"\nThe company's defaults for the init answers of {args.extends}, one at a time: Enter "
                     "keeps the base's default; a project can still change any of them (-a)."))
        args.answer = [f"{key}={value}" for key, value in specs.ask_company_defaults(base).items()]
        print()
        args.allowed_paths = ui.ask("  allowed_paths - top folders of Python files that are not "
                                    "components (e.g. devops,tools): ")
        args.verbatim_folders = ui.ask("  verbatim_folders - folders of files/ copied as they are, .j2 "
                                       "included (e.g. templates): ")
        layers = " ".join(layer["name"] for layer in base.layers)
        args.layer = ui.ask(f"  layer folders - Enter keeps {layers}; to rename, LAYER=FOLDER separated by "
                            "spaces (e.g. p1_domain=domain): ").split()
    questions = {q["id"]: q for q in base.data.get("questions", [])}
    defaults = {}
    for item in args.answer or []:
        key, sep, value = item.partition("=")
        if not sep:
            raise SpecError(f"-a {item}: write KEY=VALUE (e.g. -a ci=jenkins)")
        if key not in questions:
            raise SpecError(f"-a {key}: {args.extends} has no such init answer "
                            f"(archvow catalog lists them: {', '.join(questions)})")
        defaults[key] = specs.check_answer(base, questions[key], value)
    allowed = [entry.strip("/") for entry in _split_list(args.allowed_paths)]
    deep = [entry for entry in allowed if "/" in entry]
    if deep:
        raise SpecError(f"allowed_paths: {', '.join(deep)} - only top folders (archvow looks at the "
                        "first folder of a file's path: devops covers devops/deploy/run.py)")
    verbatim = [entry.strip("/") for entry in _split_list(args.verbatim_folders)]
    layer_names = {}
    for item in args.layer or []:
        old, sep, new = item.partition("=")
        if not sep:
            raise SpecError(f"--layer {item}: write LAYER=FOLDER (e.g. --layer p1_domain=domain)")
        layer_names[old.strip()] = new.strip()
    try:
        check_layer_names(args.name, [layer["name"] for layer in base.layers], layer_names)
    except TemplateError as exc:
        raise SpecError(str(exc).replace("layer_names:", "--layer:")) from exc
    return {"description": args.description, "defaults": defaults, "allowed_paths": allowed,
            "verbatim_folders": verbatim, "layer_names": layer_names}


def cmd_template_new(args: argparse.Namespace) -> int:
    if args.dir:  # a company template, in the team's catalog: no project needed
        try:
            root: Path | None = _root(args)
        except mf.ManifestError:
            root = None
        catalog = Path(args.dir).resolve()
        directory = scaffold_custom_template(root, args.name, args.extends, catalog=catalog,
                                             **_template_settings(args, root))
        print(ui.ok(f"Created {directory}") + "\n"
              f"Edit template.yaml and add your files in files/. To use it, on developer machines and in CI:\n"
              f"  export ARCHVOW_TEMPLATES={catalog}\n"
              f"  archvow init <package> -t {args.name} -a architects=@<group>")
        return 0
    try:
        root = _root(args)
    except mf.ManifestError as exc:
        raise SpecError("not in an archvow project: to create a company template, pass --dir "
                        "<catalog folder>") from exc
    directory = scaffold_custom_template(root, args.name, args.extends, **_template_settings(args, root))
    print(ui.ok(f"Created {directory.relative_to(root)}") + ". Edit template.yaml (a guard: the architects "
          "approve it); projects created from now on can use it with -t " + args.name + ".")
    return 0


# ------------------------------------------------------------------ parser

DEFAULT_TEMPLATE = specs.DEFAULT_TEMPLATE

FLOW = """\
how to build a project (every command prints what it changed;
`archvow <command> --help` lists all its options, with examples). What the spec stores is
written `archvow <noun> <verb>`: component, question, decision, rule, assumption, hazard,
invariant, column, dependency - `archvow <noun> --help` lists its verbs:

  1. create the project
       archvow init <package> -t pyspark-pipeline -d "<what it does>" \\
           -a architects=@<user or group> -a ai_tools=<assistant,...>
  2. declare what must exist, one component at a time (types: archvow catalog)
       archvow component add <type> <name> -d "<what it must do>" -s <ticket> -u <component,...>
       or ask the AI assistant to "draft the spec of <feature>" (/draft-spec): it proposes these
       commands, you read and run them
  3. make the decisions: what each component does, so that nothing is left to chance
       archvow show <component>                  everything about it, on one screen
       archvow specify <component>               answers what is open, one question at a time
       archvow decision make <component> <number> "<answer>"
       archvow rule add <component>[,...] "<a rule in your own words>"   (or --type <type>, --all)
       archvow column set <schema> <column,...> personal|special|none   (GDPR: every column classified)
       archvow decision make <component> P1 "<answer>"   (P: personal data, O: operations - when asked)
  4. decide what must never happen (archvow specify asks it too)
       archvow hazard add <component> S<number> <severity> "<what must never happen>"
       archvow invariant add <component> "<what always holds>" --prevents H1
  5. commit the spec
       archvow docs --check && git add .archvow && git commit -m "<ticket>: specify ..."
  6. write the code in this order - yourself, or tell the AI assistant "implement <component>"
       archvow next
  7. review what the AI assumed, run pytest, commit (the Git hook runs ruff and check), release
       archvow assumption accept <component> <number>        (or: archvow assumption reject ...)
       archvow check --complete
       archvow changes --from <last release> --markdown   (what the release contains)
     optional: a second, approved AI reviews the change and only reports (-a reviewers=<tool>):
       tell it "review the last change", or let the CI run archvow review --base develop
"""


class _Formatter(argparse.RawDescriptionHelpFormatter):
    """The same help on every Python version, so the command reference never depends on it:
    `-t TEMPLATE, --template TEMPLATE` (Python 3.13 writes `-t, --template TEMPLATE`), and the
    column of the help text measured as Python 3.12 does (3.13 counts the sub-command indent)."""

    def add_argument(self, action: argparse.Action) -> None:
        if action.help is not argparse.SUPPRESS:
            invocations = [self._format_action_invocation(action)]
            invocations += [self._format_action_invocation(sub) for sub in self._iter_indented_subactions(action)]
            length = max(map(len, invocations)) + self._current_indent
            self._action_max_length = max(self._action_max_length, length)
            self._add_item(self._format_action, [action])

    def _format_action_invocation(self, action: argparse.Action) -> str:
        if not action.option_strings or action.nargs == 0:
            return super()._format_action_invocation(action)
        value = self._format_args(action, self._get_default_metavar_for_optional(action))
        return ", ".join(f"{option} {value}" for option in action.option_strings)


class _Parser(argparse.ArgumentParser):
    """argparse parser whose help ends with template-dependent details and examples.

    The details (init answers, component types, guide words) are read from the template only
    when the help is shown, so ordinary commands never pay for it.
    """

    def __init__(self, *args, examples: str = "", details=None, **kwargs) -> None:
        kwargs.setdefault("formatter_class", _Formatter)
        super().__init__(*args, **kwargs)
        self.examples = examples
        self.details = details
        self.chosen_template: str | None = None

    def format_help(self) -> str:
        text = super().format_help()
        if self.details is not None:
            try:
                extra = self.details(self)
            except (TemplateError, mf.ManifestError, SpecError, OSError) as exc:
                extra = f"(template details unavailable: {exc})"
            text += "\n" + extra.rstrip() + "\n"
        examples = self.examples
        command = self.prog.removeprefix("archvow").strip()
        try:  # a template may give concrete examples for its own component types
            examples = (_help_template(self).data.get("help_examples") or {}).get(command) or examples
        except (TemplateError, mf.ManifestError, SpecError, OSError):
            pass
        if examples:
            text += "\nexamples:\n" + textwrap.indent(textwrap.dedent(examples).strip("\n"), "  ") + "\n"
        return _project_tickets(text)


class _TemplateAction(argparse.Action):
    """Store -t, and remember it so that `init -t NAME --help` describes that template."""

    def __call__(self, parser, namespace, values, option_string=None) -> None:
        from archvow.templates import use_pack_folder

        values = use_pack_folder(values)  # -t <folder>: the pack's name, its catalog made visible
        parser.chosen_template = values
        setattr(namespace, self.dest, values)


def _project_tickets(text: str) -> str:
    """Inside a project, the examples' tickets (US-001) are written as the project writes them."""
    from archvow.branches import ticket_example, ticket_pattern

    try:
        pattern = ticket_pattern(mf.load(mf.find_root(Path.cwd())))
    except mf.ManifestError:
        return text
    return re.sub(r"\bUS-(\d+)\b", lambda m: ticket_example(pattern, int(m.group(1))), text)


def _help_template(parser: _Parser) -> Template:
    """The template the help is about: -t, else the current project's, else the default."""
    try:
        root: Path | None = mf.find_root(Path.cwd())
    except mf.ManifestError:
        root = None
    name = parser.chosen_template
    if name is None and root is not None:
        name = mf.template_name(mf.load(root)["containers"][0])[0]
    return load_template(name or DEFAULT_TEMPLATE, root)


def _wrap(text: str, indent: int) -> str:
    return textwrap.fill(" ".join(str(text).split()), width=100, initial_indent=" " * indent,
                         subsequent_indent=" " * indent)


def answers_help(template: Template) -> str:
    """Every init answer of a template: required or default, allowed values, meaning."""
    lines = []
    questions = template.summary()["questions"]
    for q in sorted(questions, key=lambda q: not q["required"]):  # required first, then template order
        if q["required"]:
            state = "required"
        else:
            state = f"default: {q.get('default') or '(empty)'}"
            for other, values in (q.get("default_from") or {}).items():  # the default follows an earlier answer
                state = "default: " + ", ".join(f"{v} with {other}={k}" for k, v in values.items()) + \
                        f", else {q.get('default') or '(empty)'}"
        if q.get("choices"):
            joined = ", ".join(str(c) for c in q["choices"])
            state += f";  {'comma-separated, from' if q['multiple'] else 'one of'}: {joined}"
        lines.append(f"  {q['id']:<16} " + _wrap(state, 19).lstrip())
        lines.append(_wrap(q.get("prompt", ""), 19))
        if q.get("pattern_hint"):
            lines.append(_wrap(f"format: {q['pattern_hint']}", 19))
    return "\n".join(lines)


def _init_details(parser: _Parser) -> str:
    template = _help_template(parser)
    return (f"answers of template {template.ref} (-a KEY=VALUE, repeatable; another template:\n"
            "archvow init -t NAME --help, or archvow catalog):\n" + answers_help(template))


def _types_details(parser: _Parser) -> str:
    template = _help_template(parser)
    lines = [f"component types of template {template.ref} (TYPE NAME gives the component id):"]
    for key, ct in template.component_types.items():
        if not ct.get("addable", True):
            continue
        cid = str(ct.get("module", "{name}")).replace("{name}", "<name>")
        lines.append(f"  {key:<15} {cid:<15} {ct.get('description', '')}")
        hint = ct.get("name_hint")
        notes = [f"name: {hint}"] if hint else []
        if ct.get("signature_overridable"):
            symbol = (ct.get("symbols") or [{}])[0]
            notes.append(f"signature {symbol.get('signature', '')} (--signature changes it)")
        if template.kinds(key):
            notes.append(f"kinds (-k): {', '.join(template.kinds(key))} (default {template.kinds(key)[0]})")
        if notes:
            lines.append(_wrap("; ".join(notes), 34))
    return "\n".join(lines)


def _guide_words_details(parser: _Parser) -> str:
    template = _help_template(parser)
    lines = ["safety questions: use the number archvow show <component> shows (S2, or 2); the guide word works too.",
             f"guide words of template {template.ref}:"]
    for word, question in (template.data.get("guide_words") or {}).items():
        lines.append(f"  {word:<10} " + _wrap(question, 13).lstrip())
    return "\n".join(lines) + "\n\n" + SEVERITY_HELP


VERIFY_HELP = """\
tested by - every invariant is checked by a test that carries its number:
  @pytest.mark.invariant("clean_orders.INV1")   on a test (a Hypothesis @given test for a critical hazard)
archvow check fails while a coded component's invariant has no such test. Experts can ask for
another kind of check (a guard in the code, a model, a proof): see the Rules documentation.
"""


def build_parser() -> argparse.ArgumentParser:
    parser = _Parser(prog="archvow", description=__doc__, epilog=FLOW)
    parser.add_argument("--version", action="version", version=f"archvow {__version__}")
    parser.add_argument("--root", help="project root (default: search upwards from the current folder)")
    sub = parser.add_subparsers(dest="command", required=True, metavar="command",
                                help="archvow <command> --help: its options and examples")

    def command(name: str, func, help_text: str, json_flag: bool = False, *, examples: str = "",
                details=None, parent=sub) -> _Parser:
        p = parent.add_parser(name, help=help_text, description=help_text[:1].upper() + help_text[1:] + ".",
                              examples=examples, details=details)
        p.set_defaults(func=func)
        if json_flag:
            p.add_argument("--json", action="store_true", help="machine-readable output (IDE plugin, scripts)")
        return p

    component_help = "component id, as `archvow next` or the spec cards show it"

    # ---- project
    p = command("init", cmd_init, "add archvow specs and guards to a repository (no source folders)",
                details=_init_details, examples="""
        archvow init my_pipeline -a architects=@my-team
        archvow init "$NAME" -t pyspark-pipeline -d "PySpark pipeline for $NAME" \\
            -a architects=@my-team -a ai_tools="$AI_TOOL"
        archvow init "$NAME" -d "Daily orders report" -a architects="@alice @data/architects" \\
            -a ai_tools=copilot,claude-code -a platform=github -a python_version=3.12 \\
            -a ci_image=registry.example.local/python-spark:3.12 \\
            -a pip_index_url=https://nexus.example.local/repository/pypi/simple
        archvow init "$NAME" --force -a architects=@my-team -a ci_image=registry.example.local/py:3.12
            # an existing project: rewrites the generated files, keeps the committed spec

        Run init once, to create the project. Developers clone the repository instead.
        """)
    p.add_argument("package", help="snake_case Python package the code will live in (also the project name)")
    p.add_argument("-t", "--template", action=_TemplateAction, metavar="TEMPLATE",
                   help=f"architecture template: a name (default: {DEFAULT_TEMPLATE}; list: archvow catalog) or "
                        "the folder of a company template; a company template is copied into "
                        ".archvow/templates/")
    p.add_argument("-d", "--description", metavar="TEXT",
                   help="what the system does, in one line: goes into the vow, the README and "
                        "every spec card (default: the package name)")
    p.add_argument("-a", "--answer", action="append", metavar="KEY=VALUE",
                   help="answer one of the template's questions (repeatable); the keys are listed below")
    p.add_argument("--dir", help="repository root (default: current folder)")
    p.add_argument("--src", default="src", help="source root (default: src)")
    p.add_argument("--force", action="store_true",
                   help="in a folder that is already a project: rewrite the generated files from the template "
                        "(AGENTS.md, CI, hooks...). A committed spec is always kept; to start over, "
                        "git rm -r .archvow and commit")
    p.add_argument("--no-git", action="store_true",
                   help="do not create a Git repository (default: one is created, branch main)")
    p.add_argument("--no-input", action="store_true",
                   help="never ask: in a terminal, init asks the main questions no -a answered "
                        "(scripts and CI are never asked)")
    p.add_argument("--adopt", action="store_true",
                   help="existing code: propose `layer_paths` from folder and file names (core, models, crud, "
                        "services, api...) so the files stay where they are; written into .archvow/spec.vow "
                        "and printed for the architects to review (with --force in a project: adds the "
                        "files not mapped yet)")

    p = command("catalog", cmd_catalog, "list templates, their init answers and component types", True,
                examples="archvow catalog\narchvow catalog --json")

    # ---- components
    def noun(name: str, help_text: str, verbs: str, examples: str = "") -> argparse._SubParsersAction:
        """A thing stored in the spec: `archvow <noun> <verb>` (component add, hazard remove...)."""
        group = command(name, None, help_text, examples=examples)
        return group.add_subparsers(dest=f"{name}_command", required=True, metavar=verbs,
                                                help=f"archvow {name} {verbs} --help: options and examples")

    csub = noun("component", "what must exist: add, change or remove a component of the spec", "add|edit|remove",
                examples="""
        archvow component add <type> <name> -d "<what it must do>" -s <ticket> -u <component>,<component>
        archvow component edit <component> -d "<the new description>"
        archvow component remove <component>
        """)
    p = command("add", cmd_component_add, "specify a component (writes the spec, never code)", True, parent=csub,
                details=_types_details, examples="""
        archvow component add <type> <name> -d "<what it must do>" -s <ticket>
        archvow component add <type> <name> -d "<what it must do>" -u <component>,<component>  # it uses them
        archvow component add <type> <name> -d "<what it must do>" -g <group>     # in the folder <layer>/<group>/
        archvow component add <type> <name> -d "<what it must do>" -k <kind>      # a reader of a table, a database...
        archvow component add <type> <name> -d "<what it does>" --file src/<package>/crud.py  # existing code
        """)
    p.add_argument("type", help="component type (listed below)")
    p.add_argument("name", help="short snake_case name; the type turns it into the component id (below)")
    p.add_argument("-d", "--description", required=True, metavar="TEXT",
                   help="what the component must do - the instruction the AI assistant or developer "
                        "implements, with the details that matter (change it with archvow component edit)")
    p.add_argument("-s", "--spec", metavar="TICKET", help="ticket or user story it implements, e.g. US-001")
    p.add_argument("-u", "--uses", metavar="IDS",
                   help="comma-separated ids of the components it uses")
    p.add_argument("-k", "--kind", metavar="KIND",
                   help="for the types that have kinds (listed below): what it reads or writes, e.g. a reader "
                        "of files (the default), a table, a database (jdbc), a connector or custom code; "
                        "fixed once added (remove and add again to change it)")
    p.add_argument("--signature", help="replace the public function's signature (only for the types that "
                                       "allow it, listed below; e.g. a second input)")
    p.add_argument("--container", help="container id, when the project has several (default: the first)")
    p.add_argument("-g", "--group", metavar="GROUP",
                   help="a folder inside the layer, to organise many components, e.g. orders: "
                        "<layer>/orders/<file>.py and tests/<layer>/orders/test_<id>.py")
    p.add_argument("-r", "--route", action="append", metavar="ROUTE",
                   help='for a router: one route, "<function>: <METHOD> <path>" (repeatable), '
                        'e.g. "get_order: GET /orders/{order_id}"')
    p.add_argument("--from", dest="source", metavar="BRIEF",
                   help="the brief it is drawn from: briefs/<file>.md, or briefs/<file>.md#<section> (a heading); "
                        "archvow check warns when that text changes (ARCH039)")
    p.add_argument("--file", metavar="PATH",
                   help="adopt an existing module where it is (path from the project root): its layer comes "
                        "from `layer_paths`, its symbols are the public functions, classes, constants and "
                        "routes the file has today")

    p = command("edit", cmd_component_edit, "change a component's description, ticket, dependencies or signature",
                True, parent=csub, examples="""
        archvow component edit <component> -d "<the new description>"
        archvow component edit <component> -u <component>,<component>      # the complete new list
        archvow component edit <component> -g orders                       # move it into the folder orders/
        archvow component edit <component> --owners @acme/payments         # its team approves its vow
        archvow component edit <component> --owners ""                      # back to the architects
        """)
    p.add_argument("component", help=component_help)
    p.add_argument("-d", "--description", metavar="TEXT", help="the new description (what gets implemented)")
    p.add_argument("-s", "--spec", metavar="TICKET", help="the new ticket or user story")
    p.add_argument("-u", "--uses", metavar="IDS", help="the complete new list, comma-separated ('' for none)")
    p.add_argument("--signature", help="only for types with an overridable signature")
    p.add_argument("-g", "--group", metavar="GROUP",
                   help="move it to another folder inside its layer ('' for none); then git mv its files")
    p.add_argument("-r", "--route", action="append", metavar="ROUTE",
                   help='for a router: the complete new list of routes, one -r each')
    p.add_argument("--owners", metavar="WHO",
                   help="who approves changes to its vow besides the architects: @user, @group (several with "
                        "spaces or commas; '' for the architects only). Written in CODEOWNERS; a weakened guard "
                        "still needs the architects (ARCH020)")
    p.add_argument("--from", dest="source", metavar="BRIEF",
                   help="the brief it is drawn from: briefs/<file>.md, or briefs/<file>.md#<section> (a heading); "
                        "archvow check warns when that text changes (ARCH039)")
    p = command("remove", cmd_component_remove, "remove a component with its decisions, hazards and invariants "
                "(asks first)", True, parent=csub, examples="""
        archvow component remove <component>      # then delete its file and test: archvow check lists them
        """)
    p.add_argument("component", help=component_help)
    p.add_argument("--yes", action="store_true", help="do not ask for confirmation (scripts)")

    # ---- reading and answering
    p = command("show", cmd_show, "everything about a component on one screen (the whole project: archvow next)",
                True, examples="""
        archvow show <component>                # decisions, rules, safety, assumptions, next step
        archvow show <component> H1             # one of its hazards (H1) or invariants (INV1), with its links
        archvow show src/<package>/<layer>/<file>.py:42   # a file (and a line): its component, who uses it,
                                                # the tests behind each decision - where a bug points
        archvow show R1                         # one of the project's rules
        archvow show --json                     # the whole spec, as JSON (IDE use)
        """)
    p.add_argument("component", nargs="?", help="one component, a rule R1, or a file (file.py or file.py:<line>)")
    p.add_argument("item", nargs="?", metavar="H<n>|INV<n>", help="one of its hazards or invariants")
    p = command("specify", cmd_specify, "answer what is still open, one question at a time (in a terminal)",
                examples="""
        archvow specify                         # every component: decisions to make, then safety
        archvow specify <component>             # one component (in a terminal; to read: archvow show)
        """)
    p.add_argument("component", nargs="?", help="only this component (default: all)")

    qsub = noun("question", "an open question: it blocks the component until a person answers it", "add|remove",
                examples="""
        archvow question add <component> "<the question>"
        archvow decision make <component> <n> "<the answer>"     # a person answers it
        archvow question remove <component> <n>
        """)
    p = command("add", cmd_question_add, "record an open question (blocks implementation until answered)", True,
                parent=qsub, examples='archvow question add <component> "<the question>"')
    p.add_argument("component", help=component_help)
    p.add_argument("question", help="the question; a person answers it with archvow decision make")
    p.add_argument("--from", dest="source", metavar="BRIEF",
                   help="the brief it is drawn from: briefs/<file>.md, or briefs/<file>.md#<section> (a heading); "
                        "archvow check warns when that text changes (ARCH039)")
    p = command("remove", cmd_question_remove, "remove a question a person added, with its answer (asks first; "
                "the template's questions stay)", True, parent=qsub,
                examples="archvow question remove <component> 4      # its number, as archvow show prints it")
    p.add_argument("component", help=component_help)
    p.add_argument("number", type=int, help="the question's number, as archvow show prints it")
    p.add_argument("--yes", action="store_true", help="do not ask for confirmation (scripts)")

    dsub = noun("decision", "what a component does: answer its questions, so nothing is left to chance",
                "make|add|propose|accept",
                examples="""
        archvow decision make <component> <n> "<the answer>"
        archvow decision add <component> "<a new question>" "<its answer>"
        """)
    p = command("make", cmd_decision_make, "answer questions by number (archvow show lists them)", True,
                parent=dsub, examples="""
        archvow decision make <component> 1 "<the answer>"
        archvow decision make <component> 1                      # the suggested answer (archvow show shows it)
        archvow decision make <component> 3,4 "<the same answer to questions 3 and 4>"
        archvow decision make <component> P1 "<purpose of the processing>"     # P: personal data, O: operations
        archvow decision make --type writer 3 "<one answer for every writer>"   # today's and later ones
        archvow decision make --type writer 3 --unset                          # each writer answers again
        """)
    p.add_argument("component", help=component_help + " (with --type: the question's number)")
    p.add_argument("question", metavar="number", nargs="?",
                   help="the question's number in archvow show: 1, 3,4, P1 or O2 (with --type: the answer)")
    p.add_argument("answer", nargs="?", help="the decision, in plain words; it becomes a test "
                   "(none: the template's suggested answer, when it gives one)")
    p.add_argument("--type", metavar="TYPE",
                   help="answer the question once for every component of this type, today's and later ones "
                        "(an architect's decision; a component's own answer still wins)")
    p.add_argument("--unset", action="store_true",
                   help="with --type: no longer answer it for the whole type (each component answers it again)")
    p = command("propose", cmd_decision_propose, "the AI's answer to an open question, for a person to review "
                "(mode guided or free)", True, parent=dsub, examples="""
        archvow decision propose <component> 6 "<the answer the AI chose>"     # then it goes on
        archvow decision accept <component> 6                                  # a person reviews it
        """)
    p.add_argument("component", help=component_help)
    p.add_argument("question", metavar="number", help="the question's number in archvow show")
    p.add_argument("answer", help="the answer the AI chose, in plain words")
    p = command("accept", cmd_decision_accept, "accept what the AI proposed: it becomes a decision (a person, "
                "never the AI)", True, parent=dsub, examples="archvow decision accept <component> 6")
    p.add_argument("component", help=component_help)
    p.add_argument("number", type=int, help="the question's number in archvow show")
    p = command("add", cmd_decision_add, "add a question the template does not ask, with its answer", True,
                parent=dsub, examples='archvow decision add <component> "<a new question>" "<its answer>"')
    p.add_argument("component", help=component_help)
    p.add_argument("question", help="the new question")
    p.add_argument("answer", help="the decision, in plain words; it becomes a test")
    p.add_argument("--from", dest="source", metavar="BRIEF",
                   help="the brief it is drawn from: briefs/<file>.md, or briefs/<file>.md#<section> (a heading); "
                        "archvow check warns when that text changes (ARCH039)")

    rsub = noun("rule", "a rule of what components do, in plain words (R1, R2... for the project)",
                "add|edit|remove", examples="""
        archvow rule add <component> "<a rule in your own words>"
        archvow rule edit R3 "<the new text>"
        archvow rule remove R3
        """)
    p = command("add", cmd_rule_add, "record a rule for one or more components, a type, or all", True,
                parent=rsub, examples="""
        archvow rule add <component> "<a rule in your own words>"
        archvow rule add <component>,<component> "Given <situation>, when <action>, then <result>"
        archvow rule add <component> "When <trigger>, <component> <response>"
        archvow rule add --type reader "<a rule for every reader, today and later>"
        archvow rule add --all "<a rule for every component>"
        """)
    p.add_argument("words", nargs="+", metavar="ARG",
                   help='<component>[,<component>...] "rule", or only "rule" with --type/--all')
    scope = p.add_mutually_exclusive_group()
    scope.add_argument("--type", metavar="TYPE", help="every component of this type, including later ones")
    scope.add_argument("--all", action="store_true", help="every component")
    p.add_argument("--from", dest="source", metavar="BRIEF",
                   help="the brief it is drawn from: briefs/<file>.md, or briefs/<file>.md#<section> (a heading); "
                        "archvow check warns when that text changes (ARCH039)")
    p = command("edit", cmd_rule_edit, "change a rule's text (its scope stays)", True, parent=rsub,
                examples='archvow rule edit R3 "<the new text>"')
    p.add_argument("id", metavar="RULE", help="the rule's id, e.g. R3")
    p.add_argument("text", help="the new text")
    p = command("remove", cmd_rule_remove, "remove a rule (asks first)", True, parent=rsub,
                examples="archvow rule remove R3")
    p.add_argument("id", metavar="RULE", help="the rule's id, e.g. R3")
    p.add_argument("--yes", action="store_true", help="do not ask for confirmation (scripts)")

    asub = noun("assumption", "what the implementer assumed: recorded, then accepted or rejected by a person",
                "add|accept|reject", examples="""
        archvow assumption add <component> "<what was assumed>"
        archvow show <component>                           # lists the assumptions
        archvow assumption accept <component> 1            # a person, never the AI (or: reject)
        """)
    p = command("add", cmd_assumption_add, "record an implementer assumption (blocks until accepted)", True,
                parent=asub, examples='archvow assumption add <component> "<what was assumed>"')
    p.add_argument("component", help=component_help)
    p.add_argument("text", help="what the implementer assumed")
    for name, status in (("accept", "accepted"), ("reject", "rejected")):
        p = command(name, lambda a, s=status: cmd_assumption_review(a, s),
                    f"{name} assumption number N (a person, never the AI)", True, parent=asub,
                    examples=f"archvow show <component>      # lists the assumptions\n"
                             f"archvow assumption {name} <component> 1")
        p.add_argument("component", help=component_help)
        p.add_argument("number", type=int, help="assumption number, as archvow show shows it")

    bsub = noun("brief", "the documents the spec is drawn from (briefs/): record a reviewed change", "accept",
                examples="""
        archvow component add reader sales -d "..." --from briefs/sales.md#input-files
        archvow check                                   # ARCH039 when that section changes
        archvow brief accept briefs/sales.md#input-files     # reviewed: record its new text
        """)
    p = command("accept", cmd_brief_accept, "the brief changed and what was drawn from it is reviewed: record its "
                "new text (a person, never the AI)", True, parent=bsub, examples="""
        archvow brief accept briefs/sales.md#input-files     # one section
        archvow brief accept briefs/sales.md                 # every item drawn from the file
        """)
    p.add_argument("brief", metavar="BRIEF", help="briefs/<file>.md, or briefs/<file>.md#<section>")

    # ---- safety analysis
    hsub = noun("hazard", "what must never happen: record, dismiss or remove a hazard", "add|dismiss|remove",
                examples="""
        archvow show <component>              # the numbered safety questions S1, S2...
        archvow hazard add <component> <number> <severity> "<what must never happen>"
        archvow hazard dismiss <component> <number> "<why it cannot happen here>"
        archvow hazard remove <component> H1
        """)
    hp = command("add", cmd_hazard_add, "record what must never happen", True, parent=hsub,
                 details=_guide_words_details, examples="""
        archvow hazard add <component> S2 high "<what must never happen>"
        archvow hazard add system <number> critical "<what must never happen to the whole system>"
        """)
    hp.add_argument("component", help="component id, or 'system' for the whole system")
    hp.add_argument("guide_word", metavar="number", help="the safety question's number in archvow show, S2 or 2 "
                    "(or its guide word, listed below)")
    hp.add_argument("severity", choices=["critical", "high", "medium", "low"],
                    help="critical | high | medium | low")
    hp.add_argument("description", nargs="?", help="what must never happen, in plain words (default: the "
                    "suggestion archvow show shows; for critical or high, its invariant is added too)")
    hp = command("dismiss", cmd_hazard_dismiss, "record that a guide word does not apply, and why", True,
                 parent=hsub, details=_guide_words_details,
                 examples='archvow hazard dismiss <component> S3 "<why it cannot happen here>"')
    hp.add_argument("component", help="component id, or 'system'")
    hp.add_argument("guide_word", metavar="number", help="the safety question's number in archvow show, S2 or 2 "
                    "(or its guide word, listed below); several: S2,S4")
    hp.add_argument("rationale", help="why it cannot happen here")
    hp = command("remove", cmd_hazard_remove, "remove a hazard, or undo a \"not applicable\" (asks first)", True,
                 parent=hsub, examples="""
        archvow hazard remove <component> H1        # its invariants stay, no longer pointing to it
        archvow hazard remove <component> S2        # undo a "not applicable": safety question S2 is open again
        """)
    hp.add_argument("id", metavar="WHAT", help="the component (then H<n> or S<n>), or the hazard's id <component>.H1")
    hp.add_argument("question", nargs="?", metavar="H<n>|S<n>",
                    help="with a component: its hazard H<n>, or the safety question S<n> marked not applicable")
    hp.add_argument("--yes", action="store_true", help="do not ask for confirmation (scripts)")

    p = command("invariant", None, "what must always hold, so a hazard cannot happen", examples="""
        archvow invariant add <component> "<what always holds>"
        archvow invariant remove <component> INV1
        """)
    isub = p.add_subparsers(dest="invariant_command", required=True, metavar="add|remove",
                            help="archvow invariant add|remove --help: options and examples")
    ip = command("add", cmd_invariant_add, "add an invariant guarding one or more hazards", True, parent=isub,
                 details=lambda _parser: VERIFY_HELP, examples="""
        archvow invariant add <component> "<what always holds>"        # its hazard, the usual proof
        archvow invariant add <component> "<what always holds>" --prevents H2
        archvow invariant add <component> "<what always holds>" --prevents orders_reader.H1   # another component's
        """)
    ip.add_argument("component", help="component id, or 'system'")
    ip.add_argument("statement", help="the property, in plain words; it must be checkable")
    ip.add_argument("--prevents", metavar="IDS", help="the hazard(s) it prevents: H1 (this component's), orders_reader.H1 (another's) (default: the "
                    "component's one hazard that no invariant prevents yet)")
    ip.add_argument("--verify", metavar="METHOD",
                    choices=["static", "example_test", "property_test", "runtime", "model_check", "proof"],
                    help=argparse.SUPPRESS)  # experts: runtime, static, model_check, proof (docs: Rules)
    ip.add_argument("--evidence", metavar="FILE", help=argparse.SUPPRESS)
    ip.add_argument("--rule", help=argparse.SUPPRESS)
    ip = command("remove", cmd_invariant_remove, "remove an invariant (never the last guard of a critical or high "
                 "hazard; asks first)", True, parent=isub, examples="archvow invariant remove <component> INV1")
    ip.add_argument("id", metavar="WHAT", help="the component, then INV<n> (or the id <component>.INV1)")
    ip.add_argument("more", nargs="?", metavar="INV<n>", help="the invariant's number in that component, e.g. INV1")
    ip.add_argument("--yes", action="store_true", help="do not ask for confirmation (scripts)")

    # ---- personal data and third parties
    ksub = noun("column", "personal data: classify columns, or say a component removes or pseudonymises them",
                "set", examples='archvow column set <schema> <column,...> personal|special|none')
    p = command("set", cmd_column_set, "classify columns: personal, special (GDPR art. 9) or none", True,
                parent=ksub, examples="""
        archvow column set <schema> customer_email,phone personal
        archvow column set <schema> diagnosis special             # health, religion, biometrics... (art. 9)
        archvow column set <schema> order_id,amount none
        archvow column set <transformation> phone --removes        # dropped before the data is written
        archvow column set <transformation> customer_email --pseudonymises
        """)
    p.add_argument("component", help="a schema or model component (classes); any component for --removes / "
                   "--pseudonymises")
    p.add_argument("names", help="column names, separated by commas")
    p.add_argument("kind", nargs="?", choices=["personal", "special", "none"], help="personal | special | none")
    flow = p.add_mutually_exclusive_group()
    flow.add_argument("--removes", action="store_true", help="this component drops these columns")
    flow.add_argument("--pseudonymises", action="store_true", help="this component pseudonymises or encrypts them")

    p = command("dependency", None, "the third-party register (DORA): supplier, licence, criticality", examples="""
        archvow dependency add pyspark --supplier "Apache Software Foundation" --licence Apache-2.0 --criticality critical
        archvow dependency remove pyspark
        """)
    dsub = p.add_subparsers(dest="dependency_command", required=True, metavar="add|remove",
                            help="archvow dependency add|remove --help: options and examples")
    dp = command("add", cmd_dependency_add, "record a package of requirements.txt in the register", True,
                 parent=dsub, examples='archvow dependency add fastapi --supplier "Sebastián Ramírez (tiangolo)" '
                                       '--licence MIT --criticality critical')
    dp.add_argument("name", help="the package, as requirements.txt names it")
    dp.add_argument("--supplier", required=True, metavar="WHO", help="who provides and maintains it")
    dp.add_argument("--licence", required=True, metavar="SPDX", help="its licence (SPDX name, e.g. Apache-2.0, MIT)")
    dp.add_argument("--criticality", required=True, choices=["critical", "important", "minor"], metavar="LEVEL",
                    help="critical (the service stops without it; pinned with ==) | important | minor")
    dp = command("remove", cmd_dependency_remove, "remove a package from the register", True, parent=dsub,
                 examples="archvow dependency remove requests")
    dp.add_argument("name", help="the package")

    esub = noun("example", "a business example: this input gives this result, locked by its fingerprint",
                "add|remove", examples="""
        archvow example add <component> <example> -s <ticket>   # its files: tests/examples/<component>/<example>/
        archvow example remove <component> <example>
        """)
    p = command("add", cmd_example_add, "record an example whose files are in tests/examples/<component>/<example>/ "
                "(input/ and expected/); run again after its files change", True, parent=esub, examples="""
        archvow example add clean_orders FATTRIB-012-negative-quantity -s FATTRIB-012
        #   tests/examples/clean_orders/FATTRIB-012-negative-quantity/input/orders.csv
        #   tests/examples/clean_orders/FATTRIB-012-negative-quantity/expected/orders.csv
        """)
    p.add_argument("component", help=component_help)
    p.add_argument("name", metavar="example", help="its folder name: letters, digits, - and _, often the ticket first")
    p.add_argument("-s", "--spec", metavar="TICKET", help="the ticket it comes from (e.g. the Jira story)")
    p = command("remove", cmd_example_remove, "remove an example from the spec (its files stay; asks first)", True,
                parent=esub, examples="archvow example remove clean_orders FATTRIB-012-negative-quantity")
    p.add_argument("component", help=component_help)
    p.add_argument("name", metavar="example", help="the example, as archvow show <component> lists it")
    p.add_argument("--yes", action="store_true", help="do not ask for confirmation (scripts)")

    # ---- code
    p = command("prompt", cmd_prompt, "print a component's spec card as a task for an AI assistant", examples="""
        archvow prompt <component>                 # paste into an assistant that cannot read files
        archvow prompt <component>                 # a big card: its next open task (T2 of 3...)
        archvow prompt <component> --task 1        # one task of it
        archvow prompt <component> --clarify       # ask the AI what is unclear (it decides nothing)
        """)
    p.add_argument("component", help=component_help)
    p.add_argument("--task", type=int, metavar="N",
                   help="a card cut into tasks (archvow show lists them): task N instead of the next open one")
    p.add_argument("--clarify", action="store_true",
                   help="ask the AI to list ambiguities as questions instead (it answers none)")
    p = command("next", cmd_next, "planned components in build order, with what each one waits for", True,
                examples="""
        archvow next                     # then, to the AI assistant: implement everything archvow next lists as ready
        archvow next --base develop      # the same, and nothing is ready once the change is too big to review
        """)
    p.add_argument("--base", metavar="REF",
                   help="the branch the merge request targets (main, origin/main): counts the change against its "
                        "review budget (ARCH022); when it is full, nothing more is ready")

    p = command("check", cmd_check, "verify the code against the spec (exit 1 on errors)", True, examples="""
        archvow check                             # before every commit (the Git hook runs it)
        archvow check --base origin/main          # merge request: no guard weakened
        archvow check --complete                  # release gate: everything planned is built
        """)
    p.add_argument("--file", help="only report violations for this file (an IDE, or an AI checking the file it writes)")
    p.add_argument("--stdin", action="store_true", help="read --file content from stdin (unsaved buffer)")
    p.add_argument("--base", metavar="REF", help="git ref to compare guards with, e.g. origin/main")
    p.add_argument("--accept-weakening", action="store_true",
                   help="report ARCH020 as a warning (pass only after architect approval)")
    p.add_argument("--complete", action="store_true",
                   help="also fail on planned components not built yet (release gate)")
    p.add_argument("--all", action="store_true",
                   help="list every warning one by one (by default the open safety questions, ARCH035, and "
                        "the tests not marked with their decision or rule, ARCH038, are counted on one line)")
    p.add_argument("--test-report", metavar="JUNIT_XML",
                   help="pytest's JUnit report (pytest --junitxml=...): every invariant's test must have run and "
                        "passed (DORA004)")

    p = command("review", cmd_ai_review, "have an approved AI reviewer review the change, without a person "
                "(CI; it never changes code)", True, examples="""
        archvow review --base origin/main                      # merge request: report in reviews/last-change.md
        archvow review --base origin/main --acknowledged       # a person has read the HIGH findings
        """)
    p.add_argument("--base", required=True, metavar="REF",
                   help="the branch the merge request targets, e.g. origin/main: the components changed since "
                        "then are reviewed")
    p.add_argument("--acknowledged", action="store_true",
                   help="a person has read the report: HIGH findings no longer fail (CI passes it when the "
                        "merge request has the label review-acknowledged)")

    # ---- maintenance
    command("freeze", cmd_freeze, "accept today's violations; only new ones fail from now on", True,
            examples="archvow freeze      # adopting archvow on existing code; commit the result")
    p = command("audit", cmd_audit, "who recorded each decision, hazard and invariant, cross-checked with Git",
                True, examples="archvow audit\narchvow audit --strict      # in CI")
    p.add_argument("--strict", action="store_true", help="exit 1 if any record is flagged")
    p = command("changes", cmd_changes, "what a release contains, merge by merge: ticket, spec, components, "
                "tests, who merged and approved", True, examples="""
        archvow changes --from v1.2.0 --to v1.3.0 --markdown > CHANGES.md
        archvow changes --from v1.2.0                    # up to HEAD
        """)
    p.add_argument("--from", dest="start", required=True, metavar="REF", help="the previous release (a tag or a commit)")
    p.add_argument("--to", dest="end", default="HEAD", metavar="REF", help="the release (default: HEAD)")
    p.add_argument("--markdown", action="store_true", help="Markdown output")
    p = command("diff", cmd_diff, "spec changes since a branch, in plain words (merge-request report)", True,
                examples="archvow diff --base origin/main --markdown")
    p.add_argument("--base", required=True, metavar="REF", help="git ref, e.g. origin/main")
    p.add_argument("--markdown", action="store_true", help="Markdown output for merge-request reports")

    command("doctor", cmd_doctor, "check this machine's setup for the project, with the fix for each problem",
            True, examples="""
        archvow doctor          # Python, archvow (command and version), Git hook, the template's tools
        """)

    p = command("completion", cmd_completion, "Tab completion for your shell (zsh, bash or powershell)",
                examples="""
        archvow completion zsh --install          # zsh, the macOS default: ~/.archvow-completion.zsh + one line in ~/.zshrc
        archvow completion bash --install         # bash: ~/.archvow-completion.bash + one line in ~/.bashrc (~/.bash_profile on macOS)
        archvow completion powershell --install   # PowerShell: ~/.archvow-completion.ps1 + one line in $PROFILE
        archvow completion zsh                    # only print the script
        Run it once, open a new terminal. Then Tab completes commands, options and the project's own names: archvow sp<Tab> -> specify,
        archvow show <Tab> -> its components and rules R1..., then archvow show clean_orders <Tab> -> H1, INV1...
        """)
    p.add_argument("shell", choices=["zsh", "bash", "powershell"], help="the shell to complete in")
    p.add_argument("--install", action="store_true",
                   help="write the script to ~/.archvow-completion.<ext> and load it from the shell's startup file "
                        "(once); it works even when archvow is not on the PATH yet when the shell starts")

    p = command("docs", cmd_docs, "regenerate the specs (committed) and the status report (local)",
                examples="archvow docs\narchvow docs --check      # in CI: views up to date, not edited")
    p.add_argument("--check", action="store_true",
                   help="fail if committed specs are stale or edited by hand (CI)")
    p = command("template", None, "create company or project-local templates",
                examples="archvow template new acme-pyspark --extends pyspark-pipeline --dir ~/archvow-templates")
    tsub = p.add_subparsers(dest="template_command", required=True, metavar="new",
                            help="archvow template new --help: options and examples")
    tp = command("new", cmd_template_new, "create a template that extends another one", parent=tsub,
                 examples="""
        archvow template new acme-pyspark --extends pyspark-pipeline --dir ~/archvow-templates
            # a company template, in the team's catalog (then: export ARCHVOW_TEMPLATES=...)
        archvow template new my-variant --extends pyspark-pipeline
            # inside a project: .archvow/templates/my-variant
        archvow template new acme-pyspark --extends pyspark-pipeline --dir ~/archvow-templates -a ci=jenkins --allowed-paths devops,tools
            # with its settings (also -d, --verbatim-folders, --layer); without options, a terminal asks them
        """)
    tp.add_argument("name", help="name of the new template")
    tp.add_argument("--extends", required=True, metavar="TEMPLATE", help="template it builds on")
    tp.add_argument("--dir", metavar="FOLDER",
                    help="catalog folder to create it in (a company template; no project needed). "
                         "Default: the current project's .archvow/templates/")
    tp.add_argument("-d", "--description", metavar="TEXT", help="what the template is for (one line)")
    tp.add_argument("-a", "--answer", action="append", metavar="KEY=VALUE",
                    help="a company default for an init answer, repeatable (-a ci=jenkins -a sonar=yes); "
                         "a project can still override it")
    tp.add_argument("--allowed-paths", metavar="FOLDERS",
                    help="top folders of Python files that are not components, comma-separated "
                         "(devops,tools): no ARCH015 there; added to the base's")
    tp.add_argument("--verbatim-folders", metavar="FOLDERS", dest="verbatim_folders",
                    help="folders of files/ copied exactly as they are, .j2 included, comma-separated "
                         "(templates,deploy/ansible)")
    tp.add_argument("--layer", action="append", metavar="LAYER=FOLDER",
                    help="rename a layer's folder, repeatable (--layer p1_domain=domain): "
                         "src/<package>/domain/, tests/domain/; the others keep the base's")
    tp.add_argument("--no-input", action="store_true",
                    help="never ask: without options, the settings stay commented examples")
    return parser


def _agent_gate(args: argparse.Namespace) -> int:
    """Inside an AI agent in YOLO mode, or outside a sandbox when the project asks for one, archvow
    refuses to run (ARCH052, ARCH051): exit 1 with the fix. `doctor` still says what archvow sees."""
    if getattr(args, "func", None) in (cmd_doctor, cmd_completion, None):
        return 0
    from archvow.agent import gate, gate_outside

    command = args.func.__name__.removeprefix("cmd_").replace("_", " ")
    try:
        root = _root(args)
        data = mf.load(root)
    except mf.ManifestError:  # not in a project yet (init): only a person creates one
        lines = gate_outside(Path(getattr(args, "dir", None) or Path.cwd()), command)
    else:
        lines = gate(root, data, command)
    for line in lines:
        print(ui.error(line) if line.startswith("ARCH") else line, file=sys.stderr)
    return 1 if lines else 0


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    for stream in (sys.stdout, sys.stderr):  # a character the console can't show is replaced, never a crash
        try:
            stream.reconfigure(errors="replace")  # type: ignore[union-attr]
        except (AttributeError, ValueError):
            pass
    if argv[:1] == ["__complete"]:  # what Tab asks: `archvow __complete <shell> <line>` (completion.py)
        from archvow.completion import run

        return run(argv[1] if len(argv) > 1 else "zsh", argv[2] if len(argv) > 2 else "archvow ")
    if not argv:  # `archvow` alone: the icon, the version and the commands
        print(ui.logo(f"archvow {__version__}") + "\n")
        build_parser().print_help()
        return 0
    args = build_parser().parse_args(argv)
    try:
        refused = _agent_gate(args)
        if refused:
            return refused
        return args.func(args)
    except BrokenPipeError:  # output piped into `head` and the like: not an error
        import os

        os.dup2(os.open(os.devnull, os.O_WRONLY), sys.stdout.fileno())
        return 0
    except (SpecError, TemplateError, mf.ManifestError) as exc:
        print(ui.error(f"archvow: error: {exc}"), file=sys.stderr)
        return 2
    except (KeyboardInterrupt, EOFError):  # Ctrl+C or Ctrl+D during a question: no traceback
        print("\n" + ui.error("stopped"), file=sys.stderr)
        return 130


if __name__ == "__main__":
    sys.exit(main())
