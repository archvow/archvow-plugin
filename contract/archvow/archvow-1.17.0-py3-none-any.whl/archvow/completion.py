"""Tab completion for zsh, bash and PowerShell, with the standard library only.

`archvow completion zsh --install` (or `bash`, `powershell`) writes the script to one file in the
home folder (`~/.archvow-completion.zsh`, `.bash`, `.ps1`) and adds one line that loads it to the
shell's startup file, once. Without `--install` the script is printed. On Tab, the script runs
`archvow __complete ...` with the words typed so far - the `archvow` on the PATH, or else the
Python that installed the script - and archvow answers from its own commands and options and from
the project: its components, hazards, invariants, rules, open questions, columns, briefs, the
template's types, kinds and init answers.
"""

from __future__ import annotations

import argparse
import os
import shlex
import sys
from pathlib import Path

SEVERITIES = ["critical", "high", "medium", "low"]
CLASSES = ["personal", "special", "none"]

BASH = r"""# archvow Tab completion (bash) - written by `archvow completion bash --install`
_archvow_run() { if command -v archvow >/dev/null 2>&1; then archvow "$@"; else @FALLBACK@ "$@"; fi; }
_archvow() {
    local IFS=$'\n'
    COMPREPLY=( $(_archvow_run __complete bash "${COMP_LINE:0:$COMP_POINT}" 2>/dev/null) )
    if [ "${#COMPREPLY[@]}" -eq 1 ] && [[ "${COMPREPLY[0]}" == *[=#,] ]]; then
        compopt -o nospace 2>/dev/null
    fi
}
complete -o default -F _archvow archvow
"""

ZSH = r"""# archvow Tab completion (zsh) - written by `archvow completion zsh --install`
_archvow_run() { if (( $+commands[archvow] )); then archvow "$@"; else @FALLBACK@ "$@"; fi; }
_archvow() {
    local -a found
    found=("${(@f)$(_archvow_run __complete zsh "${(j: :)${(@q)words[1,CURRENT-1]}} ${(q)PREFIX}" 2>/dev/null)}")
    [[ -z "${found[1]}" ]] && { _files; return; }
    compadd -Q -S '' -- ${(M)found:#*[=#,]}
    compadd -Q -- ${found:#*[=#,]}
}
_archvow_register() {  # at the first prompt, once ~/.zshrc has run (and its compinit, if any)
    precmd_functions=(${precmd_functions:#_archvow_register})
    (( $+functions[compdef] )) || { autoload -Uz compinit && compinit; }
    compdef _archvow archvow
}
(( $+functions[compdef] )) && compdef _archvow archvow
precmd_functions+=(_archvow_register)
"""

POWERSHELL = r"""# archvow Tab completion (PowerShell) - written by `archvow completion powershell --install`
function global:_ArchvowRun {
    if (Get-Command archvow -CommandType Application -ErrorAction SilentlyContinue) { archvow @args }
    else { & @FALLBACK@ -m archvow @args }
}
Register-ArgumentCompleter -Native -CommandName archvow, archvow.exe -ScriptBlock {
    param($wordToComplete, $commandAst, $cursorPosition)
    $line = $commandAst.ToString()
    $typed = $cursorPosition - $commandAst.Extent.StartOffset
    if ($typed -lt $line.Length) { $line = $line.Substring(0, $typed) }
    if ($wordToComplete -eq '' -and -not $line.EndsWith(',')) { $line += ' ' }  # a new word
    _ArchvowRun __complete powershell "$line" 2>$null | Where-Object { $_ } | ForEach-Object {
        [System.Management.Automation.CompletionResult]::new($_, $_, 'ParameterValue', $_)
    }
}
"""


EXTENSIONS = {"zsh": "zsh", "bash": "bash", "powershell": "ps1"}


def script(shell: str) -> str:
    """The script for `shell`; when `archvow` is not on the PATH at Tab time (a virtual environment not
    activated), it runs this Python's archvow instead."""
    text = {"bash": BASH, "zsh": ZSH, "powershell": POWERSHELL}[shell]
    if shell == "powershell":
        return text.replace("@FALLBACK@", "'" + sys.executable.replace("'", "''") + "'")
    return text.replace("@FALLBACK@", f"{shlex.quote(sys.executable)} -m archvow")


def startup_files(shell: str, home: Path, platform: str = sys.platform) -> list[Path]:
    """The files a shell reads when it starts, where the line that loads the script goes."""
    if shell == "zsh":
        return [Path(os.environ.get("ZDOTDIR") or home) / ".zshrc"]
    if shell == "bash":  # macOS Terminal opens login shells: ~/.bash_profile, not ~/.bashrc
        return [home / ".bash_profile"] if platform == "darwin" else [home / ".bashrc"]
    asked = _powershell_profiles() if platform == sys.platform and home == Path.home() else []
    if asked:  # what each installed PowerShell says $PROFILE is (Documents may live in OneDrive)
        return asked
    if platform.startswith("win"):  # PowerShell 7 and Windows PowerShell 5.1
        documents = home / "Documents"
        return [documents / "PowerShell" / "Microsoft.PowerShell_profile.ps1",
                documents / "WindowsPowerShell" / "Microsoft.PowerShell_profile.ps1"]
    return [home / ".config" / "powershell" / "Microsoft.PowerShell_profile.ps1"]


def _powershell_profiles() -> list[Path]:
    import shutil
    import subprocess

    found = []
    for exe in ("pwsh", "powershell"):
        if not shutil.which(exe):
            continue
        try:
            done = subprocess.run([exe, "-NoLogo", "-NoProfile", "-Command", "$PROFILE"], capture_output=True,
                                  text=True, encoding="utf-8", errors="replace", timeout=20, check=False)
        except (OSError, subprocess.SubprocessError):
            continue
        path = done.stdout.strip()
        if done.returncode == 0 and path and Path(path) not in found:
            found.append(Path(path))
    return found


def install(shell: str, home: Path | None = None, platform: str = sys.platform) -> list[str]:
    """Write ~/.archvow-completion.<ext> and add the line that loads it to the shell's startup files
    (once). Returns what was done, one line each."""
    home = home or Path.home()
    target = home / f".archvow-completion.{EXTENSIONS[shell]}"
    target.write_text(script(shell), encoding="utf-8", newline="\n")
    done = [f"wrote {target}"]
    if shell == "powershell":
        line = f". '{target}'  # archvow Tab completion"
    else:
        line = f"[ -f {shlex.quote(str(target))} ] && . {shlex.quote(str(target))}  # archvow Tab completion"
    for startup in startup_files(shell, home, platform):
        text = startup.read_text(encoding="utf-8") if startup.is_file() else ""
        if str(target) in text:
            done.append(f"{startup} already loads it")
            continue
        startup.parent.mkdir(parents=True, exist_ok=True)
        with startup.open("a", encoding="utf-8", newline="\n") as out:
            out.write(("" if not text or text.endswith("\n") else "\n") + line + "\n")
        done.append(f"added to {startup}: {line}")
    return done


def complete(line: str, parser: argparse.ArgumentParser, root: Path | None) -> list[str]:
    """What may come next on `line` (everything typed up to the cursor, `archvow` first)."""
    try:
        words = shlex.split(line)
    except ValueError:  # an open quote: complete the words as they are
        words = line.split()
    if line.endswith(" ") or not words:
        words.append("")
    words = words[1:] if words and Path(words[0]).name == "archvow" else words
    partial, done = words[-1], words[:-1]
    current, path, positionals, after = _walk(parser, done)
    if after is not None:  # the value of an option: -k, --from, -a, -u...
        found = _option_values(after, path, positionals, partial, root)
    elif partial.startswith("-"):
        found = [o for a in current._actions for o in a.option_strings if a.help != argparse.SUPPRESS]
    else:
        sub = next((a for a in current._actions if isinstance(a, argparse._SubParsersAction)), None)
        if sub is not None:
            found = [name for name, action in sub.choices.items() if not name.startswith("_")]
        else:
            found = _positional_values(path, positionals, partial, root)
    return sorted(dict.fromkeys(f for f in found if f.startswith(partial)))


def _walk(parser: argparse.ArgumentParser, words: list[str]):
    """The parser the words reach, its command path, the positionals given, and the option waiting
    for its value (or None)."""
    current, path, positionals, waiting = parser, [], [], None
    for word in words:
        if waiting is not None:
            waiting = None
            continue
        sub = next((a for a in current._actions if isinstance(a, argparse._SubParsersAction)), None)
        if sub is not None and word in sub.choices:
            current, path, positionals = sub.choices[word], [*path, word], []
            continue
        if word.startswith("-"):
            action = next((a for a in current._actions if word.split("=")[0] in a.option_strings), None)
            if action is not None and action.nargs != 0 and "=" not in word:
                waiting = action
            continue
        positionals.append(word)
    return current, path, positionals, waiting


def _project(root: Path | None):
    """The manifest and the template of the project, or (None, None) outside one."""
    if root is None:
        return None, None
    try:
        from archvow import manifest as mf
        from archvow.templates import load_template

        data = mf.load(root)
        return data, load_template(mf.template_name(data["containers"][0])[0], root)
    except Exception:  # noqa: BLE001 - completion never fails the shell
        return None, None


def _components(data: dict | None) -> list[dict]:
    return [c for container in (data or {}).get("containers", []) for c in container.get("components", [])]


def _component(data: dict | None, cid: str) -> dict:
    return next((c for c in _components(data) if c["id"] == cid), {})


def _items(data: dict | None, kind: str, cid: str | None = None) -> list[str]:
    """Rules R1...; with a component: its hazards (H1...) or invariants (INV1...), as typed after it."""
    if kind in ("hazard", "invariant"):
        key = "hazards" if kind == "hazard" else "invariants"
        return [str(i["id"]).split(".", 1)[-1] for i in (data or {}).get(key) or []
                if (i.get("component") or "system") == cid]
    return [r["id"] for r in (data or {}).get("project_rules") or []]


def _open_decisions(data: dict | None, cid: str) -> list[str]:
    return [str(n) for n, d in enumerate(_component(data, cid).get("decisions") or [], 1)
            if not (d.get("answer") or "").strip()]


def _open_safety(data: dict | None, template, cid: str) -> list[str]:
    from archvow import manifest as mf
    from archvow.specs import safety_questions

    comp = _component(data, cid)
    if not comp or template is None:
        return []
    answered = mf.answered_safety(data)
    return [f"S{n}" for n, word in enumerate(safety_questions(template, comp), 1) if (cid, word) not in answered]


def _dismissed(data: dict | None, template, cid: str) -> list[str]:
    from archvow.specs import safety_questions

    comp = _component(data, cid)
    words = safety_questions(template, comp) if comp and template is not None else []
    gone = {d.get("guide_word") for d in (data or {}).get("dismissed") or [] if d.get("component") == cid}
    return [f"S{n}" for n, word in enumerate(words, 1) if word in gone]


def _columns(root: Path, data: dict | None, template, cid: str) -> list[str]:
    from archvow import manifest as mf
    from archvow.privacy import code_columns

    comp = _component(data, cid)
    names = list(comp.get("columns") or {})
    ctype = template.type_of(comp) if comp and template is not None else {}
    if ctype.get("columns"):
        container = next(c for c in data["containers"] if comp in c.get("components", []))
        names += [n for n, _ in code_columns(root / mf.source_path(container, comp), ctype["columns"])]
    return list(dict.fromkeys(names))


def _list_value(partial: str, values: list[str]) -> list[str]:
    """A comma list (`-u a,b`, `ARCH,SPARK`): complete its last item."""
    head, _, _ = partial.rpartition(",")
    done = set(head.split(",")) if head else set()
    return [f"{head},{v}" if head else v for v in values if v not in done]


def _briefs(root: Path | None, data: dict | None, template, partial: str) -> list[str]:
    from archvow import briefs

    if root is None:
        return []
    files = [p.relative_to(root).as_posix() for p in briefs.brief_files(root, data or {})]
    if "#" in partial:
        file = partial.split("#", 1)[0]
        path = root / file
        if path.is_file():
            return [f"{file}#{s}" for s in briefs.sections(path.read_text(encoding="utf-8", errors="replace"))]
        return []
    return [f"{f}#" if f.endswith(".md") else f for f in files]


def _option_values(action: argparse.Action, path: list[str], positionals: list[str], partial: str,
                   root: Path | None) -> list[str]:
    data, template = _project(root)
    option = action.option_strings[-1]
    if action.choices:
        return [str(c) for c in action.choices]
    if option == "--kind":
        return template.kinds(positionals[0]) if template is not None and positionals else []
    if option == "--from" and path and path[0] != "changes":
        return _briefs(root, data, template, partial)
    if option == "--uses":
        return _list_value(partial, [c["id"] for c in _components(data)])
    if option == "--template":
        from archvow.templates import discover

        return list(discover(root))
    if option == "--answer":
        return _init_answers(root, template, partial)
    return []


def _init_answers(root: Path | None, template, partial: str) -> list[str]:
    """`-a key=value`: the template's answers, then their values."""
    from archvow.specs import DEFAULT_TEMPLATE, resolved_choices
    from archvow.templates import load_template

    template = template or load_template(DEFAULT_TEMPLATE, None)
    questions = {q["id"]: q for q in template.data.get("questions", [])}
    if "=" not in partial:
        return [f"{qid}=" for qid in questions]
    key, _, value = partial.partition("=")
    question = questions.get(key)
    choices = [str(c) for c in (resolved_choices(template, question) or [])] if question else []
    if question and question.get("multiple"):
        return [f"{key}={v}" for v in _list_value(value, choices)]
    return [f"{key}={c}" for c in choices]


def _positional_values(path: list[str], positionals: list[str], partial: str, root: Path | None) -> list[str]:
    data, template = _project(root)
    ids = [c["id"] for c in _components(data)]
    n = len(positionals)
    command = " ".join(path)
    first = positionals[0] if positionals else ""
    if command == "completion":
        return ["bash", "powershell", "zsh"] if n == 0 else []
    if command == "show":
        if n == 0:
            return [*ids, *_items(data, "rule")]
        return [*_items(data, "hazard", first), *_items(data, "invariant", first)] if n == 1 else []
    if command in ("specify", "prompt", "component edit", "component remove", "question add", "decision add",
                   "assumption add"):
        return ids if n == 0 else []
    if command == "component add":
        if n == 0 and template is not None:
            return [k for k, v in template.component_types.items() if v.get("addable", True)]
        return []
    if command in ("decision make", "decision propose"):
        if n == 0:
            return ids
        if n == 1:
            from archvow.questions import component_questions

            extra = []
            comp = _component(data, first)
            if comp and template is not None and root is not None:
                try:
                    extra = [q["key"] for q in component_questions(root, data, comp, template) if not q.get("answer")]
                except Exception:  # noqa: BLE001 - completion never fails the shell
                    extra = []
            return [*_open_decisions(data, first), *extra]
        return []
    if command == "decision accept":
        if n == 0:
            return ids
        from archvow import proposals

        return [str(p["number"]) for p in proposals.load(root) if p["component"] == first] if n == 1 and root else []
    if command == "question remove":
        return ids if n == 0 else [str(i) for i in range(1, len(_component(data, first).get("decisions") or []) + 1)]
    if command in ("assumption accept", "assumption reject"):
        if n == 0:
            return ids
        return [str(i) for i, a in enumerate(_component(data, first).get("assumptions") or [], 1)
                if a.get("status") != ("accepted" if path[-1] == "accept" else "rejected")] if n == 1 else []
    if command == "hazard add":
        return [*ids, "system"] if n == 0 else _open_safety(data, template, first) if n == 1 else \
            SEVERITIES if n == 2 else []
    if command == "hazard dismiss":
        return [*ids, "system"] if n == 0 else _list_value(partial, _open_safety(data, template, first)) if n == 1 else []
    if command == "hazard remove":
        return ids if n == 0 else [*_items(data, "hazard", first), *_dismissed(data, template, first)] if n == 1 else []
    if command == "invariant add":
        return [*ids, "system"] if n == 0 else []
    if command == "invariant remove":
        return ids if n == 0 else _items(data, "invariant", first) if n == 1 else []
    if command == "rule add":
        return _list_value(partial, ids) if n == 0 else []
    if command in ("rule edit", "rule remove"):
        return _items(data, "rule") if n == 0 else []
    if command == "column set":
        if n == 0:
            return ids
        if n == 1:
            return _list_value(partial, _columns(root, data, template, first)) if root else []
        return CLASSES if n == 2 else []
    if command == "dependency add":
        from archvow.dora import unregistered

        return unregistered(root, data) if n == 0 and root and data else []
    if command == "dependency remove":
        return [e.get("name", "") for e in (data or {}).get("third_parties") or []] if n == 0 else []
    if command == "brief accept":
        return _briefs(root, data, template, partial) if n == 0 else []
    return []


def run(shell: str, line: str) -> int:
    """`archvow __complete <shell> <line>`: one candidate per line. In bash, a word stops at `=` and
    `:` (COMP_WORDBREAKS), in PowerShell at `,`: only what follows the last one is printed."""
    from archvow import manifest as mf
    from archvow.cli import build_parser

    try:
        root = mf.find_root(Path.cwd())
    except Exception:  # noqa: BLE001 - completion never fails the shell
        root = None
    try:
        found = complete(line, build_parser(), root)
    except Exception:  # noqa: BLE001 - completion never fails the shell
        found = []
    partial = "" if line.endswith(" ") else (line.split() or [""])[-1]
    cut = {"bash": max(partial.rfind("="), partial.rfind(":")) + 1,  # where each shell starts the word
           "powershell": partial.rfind(",") + 1}.get(shell, 0)
    print("\n".join(f[cut:] for f in found))
    return 0
