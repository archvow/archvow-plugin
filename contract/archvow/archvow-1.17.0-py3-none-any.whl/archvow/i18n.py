"""Translations of the texts archvow writes into a project (specs, status report, guide files).

archvow itself - its commands, options, --help and messages - stays in English. What it
generates for a project follows the project's language (`language` in .archvow/spec.vow, English when
absent). The English text is the key: `tr("fr", "## Must never happen")`. Keywords stay as
they are in every language: rule codes, statuses, severities, guide words, verification methods.
"""

from __future__ import annotations

LANGUAGES = ("en", "fr")

FR: dict[str, str] = {
    "  - prevented by **{id}**: {statement}": "  - empêché par **{id}** : {statement}",
    "  - prevents: {hazards}": "  - empêche : {hazards}",
    "  - tested by: {how}": "  - testé par : {how}",
    "  - prevented by nothing yet: do not invent a guard; say so in your answer.": "  - empêché par rien pour l'instant : n'inventez pas de garde ; dites-le dans votre réponse.",
    "# Hazards - {name}": "# Dangers - {name}",
    "# Invariants - {name}": "# Invariants - {name}",
    "## Not applicable": "## Sans objet",
    "- Nothing: the safety analysis found nothing this component must guard against.": "- Rien : l'analyse de sûreté n'a rien trouvé dont ce composant doive se protéger.",
    "- Safety questions still open (archvow show {id}) - do not invent hazards or guards; say in your answer that they are open:": "- Questions de sûreté encore ouvertes (archvow show {id}) - n'inventez ni dangers ni gardes ; dites dans votre réponse qu'elles sont ouvertes :",
    "An invariant of an implemented component is not tested yet": "Un invariant d'un composant implémenté n'est pas encore testé",
    "An invariant's test is not of the kind it requires": "Le test d'un invariant n'est pas du type qu'il exige",
    "Critical/high hazard that no invariant prevents": "Danger critique/élevé qu'aucun invariant n'empêche",
    "Invalid hazard, dismissal, invariant or project rule entry": "Danger, mise à l'écart, invariant ou règle du projet invalide",
    "Invariant tested too weakly for the hazard's severity": "Invariant testé trop faiblement pour la gravité du danger",
    "Legend: grey planned, yellow implemented, blue tested, green verified (all invariants tested), red drift.": "Légende : gris prévu, jaune implémenté, bleu testé, vert vérifié (tous les invariants testés), rouge dérive.",
    "Safety question of a component not answered (no hazard, no dismissal)": "Question de sûreté d'un composant sans réponse (ni danger, ni mise à l'écart)",
    "A decision or rule of an implemented component has no marked test":
        "Une décision ou une règle d'un composant implémenté n'a pas de test marqué",
    "A brief changed after the spec was drawn from it": "Un brief a changé après qu'on en a tiré la spec",
    "Package in requirements.txt or pyproject.toml without approval (an error in mode strict)":
        "Paquet dans requirements.txt ou pyproject.toml sans approbation (une erreur en mode strict)",
    "A test marked as evidence checks nothing (an error in mode strict and with --complete)":
        "Un test marqué comme preuve ne vérifie rien (une erreur en mode strict et avec --complete)",
    "A marked test did not run and pass in the test report (check --test-report)":
        "Un test marqué n'a pas tourné et réussi dans le rapport de tests (check --test-report)",
    "A business example's files differ from the ones a person recorded":
        "Les fichiers d'un exemple métier diffèrent de ceux qu'une personne a enregistrés",
    "A business example has no marked test (an error in mode strict and with --complete)":
        "Un exemple métier n'a pas de test marqué (une erreur en mode strict et avec --complete)",
    " (the same for every {type})": " (la même pour chaque {type})",
    "## Examples (reproduce exactly)": "## Exemples (à reproduire exactement)",
    ("Given by the business team. For each one, a test reads `input/`, runs the component and compares what it "
     "gives with `expected/`. Never change these files: archvow compares them with the ones a person recorded "
     "(ARCH055); an example that looks wrong is a question for a person."):
        ("Donnés par le métier. Pour chacun, un test lit `input/`, lance le composant et compare ce qu'il donne "
         "avec `expected/`. Ne modifiez jamais ces fichiers : archvow les compare avec ceux qu'une personne a "
         "enregistrés (ARCH055) ; un exemple qui semble faux est une question pour une personne."),
    "its test is marked {mark}": "son test est marqué {mark}",
    "- Used by: {users} - their tests must stay green.": "- Utilisé par : {users} - leurs tests doivent rester verts.",
    "- The tests of the components that use it still pass.":
        "- Les tests des composants qui l'utilisent passent toujours.",
    "- Every example above has its marked test, and its files are the ones recorded.":
        "- Chaque exemple ci-dessus a son test marqué, et ses fichiers sont ceux qui ont été enregistrés.",
    "A component's task is too long for one AI session (over max_tokens)":
        "La tâche d'un composant est trop longue pour une session d'IA (au-delà de max_tokens)",
    "A decision the AI proposed is not reviewed by a person yet (an error at the release gate in mode guided)":
        "Une décision proposée par l'IA n'est pas encore relue par une personne (une erreur au contrôle de "
        "livraison en mode guided)",
    "A file in .archvow/ that archvow does not write (nobody owns it in CODEOWNERS)":
        "Un fichier dans .archvow/ qu'archvow n'écrit pas (personne n'en est propriétaire dans CODEOWNERS)",
    "An AI agent runs archvow outside a sandbox (it can write outside the project)":
        "Un agent IA lance archvow hors d'un sandbox (il peut écrire hors du projet)",
    "An AI agent runs archvow in YOLO mode (it acts without asking anyone)":
        "Un agent IA lance archvow en mode YOLO (il agit sans rien demander à personne)",
    "An AI agent runs a command only a person runs (it decides or changes the spec)":
        "Un agent IA lance une commande que seule une personne lance (elle décide ou change la spec)",
    "Code an AI agent wrote, with no proof it ran protected (an error when it ran blocked, or in mode strict)":
        "Du code écrit par un agent IA, sans preuve qu'il tournait protégé (une erreur quand archvow l'a "
        "arrêté, ou en mode strict)",
    "Safety questions that cannot happen here, and why.": "Les questions de sûreté qui ne peuvent pas arriver ici, et pourquoi.",
    "What is always true, so a hazard cannot happen (Hazards, above), and what checks it. `archvow check` fails while a coded component's invariant is not tested.": "Ce qui est toujours vrai, pour qu'un danger ne puisse pas arriver (Dangers, plus haut), et ce qui le vérifie. `archvow check` échoue tant que l'invariant d'un composant codé n'est pas testé.",
    "What must never happen, and the invariant that prevents it (what is always true, so it cannot happen: Invariants, below). A critical or high hazard needs one; medium and low may have one.": "Ce qui ne doit jamais arriver, et l'invariant qui l'empêche (ce qui est toujours vrai, pour que ça ne puisse pas arriver : Invariants, plus bas). Un danger critique ou élevé en exige un ; moyen et faible peuvent en avoir un.",
    "a Hypothesis @given test decorated with @pytest.mark.invariant(\"{id}\") (it searches for counterexamples, not one example)": "un test Hypothesis @given décoré de @pytest.mark.invariant(\"{id}\") (il cherche des contre-exemples, pas un seul exemple)",
    "a Hypothesis @given test marked @pytest.mark.invariant(\"{id}\")": "un test Hypothesis @given marqué @pytest.mark.invariant(\"{id}\")",
    "a guard in the code marked `# archvow: enforces[{id}]`": "une garde dans le code marquée `# archvow: enforces[{id}]`",
    "a test marked @pytest.mark.invariant(\"{id}\")": "un test marqué @pytest.mark.invariant(\"{id}\")",
    "archvow check rule {rule}": "la règle archvow {rule}",
    "the model {evidence}, checked in CI": "le modèle {evidence}, vérifié en CI",
    "the proof {evidence}, checked in CI": "la démonstration {evidence}, vérifiée en CI",
    "| Component | Question | Why it cannot happen here |": "| Composant | Question | Pourquoi ça ne peut pas arriver ici |",
    "| Hazard | Component | Severity | What must never happen | Prevented by |": "| Danger | Composant | Gravité | Ce qui ne doit jamais arriver | Empêché par |",
    "| Invariant | Component | Always true | Prevents | Tested by |": "| Invariant | Composant | Toujours vrai | Empêche | Testé par |",
    "| Invariant | Component | Tested | Tested by |": "| Invariant | Composant | Testé | Testé par |",
    "**nothing yet**: archvow invariant add {c} \"...\" --prevents {id}": "**rien pour l'instant** : archvow invariant add {c} \"...\" --prevents {id}",
    "- (optional for {severity})": "- (facultatif pour {severity})",
    "{answer} (decision {number})": "{answer} (décision {number})",
    # ---- headers of generated files
    "<!-- Generated by archvow. Do not edit. -->": "<!-- Généré par archvow. Ne pas modifier. -->",
    "<!-- archvow spec of {id} - the task the AI or the developer implements. Generated from spec.vow in this folder, do not edit. -->":
        "<!-- archvow spec de {id} - la tâche que l'IA ou le développeur implémente. Générée à partir du spec.vow "
        "de ce dossier, ne pas modifier. -->",
    "<!-- archvow spec of the project - all components, rules, hazards and checks on one page. Generated from the vows (.archvow/spec.vow, .archvow/components/), do not edit. -->":
        "<!-- archvow spec du projet - tous les composants, règles, dangers et contrôles sur une page. Générée à "
        "partir des engagements (.archvow/spec.vow, .archvow/components/), ne pas modifier. -->",
    "<!-- archvow status - what the code does today against the spec. Generated from the vows and the code; local report, not committed (gitignored). -->":
        "<!-- archvow état - ce que fait le code aujourd'hui par rapport à la spec. Généré à partir des "
        "engagements et du code ; rapport local, non commité (gitignoré). -->",
    "# {name} - the project's spec": "# {name} - la spec du projet",
    "Each component's own spec (its task): `.archvow/components/<component>/spec.md`, or `archvow show <component>`.":
        "La spec de chaque composant (sa tâche) : `.archvow/components/<composant>/spec.md`, ou "
        "`archvow show <composant>`.",
    "## Checks": "## Contrôles",
    "What `archvow check` verifies on every component's code, family by family (the families the project turned on). Severity shown is the effective one (template defaults + the `rules` overrides of .archvow/spec.vow). Silence a single line only with a reason: `# archvow: ignore[CODE] -- why`.":
        "Ce que `archvow check` vérifie sur le code de chaque composant, famille par famille (les familles que "
        "le projet a activées). La gravité affichée est la gravité effective (valeurs du template + "
        "surcharges `rules` de .archvow/spec.vow). On ne fait taire une seule ligne qu'avec une raison : "
        "`# archvow: ignore[CODE] -- pourquoi`.",
    "- Checks on this code: {families} - what each one checks: `.archvow/spec.md` (Checks).":
        "- Contrôles sur ce code : {families} - ce que chacun vérifie : `.archvow/spec.md` (Contrôles).",
    # ---- spec card
    "# Task: implement `{id}` ({type}){spec}": "# Tâche : implémenter `{id}` ({type}){spec}",
    "Current status: **{status}**.": "Statut actuel : **{status}**.",
    "## STOP - decisions still to make": "## STOP - décisions encore à prendre",
    "Do **not** implement this component and do not pick a reasonable default. Ask the human these "
    "questions and wait. They record each answer with `archvow decision make {id} <number> \"<answer>\"`. "
    "When the description, a brief or the conversation already answers one, do not ask it: give that command "
    "with the answer in it, for the human to check and run.":
        "N'implémentez **pas** ce composant et ne choisissez pas une valeur par défaut « raisonnable ». "
        "Posez ces questions à une personne et attendez. Elle enregistre chaque réponse avec "
        "`archvow decision make {id} <numéro> \"<réponse>\"`. Quand la description, un brief ou la "
        "conversation répond déjà à l'une d'elles, ne la posez pas : donnez cette commande avec la réponse, "
        "pour que la personne la vérifie et la lance.",
    "Known columns (classified in the spec): {names}": "Colonnes connues (classées dans la spec) : {names}",
    "## Must never happen": "## Ne doit jamais arriver",
    " (system-wide)": " (tout le système)",
    "  - guards against: {hazards}": "  - protège contre : {hazards}",
    "  - required evidence: {how}": "  - preuve exigée : {how}",
    'a pytest test decorated with @pytest.mark.invariant("{id}")':
        'un test pytest décoré par @pytest.mark.invariant("{id}")',
    'a Hypothesis @given test decorated with @pytest.mark.invariant("{id}") (it must search for '
    "counterexamples, not check one example)":
        'un test Hypothesis @given décoré par @pytest.mark.invariant("{id}") (il doit chercher des '
        "contre-exemples, pas vérifier un seul exemple)",
    "a runtime guard in this component that fails the job when violated, marked with the comment "
    "`# archvow: enforces[{id}]`":
        "une garde à l'exécution dans ce composant, qui fait échouer le job si la propriété est violée, "
        "marquée par le commentaire `# archvow: enforces[{id}]`",
    "the model at {evidence}, checked in CI by its model checker":
        "le modèle {evidence}, vérifié en CI par son model checker",
    "the proof at {evidence}, checked in CI by its proof checker":
        "la preuve {evidence}, vérifiée en CI par son outil de preuve",
    "archvow check rule {rule} (already enforced, nothing to write)":
        "la règle archvow {rule} (déjà appliquée, rien à écrire)",
    "- No invariant yet: the safety analysis of this component is not finished (open: {words}). Do not "
    "invent invariants or guards; say in your answer that it is still open.":
        "- Pas encore d'invariant : l'analyse de sûreté de ce composant n'est pas terminée (ouverts : "
        "{words}). N'inventez ni invariant ni garde ; dites dans votre réponse qu'elle est encore ouverte.",
    "- No invariant: the safety analysis found nothing this component must guard against.":
        "- Pas d'invariant : l'analyse de sûreté n'a rien trouvé contre quoi ce composant doit se protéger.",
    "- Layer `{layer}`: never {rule}.": "- Couche `{layer}` : ne jamais {rule}.",
    "## Create exactly": "## Créer exactement",
    "- File: `{file}` - no other new file except its test.":
        "- Fichier : `{file}` - aucun autre nouveau fichier, à part son test.",
    "- Public API (nothing else may be public; helpers start with `_`):":
        "- API publique (rien d'autre ne peut être public ; les fonctions utilitaires commencent par `_`) :",
    "- May use only these components:": "- Ne peut utiliser que ces composants :",
    "- May not import other components (foundations in {layer} excepted).":
        "- Ne peut importer aucun autre composant (sauf les fondations de {layer}).",
    "## File header": "## En-tête du fichier",
    "Start the file with this docstring. Fill in the `<...>` values: the person responsible, the AI "
    "assistant you are (or `none`), today's date.":
        "Commencez le fichier par cette docstring. Remplissez les valeurs `<...>` : la personne "
        "responsable, l'assistant IA que vous êtes (ou `none`), la date du jour.",
    "<One-line summary of what this module does>.": "<Résumé en une ligne de ce que fait ce module>.",
    "## Tests to write": "## Tests à écrire",
    "- File: `{test}` - required, the build fails without it (ARCH017).":
        "- Fichier : `{test}` - obligatoire, le build échoue sans lui (ARCH017).",
    "- Kind: **{kind}**": "- Type : **{kind}**",
    "- One test per decision and per rule below, named after it, e.g. "
    "`test_empty_input_returns_empty_dataframe`, and marked with it: "
    "`@pytest.mark.decision(3)`, `@pytest.mark.rule(\"R2\")` (ARCH038).":
        "- Un test par décision et par règle ci-dessous, nommé d'après elle, par exemple "
        "`test_empty_input_returns_empty_dataframe`, et marqué avec elle : "
        "`@pytest.mark.decision(3)`, `@pytest.mark.rule(\"R2\")` (ARCH038).",
    # ---- briefs (briefs.py)
    "## Briefs": "## Briefs",
    "Sections nothing in the spec is drawn from:": "Sections dont la spec ne tire rien :",
    "# Briefs - {name}": "# Briefs - {name}",
    "Where the spec comes from: each component, question and rule drawn from a brief "
    "(`--from`). `archvow check` warns when a section changes (ARCH039); after review, "
    "`archvow brief accept <brief>` records its new text.":
        "D'où vient la spec : chaque composant, question et règle tiré d'un brief (`--from`). "
        "`archvow check` avertit quand une section change (ARCH039) ; après relecture, "
        "`archvow brief accept <brief>` enregistre son nouveau texte.",
    "| Brief | Drawn from it | Text recorded |": "| Brief | Ce qui en est tiré | Texte enregistré |",
    "Source: {ref} (for context; this card wins over the brief).":
        "Source : {ref} (pour le contexte ; cette fiche l'emporte sur le brief).",
    # ---- modes (proposals.py)
    "## Decisions to propose before coding": "## Décisions à proposer avant de coder",
    "Do not choose silently. For each question: take its suggested answer when it has "
    "one, or choose yours, and record it before coding with "
    "`archvow decision propose {id} <number> \"<answer>\"`; then go on. Stop and ask "
    "only when there is no suggestion and the choice changes the data or the results.":
        "Ne choisissez pas en silence. Pour chaque question : prenez sa réponse suggérée quand elle en a "
        "une, ou choisissez la vôtre, et enregistrez-la avant de coder avec "
        "`archvow decision propose {id} <numéro> \"<réponse>\"` ; puis continuez. Arrêtez-vous et "
        "demandez seulement quand il n'y a pas de suggestion et que le choix change les données ou les résultats.",
    "Choose each answer yourself and record it before coding with "
    "`archvow decision propose {id} <number> \"<answer>\"`; then go on. A person "
    "reviews them later.":
        "Choisissez vous-même chaque réponse et enregistrez-la avant de coder avec "
        "`archvow decision propose {id} <numéro> \"<réponse>\"` ; puis continuez. Une personne les "
        "relit plus tard.",
    "## Decisions proposed by the AI (not reviewed yet: implement them as written)":
        "## Décisions proposées par l'IA (pas encore relues : implémentez-les telles quelles)",
    # ---- tasks (tasks.py)
    "## Tasks": "## Tâches",
    "This card is cut into {n} tasks: implement one at a time, in order; after each one, "
    "`archvow check` and `pytest` pass. A task is done when the code exists and each of its "
    "items has a marked test.":
        "Cette fiche est découpée en {n} tâches : implémentez-en une à la fois, dans l'ordre ; après "
        "chacune, `archvow check` et `pytest` passent. Une tâche est faite quand le code existe et que "
        "chacun de ses éléments a un test marqué.",
    "  <- now": "  <- maintenant",
    "- More than 3 tasks: the architects may prefer to split this component.":
        "- Plus de 3 tâches : les architectes préféreront peut-être découper ce composant.",
    "## Now: task T{n} of {total}": "## Maintenant : tâche T{n} sur {total}",
    "Implement only T{n} ({what}). Keep what the earlier tasks built working; the later "
    "tasks wait.":
        "Implémentez seulement T{n} ({what}). Ce que les tâches précédentes ont construit doit "
        "continuer de marcher ; les tâches suivantes attendent.",
    "- The test of {ids}, as described under *Must never happen*.":
        "- Le test de {ids}, comme décrit sous *Ne doit jamais arriver*.",
    "## Rules (implement exactly, one test each)":
        "## Règles (à implémenter exactement, un test chacune)",
    "## Decisions made (implement exactly, do not reinterpret)":
        "## Décisions prises (à implémenter exactement, sans réinterpréter)",
    "## Reviewed assumptions": "## Hypothèses revues",
    "- accepted: {text}": "- acceptée : {text}",
    "- REJECTED (do not rely on it): {text}": "- REJETÉE (ne pas s'y fier) : {text}",
    "## Assumptions": "## Hypothèses",
    "Anything this spec does not define is not yours to decide. Ask before coding. If you still had to "
    "assume something, list it in your answer and record it with `archvow assumption add {id} \"<assumption>\"`. "
    "Until a person accepts or rejects it, CI fails (ARCH034).":
        "Ce que cette spec ne définit pas, ce n'est pas à vous de le décider. Demandez avant de coder. Si "
        "vous avez quand même dû supposer quelque chose, dites-le dans votre réponse et enregistrez-le avec "
        "`archvow assumption add {id} \"<hypothèse>\"`. Tant qu'une personne ne l'a pas acceptée ou rejetée, la CI échoue "
        "(ARCH034).",
    "## Definition of done": "## Définition de « terminé »",
    "- `archvow check` reports no errors for this component.":
        "- `archvow check` ne signale aucune erreur pour ce composant.",
    "- `ruff format .` run, then `ruff check .` and `pytest` pass.": "- `ruff format .` lancé, puis `ruff check .` et `pytest` passent.",
    "- Every invariant above is tested.": "- Chaque invariant ci-dessus est testé.",
    "- You did not edit `.archvow/`, `AGENTS.md`, `ruff.toml`, CI files or other components' tests, "
    "and added no `# noqa` / `# type: ignore` / suppressions.":
        "- Vous n'avez modifié ni `.archvow/`, ni `AGENTS.md`, ni `ruff.toml`, ni les fichiers de CI, "
        "ni les tests d'autres composants, et n'avez ajouté aucun `# noqa` / `# type: ignore` / "
        "exemption.",
    "- Working code that breaks these rules is not done.":
        "- Un code qui fonctionne mais enfreint ces règles n'est pas terminé.",
    "# Task: find what is ambiguous in the spec of `{id}` - do not write code":
        "# Tâche : trouver ce qui est ambigu dans la spec de `{id}` - n'écrivez pas de code",
    "Read the spec card below. List every case it does not define: unclear inputs, edge cases, "
    "error handling, ordering, performance limits, data volumes, anything two developers could "
    "implement differently.\n\nRules:\n- Do **not** propose answers or defaults. Only questions; humans "
    "decide.\n- Do not repeat questions already listed (answered or open) in the card.\n- One question "
    "per line, as a command the human can run to record it:\n\n    archvow question add {id} \"<question>\"\n\n"
    "Recorded questions block the implementation until a human answers them "
    "(`archvow decision make {id} <n> \"<answer>\"`).":
        "Lisez la fiche de spec ci-dessous. Listez chaque cas qu'elle ne définit pas : entrées "
        "floues, cas limites, gestion des erreurs, ordre, limites de performance, volumes de données, "
        "tout ce que deux développeurs pourraient implémenter différemment.\n\nRègles :\n- Ne proposez "
        "**aucune** réponse ni valeur par défaut. Seulement des questions ; ce sont des personnes qui "
        "décident.\n- Ne répétez pas les questions déjà listées (répondues ou ouvertes) dans la fiche.\n"
        "- Une question par ligne, sous forme de commande que la personne peut lancer pour "
        "l'enregistrer :\n\n    archvow question add {id} \"<question>\"\n\nLes questions enregistrées "
        "bloquent l'implémentation jusqu'à ce qu'une personne y réponde "
        "(`archvow decision make {id} <n> \"<réponse>\"`).",
    # ---- views
    "# Traceability - {name}": "# Traçabilité - {name}",
    "What exists, where, and why. Implementation status: `archvow check` or `{status}` (local).":
        "Ce qui existe, où, et pourquoi. État de l'implémentation : `archvow check` ou `{status}` (local).",
    "| Spec | Layer | Component | Type | File | Public symbols | Invariants |":
        "| Spec | Couche | Composant | Type | Fichier | Symboles publics | Invariants |",
    "# Safety - {name}": "# Sûreté - {name}",
    "What must never happen, and the evidence required to show it cannot. Whether the evidence exists "
    "yet: `{status}/STATUS.md` (local) or `archvow check`.":
        "Ce qui ne doit jamais arriver, et la preuve exigée pour montrer que c'est impossible. Si la "
        "preuve existe déjà : `{status}/STATUS.md` (local) ou `archvow check`.",
    "## Hazards and their guards": "## Dangers et leurs gardes",
    "| Hazard | Severity | Component | Guide word | Description | Invariant | Required evidence |":
        "| Danger | Gravité | Composant | Mot-guide | Description | Invariant | Preuve exigée |",
    "**none**": "**aucun**",
    "system": "système",
    "## Analysed and dismissed": "## Analysés et écartés",
    "| Hazard | Component | Guide word | Rationale |": "| Danger | Composant | Mot-guide | Justification |",
    "# Architecture - {name}": "# Architecture - {name}",
    "Legend: grey planned, yellow implemented, blue tested, green verified (all invariants proven), red drift.":
        "Légende : gris planned (prévu), jaune implemented (implémenté), bleu tested (testé), vert "
        "verified (tous les invariants prouvés), rouge drift (écart).",
    "# Project rules - {name}": "# Règles du projet - {name}",
    "The project's own rules, in plain words (`archvow rule add`). Each component a rule applies to implements "
    "it and has a test for it.":
        "Les règles propres au projet, en mots simples (`archvow rule add`). Chaque composant concerné par "
        "une règle l'implémente et a un test pour elle.",
    "| Rule | Applies to | Components today | What it says |":
        "| Règle | S'applique à | Composants aujourd'hui | Ce qu'elle dit |",
    "| - | - | - | none yet: archvow rule add <component> \"Given ..., when ..., then ...\" |":
        "| - | - | - | aucune pour l'instant : archvow rule add <composant> \"Étant donné ..., quand ..., alors ...\" |",
    "all components": "tous les composants",
    "every {type}": "chaque {type}",
    "Severity shown is the effective one (template defaults + manifest `rules:` overrides).":
        "La gravité affichée est celle en vigueur (valeurs du template + surcharges `rules:` du manifeste).",
    "Silence a single line only with a reason: `# archvow: ignore[CODE] -- why`.":
        "Ne faire taire qu'une seule ligne, et avec une raison : `# archvow: ignore[CODE] -- pourquoi`.",
    "| Code | Severity | Rule |": "| Code | Gravité | Règle |",
    "PEP 8 and the Python style rules are enforced by ruff (ruff.toml).":
        "PEP 8 et les règles de style Python sont appliquées par ruff (ruff.toml).",
    '# Personal data - {name}': '# Données personnelles - {name}',
    '# Third parties - {name}': '# Tiers - {name}',
    '## Personal data': '## Données personnelles',
    '## Purpose, legal basis, retention, location': '## Finalité, base légale, conservation, localisation',
    '- It pseudonymises or encrypts: {columns} (test it).': '- Il pseudonymise ou chiffre : {columns} (testez-le).',
    '- It removes: {columns} (they must not leave it).': '- Il supprime : {columns} (elles ne doivent pas en sortir).',
    '- It writes: {columns}.': '- Il écrit : {columns}.',
    '- Never partition or bucket files by them (GDPR006).': '- Ne jamais partitionner ni répartir (bucket) des fichiers selon elles (GDPR006).',
    '- Never show, print or log their values, nor collected rows (GDPR004): log counts.': '- Ne jamais afficher, imprimer ni journaliser leurs valeurs, ni des lignes collectées (GDPR004) : journalisez des comptes.',
    '- Pseudonymised before it: {columns}.': '- Pseudonymisées avant lui : {columns}.',
    'A test reads data from outside tests/ (database, cloud storage, absolute path)': 'Un test lit des données hors de tests/ (base de données, stockage cloud, chemin absolu)',
    "An invariant's test can be skipped, or a failing test job allowed to pass":
        "Le test d'un invariant peut être sauté, ou un job de tests peut échouer sans bloquer",
    'Binary or too large data file in tests/ (a real extract?)': 'Fichier de données binaire ou trop gros dans tests/ (un extrait réel ?)',
    'Classified column not found in the code': 'Colonne classée absente du code',
    'Column not classified in the spec (personal, special or none)': 'Colonne non classée dans la spec (personal, special ou none)',
    'Columns and their class (GDPR). Define exactly these; a new column is classified first (`archvow column set`), or the build fails (GDPR001):': "Les colonnes et leur classe (RGPD). Définissez exactement celles-ci ; une nouvelle colonne est d'abord classée (`archvow column set`), sinon le build échoue (GDPR001) :",
    'Component without a ticket': 'Composant sans ticket',
    'Every column the spec classifies as personal or special (GDPR art. 9), and the components that read, change and write it. Input for the record of processing (GDPR art. 30).': "Chaque colonne que la spec classe comme personnelle ou particulière (RGPD art. 9), et les composants qui la lisent, la modifient et l'écrivent. Entrée du registre des traitements (RGPD art. 30).",
    'Files partitioned or bucketed by a personal column (values end up in paths)': 'Fichiers partitionnés ou répartis selon une colonne personnelle (les valeurs finissent dans les chemins)',
    'Operational question not answered (failure detection, recovery)': "Question d'exploitation sans réponse (détection des pannes, reprise)",
    'Personal columns it handles: {columns}.': "Colonnes personnelles qu'il manipule : {columns}.",
    'Personal data in a URL (path or query parameter: it ends up in access logs)': "Donnée personnelle dans une URL (chemin ou paramètre de requête : elle finit dans les journaux d'accès)",
    'Personal data printed, shown or logged': 'Données personnelles imprimées, affichées ou journalisées',
    'Personal data processed without a decided purpose and legal basis': 'Données personnelles traitées sans finalité ni base légale décidées',
    'Personal data stored without a decided location and transfer safeguard': 'Données personnelles stockées sans localisation ni garantie de transfert décidées',
    'Personal data written without a decided retention and erasure': 'Données personnelles écrites sans durée de conservation ni effacement décidés',
    'Real-looking personal identifier in test data': "Identifiant personnel d'apparence réelle dans des données de test",
    "Registered licence differs from the installed package's": 'La licence enregistrée diffère de celle du paquet installé',
    'Separation of duties: fewer than two people can approve guard changes': 'Séparation des tâches : moins de deux personnes peuvent approuver les changements de garde',
    'Special-category data written without a tested pseudonymisation or encryption': 'Données de catégorie particulière écrites sans pseudonymisation ni chiffrement testés',
    'The register of ICT third-party providers this project depends on (DORA art. 28): every package of requirements.txt, recorded with `archvow dependency add`.': 'Le registre des prestataires tiers de TIC dont dépend ce projet (DORA art. 28) : chaque paquet de requirements.txt, enregistré avec `archvow dependency add`.',
    'Third-party package missing from the register, or a critical one not pinned': 'Paquet tiers absent du registre, ou paquet critique sans version figée',
    'open': 'ouverte',
    '{n} column(s) classified as not personal.': '{n} colonne(s) classée(s) non personnelle(s).',
    '| - | - | - | - | - | none yet: archvow dependency add <package> ... |': "| - | - | - | - | - | aucun pour l'instant : archvow dependency add <paquet> ... |",
    '| Column | Class | Declared in | Handled by | Removed or pseudonymised by | Written by |': '| Colonne | Classe | Déclarée dans | Manipulée par | Supprimée ou pseudonymisée par | Écrite par |',
    '| Component | Question | Answer |': '| Composant | Question | Réponse |',
    '| Package | Supplier | Licence | Criticality | Recorded by | On |': '| Paquet | Fournisseur | Licence | Criticité | Enregistré par | Le |',
    'No personal column in the spec.': 'Aucune colonne personnelle dans la spec.',
    '## Decisions made for personal data and operations (implement exactly)': "## Décisions prises pour les données personnelles et l'exploitation (à implémenter exactement)",
    "# Status - {name}": "# État - {name}",
    "clean": "propre",
    "{n} error(s)": "{n} erreur(s)",
    "Check: **{state}**, {n} warning(s).": "Vérification : **{state}**, {n} avertissement(s).",
    "## Components": "## Composants",
    "| Component | Type | Status | Tested | Invariants verified | Open questions | Pending assumptions |":
        "| Composant | Type | Statut | Testé | Invariants vérifiés | Questions ouvertes | Hypothèses en attente |",
    "## Invariants": "## Invariants",
    "| Invariant | Component | Method | Verified | Evidence |": "| Invariant | Composant | Méthode | Vérifié | Preuve |",
    "## Diagram": "## Diagramme",
    "yes": "oui",
    "no": "non",
    # ---- rule titles (RULES.md)
    "Module not declared in the spec": "Module non déclaré dans la spec",
    "Public symbol not declared in the spec": "Symbole public non déclaré dans la spec",
    "Declared symbol not implemented, or still a placeholder (reported with --complete)":
        "Symbole déclaré non implémenté, ou encore un bouche-trou (signalé avec --complete)",
    "Signature/annotation differs from the spec": "Signature ou annotation différente de la spec",
    "Illegal dependency between layers": "Dépendance interdite entre couches",
    "Undeclared dependency between components (missing in `uses`)":
        "Dépendance non déclarée entre composants (absente de `uses`)",
    "Import forbidden in this layer": "Import interdit dans cette couche",
    "Declared module file not created (reported with --complete)":
        "Fichier de module déclaré non créé (signalé avec --complete)",
    "Invalid entry in a vow": "Entrée invalide dans un engagement (vow)",
    "File outside any layer (neither a layer folder nor mapped in `layer_paths`)":
        "Fichier hors de toute couche (ni dans un dossier de couche, ni rattaché par `layer_paths`)",
    "Suppression without a justification": "Exemption sans justification",
    "Project template version differs from installed template":
        "La version du template du projet diffère du template installé",
    "File cannot be parsed": "Fichier illisible (erreur de syntaxe)",
    "Entry of a vow differs from what its template generates (hand-edited?)":
        "Entrée d'un engagement (vow) différente de ce que génère son template (modifiée à la main ?)",
    "Python file outside the architecture (no container, not an allowed path)":
        "Fichier Python hors de l'architecture (aucun conteneur, chemin non autorisé)",
    "Test file does not follow the test layout": "Fichier de test hors de l'organisation des tests",
    "Implemented component without its test": "Composant implémenté sans son test",
    "Component file without a correct file header": "Fichier de composant sans en-tête correct",
    "Guard weakened compared to the base branch": "Garde affaiblie par rapport à la branche de base",
    "Configuration of an AI assistant not approved for this repository":
        "Configuration d'un assistant IA non approuvé pour ce dépôt",
    "Review by an AI tool not approved as a reviewer": "Relecture par un outil IA non approuvé comme relecteur",
    "Review by the AI tool that wrote the code (self-review)":
        "Relecture par l'outil IA qui a écrit le code (auto-relecture)",
    "Critical/high hazard with no invariant guarding against it":
        "Danger critique ou élevé sans invariant qui en protège",
    "Implemented component whose invariant has no verification evidence":
        "Composant implémenté dont un invariant n'a pas de preuve",
    "Verification evidence does not match the declared method":
        "La preuve ne correspond pas à la méthode déclarée",
    "Component without the data contract its type works on (a reader without its schema)":
        "Composant sans le contrat de données sur lequel son type travaille (un lecteur sans son schéma)",
    "Implemented while a decision is still to make":
        "Implémenté alors qu'une décision reste à prendre",
    "Implemented on an assumption nobody reviewed yet":
        "Implémenté sur une hypothèse que personne n'a encore relue",
    "Guide word not analysed for a component (hazard or dismissal missing)":
        "Mot-guide non analysé pour un composant (danger ou mise à l'écart manquant)",
    "Invalid hazard or invariant entry": "Danger ou invariant invalide",
    "Verification method too weak for the hazard severity":
        "Méthode de vérification trop faible pour la gravité du danger",
    "New suppression compared to the base branch": "Nouvelle exemption par rapport à la branche de base",
    "Change too big for one merge request (files or lines over the budget)":
        "Changement trop gros pour une merge request (fichiers ou lignes au-delà du budget)",
    "Third-party package imported without approval": "Paquet tiers importé sans approbation",
    "Spark/file I/O outside an I/O layer": "E/S Spark ou fichier hors d'une couche d'E/S",
    "Spark action or execution control in a lazy-only layer":
        "Action Spark ou contrôle d'exécution dans une couche purement paresseuse",
    "SparkSession built outside the session layer": "SparkSession créée hors de la couche de session",
    "join() without explicit how= keyword": "join() sans le mot-clé how= explicite",
    "Right join (swap the DataFrames and use a left join)":
        "Jointure à droite (inverser les DataFrames et faire une jointure à gauche)",
    "Python or pandas UDF used (prefer native pyspark.sql.functions)":
        "UDF Python ou pandas utilisée (préférer les pyspark.sql.functions natives)",
    "Non-standard PySpark import (use functions as F, types as T, Window as W)":
        "Import PySpark non standard (functions as F, types as T, Window as W)",
    "Backslash line continuation (wrap the expression in parentheses)":
        "Continuation de ligne par barre oblique inverse (mettre l'expression entre parenthèses)",
    "Method chain longer than allowed": "Chaîne de méthodes plus longue qu'autorisé",
    "Window ordered without an explicit frame (rowsBetween/rangeBetween)":
        "Fenêtre ordonnée sans cadre explicite (rowsBetween/rangeBetween)",
    "Empty Window.partitionBy() (moves all data to one partition)":
        "Window.partitionBy() vide (toutes les données dans une seule partition)",
    "Empty column filled with '' or 'NA' (use F.lit(None))":
        "Colonne vide remplie avec '' ou 'NA' (utiliser F.lit(None))",
    "withColumnRenamed() (prefer .alias() inside a select)": "withColumnRenamed() (préférer .alias() dans un select)",
    "distinct()/dropDuplicates() (fix the cause of duplicates instead)":
        "distinct()/dropDuplicates() (corriger plutôt la cause des doublons)",
    "Blocking call inside an async function (it stops every other request)":
        "Appel bloquant dans une fonction async (il arrête toutes les autres requêtes)",
    "HTTPException outside the HTTP layers (raise a domain error instead)":
        "HTTPException hors des couches HTTP (lever plutôt une erreur métier)",
    "FastAPI app created outside an app component": "App FastAPI créée hors d'un composant app",
    "on_event startup/shutdown handler (use the lifespan of the app)":
        "Gestionnaire on_event de démarrage ou d'arrêt (utiliser le lifespan de l'app)",
    "Route without a response model or return type": "Route sans modèle de réponse ni type de retour",
    "File longer than allowed": "Fichier plus long qu'autorisé",
    "Function longer than allowed": "Fonction plus longue qu'autorisé",
    "Shell script longer than allowed (move the logic into Python)":
        "Script shell plus long qu'autorisé (mettez la logique en Python)",
    "Too many comment lines for the code (say it in names and docstrings)":
        "Trop de lignes de commentaire pour le code (dites-le par les noms et les docstrings)",
    # ---- archvow specify (what it says around the questions; commands and keywords stay)
    "Nothing left to specify.": "Plus rien à spécifier.",
    "stopped - the answers given before are saved (what is still open: archvow show {target})":
        "arrêté - les réponses déjà données sont enregistrées (ce qui reste ouvert : archvow show {target})",
    " Next: archvow next": " Ensuite : archvow next",
    "{count} item(s) to specify": "{count} élément(s) à spécifier",
    "vow question {key}": "question d'engagement {key}",
    "spec decision {n}": "décision de spec {n}",
    "column {name}": "colonne {name}",
    "vow question S{n}": "question d'engagement S{n}",
    "proposed by the AI: {answer}": "proposé par l'IA : {answer}",
    "answer": "réponse",
    "Enter": "Entrée",
    "Tab": "Tab",
    "suggestion": "suggestion",
    "edit": "modifier",
    "skip": "passer",
    "quit": "quitter",
    "s": "s",
    "q": "q",
    "p": "p",
    "n": "n",
    "not applicable": "sans objet",
    "personal": "personal",
    "special": "special",
    "none": "none",
    ": ": " : ",
    " (suggested)": " (suggérée)",
    " (your own)": " (la vôtre)",
    "decision made": "décision prise",
    "to change it: {command}": "pour modifier : {command}",
    "personal, special (health, religion, biometrics... GDPR art. 9) or none?":
        "personal, special (santé, religion, biométrie... RGPD art. 9) ou none ?",
    "already made in decision {number}: {answer}": "déjà prise dans la décision {number} : {answer}",
    "why it cannot happen here": "pourquoi cela ne peut pas arriver ici",
    "not applicable: {reason}": "sans objet : {reason}",
    "what must never happen (hazard)?": "qu'est-ce qui ne doit jamais arriver (hazard) ?",
    "how is it prevented (invariant)?": "comment est-ce empêché (invariant) ?",
    "{id} recorded: {text}": "{id} enregistré : {text}",
    "prevented by {id}: {statement}": "empêché par {id} : {statement}",
    "It needs an invariant: {command}": "Il lui faut un invariant : {command}",
    # ---- files written by init and spec commands
    "# Instructions for {tool}": "# Instructions pour {tool}",
    "<!-- Added by archvow init: `archvow init --force` rewrites only what is between these two markers; write your own text outside them. -->":
        "<!-- Ajouté par archvow init : `archvow init --force` ne réécrit que ce qui est entre ces deux "
        "marqueurs ; écrivez votre propre texte en dehors. -->",
    "The rules for every AI assistant are in AGENTS.md at the repository root; they are copied below so "
    "they apply even when that file is not loaded. If the two differ, AGENTS.md wins.":
        "Les règles de tout assistant IA sont dans AGENTS.md, à la racine du dépôt ; elles sont "
        "recopiées ci-dessous pour s'appliquer même quand ce fichier n'est pas chargé. En cas de "
        "différence, AGENTS.md fait foi.",
}

CATALOGUES = {"fr": FR}
MISSING: set[tuple[str, str]] = set()  # texts asked in a language that has no translation (tests read it)


def tr(language: str | None, text: str, /, **values: object) -> str:
    """`text` in `language` (unchanged when there is no translation), with `values` filled in."""
    catalogue = CATALOGUES.get(language or "en")
    translated = text
    if catalogue is not None and text:
        translated = catalogue.get(text, text)
        if text not in catalogue:
            MISSING.add((language or "en", text))
    return translated.format(**values) if values else translated
