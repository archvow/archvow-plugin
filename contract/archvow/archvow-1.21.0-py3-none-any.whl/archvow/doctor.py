"""`archvow doctor`: is this machine ready to work on the project? One line per check, with the fix.

A diagnostic, not a workflow step: run it when something does not work. The engine checks what
every project needs (Python, the archvow command and its version, Git and the hook, the
template); the template adds its own tools (`doctor:` in template.yaml, e.g. Java and PySpark).
"""

from __future__ import annotations

import importlib.metadata
import importlib.util
import re
import shutil
import subprocess
import sys
import sysconfig
from dataclasses import asdict, dataclass
from pathlib import Path

from jinja2 import Environment

from archvow import __version__
from archvow import manifest as mf
from archvow.templates import TemplateError, load_template

MIN_PYTHON = (3, 10)


@dataclass
class Finding:
    """One check: ok, warn (works, but should be fixed) or fail (blocks the work)."""

    check: str
    status: str
    detail: str
    fix: str = ""


def _run(command: list[str], cwd: Path | None = None) -> tuple[int, str]:
    """Exit code and output (stdout + stderr) of a command; 127 when it does not exist."""
    try:
        done = subprocess.run(command, cwd=cwd, capture_output=True, text=True,
                              encoding="utf-8", errors="replace", timeout=60, check=False)
    except (FileNotFoundError, PermissionError):
        return 127, ""
    except subprocess.TimeoutExpired:
        return 124, "timed out"
    return done.returncode, (done.stdout + done.stderr).strip()


def _version_tuple(text: str) -> tuple[int, ...]:
    return tuple(int(p) for p in re.findall(r"\d+", text)[:3])


def _python(findings: list[Finding], answers: dict, context: dict) -> None:
    current = f"{sys.version_info.major}.{sys.version_info.minor}"
    low = answers.get("python_version")
    high = (context.get("python_ceiling") or {}).get(answers.get("spark_version", ""))
    if sys.version_info[:2] < MIN_PYTHON or (low and _version_tuple(current) < _version_tuple(low)):
        need = low or ".".join(map(str, MIN_PYTHON))
        findings.append(Finding("Python", "fail", f"{current} ({sys.executable}); the project needs {need} or newer",
                                f"install Python {need}+ and run archvow with it (python{need} -m archvow)"))
    elif high and _version_tuple(current) > _version_tuple(high):
        findings.append(Finding("Python", "warn", f"{current}: newer than PySpark {answers['spark_version']} supports "
                                f"(up to {high}); Spark tests may fail",
                                f"use Python {high} for this project (e.g. python{high} -m pip install -r ...)"))
    else:
        findings.append(Finding("Python", "ok", f"{current} ({sys.executable})"))


def _archvow(findings: list[Finding], root: Path | None) -> None:
    location = Path(__file__).resolve().parent
    findings.append(Finding("archvow", "ok", f"{__version__} ({location})"))
    command = shutil.which("archvow")
    scripts = sysconfig.get_path("scripts")
    if command is None:
        findings.append(Finding("archvow command", "fail", "not on PATH",
                                f'add {scripts} to PATH (export PATH="{scripts}:$PATH"), or run python3 -m archvow'))
    else:
        code, out = _run([command, "--version"])
        version = out.split()[-1] if code == 0 and out else ""
        if version != __version__:
            findings.append(Finding(
                "archvow command", "fail",
                f"{command} runs {version or 'nothing (broken install)'}, this Python has {__version__}",
                "python3 -m pip uninstall -y archvow (until none is left), reinstall it, then hash -r"))
        else:
            findings.append(Finding("archvow command", "ok", command))
    if root is None:
        return
    pinned = _pinned_version(root)
    if pinned and pinned != __version__:
        findings.append(Finding("archvow version", "fail",
                                f"the project pins {pinned} (as its CI), {__version__} is installed",
                                f"python3 -m pip install archvow=={pinned}"))
    elif pinned:
        findings.append(Finding("archvow version", "ok", f"{pinned}, as the project and its CI"))


def _pinned_version(root: Path) -> str | None:
    for name in ("requirements.txt", "requirements", "requirements-dev.txt", "pyproject.toml"):
        path = root / name
        if path.is_file():
            match = re.search(r"archvow\s*==\s*([0-9][0-9A-Za-z.+-]*)", path.read_text(encoding="utf-8"))
            if match:
                return match.group(1)
    return None


def _git(findings: list[Finding], root: Path | None, answers: dict) -> None:
    if shutil.which("git") is None:
        findings.append(Finding("Git", "fail", "git is not installed", "install Git"))
        return
    if root is None:
        return
    code, top = _run(["git", "rev-parse", "--show-toplevel"], cwd=root)
    if code != 0:
        findings.append(Finding("Git", "fail", f"{root} is not a Git repository", "git init (or clone the project)"))
        return
    findings.append(Finding("Git", "ok", top))
    hooks = answers.get("git_hooks", "githooks" if (root / ".githooks").is_dir() else "none")
    if hooks == "githooks":
        _, path = _run(["git", "config", "core.hooksPath"], cwd=root)
        expected = (root / ".githooks").resolve()
        enabled = bool(path) and (Path(top) / path).resolve() == expected
        findings.append(Finding("Git hook", "ok", "enabled (.githooks)") if enabled else Finding(
            "Git hook", "fail", "not enabled: commits are not checked locally",
            f"git config core.hooksPath {expected.relative_to(Path(top).resolve()).as_posix()}"))
    elif hooks == "pre-commit":
        installed = (Path(top) / ".git" / "hooks" / "pre-commit").is_file()
        findings.append(Finding("Git hook", "ok", "pre-commit installed") if installed else Finding(
            "Git hook", "fail", "pre-commit is not installed in this clone", "pre-commit install"))


def _template(findings: list[Finding], root: Path, data: dict) -> tuple[dict, dict]:
    """The project's template (found?) and the answers given at init."""
    answers = dict(data.get("init_answers") or {})
    container = data["containers"][0]
    name, version = mf.template_name(container)
    try:
        template = load_template(name, root)
    except TemplateError as exc:
        findings.append(Finding("template", "fail", str(exc),
                                "set ARCHVOW_TEMPLATES to the folder of your team's templates (shell and CI)"))
        return {}, answers
    if version and version != template.version:
        findings.append(Finding("template", "warn", f"the project uses {name}@{version}, {template.ref} is installed",
                                f"an architect upgrades the project: archvow init {container.get('package')} "
                                "--force, then review and commit"))
    else:
        findings.append(Finding("template", "ok", template.ref))
    defaults = {q["id"]: (template.data.get("questions_defaults") or {}).get(q["id"], q.get("default"))
                for q in template.data.get("questions", [])}
    return template.data, {**{k: v for k, v in defaults.items() if v is not None}, **answers}


def _template_tools(findings: list[Finding], template: dict, answers: dict, root: Path) -> None:
    """The template's own checks: a command that must run, or a Python package (and its version)."""
    env = Environment(autoescape=False)
    render = lambda text: env.from_string(str(text)).render(**template.get("context", {}), **answers)
    for item in template.get("doctor") or []:
        name, fix = render(item.get("name", "")), render(item.get("fix", ""))
        level = "warn" if item.get("optional") else "fail"
        if "command" in item:
            command = render(item["command"]).split()
            code, out = _run(command, cwd=root)
            if code != 0:
                findings.append(Finding(name, level, f"`{' '.join(command)}` failed" if code != 127 else
                                        f"{command[0]} not found", fix))
                continue
            lines = [line for line in out.splitlines() if line.strip() and not line.startswith("Picked up")]
            first = lines[0] if lines else "ok"
            wanted = render(item.get("version", ""))
            if wanted and not re.search(rf"\b{re.escape(wanted)}", out):
                findings.append(Finding(name, level, f"{first} (needs {wanted})", fix))
            else:
                findings.append(Finding(name, "ok", first))
        elif "module" in item:
            module = render(item["module"])
            if importlib.util.find_spec(module) is None:
                findings.append(Finding(name, level, f"{module} is not installed in {sys.executable}", fix))
                continue
            try:
                version = importlib.metadata.version(render(item.get("distribution", module)))
            except importlib.metadata.PackageNotFoundError:
                version = "?"
            wanted = render(item.get("version", ""))
            if wanted and not (version == wanted or version.startswith(wanted + ".")):
                findings.append(Finding(name, level, f"{version} installed, the project uses {wanted}", fix))
            else:
                findings.append(Finding(name, "ok", version))


def run_doctor(start: Path) -> list[Finding]:
    """Every check, for the project around `start` (or only the machine, outside a project)."""
    findings: list[Finding] = []
    try:
        root: Path | None = mf.find_root(start)
    except mf.ManifestError:
        root = None
    template: dict = {}
    answers: dict = {}
    data: dict | None = None
    project: list[Finding] = []
    if root is not None:
        try:
            data = mf.load(root)
        except mf.ManifestError as exc:
            project.append(Finding("manifest", "fail", str(exc), "fix .archvow/ (git diff shows "
                                   "what changed)"))
            data = None
        if data is not None:
            template, answers = _template(project, root, data)
    _python(findings, answers, template.get("context", {}))
    from archvow.check import newer_python_needed

    wanted = newer_python_needed(root) if root is not None else None
    if wanted:  # the project's own code needs a newer Python: archvow could not parse it (ARCH013)
        findings.append(Finding("Python", "warn", f"{sys.version_info.major}.{sys.version_info.minor} runs archvow, "
                                f"the project's pyproject.toml says requires-python {wanted}: newer syntax "
                                "cannot be read (ARCH013)", f"install a Python matching {wanted} and run archvow with it"))
    _archvow(findings, root)
    _git(findings, root, answers)
    findings += project
    if root is not None and template:
        _template_tools(findings, template, answers, root)
    if root is not None and data is not None:
        _agent(findings, root, data)
    return findings


def _agent(findings: list[Finding], root: Path, data: dict) -> None:
    """The AI agent archvow runs inside, as it sees it (agent.py), and the assistants it cannot see."""
    from archvow.agent import DOCS, describe, tool_data, unseen

    status, line = describe(root, data)
    findings.append(Finding("AI agent", status, line, f"start the agent protected - see {DOCS}"))
    for tool, where in unseen(tool_data(root, data), list(data.get("ai_tools") or [])):
        findings.append(Finding(f"AI agent {tool}", "warn", f"archvow cannot see it {where}",
                                "its sandbox and YOLO mode are not checked: see " + DOCS))


def render(findings: list[Finding], root_known: bool) -> str:
    marks = {"ok": "ok  ", "warn": "warn", "fail": "FAIL"}
    width = max(len(f.check) for f in findings)
    lines = []
    for f in findings:
        lines.append(f"[{marks[f.status]}] {f.check:<{width}}  {f.detail}")
        if f.fix and f.status != "ok":
            lines.append(f"       {'':<{width}}  fix: {f.fix}")
    failed = sum(f.status == "fail" for f in findings)
    warned = sum(f.status == "warn" for f in findings)
    lines.append("")
    if not root_known:
        lines.append("Not in an archvow project: only this machine was checked (run it in a project for more).")
    lines.append(f"{failed} problem(s), {warned} warning(s)." if failed or warned else "Everything is ready.")
    return "\n".join(lines)


def as_dicts(findings: list[Finding]) -> list[dict]:
    return [asdict(f) for f in findings]
