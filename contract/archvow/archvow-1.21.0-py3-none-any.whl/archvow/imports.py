"""What a name in a Python file stands for: `nap` is `time.sleep` after `from time import sleep as nap`.

The rules that look for a call (FAPI001 blocking calls, the Spark rules, a company's `forbid_call`)
ask a `Names` object for the full name of what is called, so an alias does not hide the call:

    import time as t                 t.sleep(1)      -> time.sleep
    from time import sleep as nap    nap(1)          -> time.sleep
    from urllib import request       request.urlopen -> urllib.request.urlopen

Scopes follow Python's: a function sees its own names, then the enclosing functions', then the
module's (not a class body's). A name that a scope also binds another way (an assignment, a
parameter, a def, a for or with target...) is no longer trusted there: `full_name` returns None,
so a rule never fires on a name that may mean something else. This is not a call graph: what is
reached through getattr(), importlib or a value passed around stays out of reach.
"""

from __future__ import annotations

import ast

SHADOWED = ""  # a scope binds the name in another way than an import: unknown there

_SCOPES = (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda, ast.ClassDef)


def _bindings(scope: ast.AST) -> dict[str, str]:
    """name -> full name for the imports of one scope; SHADOWED for the names it binds otherwise."""
    found: dict[str, str] = {}
    shadowed: set[str] = set()
    if isinstance(scope, (ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda)):
        args = scope.args
        for arg in [*args.posonlyargs, *args.args, *args.kwonlyargs, args.vararg, args.kwarg]:
            if arg is not None:
                shadowed.add(arg.arg)
    body = scope.body if isinstance(scope.body, list) else [scope.body]
    todo: list[ast.AST] = list(body)
    while todo:
        node = todo.pop()
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.asname:
                    found[alias.asname] = alias.name
                else:  # `import a.b` binds `a`
                    top = alias.name.split(".")[0]
                    found[top] = top
            continue
        if isinstance(node, ast.ImportFrom):
            base = "." * node.level + (node.module or "")
            for alias in node.names:
                if alias.name != "*":
                    found[alias.asname or alias.name] = f"{base}.{alias.name}" if base else alias.name
            continue
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            shadowed.add(node.name)
            todo.extend(node.decorator_list)
            continue  # its body is its own scope
        if isinstance(node, ast.Lambda):
            continue
        if isinstance(node, ast.Name) and isinstance(node.ctx, (ast.Store, ast.Del)):
            shadowed.add(node.id)
        elif isinstance(node, ast.ExceptHandler) and node.name:
            shadowed.add(node.name)
        elif isinstance(node, (ast.Global, ast.Nonlocal)):
            shadowed.update(node.names)
        elif isinstance(node, (ast.ListComp, ast.SetComp, ast.DictComp, ast.GeneratorExp)):
            continue  # comprehension variables live in their own scope
        todo.extend(ast.iter_child_nodes(node))
    for name in shadowed:
        found[name] = SHADOWED
    return found


class Names:
    """Full names of what a file's expressions refer to, scope by scope."""

    def __init__(self, tree: ast.AST) -> None:
        self._scope_of: dict[int, list[dict[str, str]]] = {}
        self._imports: dict[str, str] = {}
        for node in ast.walk(tree):  # an import inside a function binds the name there: good enough here
            if isinstance(node, ast.Import):
                for alias in node.names:
                    self._imports[alias.asname or alias.name.split(".")[0]] = alias.name
            elif isinstance(node, ast.ImportFrom) and node.module and not node.level:
                for alias in node.names:
                    self._imports[alias.asname or alias.name] = f"{node.module}.{alias.name}"
        self._walk(tree, [])

    def _walk(self, scope: ast.AST, outer: list[dict[str, str]]) -> None:
        own = _bindings(scope)
        # a class body's names are not seen by the functions inside it
        chain = [own, *outer]
        inner_outer = outer if isinstance(scope, ast.ClassDef) else chain
        todo: list[ast.AST] = list(ast.iter_child_nodes(scope))
        while todo:
            node = todo.pop()
            self._scope_of[id(node)] = chain
            if isinstance(node, _SCOPES):
                for deco in getattr(node, "decorator_list", []):
                    self._mark(deco, chain)
                self._walk(node, inner_outer)
                continue
            todo.extend(ast.iter_child_nodes(node))

    def _mark(self, node: ast.AST, chain: list[dict[str, str]]) -> None:
        for sub in ast.walk(node):
            self._scope_of[id(sub)] = chain

    def full_name(self, node: ast.expr) -> str | None:
        """`time.sleep` for `nap` or `t.sleep`; the text itself for a name no scope binds (a builtin
        like `open`, or an unknown global); None when a scope rebinds the name or for anything else
        than names and attributes."""
        if isinstance(node, ast.Attribute):
            base = self.full_name(node.value)
            return f"{base}.{node.attr}" if base else None
        if not isinstance(node, ast.Name):
            return None
        for scope in self._scope_of.get(id(node), []):
            if node.id in scope:
                return scope[node.id] or None
        return node.id

    def imported(self) -> dict[str, str]:
        """The names an import binds anywhere in the file: {name: what it imports}."""
        return dict(self._imports)

    def short_name(self, node: ast.expr) -> str | None:
        """The last part of the full name (`sleep` for `nap`), or None."""
        full = self.full_name(node)
        return full.rsplit(".", 1)[-1] if full else None
