"""Ticket and branch names: what the project's `ticket_pattern` (an init answer, e.g. FATTRIB-[0-9]+)
says a ticket looks like.

Developers create branches with plain Git (`git switch -c feature/<ticket>-<short-name> develop`);
the Git hooks and the CI check the names. archvow uses the pattern to validate the tickets of
`component add|edit -s` and to write the project's own ticket in every example it generates.
"""

from __future__ import annotations

import re

DEFAULT_PATTERN = "[A-Z][A-Z0-9]*-[0-9]+"


def ticket_pattern(data: dict) -> str | None:
    """The project's ticket pattern, when init (or a first branch) set it explicitly."""
    return (data.get("init_answers") or {}).get("ticket_pattern")


def check_ticket(data: dict, ticket: str) -> None:
    """A ticket of the spec (`add/edit -s`) or of a branch follows the project's pattern."""
    from archvow.specs import SpecError

    pattern = ticket_pattern(data)
    if pattern and not re.fullmatch(pattern, ticket):
        raise SpecError(f"ticket '{ticket}' does not match this project's tickets ({pattern}), e.g. "
                        f"{ticket_example(pattern)}")


def ticket_example(pattern: str | None, number: int = 1) -> str:
    """A ticket written as the project writes them, for examples: FATTRIB-[0-9]+ -> FATTRIB-001.

    Without a pattern (or the generic one), US-001. The number is kept: US-005 -> FATTRIB-005.
    """
    prefix = re.match(r"\^?([A-Z][A-Z0-9_]*-)", pattern or "")
    if pattern and pattern != DEFAULT_PATTERN and prefix:
        for width in (3, 1, 2, 4, 5, 6):  # US-001 first, then whatever width the pattern wants
            candidate = f"{prefix.group(1)}{number:0{width}d}"
            if re.fullmatch(pattern, candidate):
                return candidate
    return f"US-{number:03d}"
