---
name: archvow-review
description: "Relire un composant, ou le dernier changement, par rapport à la spec - rapport seulement, jamais de code"
---

À donner : <composant> (vide : le dernier changement).

Relis ce que la personne donne (un composant, une fonctionnalité ou un fichier) comme AGENTS.md le définit (section relecture) ; sans composant donné, relis le dernier changement. Seulement si tu es un relecteur approuvé : écris le rapport dans reviews/ et ne modifie rien d'autre.
