---
name: archvow-clarify
description: "Trouver ce que la spec d'un composant ne définit pas encore et l'enregistrer en questions marquées comme celles de l'IA - sans rien décider"
---

À donner : <composant> (et au plus combien de questions : 5 si rien n'est dit).

Lance `archvow prompt <composant> --clarify --max <N>` pour le composant que la personne donne et fais la tâche qu'il affiche : enregistre toi-même chaque question avec `archvow question add <composant> "<question>" --why "<ce qui la laisse ouverte>"`. Ne propose aucune réponse et n'écris aucun code. Termine par la liste des questions enregistrées : une personne répond à chacune, la garde ou la retire.
