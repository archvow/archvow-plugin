---
name: archvow-analyze
description: "Trouver les hazards et invariants d'un composant (ses questions de sûreté) : enregistrés comme ceux de l'IA en modes guided et free, proposés en mode strict"
---

À donner : <composant>.

Analyse les risques de ce composant, comme AGENTS.md définit « Analyse les risques de <composant> » : en mode strict, propose les commandes et n'en lance aucune ; en modes guided et free, enregistre toi-même chaque hazard et invariant avec `--why` (il reste celui de l'IA jusqu'à ce qu'une personne le garde) et propose les mises à l'écart. N'écris aucun code.
