---
name: archvow-review
description: "Review a component, or the last change, against the spec - report only, never change code"
---

What to give: <component> (empty: the last change).

Review what the person gives (a component, a feature or a file) as AGENTS.md defines (section Review); with no component given, review the last change. Only if you are an approved reviewer: write the report in reviews/ and change nothing else.
