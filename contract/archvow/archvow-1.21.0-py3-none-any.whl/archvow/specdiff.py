"""`archvow diff --base REF`: the spec changes of a branch, in plain words.

Reviewers approve what the branch changes in the *spec* (components, decisions, hazards,
invariants, approved AI tools, rules) without reading a YAML diff. Changes that weaken a guard
are marked. Output as text, Markdown (merge-request report) or JSON (IDE plugin).
"""

from __future__ import annotations

import json
from pathlib import Path

from archvow import manifest as mf
from archvow.baseline import METHOD_STRENGTH, SEVERITY_ORDER, GitError, _show, merge_base
from archvow.freeze import FROZEN_REL
from archvow.proposals import AI_MANIFEST_REL, parse

SECTIONS = ("components", "decisions", "proposed by the AI", "rules", "personal data", "assumptions", "hazards",
            "invariants", "policy")


def _change(section: str, kind: str, ref: str, detail: str, weakens: bool = False) -> dict:
    return {"section": section, "change": kind, "ref": ref, "detail": detail, "weakens": weakens}


def _components(data: dict) -> dict[str, dict]:
    return {c["id"]: c for ct in data.get("containers", []) or [] for c in ct.get("components", [])}


def spec_diff(root: Path, base: str) -> list[dict]:
    commit = merge_base(root, base)
    old = mf.load_at(root, commit) or {}
    out = compare(old, mf.load(root))
    before_frozen = len(json.loads(_show(root, commit, FROZEN_REL) or '{"frozen": []}').get("frozen", []))
    frozen_path = root / FROZEN_REL
    now_frozen = len(json.loads(frozen_path.read_text(encoding="utf-8")).get("frozen", [])) if frozen_path.is_file() else 0
    if now_frozen != before_frozen:
        out.append(_change("policy", "MODIFIED", "frozen violations", f"{before_frozen} -> {now_frozen}",
                           weakens=now_frozen > before_frozen))
    text = _show(root, commit, AI_MANIFEST_REL.as_posix())
    old_proposals = parse(text, AI_MANIFEST_REL.as_posix()) if text else []
    out += proposal_changes(old_proposals, root)
    return out


def proposal_changes(old: list[dict], root: Path) -> list[dict]:
    """What the AI proposed in this branch (.archvow/proposals.vow): the reviewers read each one."""
    from archvow.proposals import load

    before = {(p["component"], int(p["number"])): p.get("answer") for p in old}
    out = []
    for p in load(root):
        key = (p["component"], int(p["number"]))
        if before.get(key) != p.get("answer"):
            out.append(_change("proposed by the AI", "PROPOSED", p["component"],
                               f"{p['number']}. {p['question']} -> {p['answer']} "
                               f"(archvow decision accept {p['component']} {p['number']})"))
    return out


def compare(old: dict, new: dict) -> list[dict]:
    """The spec changes from one version of the vows to another, in plain words."""
    out: list[dict] = []

    old_c, new_c = _components(old), _components(new)
    for cid in sorted(set(new_c) - set(old_c)):
        c = new_c[cid]
        symbols = ", ".join(s["name"] for s in c.get("symbols", []))
        out.append(_change("components", "ADDED", cid, f"{c['type']} in {c['layer']}: {symbols}"))
    for cid in sorted(set(old_c) - set(new_c)):
        out.append(_change("components", "REMOVED", cid, old_c[cid].get("description", "")))
    for cid in sorted(set(old_c) & set(new_c)):
        a, b = old_c[cid], new_c[cid]
        for key in ("description", "uses", "symbols", "layer", "type"):
            if a.get(key) != b.get(key):
                out.append(_change("components", "MODIFIED", cid, f"{key}: {a.get(key)} -> {b.get(key)}"))
        old_d = {d["question"]: d.get("answer") for d in a.get("decisions", []) or []}
        for d in b.get("decisions", []) or []:
            before = old_d.get(d["question"])
            if d["question"] not in old_d:
                state = f"-> {d['answer']}" if d.get("answer") else "(open)"
                out.append(_change("decisions", "ADDED", cid, f"{d['question']} {state}"))
            elif d.get("answer") != before:
                kind = "DECIDED" if not before else "MODIFIED"
                origin = " (proposed by the AI, accepted)" if d.get("origin") == "ai" else ""
                out.append(_change("decisions", kind, cid, f"{d['question']} -> {d.get('answer')}{origin}"))
        old_a = {x.get("text"): x.get("status") for x in a.get("assumptions", []) or []}
        for x in b.get("assumptions", []) or []:
            if x.get("text") not in old_a:
                out.append(_change("assumptions", "ADDED", cid, f"{x.get('text')} ({x.get('status')})"))
            elif old_a[x.get("text")] != x.get("status"):
                out.append(_change("assumptions", x.get("status", "").upper(), cid, x.get("text", "")))
    for cid in sorted(set(new_c) - set(old_c)):
        for d in new_c[cid].get("decisions", []) or []:
            if d.get("answer"):
                out.append(_change("decisions", "DECIDED", cid, f"{d['question']} -> {d['answer']}"))

    old_h = {h["id"]: h for h in old.get("hazards", []) or []}
    for h in new.get("hazards", []) or []:
        before = old_h.get(h["id"])
        if before is None:
            out.append(_change("hazards", "ADDED", h["id"], f"{h.get('component') or 'system'} [{h['guide_word']}] "
                               f"{h['severity']}: {h['description']}"))
        elif before.get("severity") != h.get("severity"):
            lower = SEVERITY_ORDER.get(h.get("severity"), 0) < SEVERITY_ORDER.get(before.get("severity"), 0)
            out.append(_change("hazards", "MODIFIED", h["id"],
                               f"severity {before.get('severity')} -> {h.get('severity')}", weakens=lower))
    for hid in sorted(set(old_h) - {h["id"] for h in new.get("hazards", []) or []}):
        out.append(_change("hazards", "REMOVED", hid, old_h[hid].get("description", ""), weakens=True))
    old_d = {(d.get("component"), d.get("guide_word")) for d in old.get("dismissed") or []}
    for d in new.get("dismissed") or []:
        if (d.get("component"), d.get("guide_word")) not in old_d:
            out.append(_change("hazards", "DISMISSED", d.get("component") or "system",
                               f"[{d.get('guide_word')}] {d.get('rationale', '')}"))

    old_i = {i["id"]: i for i in old.get("invariants", []) or []}
    for i in new.get("invariants", []) or []:
        before = old_i.get(i["id"])
        if before is None:
            out.append(_change("invariants", "ADDED", i["id"], f"{i['statement']} ({i['verify']})"))
            continue
        if before.get("statement") != i.get("statement"):
            out.append(_change("invariants", "MODIFIED", i["id"], f"statement -> {i['statement']}", weakens=True))
        if before.get("verify") != i.get("verify"):
            weaker = METHOD_STRENGTH.get(i.get("verify"), 0) < METHOD_STRENGTH.get(before.get("verify"), 0)
            out.append(_change("invariants", "MODIFIED", i["id"],
                               f"verify {before.get('verify')} -> {i.get('verify')}", weakens=weaker))
    for iid in sorted(set(old_i) - {i["id"] for i in new.get("invariants", []) or []}):
        out.append(_change("invariants", "REMOVED", iid, old_i[iid].get("statement", ""), weakens=True))

    old_tools, new_tools = old.get("ai_tools") or [], new.get("ai_tools") or []
    for tool in new_tools:
        if tool not in old_tools and old.get("ai_tools") is not None:
            out.append(_change("policy", "ADDED", "ai_tools", f"AI assistant approved: {tool}", weakens=True))
    for tool in old_tools:
        if tool not in new_tools:
            out.append(_change("policy", "REMOVED", "ai_tools", f"AI assistant no longer approved: {tool}"))
    old_reviewers, new_reviewers = old.get("reviewers") or [], new.get("reviewers") or []
    for tool in [t for t in new_reviewers if t not in old_reviewers]:
        out.append(_change("policy", "ADDED", "reviewers", f"AI reviewer approved: {tool}", weakens=True))
    for tool in [t for t in old_reviewers if t not in new_reviewers]:
        out.append(_change("policy", "REMOVED", "reviewers", f"AI reviewer no longer approved: {tool}"))
    if (old.get("rules") or {}) != (new.get("rules") or {}):
        out.append(_change("policy", "MODIFIED", "rules", f"{old.get('rules') or {}} -> {new.get('rules') or {}}"))
    for ct in new.get("containers", []) or []:
        before = next((c for c in old.get("containers", []) or [] if c["id"] == ct["id"]), None)
        if before and before.get("template") != ct.get("template"):
            out.append(_change("policy", "MODIFIED", "template", f"{before.get('template')} -> {ct.get('template')}",
                               weakens=True))
    out += _compare_new_keys(old, new, old_c, new_c)
    return out


def _compare_new_keys(old: dict, new: dict, old_c: dict, new_c: dict) -> list[dict]:
    """Project rules, column classes, P/O/C answers, compliance families, the third-party register."""
    out: list[dict] = []
    old_r = {r.get("id"): r for r in old.get("project_rules") or []}
    new_r = {r.get("id"): r for r in new.get("project_rules") or []}
    for rid in sorted(set(new_r) - set(old_r)):
        out.append(_change("rules", "ADDED", rid, new_r[rid].get("text", "")))
    for rid in sorted(set(old_r) & set(new_r)):
        if old_r[rid].get("text") != new_r[rid].get("text") or old_r[rid].get("scope") != new_r[rid].get("scope"):
            out.append(_change("rules", "MODIFIED", rid, new_r[rid].get("text", "")))
    for rid in sorted(set(old_r) - set(new_r)):
        out.append(_change("rules", "REMOVED", rid, old_r[rid].get("text", ""), weakens=True))
    rank = {"none": 0, "personal": 1, "special": 2}
    for cid, comp in new_c.items():
        before = old_c.get(cid, {})
        old_cols, new_cols = before.get("columns") or {}, comp.get("columns") or {}
        for name, kind in new_cols.items():
            if old_cols.get(name) != kind:
                lower = name in old_cols and rank.get(kind, 0) < rank.get(old_cols[name], 0)
                out.append(_change("personal data", "CLASSIFIED", f"{cid}.{name}",
                                   f"{old_cols.get(name, 'unclassified')} -> {kind}", weakens=lower))
        for key in ("removes", "pseudonymises"):
            added = set((comp.get("privacy") or {}).get(key) or []) - set((before.get("privacy") or {}).get(key) or [])
            if added:
                out.append(_change("personal data", key.upper(), cid, ", ".join(sorted(added))))
        old_a = before.get("answers") or {}
        for key, entry in (comp.get("answers") or {}).items():
            if (old_a.get(key) or {}).get("answer") != entry.get("answer"):
                kind = "DECIDED" if key not in old_a else "MODIFIED"
                out.append(_change("decisions", kind, cid, f"{key} -> {entry.get('answer')}"))
    old_set, new_set = set(old.get("compliance") or []), set(new.get("compliance") or [])
    for family in sorted(new_set - old_set):
        out.append(_change("policy", "ADDED", "compliance", f"rules switched on: {family}"))
    for family in sorted(old_set - new_set):
        out.append(_change("policy", "REMOVED", "compliance", f"rules switched off: {family}", weakens=True))
    old_t = {t.get("name"): t for t in old.get("third_parties") or []}
    for entry in new.get("third_parties") or []:
        before = old_t.get(entry.get("name"))
        if before is None or {k: before.get(k) for k in ("supplier", "licence", "criticality")} != \
                {k: entry.get(k) for k in ("supplier", "licence", "criticality")}:
            out.append(_change("policy", "ADDED" if before is None else "MODIFIED", "third party",
                               f"{entry.get('name')}: {entry.get('supplier')}, {entry.get('licence')}, "
                               f"{entry.get('criticality')}"))
    return out


def render(changes: list[dict], markdown: bool) -> str:
    if not changes:
        return "No spec changes in this branch." if not markdown else "### Spec changes\n\nNone.\n"
    weak = sum(1 for c in changes if c["weakens"])
    lines = ["### Spec changes" if markdown else "Spec changes", ""]
    if weak:
        lines += [f"**{weak} change(s) weaken a guard** and need an architect's approval." if markdown
                  else f"{weak} change(s) weaken a guard and need an architect's approval.", ""]
    for section in SECTIONS:
        items = [c for c in changes if c["section"] == section]
        if not items:
            continue
        lines.append(f"**{section.capitalize()}**" if markdown else section.capitalize())
        for c in items:
            mark = " ⚠ weakens a guard" if c["weakens"] else ""
            lines.append(f"- `{c['change']}` {c['ref']}: {c['detail']}{mark}" if markdown
                         else f"  {c['change']:<10} {c['ref']}: {c['detail']}{mark}")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


__all__ = ["GitError", "render", "spec_diff"]
