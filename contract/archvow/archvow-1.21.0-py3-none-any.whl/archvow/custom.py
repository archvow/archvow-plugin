"""A company's own rules, declared as data in a template (`custom_rules`), no Python needed.

    custom_rules:
      ACME001:
        title: "No direct use of the old billing API"
        severity: error                    # error (default) | warning
        forbid_import: [legacy_billing]    # module prefixes
        layers: [p1_domain, p2_io]         # optional: only in these layers
        fix: "use acme_billing.client instead"
      ACME002: {title: "No toPandas() in production code", forbid_call: ["*.toPandas"]}
      ACME003: {title: "No hard-coded bucket", forbid_pattern: "s3://acme-prod"}
      ACME004: {title: "No notebooks in the repository", forbid_file: ["**/*.ipynb"]}
      ACME005:
        title: "Every writer says which Kafka topic it feeds"
        require_question: {types: [writer], question: "Which Kafka topic, and who consumes it?"}

The family of a rule is the letters of its code (ACME): its view is .archvow/rules/ACME.md.
`require_question` adds a question C1, C2... to those component types (see questions.py).
"""

from __future__ import annotations

import ast
import fnmatch
import re
from typing import TYPE_CHECKING

from archvow import manifest as mf
from archvow.check import CUSTOM_KINDS, IGNORED_DIRS, custom_rules
from archvow.imports import Names

if TYPE_CHECKING:
    from archvow.check import _Checker


def run_custom(checker: _Checker) -> None:
    templates = list(checker.templates.values())
    rules = custom_rules(templates)
    if not rules:
        return
    for code, rule in rules.items():
        kinds = [k for k in CUSTOM_KINDS if k in rule]
        if len(kinds) != 1:
            checker.add("ARCH009", f"custom rule {code}: give exactly one of {', '.join(CUSTOM_KINDS)}",
                        mf.MANIFEST_REL.as_posix())
            rules = {c: r for c, r in rules.items() if c != code}
    files = _component_files(checker)
    for code, rule in rules.items():
        fix = f" -> {rule['fix']}" if rule.get("fix") else ""
        title = rule.get("title", code)
        if "forbid_file" in rule:
            for pattern in _as_list(rule["forbid_file"]):
                for path in sorted(checker.root.glob(pattern)):
                    rel = path.relative_to(checker.root)
                    if path.is_file() and not any(p.startswith(".") or p in IGNORED_DIRS for p in rel.parts[:-1]):
                        checker.add(code, f"{title}: {rel.as_posix()}{fix}", rel.as_posix())
            continue
        if "require_question" in rule:
            continue  # asked as a C question, checked with the other question sets
        for rel, layer, source in files:
            if rule.get("layers") and layer not in rule["layers"]:
                continue
            for line, found in _matches(rule, source):
                checker.add(code, f"{title}: {found}{fix}", rel, line)


def _as_list(value: object) -> list[str]:
    return [str(v) for v in value] if isinstance(value, list) else [str(value)]


def _component_files(checker: _Checker) -> list[tuple[str, str, str]]:
    """(path, layer, source) of every Python file of the containers."""
    found = []
    for container in checker.manifest.get("containers", []):
        base = checker.root / container["path"]
        if not base.is_dir():
            continue
        for path in sorted(base.rglob("*.py")):
            rel = path.relative_to(base)
            if any(p.startswith(".") or p in IGNORED_DIRS for p in rel.parts[:-1]):
                continue
            layer = rel.parts[0] if len(rel.parts) > 1 else ""
            found.append((path.relative_to(checker.root).as_posix(), layer,
                          path.read_text(encoding="utf-8", errors="replace")))
    return found


def _matches(rule: dict, source: str) -> list[tuple[int, str]]:
    if "forbid_pattern" in rule:
        pattern = re.compile(str(rule["forbid_pattern"]))
        return [(n, line.strip()) for n, line in enumerate(source.splitlines(), 1) if pattern.search(line)]
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []
    out = []
    names = Names(tree)
    for node in ast.walk(tree):
        if "forbid_import" in rule and isinstance(node, (ast.Import, ast.ImportFrom)):
            names = [a.name for a in node.names] if isinstance(node, ast.Import) else [node.module or ""]
            for name in names:
                if any(name == p or name.startswith(p + ".") for p in _as_list(rule["forbid_import"])):
                    out.append((node.lineno, f"import {name}"))
        elif "forbid_call" in rule and isinstance(node, ast.Call):
            called = ast.unparse(node.func)
            full = names.full_name(node.func)  # an alias is resolved: `nap` -> time.sleep
            short = node.func.attr if isinstance(node.func, ast.Attribute) else called
            candidates = {called, f"*.{short}"} | ({full, f"*.{full.rsplit('.', 1)[-1]}"} if full else set())
            for pattern in _as_list(rule["forbid_call"]):
                if any(fnmatch.fnmatch(c, pattern) or c == pattern for c in candidates):
                    out.append((node.lineno, f"{called}()" + (f" ({full})" if full and full != called else "")))
                    break
    return out
