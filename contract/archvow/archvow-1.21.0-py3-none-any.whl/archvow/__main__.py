"""Allow `python -m archvow`."""

import sys

from archvow.cli import main

sys.exit(main())
