"""How big a project may grow: at most so many components, at most so many lines of code (ARCH058).

Two init answers the architects set, off by default (empty = no limit):

    archvow init <package> --force -a max_components=40 -a max_code_lines=8000

- `max_components`: the components of the vows, the foundations included (what `archvow show` lists).
  `archvow component add` refuses the one over the limit.
- `max_code_lines`: the lines of Python under the package's folder that are neither blank, nor comments,
  nor docstrings. Tests are not counted (nothing may discourage a test).

`archvow check` warns from 90 % and fails over the limit; `archvow next` shows both on its last lines.
Raising a limit (or removing it) is a weakening the architects see in the merge request (ARCH020);
lowering it is not. Past the limit, the answer is to split the project - or an architect raises it.
"""

from __future__ import annotations

import ast
import io
import tokenize
from pathlib import Path
from typing import TYPE_CHECKING

from archvow import manifest as mf

if TYPE_CHECKING:
    from archvow.check import _Checker

ANSWERS = {"components": "max_components", "code_lines": "max_code_lines"}
WARN_AT = 0.9


def limits(data: dict) -> dict[str, int | None]:
    """{components, code_lines}: the limits the project's init answers set (None: no limit)."""
    answers = data.get("init_answers") or {}
    found = {}
    for key, answer in ANSWERS.items():
        value = str(answers.get(answer) or "").strip()
        found[key] = int(value) if value.isdigit() and int(value) > 0 else None
    return found


def component_count(data: dict) -> int:
    return sum(len(c.get("components") or []) for c in data.get("containers") or [])


def _code_lines(text: str) -> int:
    """Lines that hold code: not blank, not only a comment, not part of a docstring."""
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return sum(1 for line in text.splitlines() if line.strip() and not line.strip().startswith("#"))
    docstrings: set[int] = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)) and node.body:
            first = node.body[0]
            if isinstance(first, ast.Expr) and isinstance(first.value, ast.Constant) and isinstance(first.value.value, str):
                docstrings.update(range(first.lineno, (first.end_lineno or first.lineno) + 1))
    code: set[int] = set()
    try:
        for token in tokenize.generate_tokens(io.StringIO(text).readline):
            if token.type in (tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT,
                              tokenize.ENDMARKER):
                continue
            code.update(range(token.start[0], token.end[0] + 1))
    except (tokenize.TokenError, IndentationError):
        return len(code - docstrings)
    return len(code - docstrings)


def code_lines(root: Path, data: dict) -> int:
    """The lines of code of every container's package (its source folder), tests excluded."""
    total = 0
    for container in data.get("containers") or []:
        if not container.get("path"):
            continue
        base = root / str(container.get("path") or "")  # the package's folder (src/<package>)
        if not base.is_dir():
            continue
        for path in base.rglob("*.py"):
            if "__pycache__" in path.parts:
                continue
            total += _code_lines(path.read_text(encoding="utf-8", errors="replace"))
    return total


def usage(root: Path, data: dict) -> list[dict]:
    """[{what, used, limit}] for each limit set."""
    found = limits(data)
    rows = []
    if found["components"]:
        rows.append({"what": "components", "used": component_count(data), "limit": found["components"]})
    if found["code_lines"]:
        rows.append({"what": "code lines", "used": code_lines(root, data), "limit": found["code_lines"]})
    return rows


def refuse_new_component(data: dict, package: str) -> str | None:
    """Why a new component is refused (the project holds as many as its limit), else None."""
    limit = limits(data)["components"]
    count = component_count(data)
    if limit and count >= limit:
        return (f"{package} holds {count} components, its limit (max_components {limit}, ARCH058): split the "
                f"project, or an architect raises the limit: archvow init {package} --force -a max_components=<n>")
    return None


def run_limits(checker: _Checker) -> None:
    """ARCH058: over a limit is an error; from 90 % a warning, so the team sees it coming."""
    data = checker.manifest
    package = ((data.get("containers") or [{}])[0]).get("package", "<package>")
    for row in usage(checker.root, data):
        used, limit, what = row["used"], row["limit"], row["what"]
        answer = "max_components" if what == "components" else "max_code_lines"
        if used > limit:
            checker.add("ARCH058", f"the project has {used} {what}, over its limit of {limit} -> split the project, "
                        f"or an architect raises it: archvow init {package} --force -a {answer}=<n>",
                        mf.PROJECT_REL.as_posix())
        elif used >= WARN_AT * limit:
            checker.report.violations.append(_warning(checker, f"the project has {used} {what} of its {limit} "
                                                                f"({round(100 * used / limit)} %)"))


def _warning(checker: _Checker, message: str):
    from archvow.check import Violation

    return Violation("ARCH058", "warning", message, mf.PROJECT_REL.as_posix(), 0, 0, checker.rules["ARCH058"][1])
