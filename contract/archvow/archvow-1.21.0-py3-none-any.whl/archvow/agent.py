"""Is an AI agent running archvow, and does it run protected? ARCH051, ARCH052, ARCH053.

archvow does not configure the agents: it looks at where it runs. An agent runs archvow itself
(`archvow next` first, `archvow check`, the Git hook when it commits), so archvow runs inside the
agent, with the agent's rights, and can see three things:

1. Which agent called it: a parent process named after the tool (`claude`, `codex`, `copilot`...), or
   a variable the tool sets in the terminals where IT runs commands (CLAUDECODE, COPILOT_AGENT,
   CURSOR_AGENT, the common AGENT and AI_AGENT). Never the editor itself: a person's terminal in the
   editor has the editor as parent too. No signal: a person runs archvow, nothing changes.
2. ARCH051 - whether the agent is in a sandbox: archvow tries to create an empty file in the home
   folder (outside the project) and deletes it at once. If it can, the agent is not in a sandbox. A
   container counts as one, and so does an agent started by `archvow review` (the CI job).
3. ARCH052 - whether the agent was started in YOLO mode: the options of its command line that let it
   act without asking (--dangerously-skip-permissions, --yolo, --allow-all...).

The tools are template data (`ai_tool_detect`), not code: a company template adds its agent there.

archvow keeps each agent's last state in .archvow/agents.local (gitignored). When a person commits
code an agent wrote (the file header says `@assisted <tool>`), ARCH053 looks at that state; the
pre-commit hook leaves an `Archvow-Agent:` line that the commit-msg hook adds to the message, and
`archvow check --base` (CI) looks for that line on every commit of the merge request - a commit made
with `--no-verify` has none. A protection against mistakes and forgetting, not against cheating.
"""

from __future__ import annotations

import os
import re
import subprocess
import sys
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

STATE_REL = Path(".archvow/agents.local")    # each agent's last state, one line per agent (local)
TRAILER_REL = Path(".archvow/trailer.local")  # what the commit-msg hook adds to the next commit
TRAILER = "Archvow-Agent"
DOCS = "docs/agent-security.md"
CONTAINER_MARKERS = (Path("/.dockerenv"), Path("/run/.containerenv"))
GENERIC_VARIABLES = ("AI_AGENT", "AGENT")  # the common conventions: the value names the agent
INTERPRETERS = {"node", "nodejs", "bun", "deno", "python", "python3", "sh", "bash", "zsh", "dash"}
HEADER_RE = re.compile(r"^\s*@assisted\s+(.*?)\s*$", re.MULTILINE)


@dataclass
class Agent:
    """The agent archvow runs inside, as archvow sees it."""

    tool: str                 # claude-code, codex... or the name an unknown agent gives itself
    signal: str               # how it was seen: "process claude", "variable CURSOR_AGENT"
    sandboxed: bool = False
    where: str = ""           # why archvow says sandboxed or not
    yolo: list[str] = field(default_factory=list)  # the options found on its command line

    @property
    def state(self) -> str:
        return f"sandbox={'yes' if self.sandboxed else 'no'} yolo={'yes' if self.yolo else 'no'}"


# ------------------------------------------------------------------ where archvow runs


def _base(word: str) -> str:
    name = re.split(r"[\\/]", word)[-1].lower()
    return re.sub(r"\.(exe|cmd|bat|ps1|js|mjs|cjs)$", "", name)


def _names(args: list[str]) -> set[str]:
    """The program a process runs: its file name, or the script an interpreter runs (node claude)."""
    names = {_base(args[0])} if args else set()
    if args and _base(args[0]) in INTERPRETERS:
        names |= {_base(a) for a in args[1:2] if not a.startswith("-")}
    return names


def _linux_ancestors() -> list[tuple[int, list[str]]]:
    found, pid = [], os.getppid()
    for _ in range(40):
        if pid <= 1:
            break
        try:
            raw = Path(f"/proc/{pid}/cmdline").read_bytes()
            stat = Path(f"/proc/{pid}/stat").read_text(encoding="utf-8", errors="replace")
        except OSError:
            break
        args = [a.decode("utf-8", "replace") for a in raw.split(b"\0") if a]
        if not args:  # a process without a command line (a kernel thread): its short name
            args = [stat[stat.find("(") + 1:stat.rfind(")")]]
        found.append((pid, args))
        pid = int(stat[stat.rfind(")") + 2:].split()[1])
    return found


def _ps_ancestors() -> list[tuple[int, list[str]]]:
    """macOS and other Unix: one `ps` for every process, then the chain of parents."""
    try:
        out = subprocess.run(["ps", "-axo", "pid=,ppid=,args="], capture_output=True, text=True,
                             encoding="utf-8", errors="replace", timeout=10, check=False).stdout
    except (OSError, subprocess.SubprocessError):
        return []
    table = {}
    for line in out.splitlines():
        parts = line.split(None, 2)
        if len(parts) >= 2 and parts[0].isdigit() and parts[1].isdigit():
            table[int(parts[0])] = (int(parts[1]), (parts[2] if len(parts) > 2 else "").split())
    found, pid = [], os.getppid()
    for _ in range(40):
        if pid <= 1 or pid not in table:
            break
        parent, args = table[pid]
        found.append((pid, args))
        pid = parent
    return found


def _windows_ancestors() -> list[tuple[int, list[str]]]:
    """Windows: the parents' program names (Toolhelp); their command lines are not read."""
    try:
        import ctypes
        from ctypes import wintypes

        class Entry(ctypes.Structure):
            _fields_ = [("dwSize", wintypes.DWORD), ("cntUsage", wintypes.DWORD),
                        ("th32ProcessID", wintypes.DWORD), ("th32DefaultHeapID", ctypes.c_void_p),
                        ("th32ModuleID", wintypes.DWORD), ("cntThreads", wintypes.DWORD),
                        ("th32ParentProcessID", wintypes.DWORD), ("pcPriClassBase", ctypes.c_long),
                        ("dwFlags", wintypes.DWORD), ("szExeFile", ctypes.c_wchar * 260)]

        kernel = ctypes.windll.kernel32  # type: ignore[attr-defined]
        kernel.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
        snapshot = kernel.CreateToolhelp32Snapshot(0x2, 0)
        entry = Entry()
        entry.dwSize = ctypes.sizeof(Entry)
        table = {}
        more = kernel.Process32FirstW(snapshot, ctypes.byref(entry))
        while more:
            table[entry.th32ProcessID] = (entry.th32ParentProcessID, entry.szExeFile)
            more = kernel.Process32NextW(snapshot, ctypes.byref(entry))
        kernel.CloseHandle(snapshot)
    except Exception:  # noqa: BLE001 - no process table: archvow sees no parent
        return []
    found, pid = [], os.getppid()
    for _ in range(40):
        if pid not in table or pid == 0:
            break
        parent, name = table[pid]
        found.append((pid, [name]))
        pid = parent
    return found


def _ancestors() -> list[tuple[int, list[str]]]:
    """archvow's parent processes, nearest first: (pid, command line)."""
    if sys.platform.startswith("linux") and Path("/proc/self/stat").is_file():
        return _linux_ancestors()
    if os.name == "nt":
        return _windows_ancestors()
    return _ps_ancestors()


def _tokens(args: list[str]) -> list[str]:
    """A command line as words, --option=value split in two: both spellings compare alike."""
    words = []
    for arg in args:
        if arg.startswith("--") and "=" in arg:
            words += arg.split("=", 1)
        else:
            words.append(arg)
    return words


def _has(words: list[str], option: str) -> bool:
    wanted = _tokens(option.split())
    return any(words[i:i + len(wanted)] == wanted for i in range(len(words) - len(wanted) + 1))


def _started_by_review(chain: list[tuple[int, list[str]]]) -> bool:
    """An agent `archvow review` started (the CI job): it runs with the tools the review allows."""
    for _, args in chain:
        names = [_base(a) for a in args]
        if "archvow" in names and "review" in args[names.index("archvow") + 1:]:
            return True
    return False


def _sandbox(root: Path) -> tuple[bool, str]:
    """Can the agent write outside the project? An empty file in the home folder, deleted at once."""
    marker = next((m for m in CONTAINER_MARKERS if m.exists()), None)
    if marker is not None:
        return True, f"a container ({marker})"
    target = Path.home()
    try:
        if target.resolve() == root.resolve() or root.resolve() in target.resolve().parents:
            target = root.resolve().parent  # a home folder inside the project: next to the project
    except OSError:
        pass
    probe = target / f".archvow-sandbox-test-{os.getpid()}"
    try:
        with open(probe, "x", encoding="utf-8"):
            pass
    except OSError:
        return True, f"it cannot write in {target}"
    try:
        probe.unlink()
    except OSError:
        pass
    return False, f"it can write in {target}, outside the project"


def detect(root: Path, tools: dict) -> Agent | None:
    """The agent archvow runs inside (None: a person). `tools` = the template's `ai_tool_detect`."""
    chain = _ancestors()
    agent = None
    for _, args in chain:
        names = _names(args)
        tool = next((t for t, d in tools.items() if names & {p.lower() for p in (d or {}).get("processes") or []}),
                    None)
        if tool is not None:
            words = _tokens(args)
            yolo = [o for o in (tools[tool] or {}).get("yolo") or [] if _has(words, o)]
            agent = Agent(tool, f"process {min(names & set((tools[tool] or {}).get('processes') or []))}",
                          yolo=yolo)
            break
    if agent is None:
        agent = _by_variable(tools)
    if agent is None:
        return None
    if _started_by_review(chain):
        agent.sandboxed, agent.where = True, "started by archvow review (the CI job)"
    else:
        agent.sandboxed, agent.where = _sandbox(root)
    return agent


def _by_variable(tools: dict) -> Agent | None:
    for tool, data in tools.items():
        for marker in (data or {}).get("env") or []:
            name, _, start = str(marker).partition("=")
            value = os.environ.get(name, "")
            if value and value.lower() not in ("0", "false", "no") and value.lower().startswith(start.lower()):
                return Agent(tool, f"variable {name}")
    for name in GENERIC_VARIABLES:
        value = os.environ.get(name, "").strip()
        if value and value.lower() not in ("0", "false", "no"):
            label = re.sub(r"[^A-Za-z0-9._-]", "", value)[:40] or "an AI agent"
            return Agent(label if not label.isdigit() and label.lower() != "true" else "an AI agent",
                         f"variable {name}")
    return None


def marker_variables(tools: dict) -> set[str]:
    """Every variable that says an agent runs archvow (the tests run without them)."""
    names = {str(m).partition("=")[0] for data in tools.values() for m in (data or {}).get("env") or []}
    return names | set(GENERIC_VARIABLES)


# ------------------------------------------------------------------ the project's settings


def tool_data(root: Path, data: dict) -> dict:
    """`ai_tool_detect` of the project's template ({} when it cannot be loaded)."""
    from archvow import manifest as mf
    from archvow.templates import TemplateError, load_template

    try:
        template = load_template(mf.template_name(data["containers"][0])[0], root)
    except (TemplateError, KeyError, IndexError):
        return {}
    return dict(template.data.get("ai_tool_detect") or {})


def sandbox_required(data: dict) -> bool:
    """The `sandbox` answer: yes by default in mode strict, no in guided and free."""
    answer = (data.get("init_answers") or {}).get("sandbox")
    if answer is None:
        return str(data.get("mode") or "strict") == "strict"
    return str(answer) == "yes"


def unseen(tools: dict, approved: list[str]) -> list[tuple[str, str]]:
    """The approved assistants archvow cannot always see: (tool, where it cannot)."""
    found = []
    for tool in approved:
        entry = tools.get(tool) or {}
        if tool == "none":
            continue
        if not entry.get("processes") and not entry.get("env"):
            found.append((tool, "when it runs commands (it sets no variable archvow knows)"))
        elif entry.get("unseen"):
            found.append((tool, str(entry["unseen"])))
    return found


def problems(agent: Agent, required: bool) -> list[tuple[str, str]]:
    """Why archvow refuses to run inside this agent: (code, message)."""
    found = []
    if agent.yolo:
        options = ", ".join(agent.yolo)
        found.append(("ARCH052", f"{agent.tool} runs in YOLO mode ({options}): it acts without asking anyone - stopped"))
    if required and not agent.sandboxed:
        found.append(("ARCH051", f"{agent.tool} runs outside a sandbox ({agent.where}) - stopped"))
    return found


# ------------------------------------------------------------------ each agent's last state


def read_states(root: Path) -> dict[str, dict]:
    """tool -> {when, sandbox, yolo, blocked}."""
    path = root / STATE_REL
    states = {}
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError:
        return states
    for line in lines:
        words = line.split()
        if len(words) < 5 or line.startswith("#"):
            continue
        values = dict(w.split("=", 1) for w in words[2:4] if "=" in w)
        states[words[0]] = {"when": words[1], "sandbox": values.get("sandbox", "no"),
                            "yolo": values.get("yolo", "no"), "blocked": words[4] == "blocked",
                            "why": " ".join(words[5:])}
    return states


def write_state(root: Path, agent: Agent, blocked: list[tuple[str, str]]) -> None:
    states = read_states(root)
    when = datetime.now().astimezone().isoformat(timespec="minutes")
    lines = ["# archvow: each AI agent's last run in this project (local, never committed)"]
    for tool, state in sorted(states.items()):
        if tool != agent.tool:
            lines.append(f"{tool} {state['when']} sandbox={state['sandbox']} yolo={state['yolo']} "
                         f"{'blocked ' + state['why'] if state['blocked'] else 'ok'}".rstrip())
    why = "; ".join(code for code, _ in blocked)
    lines.append(f"{agent.tool} {when} {agent.state} {'blocked ' + why if blocked else 'ok'}")
    try:
        (root / STATE_REL).write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    except OSError:  # a read-only checkout: nothing kept
        pass


# The commands that decide or change the spec: a person runs them, never an agent (ARCH054). The AI
# may add a question or an assumption, and in modes guided and free propose a decision and add a
# component, a hazard, an invariant or a rule: each is marked as the AI's (`origin ai` for a component,
# `added_by <agent>` for the others) until a person keeps it (component / question / hazard / rule accept).
PERSON_ONLY = {"component": "", "decision make": "", "decision add": "", "decision accept": "",
               "question remove": "", "question accept": "", "assumption review": "assumption accept/reject", "hazard": "",
               "invariant": "", "rule": "", "column": "", "dependency": "", "brief accept": "", "example": "", "specify": "",
               "freeze": "", "init": ""}


AI_IN_GUIDED = ("component add", "hazard add", "invariant add", "rule add")  # the AI's own, in guided and free


def person_only(command: str, mode: str = "strict") -> str | None:
    """`command` as words ("decision make"): the name to show when only a person runs it, else None."""
    if mode in ("guided", "free") and command in AI_IN_GUIDED:
        return None
    for prefix, shown in PERSON_ONLY.items():
        if command == prefix or command.startswith(prefix + " "):
            return shown or prefix
    return None


def author(root: Path, data: dict) -> str | None:
    """The AI agent that runs this command (its tool's name), or None when a person runs it."""
    found = detect(root, tool_data(root, data))
    return found.tool if found else None


def gate(root: Path, data: dict, command: str = "") -> list[str]:
    """Run before every command in a project: the lines to print when archvow refuses to run
    inside this agent (empty: it goes on). The agent's state is kept for the commit check."""
    tools = tool_data(root, data)
    agent = detect(root, tools)
    if agent is None:
        return []
    found = problems(agent, sandbox_required(data))
    write_state(root, agent, found)
    reserved = person_only(command, str(data.get("mode") or "strict"))
    if reserved and not found:  # protected, but this command is a person's
        return [(f"ARCH054 {agent.tool} ran `archvow {reserved}`: only a person runs it (it decides or changes "
                 "the spec) - stopped"),
                "  fix: give the person the exact command; they run it in their own terminal"]
    if not found:
        return []
    fix = str((tools.get(agent.tool) or {}).get("fix") or "start the agent in its sandbox, without the "
                                                           "options that let it act without asking")
    lines = [f"{code} {message}" for code, message in found]
    if reserved:
        lines.append(f"ARCH054 `archvow {reserved}` is a person's command anyway: give it to them")
    lines += [f"  fix: {fix}", f"  why and how: {DOCS} (a person runs `archvow doctor` to see what archvow sees)"]
    return lines


def gate_outside(start: Path, command: str) -> list[str]:
    """Outside a project (archvow init in a new folder): only the person-only check, with the
    built-in assistants' signals."""
    if not person_only(command):
        return []
    from archvow.templates import TemplateError, load_template

    try:
        tools = dict(load_template("python-app", None).data.get("ai_tool_detect") or {})
    except TemplateError:
        return []
    agent = detect(start, tools)
    if agent is None:
        return []
    return [f"ARCH054 {agent.tool} ran `archvow {person_only(command)}`: only a person runs it - stopped",
            "  fix: give the person the exact command; they run it in their own terminal"]


def describe(root: Path, data: dict) -> tuple[str, str]:
    """What `archvow doctor` says: (status ok|fail, one line)."""
    agent = detect(root, tool_data(root, data))
    if agent is None:
        return "ok", "none (archvow runs for a person)"
    line = (f"{agent.tool} ({agent.signal}) · sandbox: {'yes' if agent.sandboxed else 'no'} ({agent.where})"
            f" · YOLO: {', '.join(agent.yolo) if agent.yolo else 'no'}")
    return ("fail" if problems(agent, sandbox_required(data)) else "ok"), line


# ------------------------------------------------------------------ ARCH053: code an agent wrote


def assisted_tools(text: str) -> list[str]:
    """The AI tools a file's header names (@assisted claude-code, copilot), none left out."""
    match = HEADER_RE.search(text[:4000])
    if not match or "<" in match.group(1):
        return []
    return [t.strip().lower() for t in match.group(1).split(",") if t.strip() and t.strip().lower() != "none"]


def _git(root: Path, *args: str) -> str | None:
    try:
        done = subprocess.run(["git", "-C", str(root), *args], capture_output=True, text=True,
                              encoding="utf-8", errors="replace", timeout=60, check=False)
    except (OSError, subprocess.SubprocessError):
        return None
    return done.stdout if done.returncode == 0 else None


def run_agents(checker) -> None:  # checker: check._Checker (imported, it would be a cycle)
    """ARCH053 before a commit: for the changed files an AI tool wrote, how that tool last ran here.
    Also prepares the `Archvow-Agent:` lines the commit-msg hook adds to the message."""
    root = checker.root
    changed = _git(root, "diff", "--name-only", "--relative", "HEAD")
    trailer = root / TRAILER_REL
    if changed is None:  # no Git, or no commit yet
        return
    changed += _git(root, "ls-files", "--others", "--exclude-standard") or ""  # new files, not added yet
    by_tool: dict[str, list[str]] = {}
    for rel in changed.splitlines():
        path = root / rel
        if rel.endswith(".py") and path.is_file():
            for tool in assisted_tools(path.read_text(encoding="utf-8", errors="replace")):
                by_tool.setdefault(tool, []).append(rel)
    if not by_tool:
        trailer.unlink(missing_ok=True)
        return
    states = read_states(root)
    tools = tool_data(root, checker.manifest)
    hidden = dict(unseen(tools, list(by_tool)))
    strict = str(checker.manifest.get("mode") or "strict") == "strict"
    lines = []
    for tool, files in sorted(by_tool.items()):
        state = states.get(tool)
        where = files[0] + (f" (and {len(files) - 1} more)" if len(files) > 1 else "")
        if state is None:
            lines.append(f"{tool} unverified")
            if tool in hidden:
                checker.add("ARCH053", f"written by {tool}, which archvow cannot see {hidden[tool]}: nobody "
                                       "checked how it ran (sandbox, YOLO mode)", where)
            else:
                checker.add("ARCH053", f"written by {tool}, which never ran archvow in this project: nobody "
                                       f"checked how it ran - ask {tool} to run `archvow check`, then commit again",
                            where, escalate=strict)
            continue
        lines.append(f"{tool} sandbox={state['sandbox']} yolo={state['yolo']}")
        if state["blocked"]:
            checker.add("ARCH053", f"written by {tool} while archvow refused to run inside it ({state['why']}, "
                                   f"{state['when']}): start it protected, let it run `archvow check`, then "
                                   "commit again", where, escalate=True)
    try:
        trailer.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    except OSError:
        pass


def check_commits(checker, commit: str) -> None:  # checker: check._Checker
    """ARCH053 in CI (`check --base`): every commit of the branch that changes a file an AI tool
    wrote carries the hook's `Archvow-Agent:` line for that tool, saying it ran protected."""
    root = checker.root
    log = _git(root, "log", "--no-merges", "--format=%H%x00%B%x01", f"{commit}..HEAD")
    if not log:
        return
    required = sandbox_required(checker.manifest)
    strict = str(checker.manifest.get("mode") or "strict") == "strict"
    for entry in log.split("\x01"):
        sha, _, body = entry.strip().partition("\x00")
        if not sha:
            continue
        files = _git(root, "diff-tree", "--no-commit-id", "--name-only", "-r", "--relative", sha) or ""
        written = {}
        for rel in files.splitlines():
            if rel.endswith(".py"):
                text = _git(root, "show", f"{sha}:./{rel}")
                for tool in assisted_tools(text or ""):
                    written.setdefault(tool, rel)
        if not written:
            continue
        said = {}
        for line in body.splitlines():
            name, _, value = line.partition(":")
            if name.strip().lower() == TRAILER.lower() and value.split():
                said[value.split()[0].lower()] = value.split()[1:]
        for tool, rel in sorted(written.items()):
            words = said.get(tool)
            where = f"commit {sha[:8]}"
            if words is None:
                checker.add("ARCH053", f"{where}: code written by {tool}, and the commit has no {TRAILER} line - "
                                       "the Git hooks did not run (git commit --no-verify?): redo it with the hooks "
                                       "on (the last commit: git reset --soft HEAD~1, then git commit; the hooks: "
                                       "git config core.hooksPath .githooks)", rel, escalate=strict)
            elif "yolo=yes" in words or (required and "sandbox=no" in words):
                checker.add("ARCH053", f"{where}: code written by {tool} while it ran "
                                       f"{'in YOLO mode' if 'yolo=yes' in words else 'outside a sandbox'}",
                            rel, escalate=True)
