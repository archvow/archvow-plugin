"""Drift and rule checking.

Static only (Python `ast`): the project code is never imported or executed,
so the check needs neither PySpark nor a JVM and runs in milliseconds - fast
enough for CI, pre-commit hooks and live IDE inspections.
"""

from __future__ import annotations

import ast
import io
import re
import sys
import tokenize
from dataclasses import asdict, dataclass, field
from pathlib import Path

from archvow import manifest as mf
from archvow.imports import Names
from archvow.review import check_reports
from archvow.templates import Template, TemplateError, load_template

# code -> (default severity, title). Templates and the manifest may override
# severities ("error" | "warning" | "off") and parameters.
RULES: dict[str, tuple[str, str]] = {
    # Architecture / drift
    "ARCH001": ("error", "Module not declared in the spec"),
    "ARCH002": ("error", "Public symbol not declared in the spec"),
    "ARCH003": ("error", "Declared symbol not implemented, or still a placeholder (reported with --complete)"),
    "ARCH004": ("error", "Signature/annotation differs from the spec"),
    "ARCH005": ("error", "Illegal dependency between layers"),
    "ARCH006": ("error", "Undeclared dependency between components (missing in `uses`)"),
    "ARCH007": ("error", "Import forbidden in this layer"),
    "ARCH008": ("error", "Declared module file not created (reported with --complete)"),
    "ARCH009": ("error", "Invalid entry in a vow"),
    "ARCH010": ("error", "File outside any layer (neither a layer folder nor mapped in `layer_paths`)"),
    "ARCH011": ("error", "Suppression without a justification"),
    "ARCH012": ("warning", "Project template version differs from installed template"),
    "ARCH013": ("error", "File cannot be parsed"),
    "ARCH014": ("error", "Entry of a vow differs from what its template generates (hand-edited?)"),
    "ARCH015": ("error", "Python file outside the architecture (no container, not an allowed path)"),
    "ARCH016": ("error", "Test file does not follow the test layout"),
    "ARCH017": ("error", "Implemented component without its test"),
    "ARCH018": ("error", "Component file without a correct file header"),
    "ARCH019": ("warning", "Component without the data contract its type works on (a reader without its schema)"),
    "ARCH020": ("error", "Guard weakened compared to the base branch"),
    "ARCH040": ("error", "Configuration of an AI assistant not approved for this repository"),
    "ARCH041": ("error", "Review by an AI tool not approved as a reviewer"),
    "ARCH042": ("error", "Review by the AI tool that wrote the code (self-review)"),
    "ARCH030": ("error", "Critical/high hazard that no invariant prevents"),
    "ARCH031": ("error", "An invariant of an implemented component is not tested yet"),
    "ARCH032": ("error", "An invariant's test is not of the kind it requires"),
    "ARCH033": ("error", "Implemented while a decision is still to make"),
    "ARCH034": ("error", "Implemented on an assumption nobody reviewed yet"),
    "ARCH035": ("warning", "Safety question of a component not answered (no hazard, no dismissal)"),
    "ARCH036": ("error", "Invalid hazard, dismissal, invariant or project rule entry"),
    "ARCH037": ("error", "Invariant tested too weakly for the hazard's severity"),
    "ARCH038": ("warning", "A decision or rule of an implemented component has no marked test"),
    "ARCH043": ("warning", "What the AI proposed or added (a decision, a component, a question, a hazard, a rule) is not reviewed by a person yet (an error at the release gate in mode guided)"),
    "ARCH044": ("warning", "A component's task is too long for one AI session (over max_tokens)"),
    "ARCH045": ("warning", "A test marked as evidence checks nothing (an error in mode strict and with --complete)"),
    "ARCH046": ("error", "A marked test did not run and pass in the test report (check --test-report)"),
    "ARCH050": ("error", "A file in .archvow/ that archvow does not write (nobody owns it in CODEOWNERS)"),
    "ARCH051": ("error", "An AI agent runs archvow outside a sandbox (it can write outside the project)"),
    "ARCH052": ("error", "An AI agent runs archvow in YOLO mode (it acts without asking anyone)"),
    "ARCH054": ("error", "An AI agent runs a command only a person runs (it decides or changes the spec)"),
    "ARCH053": ("warning", ("Code an AI agent wrote, with no proof it ran protected (an error when it ran "
                            "blocked, or in mode strict)")),
    "ARCH039": ("warning", "A brief changed after the spec was drawn from it"),
    "ARCH055": ("error", "A business example's files differ from the ones a person recorded"),
    "ARCH056": ("warning", "A business example has no marked test (an error in mode strict and with --complete)"),
    "ARCH057": ("warning", "An item recorded before its component changed is not reviewed yet (an error with --complete)"),
    "ARCH058": ("error", "The project is over its limit of components or lines of code (a warning from 90 %)"),
    "ARCH021": ("warning", "New suppression compared to the base branch"),
    "ARCH022": ("error", "Change too big for one merge request (files or lines over the budget)"),
    "ARCH023": ("error", "Third-party package imported without approval"),
    "ARCH024": ("warning", "Package in requirements.txt or pyproject.toml without approval (an error in mode strict)"),
    # PySpark (Palantir PySpark style guide + layer purity)
    "SPK001": ("error", "Spark/file I/O outside an I/O layer"),
    "SPK002": ("error", "Spark action or execution control in a lazy-only layer"),
    "SPK003": ("error", "SparkSession built outside the session layer"),
    "SPK004": ("error", "join() without explicit how= keyword"),
    "SPK005": ("error", "Right join (swap the DataFrames and use a left join)"),
    "SPK006": ("warning", "Python or pandas UDF used (prefer native pyspark.sql.functions)"),
    "SPK007": ("error", "Non-standard PySpark import (use functions as F, types as T, Window as W)"),
    "SPK008": ("warning", "Backslash line continuation (wrap the expression in parentheses)"),
    "SPK009": ("warning", "Method chain longer than allowed"),
    "SPK010": ("warning", "Window ordered without an explicit frame (rowsBetween/rangeBetween)"),
    "SPK011": ("error", "Empty Window.partitionBy() (moves all data to one partition)"),
    "SPK012": ("error", "Empty column filled with '' or 'NA' (use F.lit(None))"),
    "SPK013": ("warning", "withColumnRenamed() (prefer .alias() inside a select)"),
    "SPK014": ("warning", "distinct()/dropDuplicates() (fix the cause of duplicates instead)"),
    # FastAPI (template fastapi-service)
    "FAPI001": ("error", "Blocking call inside an async function (it stops every other request)"),
    "FAPI002": ("error", "HTTPException outside the HTTP layers (raise a domain error instead)"),
    "FAPI003": ("error", "FastAPI app created outside an app component"),
    "FAPI004": ("error", "on_event startup/shutdown handler (use the lifespan of the app)"),
    "FAPI005": ("warning", "Route without a response model or return type"),
    # Size limits (Palantir: file <= 250 lines, function <= 70 lines), short scripts, few comments
    "STY001": ("warning", "File longer than allowed"),
    "STY002": ("warning", "Function longer than allowed"),
    "STY003": ("warning", "Shell script longer than allowed (move the logic into Python)"),
    "STY004": ("warning", "Too many comment lines for the code (say it in names and docstrings)"),
    # GDPR / RGPD (`rules` answer GDPR, on by default)
    "GDPR001": ("error", "Column not classified in the spec (personal, special or none)"),
    "GDPR002": ("error", "Personal data processed without a decided purpose and legal basis"),
    "GDPR003": ("error", "Personal data written without a decided retention and erasure"),
    "GDPR004": ("error", "Personal data printed, shown or logged"),
    "GDPR005": ("error", "Special-category data written without a tested pseudonymisation or encryption"),
    "GDPR006": ("error", "Files partitioned or bucketed by a personal column (values end up in paths)"),
    "GDPR007": ("error", "Personal data in a URL (path or query parameter: it ends up in access logs)"),
    "GDPR008": ("error", "Personal data stored without a decided location and transfer safeguard"),
    "GDPR009": ("warning", "Classified column not found in the code"),
    # Test data (`rules` answer TST, on by default)
    "TST001": ("error", "A test reads data from outside tests/ (database, cloud storage, absolute path)"),
    "TST002": ("error", "Real-looking personal identifier in test data"),
    "TST003": ("error", "Binary or too large data file in tests/ (a real extract?)"),
    # DORA (`rules` answer DORA, opt-in)
    "DORA001": ("error", "Component without a ticket"),
    "DORA002": ("error", "Separation of duties: fewer than two people can approve guard changes"),
    "DORA003": ("error", "Third-party package missing from the register, or a critical one not pinned"),
    "DORA004": ("error", "An invariant's test can be skipped, or a failing test job allowed to pass"),
    "DORA005": ("error", "Operational question not answered (failure detection, recovery)"),
    "DORA006": ("warning", "Registered licence differs from the installed package's"),
}

# Checks that stay on in every mode and whatever the `rules` answer says: the few that protect a
# critical project (guards weakened, critical/high hazards without a tested invariant, unapproved
# AI tools, a file in .archvow/ nobody owns, an AI agent unprotected, a business example's files
# changed, personal data unclassified or written in the clear).
FLOOR = ("ARCH020", "ARCH030", "ARCH031", "ARCH040", "ARCH050", "ARCH051", "ARCH052", "ARCH053", "ARCH054",
         "ARCH055", "GDPR001", "GDPR005")
COMPLIANCE_FAMILIES = ("GDPR", "TST", "DORA")  # kept as `compliance` in the manifest


def family_name(code: str, families: dict) -> str:
    """The family a rule belongs to (rules/<NAME>.md): the template's `rule_families` (longest code
    prefix), else the code's letters (a company's custom rules)."""
    prefix = max((p for p in families if code.startswith(p)), key=len, default=None)
    if prefix is not None:
        return str((families[prefix] or {}).get("name") or prefix).upper()
    match = re.match(r"[A-Z]+", code)
    return match.group(0) if match else code


def chosen_families(manifest: dict) -> set[str] | None:
    """The code families of the `rules` answer `check` applies (None: all of them)."""
    chosen = manifest.get("families")
    if chosen is None or "all" in chosen:
        return None
    return {str(f).upper() for f in chosen if f != "none"}


def family_enabled(code: str, families: dict, chosen: set[str] | None) -> bool:
    if code in FLOOR or chosen is None:
        return True
    name = family_name(code, families)
    return name in COMPLIANCE_FAMILIES or name in chosen


# Rule families a template switches on with `rule_sets:`, or the project with the GDPR, TST
# and DORA of its `rules` answer (the other rules - and a template's `custom_rules` - apply to every project).
RULE_SETS = {"SPK": "pyspark", "FAPI": "fastapi", "GDPR": "gdpr", "TST": "tst", "DORA": "dora"}
CUSTOM_KINDS = ("forbid_import", "forbid_call", "forbid_pattern", "forbid_file", "require_question")


def missing_contracts(comp: dict, ctype: dict, by_id: dict) -> list[str]:
    """The types a component must use and does not (`requires_uses`: a reader needs its schema)."""
    used = {(by_id.get(u) or {}).get("type") for u in comp.get("uses") or []}
    return [t for t in ctype.get("requires_uses") or [] if t not in used]


REQUIREMENT_RE = re.compile(r"^\s*([A-Za-z0-9][A-Za-z0-9._-]*)")


def _pep503(name: str) -> str:
    """A package name as pip compares it: PyYAML, pyyaml and py_yaml are one package."""
    return re.sub(r"[-_.]+", "-", name).lower()


def _requirement_names(path: Path) -> list[tuple[str, int]]:
    """The packages a requirements file lists (options, -r, -e and URLs are not packages)."""
    if not path.is_file():
        return []
    found = []
    for number, line in enumerate(path.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
        text = line.split("#", 1)[0].strip()
        if not text or text.startswith(("-", "{", "git+", "http")) or ("://" in text and "@" not in text):
            continue
        match = REQUIREMENT_RE.match(text)
        if match:
            found.append((match.group(1), number))
    return found


def _pyproject_names(path: Path) -> list[tuple[str, int]]:
    """The packages of [project] dependencies and optional-dependencies (not the build tools)."""
    if not path.is_file():
        return []
    try:
        import tomllib
    except ImportError:  # Python 3.10: no TOML reader in the standard library - nothing checked
        return []
    text = path.read_text(encoding="utf-8", errors="replace")
    try:
        project = tomllib.loads(text).get("project") or {}
    except tomllib.TOMLDecodeError:
        return []
    entries = list(project.get("dependencies") or [])
    for extra in (project.get("optional-dependencies") or {}).values():
        entries += list(extra or [])
    lines = text.splitlines()
    found = []
    for entry in entries:
        match = REQUIREMENT_RE.match(str(entry))
        if match:
            number = next((n for n, line in enumerate(lines, 1) if str(entry) in line), 0)
            found.append((match.group(1), number))
    return found


def _template_packages(template: Template) -> list[str]:
    """The packages the template itself writes into requirements.txt and pyproject.toml."""
    names = []
    for rel, source in template.skeleton_files().items():
        if rel in ("requirements.txt.j2", "requirements.txt"):
            names += [n for n, _ in _requirement_names(source)]
        elif rel in ("pyproject.toml.j2", "pyproject.toml"):
            text = source.read_text(encoding="utf-8")
            for pattern in (r"^dependencies\s*=\s*\[(.*?)\]", r"^\[project\.optional-dependencies\](.*?)(?:^\[|\Z)"):
                block = re.search(pattern, text, re.DOTALL | re.MULTILINE)
                names += re.findall(r'"([A-Za-z0-9][A-Za-z0-9._-]*)', block.group(1)) if block else []
    return names


def _is_local_module(folder: Path, name: str) -> bool:
    """True when `name` is a module or package next to the importing file."""
    return (folder / f"{name}.py").is_file() or (folder / name / "__init__.py").is_file()


def rule_enabled(code: str, rule_sets: set[str] | list[str]) -> bool:
    """False for a rule of a family (e.g. the PySpark SPK rules) the project does not use."""
    family = next((name for prefix, name in RULE_SETS.items() if code.startswith(prefix)), None)
    return family is None or family in rule_sets


def generated_python_folders(template: Template) -> set[str]:
    """Top folders where the template itself writes Python files (an Airflow DAG in dags/): always
    allowed, whatever a company template's `allowed_paths` says."""
    folders = set()
    for rel in template.skeleton_files():
        target = rel.removesuffix(".j2")
        if target.endswith(".py") and "/" in target and not target.startswith("."):
            folders.add(target.split("/", 1)[0])
    return folders


def layer_paths(manifest: dict) -> list[tuple[str, str]]:
    """The project's `layer_paths` ({layer: [path, ...]}, paths from the project root) as (path, layer)
    pairs, longest path first: a file keeps its place and still belongs to a layer (adopted code)."""
    pairs = []
    for layer, paths in (manifest.get("layer_paths") or {}).items():
        for path in paths or []:
            clean = str(path).strip().replace("\\", "/").removeprefix("./").lstrip("/")
            if clean:
                pairs.append((clean, str(layer)))
    return sorted(pairs, key=lambda pair: -len(pair[0].rstrip("/")))


def mapped_layer(pairs: list[tuple[str, str]], rel: str) -> str | None:
    """The layer `layer_paths` gives the file `rel` (a .py entry is that file, any other a folder)."""
    for path, layer in pairs:
        if path.endswith(".py"):
            if rel == path:
                return layer
        elif rel.startswith(path.rstrip("/") + "/"):
            return layer
    return None


REQUIRES_PYTHON_RE = re.compile(r">=?\s*3\.(\d+)")


def newer_python_needed(root: Path) -> str | None:
    """The project's requires-python when it asks for a newer Python than the one running archvow."""
    try:
        import tomllib

        data = tomllib.loads((root / "pyproject.toml").read_text(encoding="utf-8"))
    except (OSError, ValueError, ImportError):
        return None
    wanted = str((data.get("project") or {}).get("requires-python") or "")
    match = REQUIRES_PYTHON_RE.search(wanted)
    if match and int(match.group(1)) > sys.version_info.minor:
        return wanted
    return None


def project_rule_sets(templates: list[Template], manifest: dict) -> set[str]:
    """The families switched on: the templates' `rule_sets` and the compliance families of `rules`."""
    sets = {s for t in templates for s in (t.data.get("rule_sets") or [])}
    return sets | {str(c) for c in manifest.get("compliance") or [] if c != "none"}


def custom_rules(templates: list[Template]) -> dict[str, dict]:
    """A template's own rules, declared as data (`custom_rules`): code -> definition."""
    found: dict[str, dict] = {}
    for template in templates:
        for code, rule in (template.data.get("custom_rules") or {}).items():
            if isinstance(rule, dict):
                found[str(code)] = rule
    return found


def all_rules(templates: list[Template]) -> dict[str, tuple[str, str]]:
    """archvow's rules and the templates' custom rules: code -> (default severity, title)."""
    rules = dict(RULES)
    for code, rule in custom_rules(templates).items():
        rules.setdefault(code, (str(rule.get("severity", "error")), str(rule.get("title", code))))
    return rules


DEFAULT_PARAMS = {"SPK009": {"max_chain": 5}, "TST003": {"max_kb": 200, "max_rows": 1000}, "STY001": {"max_lines": 250}, "STY002": {"max_lines": 70},
                  "STY003": {"max_lines": 150}, "STY004": {"max_percent": 30, "min_code_lines": 20},
                  "ARCH022": {"max_files": 30, "max_added_lines": 1000, "max_deleted_lines": 300},
                  "ARCH044": {"max_tokens": 4000}}

IO_ATTRS = {"read", "readStream", "write", "writeStream", "saveAsTable", "insertInto", "table"}
ACTION_ATTRS = {
    "collect", "toPandas", "show", "take", "first", "head", "count", "foreach",
    "foreachPartition", "toLocalIterator", "cache", "persist", "checkpoint", "unpersist",
}
GROUPED_PARENTS = {"groupBy", "groupby", "rollup", "cube", "pivot"}
FUNCTION_NAMESPACES = {"F", "T", "W"}
UDF_NAMES = {"udf", "pandas_udf", "udtf"}
# group/partition methods that run Python (pandas, Arrow) code: vectorised UDFs (SPK006)
PANDAS_METHODS = {"applyInPandas", "applyInPandasWithState", "mapInPandas", "mapInArrow", "applyInArrow"}
# RDD, streaming and MLlib reads and writes (SPK001), besides IO_ATTRS
IO_CALLS = {"textFile", "wholeTextFiles", "binaryFiles", "binaryRecords", "sequenceFile", "pickleFile",
            "hadoopFile", "newAPIHadoopFile", "saveAsTextFile", "saveAsSequenceFile", "saveAsPickleFile",
            "saveAsHadoopFile", "saveAsNewAPIHadoopFile", "socketTextStream", "textFileStream"}
# `.save(sc, path)` / `Model.load(sc, path)`: MLlib models take the SparkContext first
SPARK_CONTEXT_NAMES = {"sc", "spark_context", "sparkContext", "context"}
# spark.sql(...) statements that read or write storage
SQL_IO_RE = re.compile(r"^\s*(LOAD|CREATE|INSERT|DROP|ALTER|TRUNCATE|MSCK|REFRESH|CACHE)\b", re.IGNORECASE)
# a Response returned as is: FastAPI does not validate it against a response model (FAPI005)
RESPONSE_RE = re.compile(r"Response$")
SPARK_ALIASES = {"pyspark.sql.functions": "F", "pyspark.sql.types": "T", "pyspark.sql.window": "W"}
IGNORED_DIRS = {"venv", "env", "build", "dist", "node_modules", "__pycache__", "site-packages",
                "spark-warehouse"}
GROUP_RE = re.compile(r"^[a-z][a-z0-9_]*$")
SUPPRESS_RE = re.compile(r"#\s*archvow:\s*ignore\[([A-Z0-9, ]+)\](.*)$")


@dataclass
class Violation:
    code: str
    severity: str
    message: str
    file: str
    line: int = 0
    col: int = 0
    title: str = ""
    guide: dict | None = None  # what to do about it, in the project's language (archvow.guidance)


@dataclass
class SymbolStatus:
    container: str
    component: str
    symbol: str
    status: str  # planned | implemented
    reason: str = ""  # why a planned symbol is not done: missing | placeholder (its file exists)


@dataclass
class ComponentStatus:
    container: str
    component: str
    type: str
    layer: str
    status: str  # planned | implemented | tested | verified | drift
    tested: bool = False
    invariants_total: int = 0
    invariants_verified: int = 0
    open_questions: int = 0
    pending_assumptions: int = 0
    hazards: int = 0


@dataclass
class Report:
    violations: list[Violation] = field(default_factory=list)
    statuses: list[SymbolStatus] = field(default_factory=list)
    suppressed: list[dict] = field(default_factory=list)
    changes: list[dict] = field(default_factory=list)
    components: list[ComponentStatus] = field(default_factory=list)
    invariants: list[dict] = field(default_factory=list)
    frozen: list[dict] = field(default_factory=list)        # existing violations, ignored
    stale_frozen: list[dict] = field(default_factory=list)  # frozen but fixed since
    budget: dict | None = None  # with a base: the change's size against the ARCH022 budget
    safety: dict = field(default_factory=dict)  # safety questions: {"answered": n, "total": m}

    @property
    def errors(self) -> list[Violation]:
        return [v for v in self.violations if v.severity == "error"]

    def to_dict(self) -> dict:
        return {
            "ok": not self.errors,
            "errors": len(self.errors),
            "warnings": len(self.violations) - len(self.errors),
            "violations": [asdict(v) for v in self.violations],
            "statuses": [asdict(s) for s in self.statuses],
            "suppressed": self.suppressed,
            "changes": self.changes,
            "components": [asdict(c) for c in self.components],
            "invariants": self.invariants,
            "frozen": len(self.frozen),
            "stale_frozen": self.stale_frozen,
            "budget": self.budget,
            "safety": self.safety,
            "counts": self.counts(),
        }

    def counts(self) -> dict[str, int]:
        """How many violations each rule found, most first (then by code)."""
        found: dict[str, int] = {}
        for v in self.violations:
            found[v.code] = found.get(v.code, 0) + 1
        return dict(sorted(found.items(), key=lambda item: (-item[1], item[0])))


# --------------------------------------------------------------------------- helpers


def canonical_signature(signature: str) -> str:
    tree = ast.parse(f"def _f{signature}:\n    pass\n")
    return render_signature(tree.body[0])


def render_signature(node: ast.FunctionDef | ast.AsyncFunctionDef) -> str:
    text = f"({ast.unparse(node.args)})"
    if node.returns is not None:
        text += f" -> {ast.unparse(node.returns)}"
    return text


def canonical_expr(text: str) -> str:
    return ast.unparse(ast.parse(text, mode="eval").body)


def _receiver_name(node: ast.expr) -> str | None:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return node.attr
    return None


def _chain(call: ast.Call) -> tuple[list[ast.Call], ast.expr]:
    """Return the calls of a fluent chain (outermost first) and its root expression."""
    calls: list[ast.Call] = []
    node: ast.expr = call
    while isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
        calls.append(node)
        node = node.func.value
    return calls, node


def _is_stub_body(body: list[ast.stmt]) -> bool:
    """A body that only holds the place: a docstring, `pass`, `...` or `raise NotImplementedError`."""
    statements = [s for s in body if not isinstance(s, ast.Pass)
                  and not (isinstance(s, ast.Expr) and isinstance(s.value, ast.Constant))]
    if not statements:
        return True
    if len(statements) != 1 or not isinstance(statements[0], ast.Raise):
        return False
    exc = statements[0].exc
    target = exc.func if isinstance(exc, ast.Call) else exc
    return isinstance(target, ast.Name) and target.id == "NotImplementedError"


# An empty exception class is complete (`class OrderNotFoundError(Exception): pass`).
_EXCEPTION_SUFFIXES = ("Error", "Exception", "Warning")


def _is_exception_class(node: ast.ClassDef) -> bool:
    for base in node.bases:
        name = base.attr if isinstance(base, ast.Attribute) else getattr(base, "id", "")
        if name.endswith(_EXCEPTION_SUFFIXES):
            return True
    return node.name.endswith(_EXCEPTION_SUFFIXES)


def _constant_is_stub(value: ast.expr | None) -> bool:
    if not isinstance(value, ast.Call) or len(value.args) != 1:
        return False
    arg = value.args[0]
    return isinstance(arg, ast.List) and not arg.elts


# --------------------------------------------------------------------------- checker


class _Checker:
    def __init__(self, root: Path, overrides: dict[Path, str] | None = None,
                 complete: bool = False, test_report: Path | None = None) -> None:
        self.root = root
        self.complete = complete
        self.test_report = test_report  # JUnit XML of pytest: ARCH046 checks the marked tests passed
        self.templates: dict[str, Template] = {}
        self.overrides = {p.resolve(): text for p, text in (overrides or {}).items()}
        self.report = Report()
        self.manifest = mf.load(root)
        self.settings: dict[str, dict] = {}
        self.rule_sets: set[str] = set()
        self.rules: dict[str, tuple[str, str]] = dict(RULES)
        self.families: dict = {}
        self.chosen = chosen_families(self.manifest)
        self.layer_map = layer_paths(self.manifest)

    # ---- configuration
    def _configure(self, template: Template | None) -> None:
        templates = [template] if template else []
        self.rule_sets = project_rule_sets(templates, self.manifest)
        self.rules = all_rules(templates)
        self.families = dict((template.data.get("rule_families") or {}) if template else {})
        self.settings = {}
        for code, (severity, _) in self.rules.items():
            self.settings[code] = {"severity": severity, **DEFAULT_PARAMS.get(code, {})}
        for source in ((template.rules if template else {}), self.manifest.get("rules", {})):
            for code, value in (source or {}).items():
                if code in self.settings and isinstance(value, dict):
                    self.settings[code].update(value)

    def param(self, code: str, key: str) -> int:
        return int(self.settings[code][key])

    def add(self, code: str, message: str, file: str, line: int = 0, col: int = 0,
            escalate: bool = False) -> None:
        """Record a violation at its severity; `escalate` makes a warning an error (mode strict, --complete)."""
        severity = self.settings.get(code, {}).get("severity", self.rules[code][0])
        if code in FLOOR and severity == "off":  # the floor cannot be switched off
            severity = self.rules[code][0]
        if severity == "off" or not rule_enabled(code, self.rule_sets) \
                or not family_enabled(code, self.families, self.chosen):
            return
        if escalate:
            severity = "error"
        self.report.violations.append(
            Violation(code, severity, message, file, line, col, self.rules[code][1])
        )

    def enabled(self, code: str) -> bool:
        return (rule_enabled(code, self.rule_sets) and family_enabled(code, self.families, self.chosen)
                and (code in FLOOR or self.settings.get(code, {}).get("severity") != "off"))

    # ---- entry point
    def run(self) -> Report:
        templates: list[Template] = []
        for container in self.manifest["containers"]:
            self._check_container(container)
            try:
                template = load_template(mf.template_name(container)[0], self.root)
                templates.append(template)
                self.templates[container["id"]] = template
            except TemplateError:
                pass
        if len(templates) < len(self.manifest["containers"]):
            return self.report  # without its template nothing else can be judged: one clear error (ARCH009)
        self._check_project_files(templates)
        from archvow.briefs import run_briefs
        from archvow.compliance import run_compliance
        from archvow.evidence import run_evidence
        from archvow.examples import run_examples
        from archvow.proposals import run_proposals
        from archvow.safety import run_safety

        run_safety(self)
        run_evidence(self)
        run_examples(self)
        run_compliance(self)
        run_briefs(self)
        run_proposals(self)
        from archvow.limits import run_limits

        run_limits(self)
        from archvow.toreview import run_review

        run_review(self)
        self._check_task_size()
        self._check_archvow_folder()
        from archvow.agent import run_agents

        run_agents(self)
        self.report.violations = _unique(self.report.violations)
        self.report.violations.sort(key=lambda v: (v.file, v.line, v.code))
        return self.report

    def _check_container(self, container: dict) -> None:
        name, version = mf.template_name(container)
        try:
            template = load_template(name, self.root)
        except TemplateError as exc:
            self._configure(None)
            self.add("ARCH009", f"container '{container['id']}': {exc}. A company template lives in the project: "
                     f"copy its folder to .archvow/templates/{name}/ and commit it (archvow init "
                     f"{container.get('package', '<package>')} --force -t <template folder> does it)",
                     str(mf.MANIFEST_REL))
            return
        self._configure(template)
        if version and version != template.version:
            self.add(
                "ARCH012",
                f"the vow says {name}@{version}, installed is {template.ref}: to adopt it, "
                f"archvow init {container.get('package', '<package>')} --force (then review and commit)",
                str(mf.MANIFEST_REL),
            )
        components = container.get("components", [])
        self._validate_layer_paths(template)
        self._validate_manifest(container, components, template)
        by_module = {c["module"]: c for c in components}
        base = self.root / container["path"]
        seen: set[str] = set()
        for path in sorted(base.rglob("*.py")):
            module = self._module_name(container, path)
            seen.add(module)
            self._check_file(container, template, by_module, path, module)
        for component in components:
            if component["module"] not in seen:
                for symbol in component.get("symbols", []):
                    self.report.statuses.append(
                        SymbolStatus(container["id"], component["id"], symbol["name"], "planned"))
                if self.complete:
                    self.add("ARCH008", f"component '{component['id']}': {component['module']} "
                             "is planned but not created", str(mf.MANIFEST_REL))

    def _validate_layer_paths(self, template: Template) -> None:
        """ARCH009: `layer_paths` names layers of the template, each path once."""
        seen: dict[str, str] = {}
        for path, layer in self.layer_map:
            if template.layer(layer) is None:
                self.add("ARCH009", f"layer_paths: '{layer}' is not a layer of template {template.name} "
                         f"(layers: {', '.join(template.layer_names)})", str(mf.MANIFEST_REL))
            elif path in seen and seen[path] != layer:
                self.add("ARCH009", f"layer_paths: '{path}' is mapped to {seen[path]} and {layer}",
                         str(mf.MANIFEST_REL))
            seen[path] = layer

    def file_layer(self, container: dict, template: Template, rel: str, module: str) -> str | None:
        """A file's layer: the one `layer_paths` maps it to, else the folder under the package."""
        mapped = mapped_layer(self.layer_map, rel)
        if mapped is not None:
            return mapped
        parts = module.split(".")
        return parts[1] if len(parts) > 1 and template.layer(parts[1]) is not None else None

    def module_layer(self, container: dict, template: Template, target: str) -> str | None:
        """The layer of an imported module of the project (its file, mapped or by folder)."""
        base = self.root / container["path"]
        parts = target.split(".")[1:]
        for end in range(len(parts), 0, -1):
            for candidate in (base.joinpath(*parts[:end - 1], parts[end - 1] + ".py"),
                              base.joinpath(*parts[:end], "__init__.py")):
                if candidate.is_file():
                    rel = candidate.relative_to(self.root).as_posix()
                    return self.file_layer(container, template, rel, self._module_name(container, candidate))
        return parts[0] if parts and template.layer(parts[0]) is not None else None

    def _check_ai_tools(self, templates: list[Template]) -> None:
        """ARCH040: files of AI assistants that are not approved in the vow."""
        approved = mf.instructed_tools(self.manifest)  # reviewers have their tool's files too
        tool_files: dict[str, list[str]] = {}
        for template in templates:
            tool_files.update(template.data.get("ai_tool_files", {}) or {})
        for tool, paths in tool_files.items():
            if tool in approved:
                continue
            label = "a tool archvow does not approve" if tool == "unlisted" else f"'{tool}'"
            for rel in paths:
                if (self.root / rel).exists():
                    self.add("ARCH040", f"{rel} configures {label}; approved AI assistants: "
                             f"{', '.join(approved)}", rel)

    def _check_dependencies(self, templates: list[Template]) -> None:
        """ARCH023: a third-party import needs approval (template `dependencies` + the answer)."""
        if not any("dependencies" in t.data for t in templates):
            return  # the template does not govern dependencies
        allowed = {d for t in templates for d in (t.data.get("dependencies") or [])}
        allowed |= set(self.manifest.get("dependencies") or [])
        own = {c["package"] for c in self.manifest["containers"]} | {"tests", "conftest", "__future__"}
        known = set(sys.stdlib_module_names) | own | allowed
        # A folder that may import more: the Airflow DAG folder may import airflow (template); a
        # project may keep a shared library to its I/O layer (manifest, optional).
        by_path: dict[str, set[str]] = {}
        sources = [t.data.get("dependencies_by_path") or {} for t in templates]
        for mapping in [*sources, self.manifest.get("dependencies_by_path") or {}]:
            for folder, names in mapping.items():
                by_path.setdefault(folder.strip("/"), set()).update(names or [])
        for path in sorted(self.root.rglob("*.py")):
            rel = path.relative_to(self.root)
            if any(part.startswith(".") or part in IGNORED_DIRS for part in rel.parts[:-1]):
                continue
            here = set(known)
            for folder, names in by_path.items():
                if rel.as_posix().startswith(folder + "/"):
                    here |= names
            try:
                tree = ast.parse(path.read_text(encoding="utf-8"))
            except (SyntaxError, UnicodeDecodeError):
                continue  # reported as ARCH013 for component files
            reported: set[str] = set()  # one hit per package and file, at its first import
            for node in sorted((n for n in ast.walk(tree) if isinstance(n, (ast.Import, ast.ImportFrom))),
                               key=lambda n: n.lineno):
                if isinstance(node, ast.Import):
                    names = [a.name for a in node.names]
                elif not node.level and node.module:
                    names = [node.module]
                else:
                    continue
                for top in sorted({n.split(".")[0] for n in names} - here - reported):
                    reported.add(top)
                    if _is_local_module(path.parent, top):
                        continue  # a module next to the file (a script importing its sibling)
                    folders = sorted(folder for folder, names in by_path.items() if top in names)
                    if folders:
                        self.add("ARCH023", f"'{top}' may be imported only under {', '.join(folders)} "
                                 "(dependencies_by_path); call it from there", rel.as_posix(), node.lineno)
                        continue
                    package = self.manifest["containers"][0]["package"]
                    approved = ",".join([*(self.manifest.get("dependencies") or []), top])
                    self.add("ARCH023", f"'{top}' is not an approved dependency. An architect approves it: "
                             f"archvow init {package} --force -a dependencies={approved}",
                             rel.as_posix(), node.lineno)

    def _check_requirements(self, templates: list[Template]) -> None:
        """ARCH024: a package in requirements.txt or pyproject.toml nobody approved. Approved: what the
        template's own requirements.txt and pyproject.toml list, and the `dependencies` answer. Mode
        strict: an error (only an architect approves, through the manifest); guided: an error for the
        release gate (check --complete); free: a warning."""
        if not any("dependencies" in t.data for t in templates):
            return
        from archvow.proposals import mode

        approved = {_pep503(n) for t in templates for n in _template_packages(t)}
        approved |= {_pep503(str(n)) for t in templates for n in (t.data.get("dependencies") or [])}
        approved |= {_pep503(str(n)) for n in self.manifest.get("dependencies") or []}
        package = self.manifest["containers"][0]["package"]
        approved.add(_pep503(package))
        found = [(n, "requirements.txt", line) for n, line in _requirement_names(self.root / "requirements.txt")]
        found += [(n, "pyproject.toml", line) for n, line in _pyproject_names(self.root / "pyproject.toml")]
        project_mode = mode(self.manifest)
        for name, rel, line in found:
            if _pep503(name) in approved:
                continue
            listed = ",".join([*(self.manifest.get("dependencies") or []), name])
            message = (f"'{name}' is not an approved package: an architect approves it - archvow init {package} "
                       f"--force -a dependencies={listed}")
            if project_mode == "strict" or (project_mode == "guided" and self.complete):
                self.report.violations.append(Violation("ARCH024", "error", message, rel, line, 0,
                                                        self.rules["ARCH024"][1]))
            else:
                self.add("ARCH024", message, rel, line)

    ARCHVOW_FILES = ("spec.vow", "proposals.vow", "README.md", "spec.md", "frozen.json", "status.md",
                     "agents.local", "trailer.local")  # the last two: local state of agent.py, gitignored
    ARCHVOW_FOLDERS = ("components", "templates")
    COMPONENT_FILES = ("spec.vow", "spec.md")

    def _check_task_size(self) -> None:
        """ARCH044: the task an AI reads for one component (its spec.md) stays short enough to follow."""
        if not self.enabled("ARCH044"):
            return
        from archvow.prompt import tokens

        limit = self.param("ARCH044", "max_tokens")
        for container in self.manifest["containers"]:
            for comp in container.get("components", []):
                path = self.root / mf.COMPONENTS_REL / comp["id"] / mf.CARD_FILE
                try:
                    text = path.read_text(encoding="utf-8")
                except OSError:
                    continue  # not generated yet: docs --check reports it
                size = tokens(text)
                if size > limit:
                    tasks = "\n## Tasks" in text or "\n## Tâches" in text
                    one_at_a_time = (", or give the AI one task at a time: "
                                     f"archvow prompt {comp['id']} --task 1" if tasks else "")
                    self.add("ARCH044", f"{comp['id']}: its task is about {size:,} tokens, over {limit:,}"
                                        f" - split it into smaller components{one_at_a_time}",
                             path.relative_to(self.root).as_posix())

    def _check_archvow_folder(self) -> None:
        """ARCH050: CODEOWNERS lists what archvow writes in .archvow/, path by path (the AI's
        proposals are not the architects' in mode free); anything else there would be owned by nobody.
        A component folder holds its spec.vow and its spec.md, nothing else."""
        folder = self.root / ".archvow"
        if not folder.is_dir():
            return
        strays = []
        for path in sorted(folder.iterdir()):
            if path.name in (self.ARCHVOW_FOLDERS if path.is_dir() else self.ARCHVOW_FILES):
                continue
            strays.append(path)
        components = folder / "components"
        if components.is_dir():
            for sub in sorted(components.iterdir()):
                if not sub.is_dir() or not (sub / mf.COMPONENT_FILE).is_file():
                    strays.append(sub)
                    continue
                strays += [p for p in sorted(sub.iterdir()) if p.name not in self.COMPONENT_FILES]
        for path in strays:
            rel = path.relative_to(self.root).as_posix()
            self.add("ARCH050", f"{rel}: archvow does not write it, so CODEOWNERS gives it to nobody - move it "
                     "out of .archvow/ (only archvow's own files live there)", rel)

    def _check_project_files(self, templates: list[Template]) -> None:
        """ARCH015 stray Python files, ARCH016 test layout (mirror of the components)."""
        self._check_ai_tools(templates)
        check_reports(self)
        self._check_dependencies(templates)
        self._check_requirements(templates)
        container_dirs = [self.root / c["path"] for c in self.manifest["containers"]]
        allowed = {"tests"}
        for template in templates:
            allowed.update(template.data.get("allowed_paths", []))
            allowed.update(generated_python_folders(template))  # dags/...: archvow wrote them
        allowed.update(self.manifest.get("allowed_paths", []) or [])
        mirror = any(t.data.get("test_layout") == "mirror" for t in templates)
        free_dirs = [d.rstrip("/") for t in templates for d in (t.data.get("free_test_dirs") or [])]
        components = {mf.test_path(c) for container in self.manifest["containers"]
                      for c in container.get("components", [])}
        for path in sorted(self.root.rglob("*.py")):
            rel = path.relative_to(self.root)
            if any(part.startswith(".") or part in IGNORED_DIRS for part in rel.parts[:-1]):
                continue
            if any(path.is_relative_to(d) for d in container_dirs):
                continue
            top = rel.parts[0] if len(rel.parts) > 1 else rel.name
            if top not in allowed:
                self.add("ARCH015", f"{rel.as_posix()} is outside the architecture; move it into a "
                         "component or list its folder in `allowed_paths` (architect review)", rel.as_posix())
                continue
            if top == "tests" and mirror and not any(rel.as_posix().startswith(d + "/") for d in free_dirs):
                self._check_test_file(rel, components)
        self._check_scripts()

    def _check_scripts(self) -> None:
        """STY003: a shell script stays short; its logic belongs in tested Python code."""
        max_lines = self.param("STY003", "max_lines")
        for path in sorted(self.root.rglob("*.sh")):
            rel = path.relative_to(self.root)
            if any(part.startswith(".") or part in IGNORED_DIRS for part in rel.parts[:-1]):
                continue
            lines = len(path.read_text(encoding="utf-8", errors="replace").splitlines())
            if lines > max_lines:
                self.add("STY003", f"{lines} lines (max {max_lines}); move the logic into a Python "
                         "component and keep the script a launcher", rel.as_posix(), 1)

    def _check_test_file(self, rel: Path, components: set[str]) -> None:
        if rel.name in {"conftest.py", "__init__.py"}:
            return
        if rel.as_posix() not in components:
            self.add("ARCH016", f"{rel.as_posix()}: tests live in tests/<layer>/[<group>/]test_<component>.py "
                     "for a declared component", rel.as_posix())

    def _module_name(self, container: dict, path: Path) -> str:
        rel = path.relative_to(self.root / container["path"]).with_suffix("")
        parts = [container["package"], *rel.parts]
        if parts[-1] == "__init__":
            parts = parts[:-1]
        return ".".join(parts)

    # ---- manifest validation
    def _validate_manifest(self, container: dict, components: list[dict], template: Template) -> None:
        where = str(mf.MANIFEST_REL)
        ids = [c.get("id") for c in components]
        by_id = {c.get("id"): c for c in components}
        for dup in {i for i in ids if ids.count(i) > 1}:
            self.add("ARCH009", f"duplicate component id '{dup}'", where)
        for comp in components:
            cid = comp.get("id", "?")
            ctype = template.type_of(comp) if comp.get("type") in template.component_types else None
            if ctype is None:
                self.add("ARCH009", f"component '{cid}': unknown type '{comp.get('type')}'", where)
                continue
            if comp.get("layer") != ctype["layer"]:
                self.add("ARCH009", f"component '{cid}': type '{comp['type']}' belongs in layer '{ctype['layer']}'", where)
            expected_prefix = f"{container['package']}.{ctype['layer']}."
            if comp.get("adopted"):
                self._check_adopted(container, comp, ctype, template, where)
            elif not str(comp.get("module", "")).startswith(expected_prefix):
                self.add("ARCH009", f"component '{cid}': module must live under {expected_prefix}*", where)
            pattern = ctype.get("name_pattern")
            if pattern and not re.fullmatch(pattern, str(comp.get("name", ""))):
                self.add("ARCH009", f"component '{cid}': name '{comp.get('name')}' does not match {pattern}", where)
            if not str(comp.get("description", "")).strip():
                self.add("ARCH009", f"component '{cid}': a description is required (if it is hard to explain, it is a bad idea)", where)
            self._check_shape(container, comp, ctype, template)
            for used in comp.get("uses", []) or []:
                target = by_id.get(used)
                if target is None:
                    self.add("ARCH009", f"component '{cid}': uses unknown component '{used}'", where)
                elif not self._layer_allowed(template, comp.get("layer"), target.get("layer")):
                    self.add("ARCH005", f"component '{cid}' ({comp.get('layer')}) may not use '{used}' ({target.get('layer')})", where)
            for needed in missing_contracts(comp, ctype, by_id):
                self.add("ARCH019", f"'{cid}' uses no {needed}: the columns it works on are written nowhere -> "
                         f"archvow component add {needed} <name> -d \"...\", then archvow component edit {cid} -u <name>_{needed}", where)

    def _check_adopted(self, container: dict, comp: dict, ctype: dict, template: Template, where: str) -> None:
        """An adopted component keeps its file where it is: `layer_paths` must put it in its type's layer."""
        rel = mf.source_path(container, comp)
        if not (self.root / rel).is_file():
            return  # its file is gone: ARCH008 with --complete
        layer = self.file_layer(container, template, rel, str(comp.get("module", "")))
        if layer != ctype["layer"]:
            self.add("ARCH009", f"component '{comp.get('id')}': {rel} is in layer {layer or 'none'}, a "
                     f"{comp.get('type')} belongs in {ctype['layer']} - map it in `layer_paths`", where)

    def _check_shape(self, container: dict, comp: dict, ctype: dict, template: Template) -> None:
        """Every entry must be exactly what `archvow component add` (or the template) would produce."""
        cid = comp.get("id", "?")
        where = mf.where(cid)  # the component's own spec.vow
        if not ctype.get("addable", True):
            initial = {c.get("id") for c in template.data.get("initial_components", [])}
            if cid not in initial:
                self.add("ARCH014", f"component '{cid}': type '{comp.get('type')}' is template-owned; "
                         "it cannot be declared by hand", where)
            return
        if "module" not in ctype:
            return
        name = str(comp.get("name", ""))
        fmt = mf.name_values(name)
        base = ctype["module"].format(**fmt)
        group = comp.get("group")
        if group is not None and not GROUP_RE.fullmatch(str(group)):
            self.add("ARCH014", f"component '{cid}': group '{group}' must be a snake_case folder name", where)
        folder = f"{group}." if group else ""
        expected_module = f"{container['package']}.{ctype['layer']}.{folder}{base}"
        if comp.get("adopted"):  # its module is its existing file; its symbols are what the file had
            if cid != base:
                self.add("ARCH014", f"component '{cid}': a {comp.get('type')} named '{name}' must be id '{base}'",
                         where)
            return
        if comp.get("module") != expected_module or cid != base:
            self.add("ARCH014", f"component '{cid}': a {comp.get('type')} named '{name}' must be "
                     f"id '{base}', module {expected_module}", where)
        expected = ctype.get("symbols", [])
        actual = comp.get("symbols", []) or []
        if len(actual) != len(expected) and not ctype.get("extra_symbols", False):
            self.add("ARCH014", f"component '{cid}': declares {len(actual)} symbol(s), "
                     f"template '{comp.get('type')}' defines {len(expected)}", where)
        for index, (want, got) in enumerate(zip(expected, actual)):
            want_name = want["name"].format(**fmt)
            if got.get("name") != want_name or got.get("kind", "function") != want.get("kind", "function"):
                self.add("ARCH014", f"component '{cid}': symbol must be {want.get('kind', 'function')} "
                         f"'{want_name}', the spec says {got.get('kind', 'function')} '{got.get('name')}'", where)
                continue
            if "signature" in want and not (index == 0 and ctype.get("signature_overridable")):
                if canonical_signature(str(got.get("signature", "()"))) != canonical_signature(want["signature"]):
                    self.add("ARCH014", f"component '{cid}': '{want_name}' signature must be "
                             f"{want['signature']}", where)
            if "annotation" in want and got.get("annotation") != want["annotation"]:
                self.add("ARCH014", f"component '{cid}': '{want_name}' must be annotated "
                         f"{want['annotation']}", where)

    @staticmethod
    def _layer_allowed(template: Template, source: str | None, target: str | None) -> bool:
        if source == target:
            return True
        layer = template.layer(source or "")
        return bool(layer) and target in layer.get("may_import", [])

    # ---- per-file checks
    def _check_file(self, container: dict, template: Template, by_module: dict,
                    path: Path, module: str) -> None:
        rel = path.relative_to(self.root).as_posix()
        try:
            source = self.overrides.get(path.resolve()) or path.read_text(encoding="utf-8")
        except UnicodeDecodeError as exc:
            self.add("ARCH013", f"cannot be parsed: the file is not UTF-8 (byte {exc.start}) - save it as UTF-8", rel)
            return
        try:
            tree = ast.parse(source, filename=rel)
        except SyntaxError as exc:
            newer = newer_python_needed(self.root)
            hint = (f" - archvow runs on Python {sys.version_info.major}.{sys.version_info.minor} and this project "
                    f"needs {newer}: run archvow with that Python (archvow doctor shows it)") if newer else ""
            self.add("ARCH013", f"syntax error: {exc.msg}{hint}", rel, exc.lineno or 0)
            return
        parts = module.split(".")
        is_init = path.name == "__init__.py"
        layer_name = self.file_layer(container, template, rel, module)
        layer = template.layer(layer_name) if layer_name else None

        suppressions = self._suppressions(source, rel)
        before = len(self.report.violations)

        component = by_module.get(module)
        if component is None and not is_init:
            if layer is None and len(parts) > 1:
                package = self.manifest["containers"][0]["package"]
                self.add("ARCH001", f"{module} is not declared and sits in no layer: map it in `layer_paths` "
                         f"(archvow init {package} --force --adopt proposes it), then archvow component add "
                         f"<type> <name> --file {rel}", rel)
            else:
                self.add("ARCH001", f"{module} is not declared; add it with `archvow component add`", rel)
        elif layer is None and len(parts) > 1:
            self.add("ARCH010", f"'{parts[1]}' is not a layer of template {template.name} "
                     f"(layers: {', '.join(template.layer_names)}): move the file or map it in `layer_paths`",
                     rel)
        header_lines = template.data.get("file_header") or []
        if component is not None and header_lines:
            from archvow import header

            for issue in header.problems(ast.get_docstring(tree), header_lines, self.manifest, component):
                self.add("ARCH018", issue, rel, 1)
        self._check_symbols(container, component, tree, rel, is_init)
        if layer is not None:  # where the file sits: layers it may import, forbidden imports
            self._check_imports(container, template, by_module, component, layer, tree, module, rel, is_init)
        # the code rules that do not depend on a layer run on every file; the visitors skip the others
        self._check_spark_imports(tree, rel)
        names = Names(tree)
        _SparkVisitor(self, template, layer, rel, names).visit(tree)
        if rule_enabled("FAPI001", self.rule_sets):
            _FastAPIVisitor(self, template, layer, component, rel, names).visit(tree)
        self._check_sizes(tree, source, rel)
        self._check_backslashes(source, rel)
        self._apply_suppressions(before, suppressions, rel)

    def _suppressions(self, source: str, rel: str) -> dict[int, set[str]]:
        found: dict[int, set[str]] = {}
        for number, text in enumerate(source.splitlines(), start=1):
            match = SUPPRESS_RE.search(text)
            if not match:
                continue
            codes = {c.strip() for c in match.group(1).split(",") if c.strip()}
            reason = match.group(2).strip().lstrip("-—: ").strip()
            if len(reason) < 5:
                self.add("ARCH011", f"suppression of {', '.join(sorted(codes))} needs a reason: "
                         "`# archvow: ignore[CODE] -- why`", rel, number)
                continue
            found[number] = codes
        return found

    def _apply_suppressions(self, start: int, suppressions: dict[int, set[str]], rel: str) -> None:
        if not suppressions:
            return
        kept = self.report.violations[:start]
        for violation in self.report.violations[start:]:
            codes = suppressions.get(violation.line, set())
            if violation.code in codes and violation.code != "ARCH011":
                self.report.suppressed.append({"file": rel, "line": violation.line, "code": violation.code})
            else:
                kept.append(violation)
        self.report.violations = kept

    # ---- symbols (C4 level 4)
    def _check_symbols(self, container: dict, component: dict | None, tree: ast.Module,
                       rel: str, is_init: bool) -> None:
        public: dict[str, ast.stmt] = {}
        for node in tree.body:
            for name in _defined_names(node):
                if not name.startswith("_"):
                    public[name] = node
        if is_init or component is None:
            if is_init:
                for name, node in public.items():
                    self.add("ARCH002", f"'{name}' defined in a package __init__; put it in a declared component",
                             rel, node.lineno)
            return
        declared = {s["name"]: s for s in component.get("symbols", [])}
        for node in tree.body:  # a route is public whatever its name: it must be declared
            route = _route_of(node)
            if route and node.name.startswith("_"):
                self.add("ARCH002", f"route {route[0]} {route[1]} on private '{node.name}' is not declared in "
                         f"component '{component['id']}' (archvow component edit {component['id']} -r ...)", rel, node.lineno)
        for name, node in public.items():
            if name not in declared:
                self.add("ARCH002", f"'{name}' is not declared in component '{component['id']}' "
                         "(make it private with a leading underscore or declare it)", rel, node.lineno)
        for name, spec in declared.items():
            node = public.get(name)
            if node is None:
                if self.complete:
                    self.add("ARCH003", f"'{name}' of component '{component['id']}' is planned "
                             "but not implemented", rel)
                self.report.statuses.append(
                    SymbolStatus(container["id"], component["id"], name, "planned", "missing"))
                continue
            self._compare_symbol(component, spec, node, rel)
            status = _status(node)
            if status == "planned" and self.complete:
                self.add("ARCH003", f"'{name}' of component '{component['id']}' is still a placeholder "
                         "(only pass, ..., a docstring or raise NotImplementedError): implement it", rel,
                         node.lineno)
            self.report.statuses.append(SymbolStatus(container["id"], component["id"], name, status,
                                                     "placeholder" if status == "planned" else ""))

    def _compare_symbol(self, component: dict, spec: dict, node: ast.stmt, rel: str) -> None:
        kind = spec.get("kind", "function")
        name = spec["name"]
        if kind == "function":
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                self.add("ARCH004", f"'{name}' should be a function", rel, node.lineno)
            elif spec.get("signature"):
                expected = canonical_signature(spec["signature"])
                actual = render_signature(node)
                if expected != actual:
                    self.add("ARCH004", f"'{name}' signature is {actual}, the spec says {expected} -> write the "
                             "spec's signature, or a person changes the spec: archvow component edit "
                             f"{component['id']} --signature \"{actual}\"", rel, node.lineno)
        elif kind == "route":
            route = _route_of(node)
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) or route is None:
                self.add("ARCH004", f"'{name}' should be a route: @<router>.{spec['method'].lower()}"
                         f"(\"{spec['path']}\")", rel, node.lineno)
            elif route != (spec["method"], spec["path"]):
                self.add("ARCH004", f"'{name}' is {route[0]} {route[1]}, the spec says "
                         f"{spec['method']} {spec['path']}", rel, node.lineno)
        elif kind == "class":
            if not isinstance(node, ast.ClassDef):
                self.add("ARCH004", f"'{name}' should be a class", rel, node.lineno)
        elif kind == "constant":
            annotation = node.annotation if isinstance(node, ast.AnnAssign) else None
            if spec.get("annotation"):
                expected = canonical_expr(spec["annotation"])
                actual = ast.unparse(annotation) if annotation is not None else "<none>"
                if expected != actual:
                    self.add("ARCH004", f"'{name}' annotation is {actual}, the spec says {expected}", rel, node.lineno)

    # ---- imports (edges)
    def _check_imports(self, container: dict, template: Template, by_module: dict,
                       component: dict | None, layer: dict, tree: ast.Module,
                       module: str, rel: str, is_init: bool) -> None:
        package = container["package"]
        forbidden = set(layer.get("forbidden_imports", []))
        current_pkg = module if is_init else module.rpartition(".")[0]
        for node in ast.walk(tree):
            targets: list[tuple[str, int]] = []
            if isinstance(node, ast.Import):
                for alias in node.names:
                    targets.append((alias.name, node.lineno))
            elif isinstance(node, ast.ImportFrom):
                base = _resolve_from(node, current_pkg)
                for alias in node.names:
                    full = f"{base}.{alias.name}" if base and alias.name != "*" else base
                    targets.append((full, node.lineno))
            for target, line in targets:
                if not target:
                    continue
                top = target.split(".")[0]
                if top in forbidden:
                    self.add("ARCH007", f"layer '{layer['name']}' may not import '{top}'", rel, line)
                if top == package:
                    self._check_internal_edge(container, template, by_module, component, layer, target, rel, line)

    def _check_internal_edge(self, container: dict, template: Template, by_module: dict,
                             component: dict | None, layer: dict, target: str, rel: str, line: int) -> None:
        target_layer = self.module_layer(container, template, target) if "." in target else None
        if target_layer is None:
            return  # a module in no layer: ARCH001/ARCH010 on that file already say so
        if not self._layer_allowed(template, layer["name"], target_layer):
            allowed = ", ".join(layer.get("may_import", [])) or "nothing"
            self.add("ARCH005", f"layer '{layer['name']}' may not import from '{target_layer}' "
                     f"(allowed: {allowed})", rel, line)
            return
        target_component = _owning_component(by_module, target)
        if component is None or target_component is None or target_component is component:
            return
        ctype = template.type_of(target_component)
        if ctype.get("implicit_dependency"):
            return
        if target_component["id"] not in (component.get("uses") or []):
            self.add("ARCH006", f"'{component['id']}' imports '{target_component['id']}' but does not "
                     "declare it in `uses`", rel, line)

    def _check_spark_imports(self, tree: ast.Module, rel: str) -> None:
        """SPK007 on every file: functions as F, types as T, Window as W."""
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    self._check_spark_alias(alias.name, alias.asname, rel, node.lineno)
            elif isinstance(node, ast.ImportFrom) and not node.level and node.module:
                for alias in node.names:
                    self._check_spark_from(node.module, alias.name, alias.asname, rel, node.lineno)

    def _check_spark_alias(self, name: str, asname: str | None, rel: str, line: int) -> None:
        expected = SPARK_ALIASES.get(name)
        if expected and asname != expected:
            self.add("SPK007", f"import {name} as {expected}", rel, line)

    def _check_spark_from(self, base: str, name: str, asname: str | None, rel: str, line: int) -> None:
        full = f"{base}.{name}"
        if full in SPARK_ALIASES and asname != SPARK_ALIASES[full]:
            self.add("SPK007", f"use `from {base} import {name} as {SPARK_ALIASES[full]}`", rel, line)
        elif base == "pyspark.sql.types" and name == "Row":
            self.add("SPK007", "Row is not a type: use `from pyspark.sql import Row`", rel, line)
        elif base == "pyspark.sql" and name == "Window" and asname not in (None, "W"):
            self.add("SPK007", "import Window as-is or as W", rel, line)
        elif base in SPARK_ALIASES:
            self.add("SPK007", f"do not import names from {base}; use the {SPARK_ALIASES[base]}. "
                     "namespace (avoids shadowing builtins like sum/max)", rel, line)

    # ---- size and formatting
    def _check_sizes(self, tree: ast.Module, source: str, rel: str) -> None:
        lines = source.count("\n") + (0 if source.endswith("\n") or not source else 1)
        max_file = self.param("STY001", "max_lines")
        if lines > max_file:
            self.add("STY001", f"{lines} lines (max {max_file}); split the module", rel, 1)
        max_fn = self.param("STY002", "max_lines")
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                length = _body_length(node)
                if length > max_fn:
                    self.add("STY002", f"'{node.name}' is {length} lines (max {max_fn}, docstring and signature not counted)", rel, node.lineno)
        self._check_comments(source, rel)

    def _check_comments(self, source: str, rel: str) -> None:
        """STY004: comment lines against code lines; good names and docstrings say the rest."""
        try:
            tokens = list(tokenize.generate_tokens(io.StringIO(source).readline))
        except (tokenize.TokenError, SyntaxError):
            return
        skip = {tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT,
                tokenize.ENDMARKER}
        code = {line for tok in tokens if tok.type not in skip for line in range(tok.start[0], tok.end[0] + 1)}
        first_code = min(code, default=0)  # the comment block above the first code: licence, copyright, SPDX
        comments = {tok.start[0] for tok in tokens if tok.type == tokenize.COMMENT and tok.start[0] not in code
                    and tok.start[0] > first_code
                    and not tok.string.startswith(("#!", "# noqa", "# type:", "# archvow:", "# pragma"))}
        percent, minimum = self.param("STY004", "max_percent"), self.param("STY004", "min_code_lines")
        if len(code) >= minimum and len(comments) * 100 > percent * len(code):
            self.add("STY004", f"{len(comments)} comment lines for {len(code)} lines of code (max {percent}%); "
                     "rename, extract a function or move the explanation into the docstring", rel, 1)

    def _check_backslashes(self, source: str, rel: str) -> None:
        try:
            tokens = list(tokenize.generate_tokens(io.StringIO(source).readline))
        except (tokenize.TokenError, SyntaxError):
            return
        string_lines: set[int] = set()
        for tok in tokens:
            if tok.type == tokenize.STRING:
                string_lines.update(range(tok.start[0], tok.end[0]))
        for number, text in enumerate(source.splitlines(), start=1):
            if text.rstrip().endswith("\\") and number not in string_lines and not text.lstrip().startswith("#"):
                self.add("SPK008", "backslash continuation; wrap the expression in parentheses", rel, number)


class _SparkVisitor(ast.NodeVisitor):
    """PySpark rules. Those about where code lives (SPK001-003) need the file's layer; the others run on
    every file, in a layer or not (adopted code is checked before it is mapped)."""

    def __init__(self, checker: _Checker, template: Template, layer: dict | None, rel: str, names: Names) -> None:
        self.c = checker
        self.layer = layer
        self.rel = rel
        self.names = names
        self.session_layer = template.data.get("session_layer")
        self.chain_seen: set[int] = set()
        self.joined: list[set[str]] = []  # per scope: names assigned from a join (SPK014)
        self.imported = _imported_names(names)

    def _io_free(self) -> bool:
        return self.layer is not None and not self.layer.get("io_allowed", False)

    def _io(self, what: str, node: ast.AST) -> None:
        if self._io_free():
            self.c.add("SPK001", f"{what} performs I/O; move it to an I/O layer "
                       f"(layer '{self.layer['name']}' is I/O-free)", self.rel, node.lineno,  # type: ignore[index]
                       node.col_offset)

    def visit_Module(self, node: ast.Module) -> None:
        self._scope(node)

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._scope(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._scope(node)

    def _scope(self, node: ast.AST) -> None:
        self.joined.append(_joins(node))
        self.generic_visit(node)
        self.joined.pop()

    def visit_Attribute(self, node: ast.Attribute) -> None:
        if node.attr in IO_ATTRS and _receiver_name(node.value) not in FUNCTION_NAMESPACES \
                and self._spark_io_receiver(node):
            self._io(f"'.{node.attr}'", node)
        if node.attr in UDF_NAMES and _receiver_name(node.value) == "F":
            self.c.add("SPK006", _udf_message(f"F.{node.attr}"), self.rel, node.lineno, node.col_offset)
        if (node.attr == "builder" and self.names.short_name(node.value) == "SparkSession"
                and self.layer is not None and self.layer["name"] != self.session_layer):
            self.c.add("SPK003", f"build the SparkSession only in '{self.session_layer}'",
                       self.rel, node.lineno, node.col_offset)
        self.generic_visit(node)

    def _spark_io_receiver(self, node: ast.Attribute) -> bool:
        """`.table`, `.saveAsTable`, `.insertInto`: once per chain (after `.read`/`.write` it is the same
        I/O), and `.table` not on a module other than pyspark (pyarrow's pa.table builds a table)."""
        if node.attr in {"read", "readStream", "write", "writeStream"}:
            return True
        inner = node.value
        while isinstance(inner, (ast.Attribute, ast.Call, ast.Subscript)):
            inner = inner.func if isinstance(inner, ast.Call) else inner.value
            if isinstance(inner, ast.Attribute) and inner.attr in {"read", "readStream", "write", "writeStream"}:
                return False
        if node.attr == "table":
            root = _root_name(node.value)
            full = self.imported.get(root or "")
            if full and not full.startswith("pyspark"):
                return False  # pa.table(...) of pyarrow, a module function, not Spark
        return True

    def visit_Name(self, node: ast.Name) -> None:
        if isinstance(node.ctx, ast.Load) and self.names.short_name(node) in UDF_NAMES:
            self.c.add("SPK006", _udf_message(node.id, self.names.short_name(node)), self.rel, node.lineno,
                       node.col_offset)

    def visit_Call(self, node: ast.Call) -> None:
        called = self.names.full_name(node.func)
        if (called in OPEN_CALLS or called in LOG_FILE_CALLS or (called == "logging.basicConfig" and any(
                k.arg in ("filename", "filemode") for k in node.keywords))) and self._io_free():
            what = "writes a log file" if called not in OPEN_CALLS else "performs file I/O"
            self.c.add("SPK001", f"{ast.unparse(node.func)}() {what}" + (
                " (logs go to stderr: the cluster keeps them)" if called not in OPEN_CALLS else ""),
                       self.rel, node.lineno, node.col_offset)
        if isinstance(node.func, ast.Attribute):
            self._check_io_call(node, node.func)
            self._check_method(node, node.func)
            self._check_chain(node)
        self.generic_visit(node)

    def _check_io_call(self, node: ast.Call, func: ast.Attribute) -> None:
        """SPK001 beyond spark.read/write: RDD and streaming files, MLlib models and data, SQL statements."""
        if func.attr in IO_CALLS:
            self._io(f"'.{func.attr}()'", node)
        elif _receiver_name(func.value) == "MLUtils" and func.attr.startswith(("load", "save")):
            self._io(f"MLUtils.{func.attr}()", node)
        elif func.attr in {"save", "load"} and node.args and _context_argument(node.args[0]):
            self._io(f"'.{func.attr}(sc, ...)'", node)
        elif (func.attr == "sql" and node.args and isinstance(node.args[0], ast.Constant)
              and isinstance(node.args[0].value, str) and SQL_IO_RE.match(node.args[0].value)):
            self._io(f"spark.sql(\"{node.args[0].value.split()[0].upper()} ...\")", node)

    def _check_method(self, node: ast.Call, func: ast.Attribute) -> None:
        attr = func.attr
        receiver = _receiver_name(func.value)
        calls, _ = _chain(node)
        parent = calls[1].func.attr if len(calls) > 1 else None  # type: ignore[union-attr]
        if (attr in ACTION_ATTRS and self.layer is not None and self.layer.get("lazy_only", False)
                and receiver not in FUNCTION_NAMESPACES and parent not in GROUPED_PARENTS):
            self.c.add("SPK002", f"'.{attr}()' triggers execution; layer '{self.layer['name']}' must stay lazy",
                       self.rel, node.lineno, node.col_offset)
        if attr == "join":
            self._check_join(node, func)
        if attr in PANDAS_METHODS:
            self.c.add("SPK006", f"'.{attr}()' runs pandas/Arrow code in Python workers: acceptable when "
                       "native functions cannot do it - prefer them", self.rel, node.lineno, node.col_offset)
        if attr == "partitionBy" and not node.args and not node.keywords and receiver in {"Window", "W"}:
            self.c.add("SPK011", "empty partitionBy(); use an aggregation instead", self.rel, node.lineno)
        if attr == "lit" and receiver == "F" and node.args:
            arg = node.args[0]
            if isinstance(arg, ast.Constant) and arg.value in ("", "NA", "N/A", "null", "NULL"):
                self.c.add("SPK012", f"F.lit({arg.value!r}) as an empty value; use F.lit(None)", self.rel, node.lineno)
        if attr == "withColumnRenamed":
            self.c.add("SPK013", "use F.col(...).alias(...) in a select", self.rel, node.lineno)
        if (attr in {"distinct", "dropDuplicates", "drop_duplicates"} and receiver not in FUNCTION_NAMESPACES
                and self._after_join(func.value)):
            self.c.add("SPK014", f"'.{attr}()' after a join can hide a join explosion; fix the join keys "
                       "or justify it", self.rel, node.lineno)

    def _after_join(self, value: ast.expr) -> bool:
        """The DataFrame comes from a join: in the same chain, or a name this scope assigned from one."""
        if _has_join(value):
            return True
        name = _receiver_name(value)
        return bool(name and self.joined and name in self.joined[-1])

    def _check_join(self, node: ast.Call, func: ast.Attribute) -> None:
        receiver = func.value
        if isinstance(receiver, ast.Constant) or _receiver_name(receiver) in {"path", "os", "sep"}:
            return  # str.join / os.path.join
        has_on = len(node.args) >= 2 or any(k.arg == "on" for k in node.keywords)
        if not has_on:
            return
        how = next((k.value for k in node.keywords if k.arg == "how"), None)
        if how is None:
            self.c.add("SPK004", "specify the join type as a keyword, e.g. how='inner'",
                       self.rel, node.lineno, node.col_offset)
        elif isinstance(how, ast.Constant) and str(how.value).lower() in {"right", "right_outer", "rightouter"}:
            self.c.add("SPK005", "swap the DataFrames and use how='left'", self.rel, node.lineno, node.col_offset)

    def _check_chain(self, node: ast.Call) -> None:
        if id(node) in self.chain_seen:
            return
        calls, root = _chain(node)
        self.chain_seen.update(id(c) for c in calls)
        names = [c.func.attr for c in reversed(calls)]  # type: ignore[union-attr]
        max_chain = self.c.param("SPK009", "max_chain")
        if len(calls) > max_chain and _receiver_name(root) not in FUNCTION_NAMESPACES:
            self.c.add("SPK009", f"chain of {len(calls)} calls (max {max_chain}); split into named steps",
                       self.rel, node.lineno)
        if (_receiver_name(root) in {"Window", "W"} and "orderBy" in names
                and not {"rowsBetween", "rangeBetween"} & set(names)):
            self.c.add("SPK010", "add .rowsBetween(...) or .rangeBetween(...)", self.rel, node.lineno)


# --------------------------------------------------------------------------- module helpers


def _udf_message(shown: str, name: str | None = None) -> str:
    name = name or shown.split(".")[-1]
    if name == "pandas_udf":
        return f"'{shown}' creates a vectorised (pandas) UDF: acceptable when native functions cannot do it - prefer them"
    if name == "udtf":
        return f"'{shown}' creates a Python table function (UDTF): rows go through Python - prefer native functions"
    return f"'{shown}' creates a Python UDF: rows go through Python one by one - prefer native functions"


def _root_name(node: ast.expr) -> str | None:
    while isinstance(node, (ast.Attribute, ast.Call, ast.Subscript)):
        node = node.func if isinstance(node, ast.Call) else node.value
    return node.id if isinstance(node, ast.Name) else None


def _imported_names(names: Names) -> dict[str, str]:
    """Names bound by an import in the file, with what they import."""
    return names.imported()


def _context_argument(node: ast.expr) -> bool:
    """`sc` or `spark.sparkContext` given first: MLlib's save(sc, path) / load(sc, path)."""
    if isinstance(node, ast.Name):
        return node.id in SPARK_CONTEXT_NAMES
    return isinstance(node, ast.Attribute) and node.attr in SPARK_CONTEXT_NAMES


def _unique(violations: list[Violation]) -> list[Violation]:
    """One hit per rule, file, line and message (an import of nine names is one import)."""
    seen: set[tuple[str, str, int, str]] = set()
    kept = []
    for v in violations:
        key = (v.code, v.file, v.line, v.message)
        if key not in seen:
            seen.add(key)
            kept.append(v)
    return kept


def _body_length(node: ast.FunctionDef | ast.AsyncFunctionDef) -> int:
    """Lines of a function's body, without its signature and docstring (STY002)."""
    body = node.body
    if (body and isinstance(body[0], ast.Expr) and isinstance(body[0].value, ast.Constant)
            and isinstance(body[0].value.value, str)):
        body = body[1:]
    if not body:
        return 0
    return (node.end_lineno or node.lineno) - body[0].lineno + 1


def _joins(scope: ast.AST) -> set[str]:
    """Names a scope assigns from an expression that joins (SPK014 looks for distinct() after a join)."""
    found: set[str] = set()
    for node in ast.walk(scope):
        if isinstance(node, (ast.Assign, ast.AnnAssign)) and node.value is not None and _has_join(node.value):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            found.update(t.id for t in targets if isinstance(t, ast.Name))
    return found


def _has_join(expr: ast.AST) -> bool:
    for node in ast.walk(expr):
        if (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "join"
                and not isinstance(node.func.value, ast.Constant)
                and _receiver_name(node.func.value) not in {"path", "os", "sep"}):
            return True
    return False


def _defined_names(node: ast.stmt) -> list[str]:
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
        return [node.name]
    if isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
        return [node.target.id]
    if isinstance(node, ast.Assign):
        names = [t.id for t in node.targets if isinstance(t, ast.Name)]
        return [n for n in names if not (n.startswith("__") and n.endswith("__"))]
    return []


def _status(node: ast.stmt) -> str:
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        return "planned" if _is_stub_body(node.body) else "implemented"
    if isinstance(node, ast.ClassDef):
        empty = _is_stub_body(node.body) and not _is_exception_class(node)
        return "planned" if empty else "implemented"
    if isinstance(node, (ast.AnnAssign, ast.Assign)):
        return "planned" if _constant_is_stub(node.value) else "implemented"
    return "implemented"


def _resolve_from(node: ast.ImportFrom, current_pkg: str) -> str:
    if not node.level:
        return node.module or ""
    parts = current_pkg.split(".")
    base = parts[: len(parts) - (node.level - 1)] if node.level > 1 else parts
    return ".".join([*base, node.module] if node.module else base)


HTTP_METHODS = {"get": "GET", "post": "POST", "put": "PUT", "patch": "PATCH", "delete": "DELETE"}
# Calls that block the event loop when made inside `async def` (FAPI001), by full name: an alias
# (`from time import sleep as nap`) is resolved first (imports.Names).
BLOCKING_CALLS = {"time.sleep", "requests.get", "requests.post", "requests.put", "requests.patch",
                  "requests.delete", "requests.request", "urllib.request.urlopen", "subprocess.run",
                  "subprocess.call", "subprocess.check_output", "httpx.get", "httpx.post", "httpx.put",
                  "httpx.patch", "httpx.delete"}
OPEN_CALLS = {"open", "builtins.open", "io.open"}  # file I/O (SPK001) that also blocks (FAPI001)
LOG_FILE_CALLS = {"logging.FileHandler", "logging.handlers.RotatingFileHandler",  # a log file is file I/O (SPK001)
                  "logging.handlers.TimedRotatingFileHandler", "logging.handlers.WatchedFileHandler"}


def _route_of(node: ast.stmt) -> tuple[str, str] | None:
    """(METHOD, path) of a function decorated with @<router>.<method>("<path>", ...), else None."""
    if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        return None
    for deco in node.decorator_list:
        if (isinstance(deco, ast.Call) and isinstance(deco.func, ast.Attribute)
                and deco.func.attr in HTTP_METHODS and deco.args
                and isinstance(deco.args[0], ast.Constant) and isinstance(deco.args[0].value, str)):
            return HTTP_METHODS[deco.func.attr], deco.args[0].value
    return None


class _FastAPIVisitor(ast.NodeVisitor):
    """FastAPI rules: the event loop, where HTTP lives, one app, lifespan, typed responses. Where HTTP
    lives and where the app is made (FAPI002/003) need the file's layer; the others run on every file."""

    def __init__(self, checker: _Checker, template: Template, layer: dict | None, component: dict | None,
                 rel: str, names: Names) -> None:
        self.c = checker
        self.names = names
        self.layer = layer
        self.rel = rel
        self.http_layers = list(template.data.get("http_layers") or [])
        self.app_type = template.data.get("app_type")
        self.component = component
        self.in_async = False

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._route(node)
        outer, self.in_async = self.in_async, True
        self.generic_visit(node)
        self.in_async = outer

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._route(node)
        outer, self.in_async = self.in_async, False  # a nested def runs elsewhere (thread pool)
        self.generic_visit(node)
        self.in_async = outer

    def _route(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        route = _route_of(node)
        if route is None:
            return
        deco = next(d for d in node.decorator_list if isinstance(d, ast.Call)
                    and isinstance(d.func, ast.Attribute) and d.func.attr in HTTP_METHODS)
        keywords = {k.arg for k in deco.keywords}  # type: ignore[union-attr]
        # a route answering with a Response class (response_class= or returned as is) has no model to check
        if "response_model" in keywords or "response_class" in keywords or node.returns is not None:
            return
        if not _returns_response(node):
            self.c.add("FAPI005", f"route {route[0]} {route[1]}: declare what it returns (a return type "
                       "or response_model=), so the response is validated and documented", self.rel, node.lineno)

    def visit_Call(self, node: ast.Call) -> None:
        func = node.func
        called = self.names.full_name(func) if self.in_async else None
        if called in BLOCKING_CALLS:
            shown = ast.unparse(func) + ("()" if ast.unparse(func) == called else f"() ({called})")
            self.c.add("FAPI001", f"'{shown}' blocks the event loop inside async def: use an async client "
                       "(httpx.AsyncClient, asyncio.sleep) or a plain def", self.rel, node.lineno, node.col_offset)
        elif called in OPEN_CALLS:
            self.c.add("FAPI001", f"{ast.unparse(func)}() blocks the event loop inside async def: use a plain def",
                       self.rel, node.lineno, node.col_offset)
        name = func.id if isinstance(func, ast.Name) else func.attr if isinstance(func, ast.Attribute) else ""
        if name == "HTTPException" and self.layer is not None and self.layer["name"] not in self.http_layers:
            self.c.add("FAPI002", f"HTTPException belongs to {', '.join(self.http_layers)}: raise a domain error "
                       "here and map it to an HTTP status in the app's exception handlers", self.rel, node.lineno)
        if name == "FastAPI" and self.layer is not None and (self.component or {}).get("type") != self.app_type:
            self.c.add("FAPI003", f"create the FastAPI app only in the '{self.app_type}' component",
                       self.rel, node.lineno)
        if isinstance(func, ast.Attribute) and func.attr == "on_event":
            self.c.add("FAPI004", "on_event is deprecated: put startup and shutdown in the app's lifespan",
                       self.rel, node.lineno)
        self.generic_visit(node)


def file_layer_of(root: Path, manifest: dict, template: Template, rel: str, module: str) -> str | None:
    """A file's layer outside a check run (component add --file, init --adopt)."""
    mapped = mapped_layer(layer_paths(manifest), rel)
    if mapped is not None:
        return mapped
    parts = module.split(".")
    return parts[1] if len(parts) > 1 and template.layer(parts[1]) is not None else None


def symbols_of_file(source: str) -> list[dict]:
    """The public contract a file has today, as spec symbols (adopting an existing module): its
    functions with their signatures, classes, constants and every route."""
    tree = ast.parse(source)
    symbols: list[dict] = []
    for node in tree.body:
        route = _route_of(node)
        if route is not None:
            symbols.append({"kind": "route", "name": node.name, "method": route[0], "path": route[1]})  # type: ignore[union-attr]
            continue
        for name in _defined_names(node):
            if name.startswith("_"):
                continue
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                symbols.append({"kind": "function", "name": name, "signature": render_signature(node)})
            elif isinstance(node, ast.ClassDef):
                symbols.append({"kind": "class", "name": name})
            else:
                symbols.append({"kind": "constant", "name": name})
    return symbols


def _returns_response(node: ast.FunctionDef | ast.AsyncFunctionDef) -> bool:
    """The route returns a Response object it builds (RedirectResponse(...), or a name assigned from one)."""
    def builds_response(value: ast.expr | None) -> bool:
        if not isinstance(value, ast.Call):
            return False
        func = value.func
        name = func.id if isinstance(func, ast.Name) else func.attr if isinstance(func, ast.Attribute) else ""
        return bool(RESPONSE_RE.search(name))

    built = {target.id for sub in ast.walk(node) if isinstance(sub, ast.Assign) and builds_response(sub.value)
             for target in sub.targets if isinstance(target, ast.Name)}
    return any(isinstance(sub, ast.Return) and (builds_response(sub.value) or (
        isinstance(sub.value, ast.Name) and sub.value.id in built)) for sub in ast.walk(node))


def _owning_component(by_module: dict, target: str) -> dict | None:
    parts = target.split(".")
    for end in range(len(parts), 1, -1):
        candidate = ".".join(parts[:end])
        if candidate in by_module:
            return by_module[candidate]
    return None


def run_check(root: Path, only_file: Path | None = None, content: str | None = None,
              base: str | None = None, accept_weakening: bool = False,
              complete: bool = False, raw: bool = False, test_report: Path | None = None) -> Report:
    """Run every check for the project at `root`.

    `content` replaces the on-disk text of `only_file` (unsaved editor buffer).
    `base` compares guards with that git reference (see archvow.baseline).
    `raw` ignores .archvow/frozen.json (used by `archvow freeze`).
    """
    overrides = {only_file: content} if only_file is not None and content is not None else None
    checker = _Checker(root, overrides, complete, test_report)
    report = checker.run()
    if not raw:
        from archvow.freeze import apply

        apply(root, report)
    if base:
        from archvow.baseline import compare

        compare(checker, base, accept_weakening)
        report.violations.sort(key=lambda v: (v.file, v.line, v.code))
    if only_file is not None:
        rel = only_file.resolve().relative_to(root.resolve()).as_posix()
        report.violations = [v for v in report.violations if v.file == rel]
    from archvow.guidance import attach

    attach(report, str((checker.manifest or {}).get("language") or "en"))
    return report
