"""archvow: architecture specifications for AI-written code, and the guards that enforce them."""

__version__ = "1.21.0"
