"""`archvow changes --from v1.2.0 --to v1.3.0`: what a release contains, merge by merge.

For each commit on the main line between the two references (a merge, or a squashed merge):
the ticket, the spec decisions it brought, the components and tests it changed, who merged it,
and who approved it when the platform writes `Approved-by:` lines in the merge commit (GitLab
merge commit template `%{approved_by}`). Read from Git: a report, not a committed view.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

from archvow import manifest as mf
from archvow.baseline import GitError, _git
from archvow.specdiff import compare

SEP, END = "\x1f", "\x1e"
DEFAULT_TICKET = "[A-Z][A-Z0-9]*-[0-9]+"


def changes_report(root: Path, start: str, end: str = "HEAD") -> list[dict]:
    try:
        log = _git(root, "log", "--first-parent", "--reverse", f"--format=%H{SEP}%P{SEP}%an{SEP}%cn{SEP}%cI{SEP}%s"
                   f"{SEP}%b{END}", f"{start}..{end}")
    except GitError as exc:
        raise GitError(f"cannot read the history {start}..{end}: {exc}") from exc
    data = mf.load(root)
    pattern = re.compile(str((data.get("init_answers") or {}).get("ticket_pattern") or DEFAULT_TICKET))
    paths = {}
    for container in data.get("containers", []):
        for comp in container.get("components", []):
            paths[mf.source_path(container, comp)] = comp["id"]
            paths[mf.test_path(comp)] = comp["id"]
    out = []
    for record in [r for r in log.split(END) if r.strip()]:
        sha, parents, author, committer, date, subject, body = (record.strip("\n").split(SEP) + [""] * 7)[:7]
        parent = parents.split()[0] if parents.split() else None
        files = _git(root, "diff", "--name-only", parent, sha).split() if parent else []
        before = (mf.load_at(root, parent) or {}) if parent else {}
        after = mf.load_at(root, sha) or {}
        tickets = sorted(set(pattern.findall(f"{subject}\n{body}")))
        out.append({
            "commit": sha[:10], "date": date[:10], "subject": subject, "tickets": tickets,
            "merged_by": committer or author, "author": author,
            "approved_by": re.findall(r"^Approved-by:\s*(.+)$", body, re.M),
            "components": sorted({paths[f] for f in files if f in paths}),
            "tests": sorted(f for f in files if f.startswith("tests/")),
            "spec": [f"{c['change']} {c['ref']}: {c['detail']}" for c in compare(before, after)],
        })
    return out


def render_changes(rows: list[dict], start: str, end: str, markdown: bool) -> str:
    if not rows:
        return f"No change between {start} and {end}.\n"
    lines = [f"## Changes {start} -> {end}" if markdown else f"Changes {start} -> {end}", ""]
    for row in rows:
        tickets = ", ".join(row["tickets"]) or "no ticket"
        head = f"{row['date']} {row['commit']} {tickets}: {row['subject']}"
        lines.append(f"### {head}" if markdown else head)
        approved = ", ".join(row["approved_by"]) or "not recorded in the commit"
        for label, value in (("merged by", row["merged_by"]), ("approved by", approved),
                             ("components", ", ".join(row["components"]) or "-"),
                             ("tests", ", ".join(row["tests"]) or "-")):
            lines.append(f"- {label}: {value}" if markdown else f"  {label}: {value}")
        for change in row["spec"]:
            lines.append(f"- spec: {change}" if markdown else f"  spec: {change}")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def to_json(rows: list[dict]) -> str:
    return json.dumps(rows, indent=2)
