"""The templates of a project, checked (layer 2): ARCH060, a copy that differs from what init / `template update`
recorded; ARCH009, a template this archvow cannot use (a rule, an agent profile or a regime it cannot read), a
`rules:` override archvow ignores, and a regime the project chose (`compliance`) that no template holds or that
cannot be read.
"""

from __future__ import annotations

from pathlib import Path

from archvow import agents
from archvow.checks.catalogue import all_rules, final_rules, override_problem
from archvow.checks.engine import Checker
from archvow.foundation.errors import TemplateError
from archvow.foundation.paths import PROJECT_REL
from archvow.templates import Template
from archvow.templating import copies, regimes, store
from archvow.templating import rules as pack_rules


def run_templates(checker: Checker) -> None:
    for name, why in copies.changed_by_hand(checker.root, checker.manifest):
        checker.add("ARCH060", f"template {name}: {why} - an architect runs `archvow template update` (or init "
                    "--force -t), never edits the copy", (store.PROJECT_TEMPLATES / name).as_posix())
    for folder in copies.project_folders(checker.root):
        where = (folder / store.MANIFEST).relative_to(checker.root).as_posix() if (folder / store.MANIFEST).exists() \
            else folder.relative_to(checker.root).as_posix()
        try:
            if folder != copies.own_folder(checker.root):
                store.require_fit(store.meta(folder))
        except TemplateError as error:
            checker.add("ARCH012" if "needs archvow" in str(error) else "ARCH009", f"template {folder.name}: {error}",
                        where)
            continue
        try:
            pack_rules.folder_rules(folder)
            for profile in sorted(folder.glob("agents/*/agent.yaml")):
                agents.read(profile.parent, folder.name)
            for regime in sorted(folder.glob("regimes/*.yaml")):  # skipped by regimes.available: say so
                regimes.read_file(regime, template=folder.name)
        except TemplateError as error:
            checker.add("ARCH009", f"template {folder.name}: {error}", where)
    templates = list(checker.templates.values())
    every_rule = all_rules(templates)  # every container's rules, not the first's only
    final = final_rules(templates)
    for code, value in (checker.manifest.get("rules") or {}).items():  # an override is applied or reported
        problem = override_problem(code, value, every_rule, final)
        if problem:
            checker.add("ARCH009", f"rules: {problem} - archvow ignores it", PROJECT_REL.as_posix())
    for template in {t.name: t for t in templates}.values():  # a template's own `rules:` too
        where = _template_file(checker.root, template)
        for code, value in (template.rules or {}).items():
            problem = override_problem(code, value, all_rules([template]), final_rules([template]))
            if problem:
                checker.add("ARCH009", f"template {template.name}: rules: {problem} - archvow ignores it", where)
    known = {*regimes.available(checker.root), "tst", "priv", "none"}
    for name in [str(n) for n in checker.manifest.get("compliance") or [] if str(n) not in known]:
        checker.add("ARCH009", f"compliance names '{name}', a regime archvow cannot find or read: its questions and "
                    "rules do not run - use a template that holds it, fix its file, or take the name out "
                    "(archvow init <package> --force -a rules=...)", PROJECT_REL.as_posix())


def _template_file(root: Path, template: Template) -> str:
    """Where a finding about a template goes: the template.yaml of its last copy in the project, else project.vow."""
    home = root.resolve()
    for folder in reversed(template.dirs):
        if folder.resolve().is_relative_to(home) and (folder / store.MANIFEST).exists():
            return (folder.resolve() / store.MANIFEST).relative_to(home).as_posix()
    return PROJECT_REL.as_posix()
