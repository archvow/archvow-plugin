"""The spec's vow files as they are on disk (layer 1): which vow files exist and their text, before store.py
assembles them into the one dict. Imports only foundation/.
"""

from __future__ import annotations

import hashlib
from pathlib import Path

from archvow.foundation.errors import ManifestError
from archvow.foundation.paths import COMPONENTS_DIR, FEATURES_REL, PROJECT_REL

CHANGED_MEANWHILE = ("the spec changed while this command ran (another archvow command, the IDE plugin): nothing "
                     "was written - run the command again")


class Revised(dict):  # type: ignore[type-arg]
    """A spec as `load` returns it: `revision` is the content key of the files it was read from. An attribute, not a
    key: it is never in the spec, its JSON or its vows; `copy.deepcopy` keeps it."""

    def __init__(self, data: dict, revision: bytes) -> None:  # type: ignore[type-arg]
        super().__init__(data)
        self.revision = revision


def revise(data: dict, root: Path) -> None:  # type: ignore[type-arg]
    """After `save`: the copy saved is what is on disk now, so the same command may save it again."""
    if isinstance(data, Revised):
        data.revision = on_disk(root)[4]


def on_disk(root: Path) -> tuple[str, dict[str, str], dict[str, str], dict[str, str], bytes]:
    """The project vow's text, `vow_files`, and their content key: the same files give the same key. store.py keeps
    the key of the spec it loaded last; `save` compares it with the files before writing (another writer)."""
    project_text = (root / PROJECT_REL).read_text(encoding="utf-8")
    features, components, homes = vow_files(root)
    texts = "\0".join([str(root.resolve()), project_text, *(f"{k}\0{v}" for k, v in features.items()),
                       *(f"{k}\0{homes[k]}\0{v}" for k, v in components.items())])  # a move changes the key
    return project_text, features, components, homes, hashlib.sha256(texts.encode("utf-8")).digest()


def vow_files(root: Path) -> tuple[dict[str, str], dict[str, str], dict[str, str]]:
    """The features' vows (name -> text), the components' (id -> text) and where each component lives (id ->
    feature). A feature folder without its vow is still read: its components are not lost (check says so)."""
    features: dict[str, str] = {}
    components: dict[str, str] = {}
    homes: dict[str, str] = {}
    folder = root / FEATURES_REL
    for feature in sorted(p for p in folder.iterdir() if p.is_dir()) if folder.is_dir() else []:
        vow = feature / f"{feature.name}.vow"
        if vow.is_file():
            features[feature.name] = vow.read_text(encoding="utf-8")
        for path in sorted((feature / COMPONENTS_DIR).glob("*.vow")):
            text = path.read_text(encoding="utf-8")
            if path.stem in homes:  # the same text twice: a move stopped between its write and its unlink
                if text != components[path.stem]:
                    raise ManifestError(f"the component '{path.stem}' is in two features: {homes[path.stem]} and "
                                        f"{feature.name} - keep one (git rm the other file)")
                other = folder / homes[path.stem] / COMPONENTS_DIR / path.name
                if path.stat().st_mtime_ns <= other.stat().st_mtime_ns:
                    continue  # the copy written last is where it was going; the next save removes the other
            components[path.stem] = text
            homes[path.stem] = feature.name
    return features, components, homes
