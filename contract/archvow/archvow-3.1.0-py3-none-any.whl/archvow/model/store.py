"""The spec on disk: one vow for the project, one vow per component, in the .vow format.

Layout:

    .archvow/project.vow                   the project's vow
        system: {name, description}
        containers (container <id>: template "name@version", package, path)   # deployables (C4 level 2)
        rules: {CODE: {severity: error|warning|off, ...}}               # check severity overrides
        language, mode, families, compliance, ai_tools, reviewers, dependencies, init_answers,
        project rules (R1, R2...), third parties, hazards/invariants/dismissed of the whole system
    .archvow/features/<feature>/<feature>.vow          a feature: what the product does (description, brief)
    .archvow/features/<feature>/components/<id>.vow    one component's vow (C4 level 3, one Python module)
        type, layer, module, spec (written `ticket`), description, uses, symbols, decisions, columns...,
        container (only when the project has several), hazards (H1, H2...), invariants (INV1...),
        dismissed (its "not applicable" safety questions)
    .archvow/features/shared/              the feature init creates: what every feature uses
    .archvow/doc/                          what `archvow doc` writes: ignored by Git, never read back

The .vow syntax is in vowfile.py. In memory, `load` returns ONE dict, the same shape every module
has always used: containers hold their components (each with its `feature`, the folder it lives in),
`features` lists the features, and hazards, invariants and dismissals are
top-level lists carrying their `component`. Hazard and invariant ids are qualified there -
`clean_orders.H1`, `clean_orders.INV1` (`system.H1` for the whole system) - and stored short (`H1`)
in the component's own file. `save` splits the dict back into the files and writes only the ones
that changed.

A template question nobody answered yet is stored as `template_question <hash of its text>` (and its `id`), read
back with the template's current words; an answered question keeps its own words.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any, cast

from archvow.foundation import logs, once
from archvow.foundation.errors import LockError
from archvow.foundation.errors import ManifestError as ManifestError
from archvow.foundation.files import plain_copy, spec_lock
from archvow.foundation.hashing import short_digest
from archvow.foundation.paths import (
    COMPONENTS_DIR,
    FEATURES_REL,
    SHARED,
    component_vow,
    feature_vow,
)
from archvow.foundation.paths import PROJECT_REL as PROJECT_REL
from archvow.model import journal, vowfile
from archvow.model.ondisk import CHANGED_MEANWHILE, Revised, on_disk, revise
from archvow.model.spec import decision_statement
from archvow.templates import TemplateError, edge_case_text, load_template, template_name

log = logs.get("manifest")

SCHEMA_VERSION = 2
SYSTEM = "system"  # the scope of hazards and invariants of the whole system (no component)
ITEM_ID_RE = re.compile(r"^(?P<scope>[a-z][a-z0-9_]*)\.(?P<kind>H|INV)(?P<n>\d+)$", re.IGNORECASE)
COMPONENT_ITEMS = ("hazards", "invariants", "dismissed")

PROJECT_HEADER = (
    "# archvow vow of the project - what every component must follow: mode, checks, approved AI tools and\n"
    "# packages, rules R1, R2... (`archvow show` reads one component; `archvow doc` writes the whole project).\n"
    "# Never edit by hand: archvow init <package> --force -a <answer>=..., archvow rule add, archvow dependency\n"
    "# add. Set by hand, by an architect, reviewed in the merge request: only `rules` (severities and limits),\n"
    "# `allowed_paths`, `dependencies_by_path` and `layer_paths`. Format: docs/vow-format.md of archvow.\n"
)
FEATURE_HEADER = (
    "# archvow vow of the feature {id} - what the product does; its components are in components/.\n"
    "# Read: archvow show {id}. Never edit by hand: archvow feature add / rename / remove.\n"
)
COMPONENT_HEADER = (
    "# archvow vow of {id} - what it must be and do; archvow check holds the code to it.\n"
    "# Read: archvow show {id}. Change: archvow specify {id}. Never edit by hand.\n"
)


def is_project(root: Path) -> bool:
    return (root / PROJECT_REL).is_file()


def find_root(start: Path) -> Path:
    """Walk up from `start` to the directory holding .archvow/project.vow."""
    current = start.resolve()
    for candidate in (current, *current.parents):
        if (candidate / PROJECT_REL).is_file():
            return candidate
    raise ManifestError(f"no {PROJECT_REL.as_posix()} found in {start} or its parents")








# ------------------------------------------------------------------ ids


def qualify(scope: str | None, short: str) -> str:
    """'H1' of clean_orders -> 'clean_orders.H1' (already qualified ids are kept)."""
    return short if "." in str(short) else f"{scope or SYSTEM}.{short}"


def shorten(scope: str | None, item_id: str) -> str:
    """'clean_orders.H1' in clean_orders' own file -> 'H1' (another component's id stays whole)."""
    prefix = f"{scope or SYSTEM}."
    return item_id[len(prefix):] if str(item_id).startswith(prefix) else item_id


def next_item_id(items: list[dict[str, Any]], scope: str | None, kind: str) -> str:
    """The next hazard (kind H) or invariant (INV) id of one component: clean_orders.H3."""
    scope = scope or SYSTEM
    numbers = [int(m.group("n")) for i in items if (m := ITEM_ID_RE.match(str(i.get("id", ""))))
               and m.group("scope") == scope and m.group("kind").upper() == kind]
    return f"{scope}.{kind}{(max(numbers) + 1) if numbers else 1}"


def normalise_item_id(words: str | list[str]) -> str:
    """'clean_orders H1', 'clean_orders.h1' or ['clean_orders', 'H1'] -> 'clean_orders.H1'."""
    text = " ".join(words) if isinstance(words, list) else str(words)
    parts = text.replace(".", " ").split()
    if len(parts) == 2 and re.fullmatch(r"(?i)(H|INV)\d+", parts[1]):
        return f"{parts[0]}.{parts[1].upper()}"
    return text.strip()


# ------------------------------------------------------------------ template questions


def question_key(text: str) -> str:
    return short_digest(text)


def _template_texts(project: dict[str, Any], root: Path | None) -> dict[str, str]:
    """hash -> current words, for every question the project's template asks."""
    containers = project.get("containers") or []
    language = project.get("language") or "en"
    texts: dict[str, str] = {}
    for container in containers:
        try:
            template = load_template(template_name(container)[0], root, language=language)
        except (TemplateError, KeyError):
            logs.swallowed(log, "_template_texts: TemplateError, KeyError")
            continue

        def walk(node: object) -> None:
            if isinstance(node, dict):
                for key, value in node.items():
                    if key == "edge_cases" and isinstance(value, list):
                        for item in value:
                            text = edge_case_text(item)
                            texts.setdefault(question_key(text), text)
                    else:
                        walk(value)
            elif isinstance(node, list):
                for item in node:
                    walk(item)

        walk(template.data)
    return texts


# ------------------------------------------------------------------ load


def load(root: Path) -> dict[str, Any]:
    """The whole spec as one dict (the caller's own copy: it may change it)."""
    spec = once.remember(("spec", str(root.resolve())), lambda: _assembled(root))
    return Revised(plain_copy(dict(spec)), spec.revision) if isinstance(spec, Revised) else plain_copy(spec)


def _assembled(root: Path) -> dict[str, Any]:
    """The spec from its vows, shared (never changed by a caller), kept by the files' content: never stale."""
    if not is_project(root):
        raise ManifestError(f"{root / PROJECT_REL} does not exist")
    project_text, features, components, homes, key = journal.read(root, lambda: on_disk(root))  # never half a save
    where = str(root.resolve())
    cached = _LOADED.get(where)
    if cached is None or cached[0] != key:
        with logs.timed(log, "spec loaded") as note:
            cached = (key, Revised(assemble(project_text, components, root, features, homes), key))
            note["detail"] = f"{len(components)} components"
        _LOADED[where] = cached
    return cached[1]


_LOADED: dict[str, tuple[bytes, dict[str, Any]]] = {}  # per project: the content key of the vows loaded last, and the spec


def read_vow(text: str, label: str, kind: str) -> tuple[str | None, dict[str, Any]]:
    """One .vow file of this kind -> (the name on its first line, its data)."""
    try:
        found, name, data = vowfile.loads(text, label)
    except vowfile.VowError as exc:
        raise ManifestError(str(exc)) from None
    if found != kind:
        raise ManifestError(f"{label}: a vow of a {found}, where archvow expects the vow of a {kind}")
    return name, data


def assemble(project_text: str, component_texts: dict[str, str], root: Path | None,
             feature_texts: dict[str, str] | None = None, homes: dict[str, str] | None = None) -> dict[str, Any]:
    """Project vow + feature vows + component vows -> the one in-memory dict."""
    data = {"schema_version": SCHEMA_VERSION, **read_vow(project_text, PROJECT_REL.as_posix(), "project")[1]}
    homes = homes or {}
    named = dict(feature_texts or {})
    data["features"] = []
    for name in sorted({*named, *homes.values()}):
        label = feature_vow(name).as_posix()
        found, feature = read_vow(named[name], label, "feature") if name in named else (name, {})
        if found not in (None, name):
            raise ManifestError(f"{label}: the vow of `{found}` in the folder of `{name}` - the folder is "
                                "named after its feature")
        data["features"].append({"name": name, **feature} | {"name": name})  # its folder names it, never its text
    data.setdefault("containers", [])
    data.setdefault("rules", {})
    for name in COMPONENT_ITEMS:  # the whole system's own items carry no component
        items = data.get(name) or []
        for item in items:
            item.setdefault("component", None)
            _expand(item, None)
        data[name] = items
    by_container = {c["id"]: c for c in data["containers"]}
    for container in data["containers"]:
        container["components"] = []
    texts: dict[str, str] | None = None
    comps = []
    for cid, text in component_texts.items():
        label = component_vow(homes.get(cid, SHARED), cid).as_posix()
        found, comp = read_vow(text, label, "component")
        if found not in (None, cid):
            raise ManifestError(f"{label}: the vow of `{found}` in the file of `{cid}` - the file is named "
                                "after its component")
        comp = {"id": cid, "feature": homes.get(cid, SHARED), **comp} | {"id": cid, "feature": homes.get(cid, SHARED)}  # its file and folder name it (first keys, as before), never its text
        for name in COMPONENT_ITEMS:
            for item in comp.pop(name, None) or []:
                item = {"component": comp["id"], **item}
                _expand(item, comp["id"])
                data.setdefault(name, []).append(item)
        for decision in comp.get("decisions") or []:
            if "template_question" in decision:
                if texts is None:
                    texts = _template_texts(data, root)
                ref = decision.pop("template_question")
                decision["question"] = texts.get(str(ref), f"(a question the template no longer asks: {ref})")
                decision.setdefault("answer", None)
        comps.append(comp)
    comps.sort(key=lambda c: (str(c.get("layer", "")), str(c["id"])))
    for comp in comps:
        named = comp.pop("container", None)  # written only when the project has several: none is the first
        if (owner := by_container.get(named) if named else (data["containers"] or [None])[0]) is None:
            raise ManifestError(f"component {comp['id']} belongs to " + (f"container '{named}', none of the project's: {', '.join(by_container)}" if named else "no container"))
        owner["components"].append(_order_decision_keys(comp))
    inherit_type_answers(data)
    link_decision_invariants(data)
    for name in ("hazards", "invariants"):
        data[name] = sorted(data.get(name) or [], key=_item_order)
    data["dismissed"] = data.get("dismissed") or []
    if not data["dismissed"]:
        data.pop("dismissed")
    return data


def link_decision_invariants(data: dict[str, Any]) -> None:
    """An invariant saved as `from_decision N` says what decision N of its component answers now."""
    comps = {c["id"]: c for ct in data.get("containers") or [] for c in ct.get("components") or []}
    for inv in data.get("invariants") or []:
        if inv.get("from_decision") and inv.get("component") in comps:
            inv["statement"] = decision_statement(data, comps[inv["component"]], int(inv["from_decision"]))


TYPE_ORIGIN = "type"  # a decision answered once for every component of a type (never saved in the component)


def inherit_type_answers(data: dict[str, Any]) -> None:
    """The architects answer a question once for a type (`type_answers` of the project vow): every
    component of that type with that question still open gets the answer, marked origin "type". A
    component's own answer always wins; `split` writes the inherited ones back as open."""
    shared = {(str(a.get("type")), str(a.get("question"))): a for a in data.get("type_answers") or []}
    if not shared:
        return
    for container in data.get("containers") or []:
        for comp in container.get("components") or []:
            for decision in comp.get("decisions") or []:
                if str(decision.get("answer") or "").strip():
                    continue
                found = shared.get((str(comp.get("type")), str(decision.get("question"))))
                if found:
                    decision["answer"] = found.get("answer")
                    decision.update({k: found[k] for k in ("by", "on") if k in found})
                    decision["origin"] = TYPE_ORIGIN


def _order_decision_keys(comp: dict[str, Any]) -> dict[str, Any]:
    """Decisions read back as {question, answer, ...}: the order every module has always printed."""
    for i, decision in enumerate(comp.get("decisions") or []):
        if "question" in decision:
            comp["decisions"][i] = {"question": decision["question"], "answer": decision.get("answer"),
                                    **{k: v for k, v in decision.items() if k not in ("question", "answer")}}
    return comp


def _item_order(item: dict[str, Any]) -> tuple[Any, ...]:
    match = ITEM_ID_RE.match(str(item.get("id", "")))
    return (match.group("scope"), int(match.group("n")), "") if match else ("", 0, str(item.get("id")))


def _expand(item: dict[str, Any], scope: str | None) -> None:
    if "id" in item:
        item["id"] = qualify(scope, item["id"])
    if item.get("mitigates"):
        item["mitigates"] = [qualify(scope, h) for h in item["mitigates"]]


# ------------------------------------------------------------------ save


def split(data: dict[str, Any], root: Path | None) -> tuple[str, dict[str, str], dict[str, tuple[str, str]]]:
    """The one in-memory dict -> (project vow text, {feature: its vow text}, {component id: (its feature, its vow
    text)})."""
    data = plain_copy(dict(data))
    features = {}
    for feature in data.pop("features", None) or []:
        feature = dict(feature)
        name = feature.pop("name")
        features[name] = vowfile.dumps("feature", feature, name=name, comment=FEATURE_HEADER.format(id=name))
    data["schema_version"] = SCHEMA_VERSION
    several = len(data.get("containers") or []) > 1
    owned: dict[str, dict[str, list[Any]]] = {}
    system: dict[str, list[Any]] = {}
    known = {c["id"] for container in data.get("containers") or [] for c in container.get("components", [])}
    for name in COMPONENT_ITEMS:
        for item in data.pop(name, None) or []:
            scope = item.get("component")
            item = {k: v for k, v in item.items() if k != "component"} if scope in known else dict(item)
            if name == "invariants" and item.get("from_decision"):
                item.pop("statement", None)  # the decision's words: never copied into the vow
            if scope in known:
                _shorten(item, scope)
                owned.setdefault(scope, {}).setdefault(name, []).append(item)
            else:
                item.pop("component", None) if scope is None else None
                _shorten(item, None)
                system.setdefault(name, []).append(item)
    texts_of: dict[str, dict[str, str]] = {}  # per container: its template's questions
    components: dict[str, tuple[str, str]] = {}
    containers = []
    for container in data.get("containers") or []:
        comps = container.pop("components", None) or []
        containers.append(container)
        for comp in comps:
            comp = dict(comp)
            if several:
                comp["container"] = container["id"]
            decisions = []
            for decision in comp.get("decisions") or []:
                if decision.get("origin") == TYPE_ORIGIN:  # the project's answer: not the component's own
                    decision = {"question": decision.get("question", ""), "answer": None}
                if decision.get("answer") is None and set(decision) <= {"id", "question", "answer"}:
                    if container["id"] not in texts_of:
                        texts_of[container["id"]] = _template_texts(data | {"containers": [container]}, root)
                    texts = texts_of[container["id"]]
                    key = question_key(decision.get("question", ""))
                    if texts.get(key) == decision.get("question"):
                        decisions.append({**({"id": decision["id"]} if decision.get("id") else {}), "template_question": key})
                        continue
                decisions.append({"id": decision["id"], **decision} if decision.get("id") else decision)  # id first
            if "decisions" in comp:
                comp["decisions"] = decisions
            for name in COMPONENT_ITEMS:
                if owned.get(comp["id"], {}).get(name):
                    comp[name] = owned[comp["id"]][name]
            cid, feature = comp.pop("id"), str(comp.pop("feature", None) or SHARED)
            if feature not in features:  # a feature named only by its components: its vow is written too
                features[feature] = vowfile.dumps("feature", {}, name=feature, comment=FEATURE_HEADER.format(id=feature))
            components[cid] = (feature, vowfile.dumps("component", comp, name=cid,
                                                      comment=COMPONENT_HEADER.format(id=cid)))
    project = {k: v for k, v in data.items() if k != "containers"}
    ordered = {"system": project.pop("system", {}), "containers": containers}
    ordered.update({k: v for k, v in project.items() if k != "schema_version"})
    for name, items in system.items():
        ordered[name] = items
    return vowfile.dumps("project", ordered, comment=PROJECT_HEADER), features, components


def _shorten(item: dict[str, Any], scope: str | None) -> None:
    if "id" in item:
        item["id"] = shorten(scope, item["id"])
    if item.get("mitigates"):
        item["mitigates"] = [shorten(scope, h) for h in item["mitigates"]]


def save(root: Path, data: dict[str, Any]) -> Path:
    """Write the spec in one step (model/journal.py): only files whose text changes are written, and a component's
    file moves with it when it changes feature. Returns the project vow path."""
    project_text, features, components = split(data, root)
    where = str(root.resolve())
    with spec_lock(root):  # a second archvow (the IDE, another terminal) waits for this one
        journal.finish(root)  # a save stopped earlier: finished (or its staged files removed) first
        seen = getattr(data, "revision", None) or (_LOADED.get(where) or (None,))[0]  # this copy's, else the last load's
        if seen is not None and is_project(root) and on_disk(root)[4] != seen:  # never write back a stale spec
            raise LockError(CHANGED_MEANWHILE)
        path = root / PROJECT_REL
        path.parent.mkdir(parents=True, exist_ok=True)
        steps = journal.Save(root)
        steps.write(path, project_text)
        for name, text in features.items():
            steps.write(root / feature_vow(name), text)
        for cid, (feature, text) in components.items():
            steps.write(root / component_vow(feature, cid), text)
        folder = root / FEATURES_REL
        for stale in sorted(folder.glob(f"*/{COMPONENTS_DIR}/*.vow")) if folder.is_dir() else []:
            if components.get(stale.stem, ("",))[0] != stale.parent.parent.name:
                steps.delete(stale)  # removed, or moved to another feature
        for gone in sorted(p for p in folder.iterdir() if p.is_dir()) if folder.is_dir() else []:
            if gone.name not in features:  # removed or renamed: its vow and empty components/ go, proposals stay
                steps.delete(gone / f"{gone.name}.vow")
                steps.prune(gone)
        steps.commit()
        _LOADED.pop(where, None)
        revise(data, root)  # under the lock: a save just after the unlock is another writer's, never this copy's
    return path


def where(component: dict[str, Any] | None) -> str:
    """The file a finding about one component (or the project, None) points to."""
    if not component:
        return PROJECT_REL.as_posix()
    return component_vow(str(component.get("feature") or SHARED), component["id"]).as_posix()


# ------------------------------------------------------------------ helpers


def container(data: dict[str, Any], container_id: str | None) -> dict[str, Any]:
    containers = data.get("containers", [])
    if container_id is None:
        if len(containers) != 1:
            ids = ", ".join(c["id"] for c in containers)
            raise ManifestError(f"several containers ({ids}); pass --container")
        return cast(dict[str, Any], containers[0])
    for item in containers:
        if item["id"] == container_id:
            return cast(dict[str, Any], item)
    raise ManifestError(f"unknown container '{container_id}'")


def name_values(name: str) -> dict[str, str]:
    """The placeholders a component type may use: {name} orders_clean, {NAME} ORDERS_CLEAN,
    {Name} OrdersClean (a class name)."""
    return {"name": name, "NAME": name.upper(), "Name": "".join(p.capitalize() for p in name.split("_"))}


def test_path(component: dict[str, Any]) -> str:
    """Where a component's test lives: tests/<layer>/[<group>/]test_<id>.py."""
    group = f"{component['group']}/" if component.get("group") else ""
    return f"tests/{component['layer']}/{group}test_{component['id']}.py"


def source_path(container_data: dict[str, Any], component: dict[str, Any]) -> str:
    """The component's file: <container path>/<layer>/[<group>/]<id>.py."""
    return f"{container_data['path']}/" + "/".join(component["module"].split(".")[1:]) + ".py"


def hazards(data: dict[str, Any]) -> list[dict[str, Any]]:
    """The hazards: what must never happen (dismissed safety questions are not hazards)."""
    return list(data.get("hazards", []) or [])


def dismissals(data: dict[str, Any]) -> list[dict[str, Any]]:
    """Safety questions answered "not applicable", with the reason (`archvow hazard dismiss`)."""
    return list(data.get("dismissed") or [])


def answered_safety(data: dict[str, Any]) -> set[tuple[str | None, str | None]]:
    """(component, guide word) pairs whose safety question has an answer: a hazard or a dismissal."""
    return ({(h.get("component"), h.get("guide_word")) for h in data.get("hazards", []) or []}
            | {(d.get("component"), d.get("guide_word")) for d in data.get("dismissed") or []})


def instructed_tools(data: dict[str, Any]) -> list[str]:
    """AI tools that get instructions and may have their files here: the approved assistants
    (they write code) and the approved reviewers (they only write review reports)."""
    tools = [*(data.get("ai_tools") or []), *(data.get("reviewers") or [])]
    return [t for t in dict.fromkeys(tools) if t != "none"]
