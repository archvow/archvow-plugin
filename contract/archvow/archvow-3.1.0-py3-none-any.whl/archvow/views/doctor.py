"""`archvow doctor`: is this machine ready to work on the project? One line per check, with the fix.

A diagnostic, not a workflow step: run it when something does not work. The engine checks what
every project needs (Python, the archvow command and its version, Git and the hook, the
template); the template adds its own tools (`doctor:` in template.yaml, e.g. Java and PySpark).
"""

from __future__ import annotations

import importlib.metadata
import importlib.util
import os
import re
import shutil
import subprocess
import sys
import sysconfig
import tempfile
from collections.abc import Callable
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from archvow import __version__, agents
from archvow.agent import DOCS, describe, tool_data, unseen
from archvow.checks.engine import newer_python_needed
from archvow.foundation import logs
from archvow.foundation.sandbox import Sandbox
from archvow.model import store
from archvow.spec.project_files import next_steps
from archvow.templates import TemplateError, load_template, template_name
from archvow.templating.copies import changed_by_hand, recorded
from archvow.templating.store import doctor_problem

log = logs.get("doctor")

MIN_PYTHON = (3, 10)


@dataclass
class Finding:
    """One check: ok, warn (works, but should be fixed) or fail (blocks the work)."""

    check: str
    status: str
    detail: str
    fix: str = ""


def _run(command: list[str], cwd: Path | None = None) -> tuple[int, str]:
    """Exit code and output (stdout + stderr) of a command; 127 when it does not exist."""
    try:
        done = subprocess.run(command, cwd=cwd, capture_output=True, text=True,
                              encoding="utf-8", errors="replace", timeout=60, check=False)
    except (FileNotFoundError, PermissionError):
        logs.swallowed(log, "_run: FileNotFoundError, PermissionError")
        return 127, ""
    except subprocess.TimeoutExpired:
        logs.swallowed(log, "_run: subprocess.TimeoutExpired")
        return 124, "timed out"
    return done.returncode, (done.stdout + done.stderr).strip()


def _probe(command: list[str], root: Path) -> tuple[int | None, str]:
    """A template's version probe, run from an empty temporary folder: `python3 version` never reaches a file of the
    project named `version`, and a relative PATH entry finds nothing there. A program that PATH finds inside the
    project is refused (a cloned repository can carry one), unless it is in a virtualenv (a folder with pyvenv.cfg):
    the exit code is then None, and the text says why."""
    path = os.pathsep.join(p for p in os.get_exec_path() if os.path.isabs(p))
    found = shutil.which(command[0], path=path)
    if found is None:
        return 127, ""
    real, home = Path(found).resolve(), root.resolve()
    if real.is_relative_to(home) and not any((d / "pyvenv.cfg").is_file()
                                             for d in real.parents if d.is_relative_to(home) and d != home):
        return None, f"{command[0]} is a program of the project ({real.relative_to(home).as_posix()}): doctor never runs one"
    with tempfile.TemporaryDirectory(prefix="archvow-doctor-") as empty:
        return _run([found, *command[1:]], cwd=Path(empty))


def _version_tuple(text: str) -> tuple[int, ...]:
    return tuple(int(p) for p in re.findall(r"\d+", text)[:3])


def _python(findings: list[Finding], answers: dict[str, Any], context: dict[str, Any]) -> None:
    current = f"{sys.version_info.major}.{sys.version_info.minor}"
    low = answers.get("python_version")
    high = (context.get("python_ceiling") or {}).get(answers.get("spark_version", ""))
    if sys.version_info[:2] < MIN_PYTHON or (low and _version_tuple(current) < _version_tuple(low)):
        need = low or ".".join(map(str, MIN_PYTHON))
        findings.append(Finding("Python", "fail", f"{current} ({sys.executable}); the project needs {need} or newer",
                                f"install Python {need}+ and run archvow with it (python{need} -m archvow)"))
    elif high and _version_tuple(current) > _version_tuple(high):
        findings.append(Finding("Python", "warn", f"{current}: newer than PySpark {answers['spark_version']} supports "
                                f"(up to {high}); Spark tests may fail",
                                f"use Python {high} for this project (e.g. python{high} -m pip install -r ...)"))
    else:
        findings.append(Finding("Python", "ok", f"{current} ({sys.executable})"))


def _archvow(findings: list[Finding], root: Path | None) -> None:
    location = Path(__file__).resolve().parent
    findings.append(Finding("archvow", "ok", f"{__version__} ({location})"))
    command = shutil.which("archvow")
    scripts = sysconfig.get_path("scripts")
    if command is None:
        findings.append(Finding("archvow command", "fail", "not on PATH",
                                f'add {scripts} to PATH (export PATH="{scripts}:$PATH"), or run python3 -m archvow'))
    else:
        code, out = _run([command, "--version"])
        version = out.split()[-1] if code == 0 and out else ""
        if version != __version__:
            findings.append(Finding(
                "archvow command", "fail",
                f"{command} runs {version or 'nothing (broken install)'}, this Python has {__version__}",
                "python3 -m pip uninstall -y archvow (until none is left), reinstall it, then hash -r"))
        else:
            findings.append(Finding("archvow command", "ok", command))
    if root is None:
        return
    pinned = _pinned_version(root)
    if pinned and pinned != __version__:
        findings.append(Finding("archvow version", "fail",
                                f"the project pins {pinned} (as its CI), {__version__} is installed",
                                f"python3 -m pip install archvow=={pinned}"))
    elif pinned:
        findings.append(Finding("archvow version", "ok", f"{pinned}, as the project and its CI"))


def _pinned_version(root: Path) -> str | None:
    for name in ("requirements.txt", "requirements", "requirements-dev.txt", "pyproject.toml"):
        path = root / name
        if path.is_file():
            match = re.search(r"archvow\s*==\s*([0-9][0-9A-Za-z.+-]*)", path.read_text(encoding="utf-8"))
            if match:
                return match.group(1)
    return None


def _git(findings: list[Finding], root: Path | None, answers: dict[str, Any]) -> None:
    if shutil.which("git") is None:
        findings.append(Finding("Git", "fail", "git is not installed", "install Git"))
        return
    if root is None:
        return
    code, top = _run(["git", "rev-parse", "--show-toplevel"], cwd=root)
    if code != 0:
        findings.append(Finding("Git", "fail", f"{root} is not a Git repository", "git init (or clone the project)"))
        return
    findings.append(Finding("Git", "ok", top))
    hooks = answers.get("git_hooks", "githooks" if (root / ".githooks").is_dir() else "none")
    if hooks == "githooks":
        _, path = _run(["git", "config", "core.hooksPath"], cwd=root)
        expected = (root / ".githooks").resolve()
        enabled = bool(path) and (Path(top) / path).resolve() == expected
        findings.append(Finding("Git hook", "ok", "enabled (.githooks)") if enabled else Finding(
            "Git hook", "fail", "not enabled: commits are not checked locally",
            f"git config core.hooksPath {expected.relative_to(Path(top).resolve()).as_posix()}"))
    elif hooks == "pre-commit":
        installed = (Path(top) / ".git" / "hooks" / "pre-commit").is_file()
        findings.append(Finding("Git hook", "ok", "pre-commit installed") if installed else Finding(
            "Git hook", "fail", "pre-commit is not installed in this clone", "pre-commit install"))


def _template(findings: list[Finding], root: Path, data: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    """The project's template (found?) and the answers given at init. A template whose copy changed by hand (ARCH060),
    itself or a template of its chain, has its `doctor:` entries left out: what they say was never approved."""
    answers = dict(data.get("init_answers") or {})
    container = data["containers"][0]
    name = template_name(container)[0]
    try:
        template = load_template(name, root)
    except TemplateError as exc:
        logs.swallowed(log, "_template: TemplateError")
        findings.append(Finding("template", "fail", str(exc),
                                "the project's templates are copied in .archvow/templates/ by init: an architect runs "
                                "`archvow template update` (or init --force -t <template>) and commits them"))
        return {}, answers
    versions = recorded(data)
    findings.append(Finding("template", "ok", " -> ".join(f"{n} {(versions.get(n) or {}).get('version', '')}".strip()
                                                         for n in template.chain)))
    defaults = {q["id"]: (template.data.get("questions_defaults") or {}).get(q["id"], q.get("default"))
                for q in template.data.get("questions", [])}
    given = {**{k: v for k, v in defaults.items() if v is not None}, **answers}
    changed = sorted(set(template.chain) & {name for name, _ in changed_by_hand(root, data)})
    if changed and template.data.get("doctor"):
        findings.append(Finding("template tools", "fail", f"not checked: the copy of template {', '.join(changed)} "
                                "changed outside init / `archvow template update` (ARCH060)",
                                "restore the copy (git checkout .archvow/templates/), or `archvow template update`"))
        return {k: v for k, v in template.data.items() if k != "doctor"}, given
    return template.data, given


def _template_tools(findings: list[Finding], template: dict[str, Any], answers: dict[str, Any], root: Path) -> None:
    """The template's own checks: a command that must run, or a Python package (and its version)."""
    env = Sandbox(autoescape=False)
    render: Callable[[object], str] = lambda text: env.from_string(str(text)).render(**template.get("context", {}), **answers)
    for item in template.get("doctor") or []:
        name, fix = render(item.get("name", "")), render(item.get("fix", ""))
        level = "warn" if item.get("optional") else "fail"
        problem = doctor_problem({k: render(v) for k, v in item.items() if k in ("command", "module")})
        if problem:  # never run: the template asks for more than a version
            findings.append(Finding(name, "fail", problem, "fix the template's doctor: entry"))
            continue
        if "command" in item:
            command = render(item["command"]).split()
            code, out = _probe(command, root)
            if code is None:  # never run
                findings.append(Finding(name, "fail", out, "remove it from the project, or put the real tool first "
                                        "on PATH"))
                continue
            if code != 0:
                findings.append(Finding(name, level, f"`{' '.join(command)}` failed" if code != 127 else
                                        f"{command[0]} not found", fix))
                continue
            lines = [line for line in out.splitlines() if line.strip() and not line.startswith("Picked up")]
            first = lines[0] if lines else "ok"
            wanted = render(item.get("version", ""))
            if wanted and not re.search(rf"\b{re.escape(wanted)}", out):
                findings.append(Finding(name, level, f"{first} (needs {wanted})", fix))
            else:
                findings.append(Finding(name, "ok", first))
        elif "module" in item:
            module = render(item["module"])
            if importlib.util.find_spec(module) is None:
                findings.append(Finding(name, level, f"{module} is not installed in {sys.executable}", fix))
                continue
            try:
                version = importlib.metadata.version(render(item.get("distribution", module)))
            except importlib.metadata.PackageNotFoundError:
                logs.swallowed(log, "_template_tools: importlib.metadata.PackageNotFoundError")
                version = "?"
            wanted = render(item.get("version", ""))
            if wanted and not (version == wanted or version.startswith(wanted + ".")):
                findings.append(Finding(name, level, f"{version} installed, the project uses {wanted}", fix))
            else:
                findings.append(Finding(name, "ok", version))


def run_doctor(start: Path) -> list[Finding]:
    """Every check, for the project around `start` (or only the machine, outside a project)."""
    findings: list[Finding] = []
    try:
        root: Path | None = store.find_root(start)
    except store.ManifestError:
        logs.swallowed(log, "run_doctor: store.ManifestError")
        root = None
    template: dict[str, Any] = {}
    answers: dict[str, Any] = {}
    data: dict[str, Any] | None = None
    project: list[Finding] = []
    if root is not None:
        try:
            data = store.load(root)
        except store.ManifestError as exc:
            logs.swallowed(log, "run_doctor: store.ManifestError")
            project.append(Finding("manifest", "fail", str(exc), "fix .archvow/ (git diff shows "
                                   "what changed)"))
            data = None
        if data is not None:
            template, answers = _template(project, root, data)
    _python(findings, answers, template.get("context", {}))
    wanted = newer_python_needed(root) if root is not None else None
    if wanted:  # the project's own code needs a newer Python: archvow could not parse it (ARCH013)
        findings.append(Finding("Python", "warn", f"{sys.version_info.major}.{sys.version_info.minor} runs archvow, "
                                f"the project's pyproject.toml says requires-python {wanted}: newer syntax "
                                "cannot be read (ARCH013)", f"install a Python matching {wanted} and run archvow with it"))
    _archvow(findings, root)
    _git(findings, root, answers)
    findings += project
    if root is not None and template:
        _template_tools(findings, template, answers, root)
    if root is not None and data is not None:
        _agent(findings, root, data)
        if template:
            _set_up_once(findings, root, data, answers)
    return findings


SET_UP_ONCE = "set up once"


def _set_up_once(findings: list[Finding], root: Path, data: dict[str, Any], answers: dict[str, Any]) -> None:
    """The Git host and CI settings to make once, as `init` would print them (init keeps only its `!` lines)."""
    container = data["containers"][0]
    text = next_steps(template_name(container)[0], root, answers)
    hint = f"to change an answer: archvow init {container.get('package')} --force -a <question>=<answer>"
    findings.append(Finding(SET_UP_ONCE, "ok", f"{text}\n\n{hint}".strip()))


def _agent(findings: list[Finding], root: Path, data: dict[str, Any]) -> None:
    """The AI agent archvow runs inside, as it sees it (agent.py), and the assistants it cannot see."""
    status, line = describe(root, data)
    findings.append(Finding("AI agent", status, line, f"start the agent protected - see {DOCS}"))
    known = agents.profiles(root)
    for tool in store.instructed_tools(data):  # each approved agent: its profile, or the standard one
        p = agents.profile(tool, root, known)
        files = ", ".join([agents.STANDARD_SKILLS, *([p.skills] if p.skills else []),
                           *sorted(r.removesuffix(".j2") for r in p.files(str(data.get("language") or "en")))])
        seen = ", ".join(dict.fromkeys([*p.processes, *p.env, f"AI_AGENT={tool}", f"AGENT={tool}"]))  # each once
        line = (f"standard profile: archvow knows nothing more about {tool} (no unsafe options, no files of its own)"
                if p.standard else f"profile of {p.source}")
        findings.append(Finding(f"AI agent {tool}", "ok", f"{line}; files: AGENTS.md, {files}; recognised by {seen}",
                                ""))
    for tool, where in unseen(tool_data(root, data), list(data.get("ai_tools") or [])):
        findings.append(Finding(f"AI agent {tool}", "warn", f"archvow cannot see it {where}",
                                "its sandbox and YOLO mode are not checked: see " + DOCS))


def render(findings: list[Finding], root_known: bool) -> str:
    marks = {"ok": "ok  ", "warn": "warn", "fail": "FAIL"}
    width = max(len(f.check) for f in findings)
    lines = []
    for f in findings:
        if f.check == SET_UP_ONCE:  # a text to read, not a check: the command prints it after the table
            continue
        lines.append(f"[{marks[f.status]}] {f.check:<{width}}  {f.detail}")
        if f.fix and f.status != "ok":
            lines.append(f"       {'':<{width}}  fix: {f.fix}")
    failed = sum(f.status == "fail" for f in findings)
    warned = sum(f.status == "warn" for f in findings)
    lines.append("")
    if not root_known:
        lines.append("Not in an archvow project: only this machine was checked (run it in a project for more).")
    lines.append(f"{failed} problem(s), {warned} warning(s)." if failed or warned else "Everything is ready.")
    return "\n".join(lines)


def as_dicts(findings: list[Finding]) -> list[dict[str, Any]]:
    return [asdict(f) for f in findings]
