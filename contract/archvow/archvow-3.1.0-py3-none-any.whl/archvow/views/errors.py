"""`archvow show "<pasted error>"` (2.7.0): from an error as a person or an AI sees it to what archvow keeps.

Two things are read in the pasted text, nothing else:

* the project's files it names, with their line (a Python traceback's `File "...", line N`, or `<file>:<n>` as
  pytest, ruff and archvow print them): the last one is where it broke, and `show` opens it as `show file:line`;
* the known errors: the template rules whose `error` - the text people saw when it went wrong - is in it, with
  their fix and why. A lesson the team shipped in its template is found from the error itself.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from archvow.checks.catalogue import custom_rules
from archvow.templates import templates_of

PYTHON_FRAME = re.compile(r'File "(?P<path>[^"]+)", line (?P<line>\d+)')
PATH_LINE = re.compile(r"(?P<path>[\w./\\:-]*?[\w-]+\.py):(?P<line>\d+)")
# a file there is not the project's own code (a virtual environment inside the project, a build)
NOT_OURS = {"venv", ".venv", "env", "site-packages", "dist-packages", "build", "dist", "node_modules", ".tox", ".nox"}


def is_error(arg: str | None, root: Path) -> bool:
    """A pasted error, not a name or a file: text with a space or a line break (a name has none) that is not the
    path of a file (a folder name may have a space)."""
    if not arg or not re.search(r"\s", arg.strip()):
        return False
    plain = re.sub(r":\d+$", "", arg.strip())
    return not any((base / plain).is_file() for base in (Path.cwd(), root))


# an error's name, as Python prints it (KeyError, json.decoder.JSONDecodeError), then ':' or the end of the line
NAMED = re.compile(r"(?<![\w.])(?:[a-z_]\w*\.)*[A-Z]\w*(?:Error|Exception|Warning|Exit|Interrupt)(?=:|\s*$)")


def headline(text: str) -> str:
    """What went wrong: from the last error name of the last line that has one (KeyError: ..., pytest's `E` lines,
    a traceback pasted on one line by a one-line field), else the first line of the text."""
    lines = [line.strip() for line in text.strip().splitlines() if line.strip()]
    for line in reversed(lines):
        names = list(NAMED.finditer(line))
        if names:
            return line[names[-1].start():].strip()
    return lines[0] if lines else ""


def frames(root: Path, text: str) -> list[dict[str, Any]]:
    """The project's files the error names, in the order it names them, each (file, line) once."""
    out: list[dict[str, Any]] = []
    top = root.resolve()
    for match in [*PYTHON_FRAME.finditer(text), *PATH_LINE.finditer(text)]:
        rel = _ours(top, match.group("path"))
        frame = {"file": rel, "line": int(match.group("line")), "at": match.start()}
        if rel and not any(f["file"] == rel and f["line"] == frame["line"] for f in out):
            out.append(frame)
    out.sort(key=lambda f: f["at"])
    return [{"file": f["file"], "line": f["line"]} for f in out]


def _ours(top: Path, text: str) -> str | None:
    """The file's path from the project root when it is one of the project's own files, else None."""
    path = Path(text.replace("\\", "/"))
    for candidate in ([path] if path.is_absolute() else [Path.cwd() / path, top / path]):
        try:
            rel = candidate.resolve().relative_to(top)
        except (ValueError, OSError):
            continue
        if candidate.is_file() and not (set(rel.parts) & NOT_OURS):
            return rel.as_posix()
    return None


def known(root: Path, data: dict[str, Any], text: str) -> list[dict[str, Any]]:
    """The template rules whose `error` is in the pasted text (case and spaces ignored): code, message, fix, why."""
    flat = " ".join(text.split()).casefold()
    found: dict[str, dict[str, Any]] = {}
    for template in templates_of(root, data).values():
        for code, rule in custom_rules([template]).items():
            error = " ".join(str(rule.get("error") or "").split()).casefold()
            if error and error in flat:
                found[code] = {"code": code, "error": str(rule["error"]), "message": rule["title"],
                               "fix": rule["fix"], "why": rule["why"], "severity": rule["severity"]}
    return sorted(found.values(), key=lambda r: r["code"])
