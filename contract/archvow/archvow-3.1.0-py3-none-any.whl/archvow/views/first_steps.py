"""The first steps of a new project (`workspace --json` "first_steps", contract 2.1): five steps, each read from
the spec, the check and Git - never stored - so every editor shows the same card and it goes once all five are done.

1. foundations: the shared components have no open decision
2. feature: a feature besides `shared` exists
3. component: the first feature has components, and none of them has an open decision (3.1: all of them, not one)
4. build: a component of a feature is tested or verified; its command builds (`prompt --feature`) until one of the
   feature's components has code, then checks
5. commit: the spec, a feature's vows and code are in Git (once done, it stays done while the work goes on)
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from archvow.checks.engine import Report
from archvow.foundation.git import git_or_none, succeeds
from archvow.foundation.paths import SHARED
from archvow.model import features as feats
from archvow.model import store

STEPS = ("foundations", "feature", "component", "build", "commit")


def _decisions(n: int) -> str:
    return f"{n} decision{'' if n == 1 else 's'}"


def first_steps(root: Path, data: dict[str, Any], report: Report, rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """The five steps, in order, each `{step, title, detail, command, done}`."""
    status = {c.component: c for c in report.components}
    suggested = {r["component"]: r.get("suggested", 0) for r in rows}
    shared = [c["id"] for c in feats.components_of(data, SHARED)]
    open_shared = [cid for cid in shared if cid in status and status[cid].open_questions]
    asked = sum(status[cid].open_questions for cid in open_shared)
    offered = sum(suggested.get(cid, 0) for cid in open_shared)
    named = [f["name"] for f in feats.features(data) if f["name"] != SHARED]
    own = [c["id"] for c in feats.all_components(data) if feats.feature_of(c) != SHARED and c["id"] in status]
    built = [cid for cid in own if status[cid].status in ("tested", "verified")]
    tracked = git_or_none(root, "ls-files", "--", *((store.PROJECT_REL.parent / "features" / n).as_posix() for n in named), "src")
    files = (tracked or "").splitlines()
    committed = bool(named and succeeds(root, "ls-files", "--error-unmatch", store.PROJECT_REL.as_posix())
                     and any(not f.startswith("src") for f in files) and any(f.startswith("src") for f in files))
    first = named[0] if named else None
    members = [c["id"] for c in feats.components_of(data, first) if c["id"] in status] if first else []
    still = [cid for cid in members if status[cid].open_questions]
    coded = any(status[cid].status != "planned" for cid in members)
    return [
        {"step": "foundations", "title": "Answer the foundations",
         "detail": (f"{', '.join(open_shared)}: {_decisions(asked)}" + (f", {offered} with a suggestion" if offered else ""))
         if open_shared else "Their decisions are made",
         "command": f"archvow specify {open_shared[0]}" if open_shared else "archvow specify", "done": not open_shared},
        {"step": "feature", "title": "Add a feature", "detail": "What the product does",
         "command": 'archvow feature add <name> -d "what the product does"', "done": bool(named)},
        {"step": "component", "title": "Add the feature's components and answer their decisions",
         "detail": ", ".join(f"{cid}: {status[cid].open_questions} open" for cid in still[:3])
         + (f" and {len(still) - 3} more" if len(still) > 3 else "") if still
         else "Their decisions are made" if members else "What each one must do, then its decisions",
         "command": f"archvow specify {still[0]}" if still else
         f'archvow component add <type> <name> -d "what it must do" --feature {first or "<feature>"}',
         "done": bool(members) and not still},
        {"step": "build", "title": "Build them, then Check",
         "detail": "Their code and tests, checked against the spec" if coded
         else "The AI (or you) writes each one from its task",
         "command": "archvow check" if coded or not first else f"archvow prompt --feature {first}",
         "done": bool(built)},
        {"step": "commit", "title": "Commit",
         "detail": "The hooks run the same checks as CI; then open a merge request",
         "command": "git add -A && git commit", "done": committed},
    ]
