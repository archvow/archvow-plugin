"""`archvow template question <template|project> <type> <id>`: a question of a component type, written into a
template.yaml with its comments kept; in the project, every existing component of that type gets it.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any, cast

import yaml

from archvow.foundation.errors import TemplateError
from archvow.foundation.files import parse_yaml, write_text
from archvow.model import store as spec_store
from archvow.spec.template_parts import _own_manifest, is_own
from archvow.spec.template_use import add_new_questions
from archvow.templates import load_template
from archvow.templating import store


def _flow(value: object) -> str:
    """A value as one line of YAML (a list in brackets, a string quoted only when it must be)."""
    dumped: str = yaml.safe_dump(value, default_flow_style=True, allow_unicode=True, width=10_000)
    return dumped.strip().removesuffix("\n...").strip()


QUESTION_ID_RE = re.compile(r"^[a-z][a-z0-9_]*$")


def add_question(root: Path | None, folder: Path, type_name: str, question_id: str, text: str,
                 suggested: str | None = None, choices: list[str] | None = None,
                 texts: dict[str, dict[str, Any]] | None = None) -> dict[str, Any]:
    """`template question <template|project> <type> <id>`: a question of a component type, in template.yaml (and its
    translations, `texts`: language -> {question, suggested, choices}). In the project, every existing component of
    that type gets it, not answered yet. What was written: {file, components}."""
    if not QUESTION_ID_RE.match(question_id):
        raise TemplateError(f"'{question_id}': a question's id is lower case letters, digits and _ (rate_limit)")
    if not text.strip().endswith("?"):
        raise TemplateError("a question ends with '?', with an example answer before it (- e.g. ...?)")
    own = is_own(folder, root)
    if own:
        assert root is not None
        known = _project_types(root)
    else:
        template = load_template(folder.name, None, extra=(folder,))
        known = {type_name: template.component_types[type_name]} if type_name in template.component_types else {}
    if type_name not in known:
        raise TemplateError(f"no component type '{type_name}' here (types: {', '.join(sorted(known)) or 'none'})",
                            hint="a new component type is written by hand in template.yaml (docs/templates.md)")
    if any(q.get("id") == question_id for q in known[type_name].get("edge_cases") or [] if isinstance(q, dict)):
        raise TemplateError(f"a {type_name} already asks a question {question_id}",
                            hint="to reword it, write the same id again by hand in the template that extends it")
    item: dict[str, Any] = {"id": question_id, "question": text.strip()}
    if suggested:
        item["suggested"] = suggested.strip()
    if choices:
        item["choices"] = choices
    folder.mkdir(parents=True, exist_ok=True)
    _own_manifest(folder)
    insert_question(folder / store.MANIFEST, type_name, item)
    for language, own_texts in (texts or {}).items():
        translated = folder / f"template.{language}.yaml"
        if not translated.is_file():
            write_text(translated, f"# The texts of {folder.name} in '{language}'.\n")
        insert_question(translated, type_name, {"id": question_id, **own_texts})
    components: list[str] = []
    if own:
        assert root is not None
        data = spec_store.load(root)
        components = add_new_questions(root, data)
        spec_store.save(root, data)
    return {"file": str(folder / store.MANIFEST), "components": components}


def _project_types(root: Path) -> dict[str, Any]:
    found: dict[str, Any] = {}
    for container in spec_store.load(root).get("containers") or []:
        found |= load_template(container["template"], root).component_types
    return found


def insert_question(path: Path, type_name: str, item: dict[str, Any]) -> None:
    """Add one question under `component_types: <type>: edge_cases:` of a template file, keeping its comments; what
    the file says reads back the same, plus the question - else nothing is written."""
    text = path.read_text(encoding="utf-8") if path.is_file() else ""
    before = cast(dict[str, Any], parse_yaml(text) or {})
    line = "- " + _flow(item)
    lines = text.splitlines()
    top = _find(lines, r"component_types:\s*(#.*)?$", 0, 0, len(lines))
    if top is None:
        lines += ["", "component_types:", f"  {type_name}:", "    edge_cases:", f"      {line}"]
    else:
        end = _block_end(lines, top, 0)
        kind = _find(lines, rf"{re.escape(type_name)}:\s*(#.*)?$", 2, top + 1, end)
        if kind is None:
            lines[end:end] = [f"  {type_name}:", "    edge_cases:", f"      {line}"]
        else:
            kind_end = _block_end(lines, kind, 2)
            cases = _find(lines, r"edge_cases:\s*(\[\]\s*)?(#.*)?$", 4, kind + 1, kind_end)
            if cases is None:
                lines[kind_end:kind_end] = ["    edge_cases:", f"      {line}"]
            elif lines[cases].split(":", 1)[1].strip().startswith("[]"):
                lines[cases:cases + 1] = ["    edge_cases:", f"      {line}"]
            else:
                lines.insert(_block_end(lines, cases, 4), f"      {line}")
    new = "\n".join(lines) + "\n"
    after = parse_yaml(new) or {}
    expected = copy_with(before, type_name, item)
    if after != expected:
        raise TemplateError(f"{path}: archvow could not place the question in this file's layout",
                            hint=f"add it by hand under component_types: {type_name}: edge_cases:\n      {line}")
    write_text(path, new)


def copy_with(data: dict[str, Any], type_name: str, item: dict[str, Any]) -> dict[str, Any]:
    result = yaml.safe_load(yaml.safe_dump(data)) or {}
    types = result.setdefault("component_types", {}) or {}
    result["component_types"] = types
    ctype = types.setdefault(type_name, {}) or {}
    types[type_name] = ctype
    ctype["edge_cases"] = [*(ctype.get("edge_cases") or []), item]
    return dict(result)


def _find(lines: list[str], pattern: str, indent: int, start: int, end: int) -> int | None:
    rule = re.compile(" " * indent + pattern)
    return next((i for i in range(start, end) if rule.match(lines[i]) and not lines[i][indent:indent + 1].isspace()),
                None)


def _block_end(lines: list[str], head: int, indent: int) -> int:
    """The line after the block that starts at `head`: its lines are more indented (a list may sit at the key's own
    indentation); blank lines and a less indented line end it."""
    last = head
    for i in range(head + 1, len(lines)):
        stripped = lines[i].strip()
        if not stripped:
            continue
        depth = len(lines[i]) - len(lines[i].lstrip(" "))
        if depth > indent or (depth == indent and indent > 0 and stripped.startswith("- ")):
            last = i
            continue
        break
    return last + 1


