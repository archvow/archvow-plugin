"""A project's templates: its chain copied in, recorded, updated - and the questions a new version brings.

`init` copies the template's whole chain into `.archvow/templates/<name>/` and records each copy's version, source
and digest in project.vow (`templates`); `template update` takes them again from where they came from (or
`--from`). Clones, the Git hook and the CI read only the copies. A component type's question a component does not
have yet (a new version of its template, `template question project ...`) is added to every component of that
type, not answered: a built component shows it as drift (ARCH033) until someone answers it.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from archvow.foundation import logs
from archvow.foundation.errors import TemplateError
from archvow.templates import (
    Template,
    chain_of,
    edge_case_id,
    edge_case_text,
    load_template,
    open_decision,
    split_names,
)
from archvow.templating import copies, store

log = logs.get("spec.templates")


def sources_for(root: Path, given: list[str], data: dict[str, Any] | None = None) -> list[store.Source]:
    """Where the chain is looked for: what the person gives (a template folder counts with the templates next to it),
    where project.vow says the project's templates came from, archvow's, then the installed packages'."""
    found = [store.source_of(g, root)[0] for g in given]
    if data is not None:
        found += copies.recorded_sources(root, data, strict=not given)
    return store.default_sources(tuple(found))


def names_given(root: Path, refs: list[str]) -> tuple[list[str], list[str]]:
    """`-t` as given: names and template folders; (the names, the folders given as sources)."""
    names, folders = [], []
    for ref in refs:
        if store.is_template(Path(ref).expanduser()) or (store.is_template(root / ref) and "/" in ref):
            names.append(store.source_of(ref, root)[1] or "")
            folders.append(ref)
        else:
            names.append(ref)
    return names, folders


def copy_chain(root: Path, data: dict[str, Any], sources: list[store.Source]) -> list[tuple[str, str, str]]:
    """Copy the chain of every container's template into the project and record it; drop the copies no container
    uses any more. (name, version before - "" when new -, version now) for what changed."""
    found = store.find_in(sources)
    folders = {name: folder for name, (folder, _) in found.items()}
    wanted: list[str] = []
    for container in data.get("containers") or []:
        for name in chain_of(split_names(container["template"]), folders):
            if name not in wanted:
                wanted.append(name)
    before = copies.recorded(data)
    changed = []
    for name in wanted:
        folder, source = found[name]
        store.require_fit(store.meta(folder))
        copy = copies.copy_in(root, folder)
        copies.record(data, copy, copies.recorded_source(root, source))
        now = copies.recorded(data)[name]
        old = before.get(name) or {}
        if old.get("digest") != now["digest"]:
            changed.append((name, str(old.get("version") or ""), str(now["version"])))
    for name in sorted(set(copies.project_copies(root)) - set(wanted)):
        copies.drop_copy(root, name)
        changed.append((name, str((before.get(name) or {}).get("version") or "?"), ""))
    data["templates"] = {k: v for k, v in copies.recorded(data).items() if k in wanted}
    return changed


def update(root: Path, data: dict[str, Any], given: list[str]) -> dict[str, Any]:
    """`template update [--from <source>]`: the project's chain taken again from its sources; what changed, and the
    questions its components gained."""
    changed = copy_chain(root, data, sources_for(root, given, data))
    for container in data.get("containers") or []:
        load_template(container["template"], root)  # the new chain loads, or nothing more is done
    return {"changed": [{"template": n, "before": b or None, "now": a or None} for n, b, a in changed],
            "questions": add_new_questions(root, data)}


def add_new_questions(root: Path, data: dict[str, Any]) -> list[str]:
    """Every component gets the questions of its type it does not have yet (by id), not answered; a decision with no
    id takes the id of the question it answers (same text). The components that gained one, as `id: q1, q2`."""
    gained = []
    for container in data.get("containers") or []:
        template = load_template(container["template"], root)
        initial = {c.get("id"): c for c in template.data.get("initial_components") or []}
        for comp in container.get("components") or []:
            source = initial.get(comp.get("id")) or template.type_of(comp)
            decisions = comp.setdefault("decisions", [])
            label_ids(decisions, source.get("edge_cases") or [])
            have = {d.get("id") for d in decisions if d.get("id")}
            new = [q for q in source.get("edge_cases") or [] if edge_case_id(q) and edge_case_id(q) not in have]
            if new:
                decisions += [open_decision(q) for q in new]
                gained.append(f"{comp['id']}: {', '.join(edge_case_id(q) for q in new)}")
    return gained


def label_ids(decisions: list[dict[str, Any]], questions: list[Any]) -> None:
    """Decisions recorded before their questions had ids: each takes the id of the question with its text, else - in
    a component archvow 2 recorded, none of its decisions with an id yet - of the question at its place among the
    template's (they were added first, in the template's order). A decision a person added keeps no id."""
    texts = {edge_case_text(q): edge_case_id(q) for q in questions if edge_case_id(q)}
    used = {d.get("id") for d in decisions if d.get("id")}
    by_place = not used  # once labelled, a place says nothing: a question added since sits at a person's decision's
    for index, decision in enumerate(decisions):
        if decision.get("id"):
            continue
        ident = texts.get(str(decision.get("question") or ""))
        if ident is None and by_place and index < len(questions) and edge_case_id(questions[index]) not in used:
            ident = edge_case_id(questions[index])
        if ident and ident not in used:
            decision["id"] = ident
            used.add(ident)


def switch_problems(root: Path, data: dict[str, Any], new: str, given: tuple[Path, ...] = ()) -> list[str]:
    """`init --force -t <another template>`: what of the spec the new template has no place for (a component's type
    or layer)."""
    try:
        template = load_template(new, root, extra=given, from_sources=True)
    except TemplateError as error:
        return [str(error)]
    problems = []
    for container in data.get("containers") or []:
        for comp in container.get("components") or []:
            if comp.get("type") not in template.component_types:
                problems.append(f"{comp['id']}: type {comp.get('type')}")
            elif comp.get("layer") not in template.layer_names:
                problems.append(f"{comp['id']}: layer {comp.get('layer')}")
    return problems


def old_name(ref: str) -> str:
    """A template as archvow 2 recorded it (archvow/fastapi-service@2.8.0): its name (fastapi-service)."""
    return ref.split("@", 1)[0].rsplit("/", 1)[-1]


def label_decisions(data: dict[str, Any], template: Template) -> None:
    """Decisions recorded before their questions had ids get them (archvow 2 projects; new questions are added
    by `archvow template update`, never here)."""
    initial = {c.get("id"): c for c in template.data.get("initial_components") or []}
    for container in data.get("containers") or []:
        for comp in container.get("components") or []:
            source = initial.get(comp.get("id")) or template.type_of(comp)
            label_ids(comp.setdefault("decisions", []), source.get("edge_cases") or [])


def relocalize(data: dict[str, Any], root: Path, old_language: str, language: str) -> None:
    """Replace the texts the templates wrote into the manifest by the same texts in the new language.

    Each container by its own template: the questions of each component type, and the descriptions and
    questions of the starting components, are matched by position; anything a person wrote stays as it is.
    """
    templates = []
    for container in data.get("containers") or []:
        name = str(container["template"]).partition("@")[0]
        old, new = (load_template(name, root, language=lang) for lang in (old_language, language))
        templates.append((old, new))
        for comp in container.get("components") or []:
            before = old.type_of(comp)
            after = new.type_of(comp)
            pairs = list(zip(map(edge_case_text, before.get("edge_cases") or []),
                             map(edge_case_text, after.get("edge_cases") or []), strict=False))
            initial_old = next((c for c in old.data.get("initial_components", []) if c.get("id") == comp["id"]), None)
            initial_new = next((c for c in new.data.get("initial_components", []) if c.get("id") == comp["id"]), None)
            if initial_old and initial_new:
                pairs += list(zip(map(edge_case_text, initial_old.get("edge_cases") or []),
                                  map(edge_case_text, initial_new.get("edge_cases") or []), strict=False))
                if comp.get("description") == initial_old.get("description"):
                    comp["description"] = initial_new.get("description", comp["description"])
            mapping = dict(pairs)
            for decision in comp.get("decisions", []) or []:
                decision["question"] = mapping.get(decision.get("question"), decision.get("question"))
    for entry in data.get("type_answers") or []:  # answered once for a type: matched by its question, translated too
        kind = {"type": entry.get("type")}
        for old, new in templates:  # the first container whose template asks it
            mapping = dict(zip(map(edge_case_text, old.type_of(kind).get("edge_cases") or []),
                               map(edge_case_text, new.type_of(kind).get("edge_cases") or []), strict=False))
            if entry.get("question") in mapping:
                entry["question"] = mapping[entry["question"]]
                break
