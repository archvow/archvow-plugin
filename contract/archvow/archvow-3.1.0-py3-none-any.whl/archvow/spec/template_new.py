"""`archvow template new <name>`: a template folder - from scratch, or extending others - with its template.yaml
commented, its translations, a README and files/.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from archvow import __version__
from archvow.foundation.errors import TemplateError
from archvow.foundation.files import write_text
from archvow.templates import load_template
from archvow.templating import store
from archvow.templating.merge import check_layer_names


def new_template(name: str, parent: Path, extends: list[str], description: str, version: str = "1.0.0",
                 languages: tuple[str, ...] = ("en", "fr"), settings: dict[str, Any] | None = None,
                 sources: tuple[Path, ...] = ()) -> Path:
    """`template new <name>`: a template folder - template.yaml (commented), its translation, README.md, files/.
    From scratch without `extends`; else every base must be found (sources: `--from`, archvow's, packages')."""
    if not store.NAME_RE.match(name) or name == store.OWN_NAME:
        raise TemplateError(f"'{name}': a template's name is lowercase letters, digits and dashes (acme-pyspark), "
                            "not 'project'")
    if not store.VERSION_RE.match(version):
        raise TemplateError(f"--version {version}: MAJOR.MINOR.PATCH (1.0.0)")
    target = parent.expanduser().resolve() / name
    if target.exists():
        raise TemplateError(f"{target} already exists")
    base = None
    if extends:
        try:
            near = parent.expanduser().resolve()
            base = load_template(extends, None, extra=(*sources, *([near] if near.is_dir() else [])))
        except TemplateError as error:
            raise TemplateError(str(error), hint="archvow catalog lists the templates; a template of your own: "
                                "--from <the folder that holds it>") from error
    settings = settings or {}
    major, minor = (int(p) for p in __version__.split(".")[:2])
    languages = tuple(dict.fromkeys(("en", *languages)))
    text = (FROM_BASE if base is not None else FROM_SCRATCH).format(
        name=name, extends=_flow(extends) if len(extends) > 1 else (extends[0] if extends else ""),
        version=version, archvow=f'">={major}.{minor},<{major + 1}"', languages=_flow(list(languages)),
        description=_flow(description), bases=", ".join(extends))
    if settings.get("defaults"):
        text = text.replace(DEFAULTS_EXAMPLE, "questions_defaults:\n" + "".join(
            f"  {key}: {_flow(value)}\n" for key, value in settings["defaults"].items()))
    if settings.get("allowed_paths"):
        text = text.replace(ALLOWED_EXAMPLE, f"allowed_paths: {_flow(settings['allowed_paths'])}\n")
    if settings.get("verbatim_folders"):
        text = text.replace(VERBATIM_EXAMPLE, f"verbatim_folders: {_flow(settings['verbatim_folders'])}\n")
    if base is not None and base.layers:  # every layer with its folder: the base's, unless renamed here
        current = base.data.get("layer_names") or {}
        layers = {layer["name"]: current.get(layer["name"], layer["name"]) for layer in base.layers}
        check_layer_names(name, list(layers), settings.get("layer_names") or {})
        layers |= settings.get("layer_names") or {}
        text = text.replace(LAYERS_EXAMPLE, "layer_names:\n" + "".join(
            f"  {layer}: {where}\n" for layer, where in layers.items()))
    (target / "files").mkdir(parents=True)
    write_text(target / store.MANIFEST, text)
    for language in languages:
        if language != "en":  # its texts in the template's other languages (what the bases say is already)
            write_text(target / f"template.{language}.yaml",
                       f"# The texts of {name} in '{language}': only what template.yaml adds or changes (description,\n"
                       f"# questions by id, component types, layers...); what it inherits is already translated.\n"
                       f"# Files in '{language}' go in files-{language}/.\n")
    write_text(target / "README.md", README.format(name=name, description=description, parent=parent))
    store.meta(target)  # what was written reads back
    return target


def _flow(value: object) -> str:
    """A value as one line of YAML (a list in brackets, a string quoted only when it must be)."""
    dumped: str = yaml.safe_dump(value, default_flow_style=True, allow_unicode=True, width=10_000)
    return dumped.strip().removesuffix("\n...").strip()


README = """# Template {name}

{description}

A template of archvow (docs/templates.md): `template.yaml` (+ `template.<lang>.yaml` for its texts in another
language), the project's files in `files/` (+ `files-<lang>/`), and its parts: declarative rules in `rules/`, agent
profiles in `agents/`, privacy regimes in `regimes/` - data only, never Python.

    archvow template rule {name} ACME001 --kind forbid_import ...     a rule, proved by its bad and good examples
    archvow template question {name} <type> <id> --text "...?"        a question of a component type
    archvow template agent {name} <agent> ...                         an agent profile
    archvow template check {name}                                     every part, every language, a project from it
    archvow init <package> -t {parent}/{name}                         a project from it (its chain is copied in)

A project takes a new version deliberately: `archvow template update`, reviewed in its merge request.
"""

DEFAULTS_EXAMPLE = """\
# questions_defaults:
#   ci: jenkins
#   sonar: "yes"
"""
ALLOWED_EXAMPLE = "# allowed_paths: [devops, tools]\n"
VERBATIM_EXAMPLE = "# verbatim_folders: [templates]\n"
LAYERS_EXAMPLE = "# layer_names: {p1_domain: domain}\n"

COMMON = """\
name: {name}
version: {version}
archvow: {archvow}               # the archvow versions it works with
languages: {languages}
description: {description}
"""

FROM_BASE = """\
# Template '{name}'. Everything not declared here is inherited from {bases}.
# One merge rule: mappings merge key by key, lists add to the base's, and a list item with an `id` (a question)
# or a `name` (a layer) replaces the base's item of the same id. Nothing is removed unless you say so:
#   remove: [component_types.cli, component_types.model.edge_cases.shape, rule_sets.fastapi]
# Files: put them in ./files/ - rendered with Jinja2 when they end in .j2, copied as they are otherwise (or when
# their folder is in `verbatim_folders`). Files in another language go in ./files-<lang>/.
""" + COMMON + """extends: {extends}

# Your defaults for the init answers (a project can still override them with -a).
""" + DEFAULTS_EXAMPLE.replace("{", "{{").replace("}", "}}") + """
# Top folders of Python files that are not components (no ARCH015), added to the base's.
""" + ALLOWED_EXAMPLE + """
# Folders of ./files/ copied exactly as they are, even their .j2 files (another tool renders them).
""" + VERBATIM_EXAMPLE + """
# The folder of each layer (src/<package>/<folder>/, tests/<folder>/): change the right-hand side to rename one;
# archvow uses it everywhere (layers, component types, the files it writes).
""" + LAYERS_EXAMPLE.replace("{", "{{").replace("}", "}}") + """
# Example: a new component type, with its questions (each with an id: a template below may reword it).
# component_types:
#   stream_reader:
#     layer: p2_io
#     description: Structured Streaming source.
#     module: "{{name}}_stream_reader"
#     name_pattern: "^[a-z][a-z0-9_]*$"
#     symbols:
#       - {{kind: function, name: "read_{{name}}_stream", signature: "(spark: SparkSession, source: str) -> DataFrame"}}
#     guide_words: [missing, wrong]
#     edge_cases:
#       - {{id: unavailable, question: "The source is unavailable: fail or wait (e.g. wait 10 min, then fail)?"}}
#       - {{id: no_event_time, question: "A record has no event time: drop it or fail (e.g. drop and count it)?",
#          suggested: "fail with the record's key in the error"}}

# Example: a question of an inherited type, reworded for this stack (the same id).
# component_types:
#   utility:
#     edge_cases:
#       - {{id: contract, question: "What exactly does it take and return - e.g. to_cents(Decimal(\\"9.9\\")) -> 990?"}}

# Example: tune a rule for every project using this template.
# rules:
#   STY001: {{severity: error, max_lines: 200}}
"""

FROM_SCRATCH = """\
# Template '{name}', written from scratch: it inherits nothing (docs/templates.md lists every key).
# The least a template holds: its layers and its component types, each question with an id.
""" + COMMON + """
# kind: web-service            what it builds, and its style, shown by archvow catalog
# style: layered

layers:                        # src/<package>/<layer>/; each layer lists the layers it may import
  - name: p0_common
    description: Shared foundations - settings, logging
    may_import: []
  - name: p1_domain
    description: Business rules - pure functions, no I/O
    may_import: [p0_common]

component_types:
  logic:
    layer: p1_domain
    description: A business rule as a pure function.
    module: "{{name}}"
    name_pattern: "^[a-z][a-z0-9_]*$"
    symbols:
      - {{kind: function, name: "{{name}}"}}
    edge_cases:
      - {{id: contract, question: "What exactly does it take and return - e.g. vat(100) -> 20?"}}

# The project's files go in ./files/ (rendered with Jinja2 when they end in .j2): AGENTS.md.j2, README.md.j2,
# pyproject.toml.j2... A template that extends python-base gets them all; from scratch, write the ones you need.
""" + DEFAULTS_EXAMPLE.replace("{", "{{").replace("}", "}}") + ALLOWED_EXAMPLE + VERBATIM_EXAMPLE + \
    LAYERS_EXAMPLE.replace("{", "{{").replace("}", "}}")
