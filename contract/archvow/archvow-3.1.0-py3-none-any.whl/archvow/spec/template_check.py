"""`archvow template check <folder>`: the architect's test of a template before sharing it.

It reads the template as archvow will - with its whole chain, found next to it, in archvow's templates or in the
installed packages - in each of its languages: every layer it names declared, every question with an id, each
agent profile, each regime, each rule of the chain proved (it catches its bad example and passes its good one, in
the places of this template), no final rule written again; then it creates a throwaway project from it in each
language (every file renders, every answer rule holds). Nothing is written in the template.
"""

from __future__ import annotations

import tempfile
from pathlib import Path

import yaml

from archvow import agents
from archvow.checks.catalogue import all_rules, override_problem
from archvow.foundation import logs
from archvow.foundation.errors import ArchvowError, TemplateError
from archvow.spec.answers import question_default
from archvow.spec.init import init_project
from archvow.spec.template_parts import example_problem, proved_scope, scope_problem
from archvow.templates import Template, load_template
from archvow.templating import regimes, store
from archvow.templating import rules as pack_rules
from archvow.templating.store import doctor_problem

log = logs.get("spec.template_check")
SAMPLE_ANSWERS = {"architects": "@template-check/architects"}  # a required answer a throwaway project needs


def check_template(folder: Path) -> tuple[store.Meta | None, list[str], list[str]]:
    """(the template, what is wrong, what was proved)."""
    problems: list[str] = []
    proved: list[str] = []
    try:
        found = store.meta(folder)
        store.require_fit(found)
    except TemplateError as error:
        return None, [str(error)], proved
    chain = f", extends {', '.join(found.extends)}" if found.extends else ", from scratch"
    proved.append(f"template.yaml: {found.name} {found.version}, archvow {found.archvow or 'any'}, languages "
                  f"{', '.join(found.languages)}{chain}")
    loaded = None
    for language in found.languages:
        template = _check_language(folder, found, language, problems, proved)
        loaded = loaded or template
    if loaded is None:
        return found, problems, proved
    _check_rules(folder, found, loaded, problems, proved)
    for path in sorted((folder / "agents").glob("*/agent.yaml")):
        try:
            agents.read(path.parent, found.name)
            proved.append(f"agent {path.parent.name}: profile read")
        except TemplateError as error:
            problems.append(str(error))
    _check_regimes(folder, found, loaded, problems, proved)
    return found, problems, proved


def _check_language(folder: Path, found: store.Meta, language: str, problems: list[str],
                    proved: list[str]) -> Template | None:
    name = found.name
    if language != "en" and not (folder / f"template.{language}.yaml").is_file():
        problems.append(f"template {name}: no template.{language}.yaml (its texts in {language})")
    english = {p.relative_to(folder / "files").as_posix() for p in (folder / "files").rglob("*")
               if p.is_file()} if (folder / "files").is_dir() else set()
    if language != "en" and english:
        local = folder / f"files-{language}"
        have = {p.relative_to(local).as_posix() for p in local.rglob("*") if p.is_file()} if local.is_dir() else set()
        texts = sorted(r for r in english - have if r.endswith((".md", ".md.j2")))
        if texts:
            problems.append(f"template {name}: files-{language}/ lacks {', '.join(texts[:5])}"
                            + (" ..." if len(texts) > 5 else ""))
    try:
        template = load_template(name, None, language=language, extra=(folder,))
    except ArchvowError as error:
        problems.append(f"template {name} ({language}): {error}")
        return None
    if language == found.languages[0]:
        proved.append(f"chain: {' -> '.join(template.chain)}: merged, every layer it names declared, every "
                      "question with an id")
        known = all_rules([template])
        for problem in filter(None, (override_problem(code, value, known) for code, value in
                                     (template.rules or {}).items())):
            problems.append(f"template {name}: rules: {problem}")  # applied as the project's are, refused as they are
        for item in template.data.get("doctor") or []:
            if doctor_problem(item) and "{{" not in str(item.get("command", "")) + str(item.get("module", "")):
                problems.append(f"template {name}: doctor entry '{item.get('name', '?')}': {doctor_problem(item)}")
    if template.data.get("abstract"):
        proved.append(f"template {name} ({language}): read (a base others extend)")
        return template
    asked = {q.get("id") for q in template.data.get("questions", [])}
    answers = {key: value for key, value in SAMPLE_ANSWERS.items() if key in asked}  # a template from scratch asks none
    for question in template.data.get("questions", []):
        if question.get("required") and question["id"] not in answers and \
                question_default(template, question, answers) in (None, ""):
            problems.append(f"template {name}: required answer '{question['id']}' has no default - "
                            "template check cannot try it; give it a default or an example")
            return template
    if any(q.get("id") == "language" for q in template.data.get("questions", [])):
        answers["language"] = language
    with tempfile.TemporaryDirectory() as tmp:
        target = Path(tmp) / "project"
        target.mkdir()
        try:
            written = init_project(target, str(folder), "template_check", None, answers)
        except ArchvowError as error:
            problems.append(f"template {name} ({language}): a project from it fails: {error}")
            return template
    proved.append(f"template {name} ({language}): a project from it writes {len(written)} files")
    return template


def _check_rules(folder: Path, found: store.Meta, template: Template, problems: list[str], proved: list[str]) -> None:
    """Each rule of the chain proved in this template's places; its own rules in every language it has."""
    where = {"in_layers": {str(layer.get("name")) for layer in template.layers},
             "in_types": set(template.component_types)}
    problems += pack_rules.weakened_final(template.dirs)
    for directory in template.dirs:
        for path in sorted((directory / "rules").glob("*.yaml")):
            try:
                rules = pack_rules.read_file(path)
            except TemplateError as error:
                problems.append(str(error))
                continue
            for code, rule in rules.items():
                verdict = example_problem(code, rule) or scope_problem(code, rule, where)
                own = directory == folder.resolve() or directory == folder
                missing = [lang for lang in found.languages if lang != "en" and not rule.get(f"message_{lang}")]
                if verdict:
                    problems.append(verdict if own else f"{verdict} (a rule of {directory.name})")
                elif own and missing:
                    problems.append(f"{code}: no message in {', '.join(missing)} (message_{missing[0]})")
                elif own:
                    scope = proved_scope(rule) if where["in_layers"] or where["in_types"] else ""
                    final = "; final" if rule.get("final") else ""
                    proved.append(f"rule {code}: catches its bad example, passes its good one"
                                  + (f"; {scope}" if scope else "") + final)


def _check_regimes(folder: Path, found: store.Meta, template: Template, problems: list[str], proved: list[str]) -> None:
    """Each regime of the template: its file as archvow reads it, a letter and a prefix no other regime of its chain
    nor of archvow's templates has (a building block is used beside them), every text in each of the template's
    languages."""
    shipped = tuple(p for p in sorted(store.shipped_folder().iterdir()) if store.is_template(p))
    others = {r.id: r for r in regimes.of_folders((*shipped, *(d for d in template.dirs
                                                                 if d.resolve() != folder.resolve()))).values()}
    for path in sorted((folder / "regimes").glob("*.yaml")):
        try:
            regime = regimes.read_file(path, template=found.name)
        except TemplateError as error:
            problems.append(str(error))
            continue
        clash = next((r for r in others.values() if r.id != regime.id and (r.letter == regime.letter
                                                                           or r.prefix == regime.prefix)), None)
        if clash:
            problems.append(f"regime {regime.id}: letter {regime.letter} or prefix {regime.prefix} is already regime "
                            f"{clash.id}'s ({clash.template}: letter {clash.letter}, prefix {clash.prefix})")
            continue
        raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        texts = [("title", raw), *[("title", r) for r in (raw.get("rules") or {}).values()],
                 *[("text", q) for items in (raw.get("questions") or {}).values() for q in items or []],
                 *[(k, raw.get("register") or {}) for k in ("title", "intro", "answers")]]
        missing = {lang: sum(1 for key, part in texts if part.get(key) and not part.get(f"{key}_{lang}"))
                   for lang in found.languages if lang != "en"}
        lacking = next((lang for lang, count in missing.items() if count), None)
        if lacking:
            problems.append(f"regime {regime.id}: {missing[lacking]} text(s) without their {lacking} version "
                            f"(title_{lacking}...)")
            continue
        asked = sum(len(q) for q in regime.questions.values())
        proved.append(f"regime {regime.id}: {regime.name}, {asked} question(s) {regime.letter}1..., "
                      f"{len(regime.rules)} rule(s), register {regime.register['file']}")
