"""Declarative rules: a template's `rules/<FAMILY>.yaml`, one entry per code (the family is the code's letters).

    ACME001:
      kind: forbid_import          one of KINDS
      target: [legacy_billing]     what the kind looks for (module prefixes, calls, a pattern, files, a keyword...)
      in_types: [writer]           optional: only in files of these component types
      in_layers: [p2_io]           optional: only in these layers
      severity: error              error (default) or warning
      message: No direct use of the old billing API      message_fr: ...   (the finding, per language)
      fix: use acme_billing.client instead                fix_fr: ...
      why: the old API bypasses the audit log             why_fr: ...
      error: legacy_billing.AuditError                    optional: the error people saw (2.7.0) -
                                                          `archvow show "<pasted error>"` finds the rule by it
      bad: "import legacy_billing"                        an example it must catch (a file path for forbid_file)
      good: "import acme_billing.client"                  an example it must pass
      final: true                                         optional: no template below and no project may make
                                                          it weaker (warning, off)

The rules of a template apply to it and to every template that extends it (a project's own rules, in
.archvow/template/rules/, to that project only).
No Python runs: the kinds are matched by archvow (custom.py).
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

import yaml

from archvow.foundation import once
from archvow.foundation.errors import TemplateError
from archvow.foundation.files import parse_yaml
from archvow.templating import patterns, regimes, store
from archvow.templating.regimes import OWN_PREFIXES

KINDS = {
    "forbid_import": "a module the code must not import (prefixes: legacy_billing covers legacy_billing.client)",
    "forbid_call": "a function or method the code must not call (time.sleep, *.toPandas)",
    "forbid_pattern": "a text the code must not contain (a regular expression: s3://acme-prod)",
    "forbid_file": "files the repository must not hold (globs: **/*.ipynb)",
    "only_in": "a module imported only in the given component types or layers (requests only in clients)",
    "require_keyword": "a text every file of the given types or layers must contain (a regular expression)",
    "require_question": "a question every component of the given types must answer (asked as C1, C2...)",
}
CODE_RE = re.compile(r"^([A-Z]{2,8})(\d{3})$")
# a rule's `error` is found in a pasted error by its text (views/errors.py): shorter would match anything
ERROR_MIN = 6


def reserved() -> tuple[str, ...]:
    """The families a template's rule may not use: archvow's own code families and the prefixes of the regimes it
    ships (GDPR, USP, GLBA, DORA). Read when a rule is checked, not when archvow starts: every command imports
    this module."""
    return once.remember(("reserved families",), lambda: (*OWN_PREFIXES, *(
        r.prefix for r in regimes.of_folders(tuple(p for p in sorted(store.shipped_folder().iterdir())
                                                   if store.is_template(p))).values())))


def family(code: str) -> str:
    match = CODE_RE.match(code)
    return match.group(1) if match else ""


def read_file(path: Path) -> dict[str, dict[str, Any]]:
    """The rules of one family file, checked: code -> rule."""
    try:
        raw = parse_yaml(path.read_text(encoding="utf-8")) or {}
    except (OSError, yaml.YAMLError) as error:
        raise TemplateError(f"{path}: cannot be read ({error})") from error
    if not isinstance(raw, dict):
        raise TemplateError(f"{path}: expected a mapping, one entry per rule code (ACME001: ...)")
    rules = {}
    for code, rule in raw.items():
        code = str(code)
        problem = problem_of(code, rule, path.stem)
        if problem:
            raise TemplateError(f"{path}: {code}: {problem}")
        rules[code] = dict(rule)
    return rules


def problem_of(code: str, rule: object, family_name: str | None = None) -> str:
    """What is wrong with a rule's declaration ('' when nothing)."""
    if not CODE_RE.match(code):
        return "a code is 2 to 8 capital letters and 3 digits (ACME001)"
    if family(code) in reserved():
        return f"{family(code)} is one of archvow's own families: choose your company's letters"
    if family_name is not None and family(code) != family_name:
        return f"belongs in rules/{family(code)}.yaml, not rules/{family_name}.yaml"
    if not isinstance(rule, dict):
        return "expected a mapping (kind, target, message...)"
    if rule.get("kind") not in KINDS:
        return f"kind must be one of {', '.join(KINDS)}"
    if not rule.get("target"):
        return "give its target (what the kind looks for)"
    if rule["kind"] in ("forbid_pattern", "require_keyword"):  # compiled here, not when a check meets it
        if isinstance(rule["target"], list) and len(rule["target"]) > 1:
            return f"{rule['kind']} takes one regular expression: join the alternatives with | (a|b)"
        for pattern in rule["target"] if isinstance(rule["target"], list) else [rule["target"]]:
            try:
                re.compile(str(pattern))
            except re.error as error:
                return f"target {str(pattern)!r} is not a valid regular expression ({error})"
            if patterns.problem(str(pattern)):
                return patterns.problem(str(pattern))
    if not str(rule.get("message") or "").strip():
        return "give its message (what the finding says)"
    if str(rule.get("severity", "error")) not in ("error", "warning"):
        return "severity is error or warning"
    if not isinstance(rule.get("final", False), bool):
        return "final is true or false (true: no template below and no project may make it weaker)"
    if "error" in rule and len(str(rule.get("error") or "").strip()) < ERROR_MIN:
        return f"error is the text people saw when it went wrong, at least {ERROR_MIN} characters (Java heap space)"
    if rule["kind"] in ("only_in", "require_keyword", "require_question") and not (
            rule.get("in_types") or rule.get("in_layers")):
        return f"{rule['kind']} needs in_types or in_layers (where it applies)"
    if rule["kind"] == "require_question" and not rule.get("in_types"):
        return "require_question needs in_types (the component types that answer it)"
    if rule["kind"] != "require_question" and (rule.get("bad") is None or rule.get("good") is None):
        return "give a bad example (it must be caught) and a good one (it must pass)"
    return ""


def folder_rules(folder: Path) -> dict[str, dict[str, Any]]:
    """Every rule of one template folder: code -> rule."""
    found: dict[str, dict[str, Any]] = {}
    for path in sorted((folder / "rules").glob("*.yaml")):
        found |= read_file(path)
    return found


def template_rules(template: object) -> dict[str, dict[str, Any]]:
    """The rules a template brings: those of every template of its chain (and of the project's own additions), in
    the template's language (message_<lang>, fix_<lang>, why_<lang> when given). A rule file that cannot be read is
    left out here; `check` reports it (ARCH009). Read once per command that only reads (check asks for every
    component's question sets)."""
    language = str(getattr(template, "language", "en"))
    dirs = tuple(str(folder) for folder in getattr(template, "dirs", []))
    return once.remember(("template rules", dirs, language), lambda: _template_rules(dirs, language))


def _template_rules(dirs: tuple[str, ...], language: str) -> dict[str, dict[str, Any]]:
    found: dict[str, dict[str, Any]] = {}
    for folder in dirs:
        try:
            rules = folder_rules(Path(folder))
        except TemplateError:
            continue
        for code, rule in rules.items():
            if (found.get(code) or {}).get("final"):
                continue  # a final rule stays as its template wrote it (template check reports the attempt)
            found[code] = localized(rule, language)
    return found


def weakened_final(dirs: list[Path]) -> list[str]:
    """The final rules a later template of the chain writes again: what `template check` refuses."""
    final: dict[str, str] = {}
    problems = []
    for folder in dirs:
        try:
            rules = folder_rules(folder)
        except TemplateError:
            continue
        for code, rule in rules.items():
            if code in final:
                problems.append(f"{code} is final in template {final[code]}: {folder.name} cannot write it again")
            elif rule.get("final"):
                final[code] = folder.name
    return problems


def localized(rule: dict[str, Any], language: str) -> dict[str, Any]:
    """The rule's texts in a language, and the shape the matchers read (custom.py)."""
    texts = {k: str(rule.get(f"{k}_{language}") or rule.get(k) or "") for k in ("message", "fix", "why")}
    target = rule["target"]
    return {**rule, "title": texts["message"], "fix": texts["fix"], "why": texts["why"],
            "severity": str(rule.get("severity", "error")),
            "targets": [str(t) for t in target] if isinstance(target, list) else [str(target)],
            "types": [str(t) for t in rule.get("in_types") or []],
            "layers": [str(t) for t in rule.get("in_layers") or []]}
