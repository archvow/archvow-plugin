"""Where each part of a merged template comes from: `archvow catalog <template> --all`."""

from __future__ import annotations

from typing import Any

from archvow.foundation.errors import TemplateError
from archvow.templates import Template, edge_case_id, edge_case_text, read_raw_texts
from archvow.templating import rules as declarative


def origins(template: Template) -> dict[str, Any]:
    """Everything the merged template asks and checks, each with the template of its chain it comes from (the last
    one that writes it): `catalog <template> --all`."""
    raws = [(name, read_raw_texts(folder, template.language)) for name, folder in zip(template.chain, template.dirs,
                                                                                    strict=False)]

    def last(test: Any) -> str:
        return next((name for name, raw in reversed(raws) if test(raw)), "?")

    def asks(raw: dict[str, Any], type_name: str, ident: str) -> bool:
        ctype = (raw.get("component_types") or {}).get(type_name) or {}
        return any(edge_case_id(q) == ident for q in ctype.get("edge_cases") or [])

    types = {}
    for type_name, ctype in template.component_types.items():
        types[type_name] = {
            "layer": ctype.get("layer"), "from": last(lambda r, t=type_name: t in (r.get("component_types") or {})),
            "questions": [{"id": ident, "question": edge_case_text(q),
                           "from": last(lambda r, t=type_name, i=ident: asks(r, t, i))}
                          for q in ctype.get("edge_cases") or [] for ident in [edge_case_id(q)]]}
    rules: list[dict[str, Any]] = []
    for name, folder in zip(template.chain, template.dirs, strict=False):
        try:
            found = declarative.folder_rules(folder)
        except TemplateError:
            continue
        for code, rule in found.items():
            rules = [r for r in rules if r["code"] != code] + [{
                "code": code, "kind": rule.get("kind"), "severity": rule.get("severity", "error"),
                "message": rule.get(f"message_{template.language}") or rule.get("message"),
                "final": bool(rule.get("final")), "from": name}]
    return {
        "chain": list(template.chain),
        "layers": [{"name": layer["name"], "may_import": layer.get("may_import") or [],
                    "from": last(lambda r, n=layer["name"]: any(isinstance(x, dict) and x.get("name") == n
                                                               for x in r.get("layers") or []))}
                   for layer in template.layers],
        "questions": [{"id": ident, "from": last(lambda r, i=ident: any(
            isinstance(x, dict) and x.get("id") == i for x in r.get("questions") or []))}
                      for q in template.data.get("questions") or [] for ident in [q.get("id")]],
        "component_types": types,
        "guide_words": [{"word": word, "question": text,
                         "from": last(lambda r, w=word: w in (r.get("guide_words") or {}))}
                        for word, text in (template.data.get("guide_words") or {}).items()],
        "rule_sets": [{"name": str(name), "from": last(lambda r, n=name: n in (r.get("rule_sets") or {}))}
                      for name in (template.data.get("rule_sets") or {})],
        "rules": rules,
        "regimes": [{"name": r.name, "from": r.template} for r in template.regimes],
    }
