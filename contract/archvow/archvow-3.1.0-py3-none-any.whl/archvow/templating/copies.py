"""A project's copies of its templates: `.archvow/templates/<name>/`, recorded in project.vow (`templates`: version,
source, digest), and its own additions (`.archvow/template/`). Clones, the Git hook and the CI read only what the
repository holds - no environment variable, no install, no network; a copy changed by hand is ARCH060.
"""

from __future__ import annotations

import os
import shutil
from pathlib import Path
from typing import Any

from archvow.foundation import logs
from archvow.foundation.errors import LockError, TemplateError, VowError
from archvow.foundation.files import spec_lock
from archvow.foundation.hashing import parts_digest
from archvow.foundation.paths import PROJECT_REL
from archvow.model import vowfile
from archvow.templating.store import (
    MANIFEST,
    OWN,
    PROJECT_TEMPLATES,
    SHIPPED,
    SKIPPED,
    Source,
    is_template,
    kept,
    meta,
    package_folder,
    require_fit,
)

log = logs.get("templating")


def project_copies(root: Path | None) -> dict[str, Path]:
    """name -> its copy in .archvow/templates/ (a copy being written, .<name>.new, is not one)."""
    if root is None:
        return {}
    recover(root)
    return {p.parent.name: p.parent for p in sorted((root / PROJECT_TEMPLATES).glob(f"[!.]*/{MANIFEST}"))}


def own_folder(root: Path | None) -> Path | None:
    """The project's own additions (.archvow/template/), when it has some."""
    if root is None:
        return None
    folder = root / OWN
    return folder if folder.is_dir() and any(folder.iterdir()) else None


def project_folders(root: Path | None) -> list[Path]:
    """Every template folder of the project: its copies, then its own additions."""
    own = own_folder(root)
    return [*project_copies(root).values(), *([own] if own is not None else [])]


def has_copies(root: Path | None) -> bool:
    return root is not None and (root / PROJECT_TEMPLATES).is_dir()


def digest(folder: Path) -> str:
    """What a copy holds: every file's path and content (12 characters, as the other digests archvow stores)."""
    files = sorted(p for p in folder.rglob("*") if p.is_file() and kept(p, folder))
    return parts_digest((p.relative_to(folder).as_posix(), p.read_bytes()) for p in files)


def recover(root: Path) -> None:
    """A copy stopped between its two renames (`copy_chain`) left `.<name>.old` and no `<name>/`: the old copy - what
    project.vow records - is put back, and the new one dropped. Under the write lock; skipped while another archvow
    holds it (its copy may be under way)."""
    folder = root / PROJECT_TEMPLATES
    if not any(old.is_dir() and not (folder / old.name[1:-4]).exists() for old in folder.glob(".*.old")):
        return
    try:
        with spec_lock(root, wait=0):
            for old in sorted(folder.glob(".*.old")):
                target = folder / old.name[1:-4]
                if old.is_dir() and not target.exists():
                    old.rename(target)
                    shutil.rmtree(folder / f".{target.name}.new", ignore_errors=True)
                    log.info("template %s: a copy stopped half-way, the old copy put back", target.name)
    except LockError:
        logs.swallowed(log, "recover: LockError")


def _refuse_links(source: Path) -> None:
    for path in sorted(source.rglob("*")):  # copytree would copy what a link points to into the repository
        if path.is_symlink() and kept(path, source):
            raise TemplateError(f"{path}: a symbolic link - a template holds its own files only (archvow commits "
                                "the copy with the spec); replace the link with the file it means")


def copy_in(root: Path, source: Path) -> Path:
    """Copy one template into the project (replacing an earlier copy); the copy's folder."""
    found = meta(source)
    require_fit(found)
    target = root / PROJECT_TEMPLATES / found.name
    if source.resolve() == target.resolve():
        return target
    _refuse_links(source)
    new, old = target.with_name(f".{found.name}.new"), target.with_name(f".{found.name}.old")  # never a name
    recover(root)
    for leftover in (new, old):
        shutil.rmtree(leftover, ignore_errors=True)
    new.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(source, new, ignore=shutil.ignore_patterns(*SKIPPED, "*.pyc"))  # stopped here: the old stays
    with spec_lock(root):  # stopped between the renames: `recover` puts the old copy back
        if target.exists():
            target.rename(old)
        new.rename(target)
    shutil.rmtree(old, ignore_errors=True)
    return target


def drop_copy(root: Path, name: str) -> None:
    shutil.rmtree(root / PROJECT_TEMPLATES / name, ignore_errors=True)


def recorded(data: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """The templates project.vow records: name -> {version, source, digest}."""
    found = data.get("templates") or {}
    return {str(k): dict(v or {}) for k, v in found.items()} if isinstance(found, dict) else {}


def recorded_names(root: Path | None) -> set[str] | None:
    """The templates project.vow records, read from it alone (no spec load: the agent gate asks before anything
    else); None before init. An unreadable project.vow records nothing."""
    vow = root / PROJECT_REL if root is not None else None
    if vow is None or not vow.is_file():
        return None
    try:
        return set(recorded(vowfile.loads(vow.read_text(encoding="utf-8"), PROJECT_REL.as_posix())[2]))
    except (OSError, VowError):
        logs.swallowed(log, "recorded_names: OSError, VowError")
        return set()


def record(data: dict[str, Any], folder: Path, source: str) -> None:
    """A copy's version, source and digest, into the project's data (project.vow `templates`)."""
    found = recorded(data)
    copy = meta(folder)
    found[copy.name] = {"version": copy.version, "source": source, "digest": digest(folder)}
    data["templates"] = dict(sorted(found.items()))


def recorded_source(root: Path, source: Source) -> str:
    """How project.vow names where a template comes from: archvow and a package by name; a folder of templates by
    its path from the project's root - `templates` inside it, `../company/templates` beside it - the same on every
    clone laid out alike, never a person's home path. Only a folder on another drive (Windows) keeps its absolute
    path."""
    given = Path(source.name).expanduser()
    if source.name == SHIPPED or not given.exists():
        return source.name
    given = given.parent if is_template(given) else given
    try:
        # the path as given first (a link the person went through stays in it), when it leads from the root to the
        # same folder; else the real one
        for rel in (os.path.relpath(os.path.abspath(given), os.path.abspath(root)),
                    os.path.relpath(source.folder, root.resolve())):
            if (root / rel).resolve() == source.folder:
                return Path(rel).as_posix()
        return Path(os.path.relpath(source.folder, root.resolve())).as_posix()
    except ValueError:  # another drive: no path from the root leads there
        return str(source.folder)


def recorded_sources(root: Path, data: dict[str, Any], strict: bool = True) -> list[Source]:
    """Where the project's templates came from, as project.vow records them (a missing folder is refused: never
    the same path read from wherever archvow runs; skipped when not `strict`: `--from` names another place)."""
    found: list[Source] = []
    for name, entry in recorded(data).items():
        given = str(entry.get("source") or "")
        if not given or given == SHIPPED:
            continue
        if "/" in given or "\\" in given or given.startswith(".") or Path(given).is_absolute():
            folder = root / given if not Path(given).is_absolute() else Path(given)
            if not folder.is_dir() and not strict:
                continue
            if not folder.is_dir():
                raise TemplateError(f"template {name} comes from {given} (from the project's root: "
                                    f"{os.path.normpath(folder)}), which does not exist",
                                    hint="lay the folders out as project.vow records them, or archvow template "
                                    "update --from <folder or package>")
            found.append(Source(given, folder.resolve()))
        else:
            found.append(Source(given, package_folder(given)))
    return found


def changed_by_hand(root: Path, data: dict[str, Any]) -> list[tuple[str, str]]:
    """The copies that differ from what init / `template update` recorded: (name, why)."""
    found = []
    copies = project_copies(root)
    for name, entry in recorded(data).items():
        if name not in copies:
            found.append((name, f"recorded in project.vow, but its copy {PROJECT_TEMPLATES.as_posix()}/{name}/ is "
                          "missing"))
        elif digest(copies[name]) != entry.get("digest"):
            found.append((name, "its copy differs from what init / `archvow template update` wrote"))
    for name in sorted(set(copies) - set(recorded(data))):
        found.append((name, f"copied into {PROJECT_TEMPLATES.as_posix()}/ but not recorded in project.vow"))
    return found
