"""Templates found, read, copied into a project and recorded.

A template is a folder holding `template.yaml` and any of `files/` (+ `files-<lang>/`), `rules/<FAMILY>.yaml`,
`agents/<agent>/agent.yaml` and `regimes/<id>.yaml` - data only, never Python. Its `template.yaml` names it and
gives its `version`, the archvow versions it works with (`archvow: ">=3.0,<4"`), its `languages` and the templates
it `extends`.

Where a name is found (init, `template check`, `template update`): the folders given (a template folder counts
with the templates next to it), then the templates archvow ships, then the installed pip packages that name a
folder of templates in the entry point group `archvow.templates` (read from their metadata, never imported). Two
places with the same name are refused.

A project keeps a copy of every template of its chain in `.archvow/templates/<name>/`, recorded in project.vow
(`templates`: version, source, digest): clones, the Git hook and the CI read only what the repository holds - no
environment variable, no install, no network. Its own additions (`archvow template rule|question|agent project`)
live in `.archvow/template/`, a guard like project.vow.
"""

from __future__ import annotations

import importlib.metadata
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from archvow import __version__
from archvow.foundation import logs, once
from archvow.foundation.errors import TemplateError
from archvow.foundation.files import parse_yaml
from archvow.foundation.paths import ARCHVOW_DIR

log = logs.get("templating")

PROJECT_TEMPLATES = ARCHVOW_DIR / "templates"  # the copies of the project's chain
OWN = ARCHVOW_DIR / "template"                 # the project's own additions, applied last
OWN_NAME = "project"                           # how commands and messages name it
SHIPPED = "archvow"                            # the source of the templates archvow ships
ENTRY_POINTS = "archvow.templates"             # a pip package names its folder of templates here
NAME_RE = re.compile(r"^[a-z][a-z0-9]*(-[a-z0-9]+)*$")
VERSION_RE = re.compile(r"^\d+\.\d+\.\d+$")
SKIPPED = {"__pycache__", ".git", ".DS_Store"}
MANIFEST = "template.yaml"

VERSION_FLAGS = ("--version", "-version", "-V", "version")
PROGRAM_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._+-]*$")  # a program on PATH, never a path
MODULE_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def doctor_problem(item: dict[str, Any]) -> str:
    """Why a template's `doctor:` entry is refused, or "": a command is `<program> <version flag>` (a template never
    runs code: doctor only asks a tool its version), a module a top-level name (find_spec of a.b imports a)."""
    if "command" in item:
        words = str(item["command"]).split()
        if len(words) != 2 or not PROGRAM_RE.match(words[0]) or words[1] not in VERSION_FLAGS:
            return (f"doctor runs a version probe only (`<program> {' | '.join(VERSION_FLAGS)}`), not "
                    f"`{item['command']}`")
    if "module" in item and not MODULE_RE.match(str(item["module"])):
        return f"doctor checks a top-level Python package (`fastapi`), not `{item['module']}`"
    return ""


def kept(path: Path, base: Path) -> bool:
    """Whether a file of a template counts: the digest and every loader skip the same SKIPPED folders and files."""
    return not SKIPPED & set(path.relative_to(base).parts)


def is_template(folder: Path) -> bool:
    return (folder / MANIFEST).is_file()


# ---- what a template says of itself


@dataclass(frozen=True)
class Meta:
    """What a template's template.yaml says of it, and where it is."""

    name: str
    version: str
    root: Path
    description: str = ""
    archvow: str = ""            # the archvow versions it works with: ">=3.0,<4" (empty: any)
    languages: tuple[str, ...] = ("en",)
    extends: tuple[str, ...] = ()
    abstract: bool = False

    def summary(self) -> dict[str, Any]:
        return {"name": self.name, "version": self.version, "description": self.description,
                "archvow": self.archvow, "languages": list(self.languages), "extends": list(self.extends),
                "abstract": self.abstract,
                "agents": sorted(p.parent.name for p in (self.root / "agents").glob("*/agent.yaml")),
                "rule_families": sorted(p.stem for p in (self.root / "rules").glob("*.yaml")),
                "regimes": sorted(p.stem for p in (self.root / "regimes").glob("*.yaml"))}


def extends_of(raw: dict[str, Any]) -> tuple[str, ...]:
    """`extends: a` or `extends: [a, b]`, as names."""
    value = raw.get("extends")
    if not value:
        return ()
    items = value if isinstance(value, list) else str(value).split(",")
    return tuple(str(v).strip() for v in items if str(v).strip())


def read_raw(folder: Path) -> dict[str, Any]:
    path = folder / MANIFEST
    try:
        data = parse_yaml(path.read_text(encoding="utf-8")) or {}
    except OSError as error:
        raise TemplateError(f"{folder}: no {MANIFEST} - not a template",
                            hint="a template is a folder with template.yaml: archvow template new <name>") from error
    except yaml.YAMLError as error:
        raise TemplateError(f"{path}: invalid YAML: {error}") from error
    if not isinstance(data, dict):
        raise TemplateError(f"{path}: expected a mapping at top level")
    return data


def meta(folder: Path) -> Meta:
    """The template in `folder`; TemplateError when its template.yaml is missing or says too little."""
    return once.remember(("template meta", str(folder)), lambda: _meta(folder))


def _meta(folder: Path) -> Meta:
    raw = read_raw(folder)
    path = folder / MANIFEST
    own = folder == folder.parent / OWN.name and folder.parent.name == ARCHVOW_DIR.name
    name = OWN_NAME if own else str(raw.get("name") or "")
    if not own and name != folder.name:
        raise TemplateError(f"{path}: name '{name}' must be its folder's name ({folder.name})")
    if not own and not NAME_RE.match(name):
        raise TemplateError(f"{path}: name '{name}' must be lowercase letters, digits and dashes (acme-pyspark)")
    version = str(raw.get("version") or ("0.0.0" if own else ""))
    if not VERSION_RE.match(version):
        raise TemplateError(f"{path}: version '{version}' must be MAJOR.MINOR.PATCH (1.0.0)")
    languages = tuple(dict.fromkeys(("en", *[str(lang) for lang in raw.get("languages") or []])))
    return Meta(name=name, version=version, root=folder, description=str(raw.get("description") or ""),
                archvow=str(raw.get("archvow") or ""), languages=languages, extends=extends_of(raw),
                abstract=bool(raw.get("abstract")))


def _version(text: str) -> tuple[int, ...]:
    return tuple(int(part) for part in re.findall(r"\d+", text)[:3])


def fits(found: Meta, version: str = __version__) -> bool:
    """Whether this archvow is in the template's range (">=3.0,<4"; empty: any)."""
    have = _version(version)
    for condition in filter(None, (c.strip() for c in found.archvow.split(","))):
        match = re.match(r"^(>=|<=|==|>|<)\s*(\d+(?:\.\d+){0,2})$", condition)
        if match is None:
            raise TemplateError(f"template {found.name}: archvow '{found.archvow}' is not a version range (>=3.0,<4)")
        op, wanted = match.groups()
        want = _version(wanted)
        mine = have[:len(want)]
        ok = {">=": mine >= want, "<=": mine <= want, "==": mine == want, ">": mine > want, "<": mine < want}[op]
        if not ok:
            return False
    return True


def require_fit(found: Meta) -> None:
    if not fits(found):
        raise TemplateError(f"template {found.name} {found.version} needs archvow {found.archvow}; this is archvow "
                            f"{__version__}", hint=f"install an archvow in that range, or take a version of "
                            f"{found.name} that fits (archvow template update --from <folder or package>)")


# ---- where templates come from


def shipped_folder() -> Path:
    """The templates archvow ships: inside the installed package (the wheel), else archvow's own repository (an
    editable install), `templates/` at its root."""
    here = Path(__file__).resolve()
    for folder in (here.parents[1] / "resources" / "templates", here.parents[3] / "templates"):
        if folder.is_dir() and any(is_template(p) for p in folder.iterdir()):
            return folder
    raise TemplateError("the templates archvow ships are not installed with it: reinstall archvow from its wheel")


def package_folder(source: str) -> Path:
    """The folder of templates an installed pip package names (entry point group archvow.templates), read from its
    metadata - never imported, no company code runs."""
    for name, folder in _packages().items():
        if source == name:
            return folder
    raise TemplateError(f"'{source}' is neither a folder of templates nor an installed package with templates",
                        hint=f"give the folder, or pip install the package that declares it ({ENTRY_POINTS})")


_PACKAGES: dict[tuple[str, ...], dict[str, Path]] = {}


def _packages() -> dict[str, Path]:
    """name -> folder, for every installed package declaring archvow.templates (read once per Python path)."""
    key = tuple(sys.path)
    if key not in _PACKAGES:
        _PACKAGES.clear()
        _PACKAGES[key] = _scan_packages()
    return dict(_PACKAGES[key])


def _scan_packages() -> dict[str, Path]:
    found: dict[str, Path] = {}
    for distribution in importlib.metadata.distributions():
        name = str((distribution.metadata.get_all("Name") or [""])[0])
        for point in [p for p in distribution.entry_points if p.group == ENTRY_POINTS]:
            located = Path(str(distribution.locate_file(point.value.replace(".", "/"))))
            if located.is_dir():
                found.setdefault(name, located.resolve())
                found.setdefault(point.name, located.resolve())
            else:
                log.info("package %s: entry point %s names %s, which is no folder", name, ENTRY_POINTS, point.value)
    return found


@dataclass(frozen=True)
class Source:
    """A place templates come from: a folder of template folders, recorded as `name` in project.vow."""

    name: str      # "archvow", a package name, or a folder as the person gave it
    folder: Path


def source_of(given: str | Path, root: Path | None = None) -> tuple[Source, str | None]:
    """A source as a person gives it - a template folder, a folder of templates, or a package name - and the
    template it names when it is one (else None)."""
    text = str(given)
    if text == SHIPPED:
        return Source(SHIPPED, shipped_folder()), None
    folder = Path(text).expanduser()
    if root is not None and not folder.is_absolute() and not folder.exists() and (root / folder).exists():
        folder = root / folder
    if is_template(folder):
        return Source(text, folder.resolve().parent), folder.resolve().name
    if folder.is_dir():
        return Source(text, folder.resolve()), None
    if "/" in text or "\\" in text or text.startswith("."):
        raise TemplateError(f"{text}: no such folder")
    return Source(text, package_folder(text)), None


def default_sources(given: tuple[Source, ...] = ()) -> list[Source]:
    """The folders given, archvow's templates, then the installed packages'."""
    found = list(given)
    found.append(Source(SHIPPED, shipped_folder()))
    found += [Source(name, folder) for name, folder in sorted(_packages().items())]
    unique: dict[Path, Source] = {}
    for source in found:
        unique.setdefault(source.folder, source)
    return list(unique.values())


def find_in(sources: list[Source]) -> dict[str, tuple[Path, Source]]:
    """name -> (its folder, its source), over every source; a name two places hold is refused."""
    found: dict[str, tuple[Path, Source]] = {}
    for source in sources:
        for manifest in sorted(source.folder.glob(f"*/{MANIFEST}")):
            folder = manifest.parent.resolve()
            if not kept(manifest, source.folder):
                continue
            before = found.get(folder.name)
            if before is not None and before[0] != folder:
                raise TemplateError(f"template {folder.name} is in two places: {before[0]} ({before[1].name}) and "
                                    f"{folder} ({source.name})",
                                    hint="a name is unique: rename one (a company's templates start with its name)")
            found.setdefault(folder.name, (folder, source))
    return found


def default_name(sources: list[Source] | None = None) -> str:
    """The template `init` uses without -t: the one marked `default: true` among the sources (python-app, of the
    templates archvow ships)."""
    found = find_in(sources if sources is not None else default_sources())
    marked = sorted(name for name, (folder, _) in found.items() if read_raw(folder).get("default"))
    if len(marked) != 1:
        raise TemplateError("name the template: archvow init <package> -t <template>" + (
            f" (several are marked default: {', '.join(marked)})" if marked else ""), hint="archvow catalog lists them")
    return marked[0]
