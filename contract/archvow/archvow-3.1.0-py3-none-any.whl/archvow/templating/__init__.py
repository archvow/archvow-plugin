"""Templates as data (layer 1): where they are found, a project's copies of its chain, and the parts a template
holds besides its template.yaml - data only, never Python.

    store.py    find templates (folders, archvow's, installed packages), copy a chain into a project, record and
                digest the copies, the project's own additions (.archvow/template/)
    rules.py    the declarative rules of a template (rules/<FAMILY>.yaml), read and checked
    regimes.py  the privacy and resilience regimes of a template (regimes/<id>.yaml)
    patterns.py the regular expressions a rule may hold, checked for catastrophic backtracking

Loading and merging a template's chain is templates.py; the commands that write templates are in spec/
(template_parts.py, template_check.py, template_use.py).
May import: foundation, model.
"""
