"""The one merge rule of templates, and what a merged chain must hold.

A template over its bases (`inherit`): mappings merge key by key, lists add, a list item with an `id` (or a `name`)
replaces the base's item of the same id; a template removes something only by saying so (`remove`). A translation
(or a component kind) over a template (`overlay`): items with an id or a name by it, any other list replaced.
"""

from __future__ import annotations

import copy
import keyword
import re
from typing import Any

from archvow.foundation.errors import TemplateError


def question_id(item: object) -> str:
    return str(item.get("id") or "") if isinstance(item, dict) else ""


def _identity(item: object) -> tuple[str, str] | None:
    if isinstance(item, dict):
        for key in ("id", "name"):
            if item.get(key) is not None:
                return key, str(item[key])
    return None


def inherit(base: dict[str, Any], child: dict[str, Any]) -> dict[str, Any]:
    """A template over its bases: mappings merge key by key, lists add, a list item with an `id` (or a `name`)
    replaces the base's item of the same id - recursively."""
    result = copy.deepcopy(base)
    for key, value in child.items():
        result[key] = _inherit_value(result.get(key), value)
    return result


def _inherit_value(base: object, child: object) -> object:
    if isinstance(child, dict) and isinstance(base, dict):
        return inherit(base, child)
    if isinstance(child, list) and isinstance(base, list):
        items = copy.deepcopy(base)
        for item in child:
            identity = _identity(item)
            index = next((i for i, old in enumerate(items) if identity is not None and _identity(old) == identity),
                         None)
            if index is not None:
                items[index] = _inherit_value(items[index], item)
            elif item not in items:
                items.append(copy.deepcopy(item))
        return items
    return copy.deepcopy(child)


def remove(data: dict[str, Any], path: str, name: str) -> None:
    """`remove: [component_types.cli, component_types.model.edge_cases.shape, rule_sets.fastapi]`: a key of a
    mapping, an item of a list by its id or name, or a value of a list."""
    parts = path.split(".")
    here: object = data
    for i, part in enumerate(parts):
        last = i == len(parts) - 1
        if isinstance(here, dict) and part in here:
            if last:
                del here[part]
                return
            here = here[part]
            continue
        if isinstance(here, list):
            index = next((j for j, item in enumerate(here) if (_identity(item) or ("", ""))[1] == part
                          or (not isinstance(item, (dict, list)) and str(item) == part)), None)
            if index is not None:
                if last:
                    del here[index]
                    return
                here = here[index]
                continue
        raise TemplateError(f"template {name}: remove: {path} - its bases have no {'.'.join(parts[:i + 1])}",
                            hint="remove names what a base brings: a key, an item by its id or name, or a value")


def overlay(base: dict[str, Any], texts: dict[str, Any]) -> dict[str, Any]:
    """A translation (or a component kind) over a template: mappings key by key, list items with an id or a name
    by it, any other list replaced."""
    result = copy.deepcopy(base)
    for key, value in texts.items():
        old = result.get(key)
        if isinstance(value, dict) and isinstance(old, dict):
            result[key] = overlay(old, value)
        elif isinstance(value, list) and isinstance(old, list) and value and all(_identity(v) for v in value) \
                and all(_identity(o) for o in old):
            items = copy.deepcopy(old)
            for item in value:
                index = next((i for i, o in enumerate(items) if _identity(o) == _identity(item)), None)
                if index is None:
                    items.append(copy.deepcopy(item))
                else:
                    items[index] = overlay(items[index], item)
            result[key] = items
        else:
            result[key] = copy.deepcopy(value)
    return result


def validate(name: str, data: dict[str, Any]) -> None:
    """What the merged chain must hold: every question an id, every layer it names declared."""
    layers = [layer["name"] for layer in data.get("layers") or [] if isinstance(layer, dict) and "name" in layer]
    for layer in data.get("layers") or []:
        unknown = [m for m in layer.get("may_import") or [] if m not in layers]
        if unknown:
            raise TemplateError(f"template {name}: layer {layer.get('name')}: may_import names {', '.join(unknown)}, "
                                f"not a layer (the layers: {', '.join(layers)})")
    for type_name, ctype in (data.get("component_types") or {}).items():
        if not isinstance(ctype, dict):
            raise TemplateError(f"template {name}: component type {type_name} is not a mapping")
        if layers and ctype.get("layer") is not None and ctype.get("layer") not in layers:
            raise TemplateError(f"template {name}: component type {type_name}: layer {ctype.get('layer')} is not "
                                f"a layer (the layers: {', '.join(layers)})")
        check_questions(name, f"component type {type_name}", ctype.get("edge_cases"))
        for kind, own in (ctype.get("kinds") or {}).items():
            check_questions(name, f"component type {type_name}, kind {kind}", (own or {}).get("edge_cases"))
        ids = [question_id(q) for q in ctype.get("edge_cases") or []]
        for word, target in (ctype.get("safety_decisions") or {}).items():
            if not isinstance(target, str) or (target not in ids and not ctype.get("kinds")):
                raise TemplateError(f"template {name}: component type {type_name}: safety_decisions {word}: "
                                    f"{target!r} is not one of its question ids ({', '.join(ids) or 'none'})")
    for component in data.get("initial_components") or []:
        check_questions(name, f"starting component {component.get('id')}", component.get("edge_cases"))


ID_RE = re.compile(r"^[a-z][a-z0-9_]*$")


def check_questions(name: str, where: str, questions: Any) -> None:
    seen: set[str] = set()
    for item in questions or []:
        ident = question_id(item)
        if not isinstance(item, dict) or not item.get("question") or not ID_RE.match(ident):
            raise TemplateError(f"template {name}: {where}: every question is {{id, question}} with an id in lower "
                                f"case ({str(item)[:60]})", hint="- {id: shape, question: \"What ... - e.g. ...?\"}")
        if ident in seen:
            raise TemplateError(f"template {name}: {where}: question id {ident} twice")
        seen.add(ident)






# ---- layer names: a template names its layers' folders (`layer_names`), everywhere in its data


def renames(data: dict[str, Any]) -> dict[str, str]:
    """`layer_names`, the layer -> folder pairs that change something (built-in name -> new name)."""
    return {old: new for old, new in (data.get("layer_names") or {}).items() if old != new}


def rename_words(value: object, renames: dict[str, str]) -> object:
    """Every layer name in a value (a text, or the strings of a list or mapping) replaced as a whole
    word: p2_io in "p2_io components" or "{{ package }}.p2_io.reader", never inside another name."""
    if not renames:
        return value
    if isinstance(value, str):
        pattern = re.compile(r"(?<![A-Za-z0-9_])(" + "|".join(map(re.escape, renames)) + r")(?![A-Za-z0-9_])")
        return pattern.sub(lambda m: renames[m.group(1)], value)
    if isinstance(value, list):
        return [rename_words(item, renames) for item in value]
    if isinstance(value, dict):
        return {rename_words(k, renames): rename_words(v, renames) for k, v in value.items()}
    return value


LAYER_FOLDER_RE = re.compile(r"^[a-z_][a-z0-9_]*$")


def check_layer_names(template_name: str, layers: list[str], names: dict[str, Any]) -> None:
    """`layer_names` maps existing layers to folders: valid package names, all different."""
    if not isinstance(names, dict):
        raise TemplateError(f"template '{template_name}': layer_names must map a layer to its folder")
    unknown = [old for old in names if old not in layers]
    if unknown:
        raise TemplateError(f"template '{template_name}': layer_names: unknown layer(s) {', '.join(unknown)} "
                            f"(the layers are {', '.join(layers)})")
    bad = [str(new) for new in names.values()
           if not LAYER_FOLDER_RE.match(str(new)) or keyword.iskeyword(str(new))]
    if bad:
        raise TemplateError(f"template '{template_name}': layer_names: {', '.join(bad)} - a folder name is "
                            "a Python package name: lower case, digits and _, not a keyword")
    folders = [names.get(layer, layer) for layer in layers]
    twice = sorted({f for f in folders if folders.count(f) > 1})
    if twice:
        raise TemplateError(f"template '{template_name}': layer_names: {', '.join(twice)} given to two layers")


def apply_layer_names(template_name: str, data: dict[str, Any]) -> dict[str, Any]:
    names = data.get("layer_names") or {}
    check_layer_names(template_name, [layer["name"] for layer in data.get("layers", [])], names)
    pairs = renames(data)
    if not pairs:
        return data
    renamed = {key: (value if key == "layer_names" else rename_words(value, pairs)) for key, value in data.items()}
    renamed["layer_names"] = dict(names)  # kept as written: the built-in name -> its folder (for the files)
    return renamed
