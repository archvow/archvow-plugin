"""`archvow next` and `archvow prompt`: what to build next, and a component's task for an AI assistant.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any

from archvow import proposals as ai
from archvow.checks.engine import Report
from archvow.checks.run import run_check
from archvow.cli.args import COMPONENT_HELP, Builder
from archvow.cli.console import style as ui
from archvow.cli.output import current_branch, print_result, project_root, task_text
from archvow.foundation import logs
from archvow.foundation.errors import GitError, SpecError
from archvow.foundation.git import merge_base
from archvow.foundation.text import tokens
from archvow.limits import usage
from archvow.model import features as feats
from archvow.model import store
from archvow.views.component import safety_worksheet
from archvow.views.component_doc import render_clarify, render_prompt
from archvow.views.feature_doc import feature_clarify, feature_prompt
from archvow.views.plan import plan_with_budget

log = logs.get("cli")


def cmd_prompt(args: argparse.Namespace) -> int:
    root = project_root(args)
    if args.max is not None and not args.clarify:
        raise SpecError("--max goes with --clarify: archvow prompt <component> --clarify --max 5")
    if args.max is not None and args.max < 1:
        raise SpecError("--max: at least 1 question")
    if args.feature:
        if args.clarify and (args.component or args.task is not None):
            raise SpecError("--feature --clarify checks the whole feature: no component, no --task "
                            f"(archvow prompt --feature {args.feature} --clarify)")
        text = feature_clarify(root, args.feature, args.max or 5) if args.clarify else feature_prompt(
            root, args.feature, args.component, args.task)
    elif not args.component:
        raise SpecError("which component? archvow prompt <component> (or --feature <feature>: the whole feature)")
    else:
        text = render_clarify(root, args.component, args.max or 5) if args.clarify else render_prompt(
            root, args.component, task=args.task)
    print(text, end="")
    if sys.stderr.isatty():  # for the person who runs it; the AI reads stdout only
        print(ui.dim(f"~{tokens(text):,} tokens"), file=sys.stderr)
    return 0


def _guard_notes(root: Path) -> dict[str, list[str]]:
    """Per component, what `next` adds to its line: decisions the AI proposed, assumptions nobody
    reviewed yet (they block the commit, ARCH034), critical/high hazards nothing prevents yet,
    invariants of written code that no test checks yet."""
    data = store.load(root)
    notes: dict[str, list[str]] = {}
    proposed: dict[str, int] = {}
    for p in ai.load(root):
        proposed[p["component"]] = proposed.get(p["component"], 0) + 1
    hazards, invariants = store.hazards(data), data.get("invariants", []) or []
    report = run_check(root) if hazards or invariants else None
    guarded = {h for inv in invariants for h in inv.get("mitigates", []) or []}
    untested = {i["id"] for i in report.invariants if not i.get("verified")} if report else set()
    coded = {c.component for c in report.components if c.status != "planned"} if report else set()
    for container in data.get("containers", []):
        for comp in container.get("components", []):
            cid = comp["id"]
            unguarded = sum(1 for h in hazards if h.get("component") == cid
                            and h["severity"] in ("critical", "high") and h["id"] not in guarded)
            weak = sum(1 for i in invariants if i.get("component") == cid and i["id"] in untested) if cid in coded else 0
            assumed = sum(1 for a in comp.get("assumptions", []) or [] if a.get("status", "proposed") == "proposed")
            found = [f"created by the AI, to accept -> archvow component accept {cid}" if comp.get("origin") == "ai" else "",
                     f"{proposed[cid]} proposed by the AI" if proposed.get(cid) else "",
                     f"{assumed} assumption(s) to review -> archvow show {cid}" if assumed else "",
                     f"{unguarded} hazard(s) prevented by nothing" if unguarded else "",
                     f"{weak} invariant(s) not tested" if weak else ""]
            if any(found):
                notes[cid] = [n for n in found if n]
    return notes


def _task_tokens(root: Path, component: str, shared: dict[str, Any]) -> int | None:
    """About how many tokens the AI reads for a component's task (`archvow prompt`)."""
    try:
        return tokens(task_text(root, component, shared))
    except SpecError:
        logs.swallowed(log, "_task_tokens: SpecError")
        return None


def next_rows(root: Path, base: str | None, report: Report | None = None) -> tuple[list[dict[str, Any]], dict[str, Any] | None, list[dict[str, Any]]]:
    """What `archvow next` lists (its --json): the planned components in build order, the done ones that still
    have a guard to fix, each with its notes and tokens; the change budget against `base`; the run lines.
    `report`: the check the caller already ran (workspace), not run again."""
    rows, budget, runs = plan_with_budget(root, base, report)  # runs: the entry points' run lines
    notes = _guard_notes(root)
    listed = {r["component"] for r in rows}
    data = store.load(root)
    for container in data.get("containers", []):  # done components that still have a guard to fix
        for comp in container.get("components", []):
            if comp["id"] in notes and comp["id"] not in listed:
                rows.append({"component": comp["id"], "type": comp["type"], "readiness": "coded"})
    shared: dict[str, Any] = {"data": data}  # read once for every task
    for r in rows:
        if r["component"] in notes:
            r["notes"] = notes[r["component"]]
        size = _task_tokens(root, r["component"], shared)
        if size is not None:
            r["tokens"] = size  # what the AI reads for it: its prompt (ARCH044 warns over the limit)
    return rows, budget, runs


def cmd_next(args: argparse.Namespace) -> int:
    root = project_root(args)
    rows, budget, runs = next_rows(root, args.base)
    data = store.load(root)
    if args.feature:  # one feature: its own rows, in the same build order
        members = {c["id"] for c in feats.components_of(data, feats.find(data, args.feature)["name"])}
        rows = [r for r in rows if r["component"] in members]

    def line(r: dict[str, Any]) -> str:
        state = "ready" if r["readiness"].startswith("ready") else "blocked" if r["readiness"].startswith("blocked") else "wait"
        hint = (f"  -> archvow show {r['component']}" if "to review" in r["readiness"]
                else f"  -> archvow specify {r['component']}" if state == "blocked" else "")
        extra = ui.warn(" - " + ", ".join(r["notes"])) if r.get("notes") else ""
        size = ui.dim(f"  ~{r['tokens']:,} tokens") if state == "ready" and r.get("tokens") else ""
        offered = f" ({r['suggested']} suggested)" if state == "blocked" and r.get("suggested") else ""
        return (f"{ui.mark(state)} {r['component']:<28} {r['type']:<15} {r['readiness']}{offered}"
                + (f" ({r['started']})" if r.get("started") else "") + extra + size + ui.dim(hint))

    header = ui.dim(f"  {'component':<28} {'type':<15} status") if rows else ""  # the types: archvow catalog lists them
    text = "\n".join([header, *(line(r) for r in rows)]) if rows else (
        "Nothing planned. Add components with `archvow component add`.")
    sheet = safety_worksheet(root)
    total = sum(len(c["questions"]) for c in sheet)
    done = sum(q["status"] == "answered" for c in sheet for q in c["questions"])
    if rows and done < total:
        text += f"\n\nSafety: {done} of {total} questions answered" + ui.dim("  -> archvow specify")
    if not args.feature and not [f for f in feats.features(data) if f["name"] != "shared"]:
        text += "\n\n" + ui.title("Then:") + " " + ui.code('archvow feature add <name> -d "what the product does"')
    created = [c["id"] for ct in data.get("containers", []) for c in ct.get("components", []) if c.get("origin") == "ai"]
    proposed = len(ai.load(root))
    if created or proposed:  # what the AI did on its own (modes guided, free): a person looks at it
        parts = ([f"{len(created)} component(s): {', '.join(created)}"] if created else []) + \
                ([f"{proposed} decision(s)"] if proposed else [])
        text += "\n\n" + ui.warn(f"Created or proposed by the AI - to review: {'; '.join(parts)}") + ui.dim(
            "  -> archvow show <component>, then archvow component accept <component> / decision accept <component> <n>")
    if args.base and budget is None:
        try:
            merge_base(root, args.base)
            why = "git cannot measure the change"
        except GitError as exc:
            logs.swallowed(log, "cmd_next: GitError")
            why = str(exc)
        text += f"\n{ui.warn(f'Change budget unknown: cannot compare with {args.base!r}: {why}')}"
    elif budget:
        size = (f"Change budget against {budget['base']}: {budget['files']}/{budget['max_files']} files, "
                f"{budget['added_lines']}/{budget['max_added_lines']} lines added (ARCH022).")
        here = current_branch(root) or "<this branch>"
        text += "\n\n" + (ui.warn(size + " Full: stop here - commit and open the merge request. To go on "
                                  f"before it is merged, start the next branch from this one (git switch -c "
                                  f"feature/<ticket>-<short-name> {here}) and run archvow next --base {here}: "
                                  "only the new work counts.") if budget["full"] else size)
    sizes = usage(root, data)
    if sizes:  # how big the project is, against its limits (ARCH058)
        usage_line = " · ".join(f"{u['what']} {u['used']:,}/{u['limit']:,}" for u in sizes)
        over = any(u["used"] > u["limit"] for u in sizes)
        text += "\n\n" + (ui.warn(f"Limits: {usage_line} - over: split the project, or an architect raises it") if over
                            else ui.dim(f"Limits: {usage_line}"))
    if runs:  # how to try it on a laptop, or what it still needs (never a deployment command)
        text += "\n\n" + "\n".join(ui.ok(r["line"]) if r["ready"] else ui.warn(r["line"]) for r in runs)
    print_result(args, {"components": rows, "budget": budget} if args.base else rows, text)
    return 0


def declare_prompt(b: Builder) -> None:
    """`archvow prompt`: its parser."""
    # ---- code
    p = b.command("prompt", cmd_prompt, "print a component's task for an AI assistant: its spec, what it uses, the rules", examples="""
        archvow prompt <component>                 # paste into an assistant that cannot read files
        archvow prompt <component>                 # a big spec: its next open task (T2 of 3...)
        archvow prompt <component> --task 1        # one task of it
        archvow prompt <component> --clarify       # ask the AI what is unclear (it decides nothing)
        archvow prompt <component> --clarify --max 3    # at most 3 questions, the riskiest first
        archvow prompt --feature <feature>         # the feature, then its next component to build
        archvow prompt --feature <feature> --clarify    # check the whole feature before any code
        """)
    p.add_argument("component", nargs="?", help=COMPONENT_HELP + " (with --feature: the one to build now; default: "
                                                    "the feature's next ready one)")
    p.add_argument("-f", "--feature", metavar="FEATURE",
                   help="the whole feature: what it does, one line per component (the AI sees every one), what "
                        "the others already decided, then the full task of the component to build now")
    p.add_argument("--task", type=int, metavar="N",
                   help="a spec cut into tasks (archvow show lists them): task N instead of the next open one")
    p.add_argument("--clarify", action="store_true",
                   help="ask the AI to list ambiguities as questions instead (it answers none); with --feature: "
                        "where the feature's components disagree or leave a gap between them")
    p.add_argument("--max", type=int, metavar="N",
                   help="with --clarify: at most N questions, the riskiest first (default 5)")


def declare_next(b: Builder) -> None:
    """`archvow next`: its parser."""
    p = b.command("next", cmd_next, "planned components in build order, with what each one waits for", True,
                  examples="""
        archvow next                     # then, to the AI assistant: implement everything archvow next lists as ready
        archvow next --base develop      # the same, and nothing is ready once the change is too big to review
        archvow next --feature orders    # one feature's components only
        """)
    p.add_argument("-f", "--feature", metavar="FEATURE", help="only this feature's components")
    p.add_argument("--base", metavar="REF",
                   help="the branch the merge request targets (main, origin/main): counts the change against its "
                        "review budget (ARCH022); when it is full, nothing more is ready")
