"""`archvow catalog`: the templates a project could use, their init answers and component types; one template merged,
with where each of its questions, guide words and rules comes from (`--all`).
"""

from __future__ import annotations

import argparse
import textwrap
from pathlib import Path
from typing import Any

from archvow import agents
from archvow.cli.args import Builder, answers_help
from archvow.cli.console import style as ui
from archvow.cli.output import as_json, project_root
from archvow.foundation import logs
from archvow.model import store
from archvow.templates import Template, available, load_template
from archvow.templating import copies, regimes
from archvow.templating import store as template_store
from archvow.templating.origins import origins

log = logs.get("cli")


def catalog_templates(root: Path | None) -> list[Template]:
    """The templates a project could use (archvow's, the installed packages'): what `archvow catalog` lists. A shared
    base is extended, never used directly: it is left out. In a project, each container's template comes first as
    the project uses it - its copies and its own additions - (its types for `component add`, a company's too)."""
    data = store.load(root) if root is not None and store.is_project(root) else {}
    used = [load_template(str(c["template"]), root) for c in data.get("containers") or [] if c.get("template")]
    names = sorted(set(available(root, from_sources=True)) - {t.name for t in used})
    return used + [t for t in (load_template(name, root, from_sources=True) for name in names)
                   if not t.data.get("abstract")]


def catalog_parts(root: Path | None, loaded: list[Template]) -> dict[str, Any]:
    """What `catalog --json` and `workspace --json` say of the templates: those available, the project's chain (its
    copies, as project.vow records them), the agents, the privacy regimes (the project's, else those of the templates
    listed)."""
    data = store.load(root) if root is not None and store.is_project(root) else {}
    recorded = copies.recorded(data)
    project = [{**template_store.meta(folder).summary(), **recorded.get(name, {})}
               for name, folder in copies.project_copies(root).items()]
    found = regimes.available(root) if project else {r.id: r for t in loaded for r in t.regimes}
    listed = [t.summary() for t in loaded]
    for summary in listed:  # the project's own template: where it came from, as project.vow records it, never a path here
        summary["source"] = (recorded.get(str(summary["name"]).split(", ")[-1]) or {}).get("source", summary["source"])
    return {"templates": listed, "project_templates": project,
            "agents": [p.summary() for p in agents.profiles(root).values()],
            "regimes": [r.summary() for r in sorted(found.values(), key=lambda r: r.id)]}


def cmd_catalog(args: argparse.Namespace) -> int:
    root: Path | None
    try:
        root = project_root(args)
    except store.ManifestError:
        logs.swallowed(log, "cmd_catalog: store.ManifestError")
        root = None
    if args.template:
        return _catalog_one(args, root)
    loaded = catalog_templates(root)
    templates = [template.summary() for template in loaded]
    if args.json:
        print(as_json(catalog_parts(root, loaded)))
        return 0
    if root is not None and copies.has_copies(root):
        chain = ", ".join(f"{n} {e.get('version')}" for n, e in copies.recorded(store.load(root)).items())
        print(ui.title("this project's templates") + ui.dim(f"  {chain} (.archvow/templates/; archvow template update)"))
    print(ui.dim("  agents with a profile (any other name gets the standard one): "
                 + ", ".join(sorted(agents.profiles(root)))) + "\n")
    for template, t in zip(loaded, templates, strict=True):
        chain = f" (extends {', '.join(t['extends'])})" if t["extends"] else ""
        default = ui.dim("  default") if t.get("default") else ""
        print(ui.title(f"{t['name']} {t['version']}") + f"  [{t['language']} / {t['kind']} / {t['style']}]{chain}"
              + default)
        print(f"    {t['description']}")
        print("  component types (archvow component add TYPE NAME):")
        for key, ct in t["component_types"].items():
            if ct["addable"]:
                print(f"    - {key:<15} -> {ct['layer']:<15} {ct['description']}")
        names = ", ".join(r.name for r in template.regimes)
        if names:
            print(f"  regimes (-a rules=...): {names}")
        print(f"  init answers (archvow init NAME -t {t['name']} -a KEY=VALUE):")
        print(textwrap.indent(answers_help(template), "  "))
    return 0


def _catalog_one(args: argparse.Namespace, root: Path | None) -> int:
    """`catalog <template> [--all]`: one template, merged; --all: every question, guide word and rule, with the
    template of its chain it comes from."""
    folder = Path(args.template).expanduser()
    if template_store.is_template(folder):
        template = load_template(folder.resolve().name, None, extra=(folder.resolve(),))
    elif root is not None and args.template in copies.project_copies(root):
        template = load_template(args.template, root)
    else:
        template = load_template(args.template, None, from_sources=True)
    found = origins(template)
    if args.json:
        print(as_json({**template.summary(), "origins": found}))
        return 0
    print(ui.title(f"{template.name} {template.version}") + ui.dim(f"  chain: {' -> '.join(found['chain'])}"))
    print("  layers: " + ", ".join(f"{layer['name']} ({layer['from']})" for layer in found["layers"]))
    for type_name, ctype in found["component_types"].items():
        print(f"  {type_name} -> {ctype['layer']}  ({ctype['from']})")
        if args.all:
            for q in ctype["questions"]:
                print(ui.dim(f"      {q['id']:<20} {q['from']:<18} ") + q["question"])
    if args.all:
        print("  guide words:")
        for word in found["guide_words"]:
            print(ui.dim(f"      {word['word']:<20} {word['from']:<18} ") + word["question"])
        if found["rule_sets"]:
            print("  rule sets (archvow's checks): " + ", ".join(f"{r['name']} ({r['from']})" for r in found["rule_sets"]))
        print(f"  declarative rules ({len(found['rules'])}):")
        for rule in found["rules"]:
            final = ", final" if rule["final"] else ""
            print(ui.dim(f"      {rule['code']:<10} {rule['from']:<18} {rule['kind']}, {rule['severity']}{final}: ")
                  + str(rule["message"]))
        if found["regimes"]:
            print("  regimes: " + ", ".join(f"{r['name']} ({r['from']})" for r in found["regimes"]))
    else:
        print(ui.dim(f"  every question, guide word and rule, with where it comes from: archvow catalog {args.template} "
                     "--all"))
    return 0


def declare_catalog(b: Builder) -> None:
    """`archvow catalog`: its parser."""
    p = b.command("catalog", cmd_catalog, "list templates, their init answers and component types; one template: "
                  "where each of its questions, guide words and rules comes from", True,
                  examples="archvow catalog\narchvow catalog --json\narchvow catalog fastapi-service --all\n"
                           "archvow catalog ~/templates/acme-pyspark --all")
    p.add_argument("template", nargs="?", help="one template, by name or folder: its chain, merged")
    p.add_argument("--all", action="store_true", help="every question, guide word and rule, with the template of "
                   "its chain it comes from")


