"""Readable terminal output: green success, yellow attention, red errors.

Colours are used only on an interactive terminal. They are switched off when the output is
piped or redirected (CI logs, files), when NO_COLOR is set (https://no-color.org) or TERM is
"dumb"; FORCE_COLOR switches them on. Symbols fall back to ASCII when the terminal cannot
print them. JSON output (--json) never goes through this module.
"""

from __future__ import annotations

import os
import re
import shutil
import sys
import textwrap
from typing import Any, TextIO

from archvow.foundation import logs
from archvow.foundation.config import settings

log = logs.get("ui")

RESET, BOLD, DIM = "\033[0m", "\033[1m", "\033[2m"
RED, GREEN, YELLOW, CYAN = "\033[31m", "\033[32m", "\033[33m", "\033[36m"
BLUE, MAGENTA = "\033[94m", "\033[95m"  # bright: readable on dark and light terminals


def _enabled(stream: TextIO) -> bool:
    env = settings()
    if env.no_color:
        return False
    if env.force_color:
        return True
    terminal = hasattr(stream, "isatty") and stream.isatty() and not env.dumb_terminal
    return terminal and (os.name != "nt" or _windows_colours())


_WINDOWS: list[bool] = []


def _windows_colours() -> bool:
    """The Windows console shows colour codes once asked to (Windows 10 and later): ask once, with
    the standard library; if it refuses, archvow prints plain text - never stray codes."""
    if not _WINDOWS:
        try:
            import ctypes

            kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
            ok = True
            for handle in (-11, -12):  # standard output, standard error
                console = kernel32.GetStdHandle(handle)
                mode = ctypes.c_uint32()
                if not kernel32.GetConsoleMode(console, ctypes.byref(mode)):
                    ok = False
                    continue
                ok = bool(kernel32.SetConsoleMode(console, mode.value | 0x0004)) and ok  # VT processing
            _WINDOWS.append(ok)
        except (AttributeError, OSError, ImportError):
            logs.swallowed(log, "_windows_colours: AttributeError, OSError, ImportError")
            _WINDOWS.append(False)
    return _WINDOWS[0]


def _unicode(stream: TextIO) -> bool:
    encoding = (getattr(stream, "encoding", None) or "").lower()
    return "utf" in encoding


def _paint(text: str, *codes: str, stream: TextIO | None = None) -> str:
    stream = stream or sys.stdout
    return f"{''.join(codes)}{text}{RESET}" if _enabled(stream) else text


def _symbol(fancy: str, plain: str, stream: TextIO | None = None) -> str:
    return fancy if _unicode(stream or sys.stdout) else plain


def ok(text: str) -> str:
    return _paint(f"{_symbol('✔', 'OK')} {text}", GREEN)


def warn(text: str) -> str:
    return _paint(f"{_symbol('!', '!')} {text}", YELLOW)


def error(text: str) -> str:
    return _paint(f"{_symbol('✖', 'ERROR')} {text}", RED, stream=sys.stderr)


# archvow's icon: two arms that meet, held up by an arch (the same motif as the editor plugin's icon)
LOGO = (
    "▀█████      █████▀",
    " ▀█████    █████▀",
    "  ▀█████▄▄█████▀",
    "    ████▀▀████",
    "     ██    ██",
    "     ██    ██",
    "     ██    ██",
)
LOGO_ASCII = (
    "#####      #####",
    " #####    #####",
    "  #####..#####",
    "    ###..###",
    "     ##  ##",
    "     ##  ##",
)
LOGO_GREEN = "\033[38;5;36m"  # the icon's green (#1A876B), in the 256 colours every terminal has


def logo(caption: str = "", stream: TextIO | None = None) -> str:
    """archvow's icon, in green, with a caption beside its middle line."""
    stream = stream or sys.stdout
    lines = list(LOGO if _unicode(stream) else LOGO_ASCII)
    width = max(len(line) for line in lines) + 3
    middle = len(lines) // 2
    return "\n".join(_paint(line.ljust(width) if caption and i == middle else line, LOGO_GREEN, stream=stream)
                     + (_paint(caption, BOLD, stream=stream) if caption and i == middle else "")
                     for i, line in enumerate(lines))


def mark(state: str) -> str:
    """One status character: done / ready (green), open / blocked (red), waiting (dim)."""
    if state in ("done", "ready"):
        return _paint(_symbol("✔", "+"), GREEN)
    if state in ("open", "blocked"):
        return _paint(_symbol("✖", "x"), RED)
    return _paint(_symbol("·", "."), DIM)


def red(text: str) -> str:
    return _paint(text, RED)


def yellow(text: str) -> str:
    return _paint(text, YELLOW)


def example_mark(result: str) -> str:
    """A business example's state: its test passes (✔ green), fails (✖ red), is not written yet (○ yellow),
    did not run or was skipped (· dim)."""
    if result == "passing":
        return _paint(_symbol("✔", "+"), GREEN)
    if result == "failing":
        return _paint(_symbol("✖", "x"), RED)
    if result == "no_test":
        return _paint(_symbol("○", "o"), YELLOW)
    return _paint(_symbol("·", "."), DIM)


def title(text: str) -> str:
    return _paint(text, BOLD)


def label(text: str, kind: str) -> str:
    """What `specify` asks now, in colour so it stands out: a spec decision in blue, a vow question
    (hazard, personal data, operations) in magenta."""
    return _paint(text, BOLD, BLUE if kind == "decision" else MAGENTA)


def dim(text: str) -> str:
    return _paint(text, DIM)


def hint(text: str) -> str:
    """A suggestion inside an input prompt, greyed like every suggestion (`ask` makes its colour
    codes invisible to line editing)."""
    return _paint(text, DIM)


# an example: "(e.g. ...)", or "- e.g. ..." up to the next " - " before the question mark, else up to
# a colon, the question mark or the end ("- e.g. amount = abc: stop or drop?")
EXAMPLE_RE = re.compile(r"\((?:e\.g\.|par ex\.)[^)]*\)"
                        r"|- (?:e\.g\.|par ex\.) (?:[^?]*?(?= - )|[^?:]*?(?=:|\?|$))")


def question(text: str, indent: int = 0) -> str:
    """A question as `specify` shows it: wrapped to the terminal, in bold, its examples in grey (an
    example cut over two lines stays grey on both)."""
    width = max(40, shutil.get_terminal_size((100, 24)).columns - 1)
    text = " ".join(str(text).split())
    if not _enabled(sys.stdout):
        return "\n".join(" " * indent + line for line in textwrap.wrap(text, width=width - indent))
    examples = [m.span() for m in EXAMPLE_RE.finditer(text)]  # wrapped as plain text, then painted by position
    glued = text  # "- e.g." / "- par ex." stay on one line: their spaces do not break while wrapping
    for a, _ in examples:
        lead = re.match(r"[-(]?\s*(?:e\.g\.|par ex\.)", text[a:])
        if lead:
            glued = glued[:a] + lead.group(0).replace(" ", "\x00") + glued[a + lead.end():]
    out, at = [], 0
    for line in (part.replace("\x00", " ") for part in textwrap.wrap(glued, width=width - indent)):
        start = text.find(line, at)
        at = start + len(line)
        chunks: list[list[Any]] = []
        for offset, char in enumerate(line):
            grey = any(a <= start + offset < b for a, b in examples)
            if chunks and chunks[-1][0] == grey:
                chunks[-1][1] += char
            else:
                chunks.append([grey, char])
        out.append(" " * indent + RESET.join((DIM if grey else BOLD) + chunk for grey, chunk in chunks) + RESET)
    return "\n".join(out)


def wrap(text: str, indent: int = 0) -> str:
    """Plain text wrapped to the terminal's width, every line indented."""
    width = max(40, shutil.get_terminal_size((100, 24)).columns - 1)
    return textwrap.fill(" ".join(str(text).split()), width=width, initial_indent=" " * indent,
                         subsequent_indent=" " * indent)


def code(text: str) -> str:
    return _paint(text, CYAN)


def severity(level: str, text: str) -> str:
    return _paint(text, RED if level == "error" else YELLOW)


def steps(text: str) -> str:
    """Render the template's setup text. Line conventions, so templates stay plain text:

        Title:           a section title (bold)
          - item         a normal point
          ! item         needs attention (yellow)
          > item         something to do (cyan arrow)
    """
    out = []
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            out.append("")
        elif not line.startswith(" ") and stripped.endswith(":"):
            out.append(title(stripped[:-1].rstrip()))
        elif stripped.startswith("! "):
            out.append("  " + warn(stripped[2:]))
        elif stripped.startswith("> "):
            out.append("  " + _paint(_symbol("→", ">"), CYAN) + " " + stripped[2:])
        elif stripped.startswith("- "):
            out.append(f"  {_symbol('•', '-')} {stripped[2:]}")
        else:
            out.append(line)
    return "\n".join(out)
