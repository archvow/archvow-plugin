"""Writing the files archvow owns, and the lock around a spec change.

`write_text` writes a file whole or not at all: the text goes to a temporary file next to it, then
replaces it in one step (os.replace). Ctrl+C, a full disk or a crash never leave half a vow. UTF-8, LF
line endings on every system, and the file keeps its permissions (a hook stays executable).

`spec_lock(root)` is held while a command changes the spec (archvow.model.store.save): a second archvow - a
person's terminal and the IDE plugin at the same time - waits for it, then says who holds it.
"""

from __future__ import annotations

import ast
import contextlib
import copy
import functools
import marshal
import os
import socket
import tempfile
import time
from collections.abc import Iterator
from pathlib import Path
from typing import TypeVar

import yaml

from archvow.foundation import logs, once
from archvow.foundation.errors import LockError
from archvow.foundation.paths import WRITE_LOCK_REL

log = logs.get("files")
WAIT_SECONDS = 10.0


def write_text(path: Path, text: str) -> None:
    """Replace the file's content with `text` atomically (UTF-8, LF), keeping its mode if it exists."""
    path.parent.mkdir(parents=True, exist_ok=True)
    mode = path.stat().st_mode & 0o7777 if path.exists() else None
    handle, temporary = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(handle, "w", encoding="utf-8", newline="\n") as out:
            out.write(text)
        if mode is not None:
            os.chmod(temporary, mode)
        else:
            umask = os.umask(0)
            os.umask(umask)
            os.chmod(temporary, 0o666 & ~umask)
        os.replace(temporary, path)
    except BaseException:
        with contextlib.suppress(OSError):
            os.unlink(temporary)
        raise


def _holder(lock: Path) -> str:
    try:
        return lock.read_text(encoding="utf-8").strip() or "another archvow"
    except OSError:
        return "another archvow"


def _stale(lock: Path) -> bool:
    """A lock left by an archvow that stopped without removing it (same machine, process gone)."""
    try:
        host, _, pid = lock.read_text(encoding="utf-8").split()[0].partition(":")
    except (OSError, IndexError):
        return False
    if host != socket.gethostname() or not pid.isdigit():
        return False
    try:
        os.kill(int(pid), 0)
    except ProcessLookupError:
        return True
    except OSError:  # it exists but belongs to someone else, or the system does not say
        return False
    return False


BREAKER_SECONDS = 30.0  # a breaker lock is held for an instant: one this old was left by a stopped archvow


def _take_stale(lock: Path) -> bool:
    """Remove a stale lock - only the very file judged stale, and only by one archvow at a time. Two archvows may both
    judge it: each first takes the short breaker lock (break.local, beside it), then judges the lock again and removes
    it only if it is still the file judged. The lock is never moved aside: while it was, a third archvow could take the
    empty place, and the lock put back was lost (two holders). True: try to take the lock again."""
    def state(path: Path) -> tuple[int, int, str]:  # an inode can be reused at once: its time and text too
        info = path.stat()
        return info.st_ino, info.st_mtime_ns, path.read_text(encoding="utf-8", errors="replace")

    if not _stale(lock):
        return not lock.exists()  # gone meanwhile: try to take it
    breaker = lock.with_name("break.local")
    try:
        handle = os.open(breaker, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o644)
    except FileExistsError:
        _drop_old_breaker(breaker)
        return False  # another archvow is judging it: wait
    os.close(handle)
    try:
        try:
            judged = state(lock)
        except OSError:
            return True  # gone meanwhile
        if _stale(lock) and state(lock) == judged:
            log.info("removed a lock left by a stopped archvow (%s)", _holder(lock))
            lock.unlink()
        return True
    finally:
        with contextlib.suppress(OSError):
            breaker.unlink()


def _drop_old_breaker(breaker: Path) -> None:
    """A breaker lock left by an archvow stopped while it held it (an instant): removed once it is old."""
    with contextlib.suppress(OSError):
        if time.time() - breaker.stat().st_mtime > BREAKER_SECONDS:
            breaker.unlink()


@contextlib.contextmanager
def spec_lock(root: Path, wait: float = WAIT_SECONDS) -> Iterator[None]:
    """Hold .archvow/write.local while the block runs; wait up to `wait` seconds for another holder."""
    lock = root / WRITE_LOCK_REL
    if not lock.parent.is_dir():  # not a project yet: nothing to protect
        yield
        return
    deadline = time.monotonic() + wait
    while True:
        try:
            handle = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o644)
        except FileExistsError:
            if _take_stale(lock):
                continue
            if time.monotonic() >= deadline:
                raise LockError(f"{_holder(lock)} is changing the spec of this project: wait for it to finish, "
                                f"or, if no archvow is running, delete {WRITE_LOCK_REL.as_posix()}") from None
            time.sleep(0.1)
            continue
        break
    try:
        with os.fdopen(handle, "w", encoding="utf-8") as out:
            out.write(f"{socket.gethostname()}:{os.getpid()} archvow (pid {os.getpid()})\n")
        yield
    finally:
        with contextlib.suppress(OSError):
            lock.unlink()


T = TypeVar("T")
_LOADER = getattr(yaml, "CSafeLoader", yaml.SafeLoader)  # libyaml when available: same result, much faster


@functools.lru_cache(maxsize=1024)
def _parse(text: str) -> object:
    return yaml.load(text, Loader=_LOADER)


def parse_python(text: str) -> ast.Module:
    """A Python source's tree, parsed once per text while a command only reads: check's families, the views and
    the evidence all read the same code and tests (ISSUE-032). Shared: no caller changes it. SyntaxError as from
    ast.parse."""
    return once.remember(("python", text), lambda: ast.parse(text))


def walked(tree: ast.AST) -> list[ast.AST]:
    """Every node of a tree, in ast.walk's order: walked once per tree while a command only reads. Kept by the
    tree's id: the list holds the tree (its first node), so no other tree can take that id meanwhile."""
    return once.remember(("walked", id(tree)), lambda: list(ast.walk(tree)))


def parse_yaml(text: str) -> object:
    """Parse YAML safely. A command reads the same files many times: the parse is cached by
    content (never stale) and every caller gets its own copy to change."""
    return plain_copy(_parse(text))


def plain_copy(value: T) -> T:
    """A deep copy of plain data (dicts, lists, text, numbers): marshal's, about four times as fast as
    copy.deepcopy - every caller of the spec and of a YAML file gets its own copy (ISSUE-032). Anything marshal
    does not know (a date, a dict subclass) is copied by deepcopy."""
    try:
        return marshal.loads(marshal.dumps(value))  # type: ignore[arg-type, no-any-return]
    except ValueError:
        return copy.deepcopy(value)
