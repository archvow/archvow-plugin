"""The short digests archvow stores in vows: 12 hexadecimal characters of a sha256. They are written in
committed files (template questions, briefs, business examples), so the way each is computed never
changes: a different value would look like a changed question or a changed brief."""

from __future__ import annotations

import hashlib
import os
import time
from collections.abc import Callable, Iterable
from pathlib import Path

from archvow.foundation import logs

log = logs.get("hashing")
LENGTH = 12
RACY_NS = 2_000_000_000  # a file saved this recently may change again within its time stamp: its content counts


def short_digest(text: str) -> str:
    """The digest of a text, as stored for template questions (vow `template_question`)."""
    return hashlib.sha256(str(text).encode("utf-8")).hexdigest()[:LENGTH]


def text_digest(text: str) -> str:
    """The digest of a text blind to trailing spaces and to blank lines at the ends (a brief's section)."""
    normal = "\n".join(line.rstrip() for line in text.strip().splitlines())
    return short_digest(normal)


def parts_digest(parts: Iterable[tuple[str, bytes]]) -> str:
    """The digest of named contents in order: each name and content followed by a NUL byte, Windows line
    endings read as LF (a business example: its input/, expected/ and scenario.feature files)."""
    digest = hashlib.sha256()
    for name, content in parts:
        digest.update(name.encode("utf-8") + b"\0")
        digest.update(content.replace(b"\r\n", b"\n") + b"\0")
    return digest.hexdigest()[:LENGTH]


def _on_the_way(rel: str, kept: list[str]) -> bool:
    """Whether a folder is one of `kept`, inside one, or holds one."""
    return any(k == rel or k.startswith(f"{rel}/") or rel.startswith(f"{k}/") for k in kept)


def tree_state(root: Path, skip: Iterable[str] = (), keep: Iterable[str] = (),
               skip_dir: Callable[[str], bool] | None = None) -> str:
    """A digest of what a folder holds now - each file's path, size and modification time, `.git` and the folders
    named in `skip` and those `skip_dir` refuses (their path from the root) left out, except in or on the way to a
    folder of `keep` (paths from the root): equal digests mean nothing was added, removed, saved or touched
    (`archvow workspace --since`). Each file's change time counts too (st_ctime): the system sets it on every
    write, and also when a tool sets the modification time back, so an edit with its old time restored is seen. A
    file saved in the last 2 seconds counts by its content too: a save of the same size within the same time stamp
    changes the digest. Never stored: it only tells a tool that its last answer still holds."""
    skipped, kept, now = {".git", *skip}, [k.strip("/") for k in keep], time.time_ns()
    digest = hashlib.sha256()
    for folder, dirs, files in os.walk(root):
        here = Path(folder).relative_to(root)
        dirs[:] = sorted(d for d in dirs if (d not in skipped and not (skip_dir and skip_dir((here / d).as_posix())))
                         or _on_the_way((here / d).as_posix(), kept))
        prefix = "" if here == Path() else f"{here.as_posix()}/"  # each file's path from the root, as text: fast
        for name in sorted(files):
            path = Path(folder) / name
            try:
                info = os.stat(os.path.join(folder, name))
            except OSError:
                logs.swallowed(log, "tree_state: OSError")
                continue  # removed while walking: the next call sees it gone
            digest.update(f"{prefix}{name}\0{info.st_size}\0{info.st_mtime_ns}\0{_changed(info)}\0".encode())
            if now - info.st_mtime_ns < RACY_NS:  # Git's "racy" rule: a same-size save in the same tick changes it
                digest.update(_content(path))
    return digest.hexdigest()[:LENGTH]


def _content(path: Path) -> bytes:
    try:
        return hashlib.sha256(path.read_bytes()).digest()
    except OSError:
        logs.swallowed(log, "_content: OSError")
        return b""


def _changed(info: os.stat_result) -> int:
    """When the file's data or its metadata last changed (POSIX st_ctime): no tool can set it. Windows has no such
    time (its st_ctime is the creation's until Python 3.12): 0 there, its digest reads size and times only."""
    return 0 if os.name == "nt" else info.st_ctime_ns
