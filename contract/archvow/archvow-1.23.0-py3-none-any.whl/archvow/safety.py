"""Safety checks: what must never happen, and the evidence that it cannot.

Principles (from critical-systems practice, adapted to data pipelines):

* Few essential properties, verified without compromise. Hazards are found systematically
  (HAZOP-style guide words per component, ARCH035); each critical/high hazard needs an
  invariant (ARCH030) verified by a method strong enough for its severity (ARCH037).
* Trust the verifier, not the implementer. An invariant counts as verified only with
  machine-checkable evidence: a pytest test marked ``@pytest.mark.invariant("clean_orders.INV1")``
  (a Hypothesis ``@given`` test for property_test), a ``# archvow: enforces[clean_orders.INV1]``
  runtime guard in the component, an archvow rule add at error severity, or a model/proof file
  checked by its own tool in CI (ARCH031, ARCH032).
* No silent design decisions. A component cannot be implemented while a decision is still
  to make (ARCH033) or while it relies on an assumption nobody reviewed yet (ARCH034).
"""

from __future__ import annotations

import ast
import re
from collections import defaultdict
from pathlib import Path
from typing import TYPE_CHECKING

from archvow import manifest as mf
from archvow.check import ComponentStatus
from archvow.foundation import logs

log = logs.get("safety")

if TYPE_CHECKING:
    from archvow.check import _Checker
    from archvow.templates import Template

ENFORCES_RE = re.compile(r"#\s*archvow:\s*enforces\[([A-Za-z0-9_., -]+)\]")
SEVERITIES = ("critical", "high", "medium", "low")
METHODS = ("static", "example_test", "property_test", "runtime", "model_check", "proof")
SKIP_DIRS = {"venv", "env", "build", "dist", "node_modules", "__pycache__", "site-packages"}
MANIFEST = mf.PROJECT_REL.as_posix()


def _python_files(base: Path) -> list[Path]:
    if not base.is_dir():
        return []
    return [p for p in sorted(base.rglob("*.py"))
            if not any(part.startswith(".") or part in SKIP_DIRS for part in p.relative_to(base).parts[:-1])]


def _decorator_name(node: ast.expr) -> str:
    target = node.func if isinstance(node, ast.Call) else node
    if isinstance(target, ast.Attribute):
        return target.attr
    if isinstance(target, ast.Name):
        return target.id
    return ""


def collect_test_evidence(root: Path) -> dict[str, list[dict]]:
    """INV id -> tests marked with it: {file, line, test, property}."""
    evidence: dict[str, list[dict]] = defaultdict(list)
    for path in _python_files(root / "tests"):
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
        except (SyntaxError, UnicodeDecodeError):  # not UTF-8: the "not tested" message names it
            logs.swallowed(log, "collect_test_evidence: SyntaxError, UnicodeDecodeError")
            continue
        for node in ast.walk(tree):
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            names = [_decorator_name(d) for d in node.decorator_list]
            is_property = "given" in names
            for deco in node.decorator_list:
                if isinstance(deco, ast.Call) and _decorator_name(deco) == "invariant":
                    for arg in deco.args:
                        if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
                            evidence[arg.value].append({
                                "file": path.relative_to(root).as_posix(), "line": node.lineno,
                                "test": node.name, "property": is_property})
    return evidence


def decision_tests(root: Path, test_file: str, number: int) -> list[dict]:
    """The tests of one test file marked @pytest.mark.decision(number): {file, line, test, property}."""
    path = root / test_file
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"))
    except (OSError, SyntaxError, UnicodeDecodeError):
        logs.swallowed(log, "decision_tests: OSError, SyntaxError, UnicodeDecodeError")
        return []
    found = []
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        names = [_decorator_name(d) for d in node.decorator_list]
        for deco in node.decorator_list:
            if isinstance(deco, ast.Call) and _decorator_name(deco) == "decision" and any(
                    isinstance(a, ast.Constant) and str(a.value) == str(number) for a in deco.args):
                found.append({"file": test_file, "line": node.lineno, "test": node.name, "property": "given" in names})
    return found


def collect_runtime_evidence(root: Path, containers: list[dict]) -> dict[str, list[str]]:
    """INV id -> source files containing `# archvow: enforces[<component>.INV<n>]`."""
    found: dict[str, list[str]] = defaultdict(list)
    for container in containers:
        for path in _python_files(root / container["path"]):
            for match in ENFORCES_RE.finditer(path.read_text(encoding="utf-8", errors="replace")):
                for inv in (i.strip() for i in match.group(1).split(",")):
                    found[inv].append(path.relative_to(root).as_posix())
    return found


def run_safety(checker: _Checker) -> None:
    root = checker.root
    data = checker.manifest
    containers = data.get("containers", [])
    hazards = data.get("hazards", []) or []
    invariants = data.get("invariants", []) or []

    components: dict[str, tuple[dict, dict, Template | None]] = {}
    for container in containers:
        for comp in container.get("components", []):
            components[comp["id"]] = (container, comp, checker.templates.get(container["id"]))
    template = next(iter(checker.templates.values()), None)
    guide_words = (template.data.get("guide_words", {}) if template else {}) or {}
    floor = (template.data.get("verification_floor", {}) if template else {}) or {}

    _validate(checker, hazards, invariants, components, guide_words)
    known_types = {comp.get("type") for _, comp, _ in components.values()} | {
        t for _, _, tpl in components.values() if tpl for t in tpl.component_types}
    for rule in data.get("project_rules") or []:
        scope = rule.get("scope") or {}
        unknown = [c for c in scope.get("components") or [] if c not in components]
        problems = [f"unknown component(s) {', '.join(unknown)}"] if unknown else []
        if scope.get("type") and scope["type"] not in known_types:
            problems.append(f"unknown component type '{scope['type']}'")
        if not str(rule.get("text", "")).strip():
            problems.append("no text")
        for problem in problems:
            checker.add("ARCH036", f"rule {rule.get('id')}: {problem}", MANIFEST)
    for dismissal in data.get("dismissed") or []:
        problems = []
        if dismissal.get("component") and dismissal["component"] not in components:
            problems.append(f"unknown component '{dismissal['component']}'")
        if guide_words and dismissal.get("guide_word") not in guide_words:
            problems.append(f"unknown guide word '{dismissal.get('guide_word')}'")
        if not str(dismissal.get("rationale", "")).strip():
            problems.append("no reason given")
        for problem in problems:
            checker.add("ARCH036", f"dismissal of {dismissal.get('component') or 'system'} "
                        f"{dismissal.get('guide_word')}: {problem}", MANIFEST)
    hazard_by_id = {h.get("id"): h for h in hazards}

    # ARCH030: every critical/high hazard is guarded by at least one invariant
    mitigated = {h for inv in invariants for h in inv.get("mitigates", []) or []}
    for hazard in hazards:
        if hazard.get("severity") in ("critical", "high") and hazard.get("id") not in mitigated:
            target = hazard.get("component") or "system"
            checker.add("ARCH030", f"'{target}': {hazard['id']} ({hazard['severity']}) "
                        f"'{hazard.get('description')}' is prevented by no invariant (what is always true, so "
                        f"it cannot happen) -> archvow invariant add {target} \"...\" --prevents {hazard['id']}",
                        MANIFEST)

    # implementation status per component, from the symbol statuses of the main check
    planned: set[str] = set()
    seen: set[str] = set()
    for status in checker.report.statuses:
        seen.add(status.component)
        if status.status == "planned":
            planned.add(status.component)
    implemented = {cid for cid in components if cid in seen and cid not in planned}

    blocked: set[str] = set()  # components with their own safety errors

    # evidence
    tests = collect_test_evidence(root)
    runtime = collect_runtime_evidence(root, containers)
    verified: dict[str, bool] = {}
    report_invariants = []
    for inv in invariants:
        ok, detail = _verify(checker, inv, tests, runtime, components)
        verified[inv.get("id")] = ok
        severities = [hazard_by_id.get(h, {}).get("severity") for h in inv.get("mitigates", []) or []]
        report_invariants.append({"id": inv.get("id"), "component": inv.get("component"),
                                  "statement": inv.get("statement"), "verify": inv.get("verify"),
                                  "verified": ok, "evidence": detail,
                                  "severity": _worst(severities)})
        # ARCH037: the few essential properties are verified without compromise
        for severity in severities:
            allowed = floor.get(severity)
            if allowed and inv.get("verify") not in allowed:
                checker.add("ARCH037", f"{inv.get('id')} prevents a {severity} hazard: a {inv.get('verify')} is "
                            f"not enough, it needs one of {', '.join(allowed)} -> archvow invariant add "
                            f"{inv.get('component') or 'system'} \"...\" --prevents "
                            f"{','.join(inv.get('mitigates') or [])}", MANIFEST)
                break
        cid = inv.get("component")
        must_have = (cid in implemented) if cid else checker.complete
        if not ok and must_have:
            if cid:
                blocked.add(cid)
            where = f"'{cid}' is implemented but" if cid else "system invariant:"
            mark = (f"@pytest.mark.decision({inv['from_decision']})" if inv.get("from_decision")
                    else f'@pytest.mark.invariant("{inv.get("id")}")')
            how = {"example_test": f"mark a test {mark}",
                   "property_test": f"mark a Hypothesis @given test {mark}",
                   "runtime": f"add a guard marked  # archvow: enforces[{inv.get('id')}]  in its file"}
            fix = f" -> {how[inv.get('verify')]}" if inv.get("verify") in how else ""
            if cid and cid in components and inv.get("verify") in ("example_test", "property_test"):
                fix += f" in {mf.test_path(components[cid][1])}"
            fix += _near_miss(inv.get("id"), tests, {i.get("id") for i in invariants})
            if inv.get("verify") in ("example_test", "property_test"):
                from archvow.evidence import unreadable_hint

                fix += unreadable_hint(root)
            checker.add("ARCH031", f"{where} {inv.get('id')} '{inv.get('statement')}' is not tested yet "
                        f"({inv.get('verify')}){fix}", MANIFEST)
    checker.report.invariants = report_invariants

    # per component: questions, assumptions, guide-word coverage, status
    from archvow import proposals as ai

    proposed = set(ai.by_question(root)) if ai.mode(data) != "strict" else set()
    analysed = mf.answered_safety(data)
    total = answered = 0
    drift_files = {v.file for v in checker.report.violations if v.severity == "error"}
    for cid, (container, comp, comp_template) in components.items():
        ctype = comp_template.type_of(comp) if comp_template else {}
        open_questions = [d for n, d in enumerate(comp.get("decisions", []) or [], 1)
                          if not (d.get("answer") or "").strip() and (cid, n) not in proposed]  # proposed: no block
        # an assumption blocks until a person reviews it; a rejected one no longer blocks: the spec card
        # tells the implementer not to rely on it
        pending = [a for a in comp.get("assumptions", []) or [] if a.get("status", "proposed") == "proposed"]
        if cid in implemented and open_questions:
            blocked.add(cid)
            checker.add("ARCH033", f"'{cid}' is implemented but {len(open_questions)} decision(s) are still to make, "
                        f"e.g. '{open_questions[0]['question']}' - the code made a silent choice "
                        + (f"-> archvow show {cid}, then archvow decision make {cid} <number> \"...\""
                           if ai.mode(data) == "strict" else
                           f"-> the AI records its choice: archvow decision propose {cid} <number> \"...\""),
                        mf.where(cid))
        if cid in implemented and pending:
            blocked.add(cid)
            numbers = ", ".join(str(n) for n, a in enumerate(comp.get("assumptions", []) or [], 1) if a in pending)
            checker.add("ARCH034", f"'{cid}' relies on {len(pending)} assumption(s) nobody reviewed yet "
                        f"(number {numbers}), e.g. '{pending[0].get('text')}' -> archvow show {cid}, then a person "
                        f"runs archvow assumption accept {cid} <number>, or reject (the code must then not rely "
                        "on it)", mf.where(cid))
        for number, word in enumerate(ctype.get("guide_words", []) or [], 1):
            total += 1
            answered += (cid, word) in analysed
            if (cid, word) not in analysed:
                checker.add("ARCH035", f"'{cid}': safety question S{number} not answered ({word}) - "
                            f"{guide_words.get(word, word)} -> archvow show {cid}", mf.where(cid))
        comp_invariants = [i for i in invariants if i.get("component") == cid]
        file = mf.source_path(container, comp)
        tested = (root / mf.test_path(comp)).is_file()
        if cid in implemented and tested:
            _check_marks(checker, data, comp)
        n_verified = sum(1 for i in comp_invariants if verified.get(i.get("id")))
        kind = ctype.get("test", "none") if ctype else "none"
        if cid in implemented and kind != "none" and not tested:
            blocked.add(cid)
            checker.add("ARCH017", f"'{cid}' is implemented but has no {kind} test: {mf.test_path(comp)}",
                        MANIFEST)
        if file in drift_files or cid in blocked:
            status = "drift"
        elif cid not in implemented:
            status = "planned"
        elif not tested:
            status = "implemented"
        elif n_verified == len(comp_invariants) and comp_invariants:
            status = "verified"
        else:
            status = "tested"
        checker.report.components.append(ComponentStatus(
            container=container["id"], component=cid, type=comp.get("type", ""), layer=comp.get("layer", ""),
            status=status, tested=tested, invariants_total=len(comp_invariants),
            invariants_verified=n_verified, open_questions=len(open_questions),
            pending_assumptions=len(pending),
            hazards=sum(1 for h in hazards if h.get("component") == cid)))
    checker.report.safety = {"answered": answered, "total": total}


def _check_marks(checker: _Checker, data: dict, comp: dict) -> None:
    """ARCH038: each decision made and each rule of a coded component has a test marked with it."""
    from archvow.specs import rules_for
    from archvow.tasks import collect_marks

    marks = collect_marks(checker.root / mf.test_path(comp))
    decisions = [str(n) for n, d in enumerate(comp.get("decisions", []) or [], 1)
                 if (d.get("answer") or "").strip() and str(n) not in marks["decision"]]
    rules = [r["id"] for r in rules_for(data, comp) if r["id"].upper() not in marks["rule"]]
    if not decisions and not rules:
        return
    missing = ([f"decision{'s' if len(decisions) > 1 else ''} {', '.join(decisions)}"] if decisions else []) + \
              ([f"rule{'s' if len(rules) > 1 else ''} {', '.join(rules)}"] if rules else [])
    example = f"@pytest.mark.decision({decisions[0]})" if decisions else f'@pytest.mark.rule("{rules[0]}")'
    checker.add("ARCH038", f"'{comp['id']}': {' and '.join(missing)} without a marked test -> mark the test "
                f"of each one in {mf.test_path(comp)}, e.g. {example}", mf.test_path(comp))


def _worst(severities: list[str | None]) -> str | None:
    ranked = [s for s in SEVERITIES if s in severities]
    return ranked[0] if ranked else None


def _near_miss(inv_id: str, tests: dict, known: set) -> str:
    """A mark that almost names the invariant (INV1, "clean_orders INV1", INV-1 for clean_orders.INV1):
    say how to write it. Marks of other invariants are never a near miss."""
    short = inv_id.rsplit(".", 1)[-1]
    norm = lambda key: key.replace(" ", ".").replace("-", "")
    found = [t for key, marks in tests.items() if key not in known and norm(key) in (inv_id, short)
             for t in marks]
    if not found:
        return ""
    t = found[0]
    return f" (found a mark that almost names it in {t['file']}:{t['line']}: write invariant(\"{inv_id}\"))"


def _verify(checker: _Checker, inv: dict, tests: dict, runtime: dict,
            components: dict) -> tuple[bool, list[str]]:
    inv_id = inv.get("id")
    method = inv.get("verify")
    marked = list(tests.get(inv_id, []))
    cid = inv.get("component")
    if inv.get("from_decision") and cid in components:  # the invariant IS decision N: its test proves it
        marked += decision_tests(checker.root, mf.test_path(components[cid][1]), int(inv["from_decision"]))
    if method == "example_test":
        return bool(marked), [f"{t['file']}::{t['test']}" for t in marked]
    if method == "property_test":
        props = [t for t in marked if t["property"]]
        for t in marked:
            if not t["property"]:
                checker.add("ARCH032", f"{inv_id} is verified by property_test but {t['test']} has no "
                            "Hypothesis @given (example tests do not search for counterexamples)",
                            t["file"], t["line"])
        return bool(props), [f"{t['file']}::{t['test']}" for t in props]
    if method == "runtime":
        files = runtime.get(inv_id, [])
        cid = inv.get("component")
        if cid and cid in components:
            container, comp, _ = components[cid]
            own = f"{container['path']}/" + "/".join(comp["module"].split(".")[1:]) + ".py"
            files = [f for f in files if f == own]
        return bool(files), files
    if method in ("model_check", "proof"):
        evidence = inv.get("evidence")
        if evidence and (checker.root / evidence).is_file():
            return True, [evidence]
        if evidence:
            checker.add("ARCH032", f"{inv_id}: evidence file '{evidence}' does not exist", MANIFEST)
        return False, []
    if method == "static":
        rule = inv.get("rule")
        if rule in checker.rules and checker.settings.get(rule, {}).get("severity") == "error":
            return True, [f"rule {rule}"]
        checker.add("ARCH032", f"{inv_id}: static rule '{rule}' is unknown or not at error severity", MANIFEST)
        return False, []
    return False, []


def _validate(checker: _Checker, hazards: list[dict], invariants: list[dict],
              components: dict, guide_words: dict) -> None:
    seen: set[str] = set()
    for hazard in hazards:
        hid = hazard.get("id", "?")
        problems = []
        if hid in seen:
            problems.append("duplicate id")
        seen.add(hid)
        if hazard.get("component") and hazard["component"] not in components:
            problems.append(f"unknown component '{hazard['component']}'")
        if guide_words and hazard.get("guide_word") not in guide_words:
            problems.append(f"unknown guide word '{hazard.get('guide_word')}'")
        if hazard.get("severity") not in SEVERITIES:
            problems.append(f"severity must be one of {', '.join(SEVERITIES)}")
        if not str(hazard.get("description", "")).strip():
            problems.append("description is empty")
        for problem in problems:
            checker.add("ARCH036", f"hazard {hid}: {problem}", MANIFEST)
    known_hazards = {h.get("id") for h in hazards}
    seen = set()
    for inv in invariants:
        iid = inv.get("id", "?")
        problems = []
        if iid in seen:
            problems.append("duplicate id")
        seen.add(iid)
        if inv.get("component") and inv["component"] not in components:
            problems.append(f"unknown component '{inv['component']}'")
        if inv.get("verify") not in METHODS:
            problems.append(f"verify must be one of {', '.join(METHODS)}")
        missing = [h for h in inv.get("mitigates", []) or [] if h not in known_hazards]
        if missing:
            problems.append(f"mitigates unknown hazard(s) {', '.join(missing)}")
        if not inv.get("mitigates"):
            problems.append("must mitigate at least one hazard (why does it exist?)")
        if not str(inv.get("statement", "")).strip():
            problems.append("statement is empty")
        for problem in problems:
            checker.add("ARCH036", f"invariant {iid}: {problem}", MANIFEST)
