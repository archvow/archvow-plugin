"""What a person must look at again after a component changes: the items recorded before (ARCH057).

A decision, a hazard, an invariant, a "not applicable" answer, an accepted assumption or a business
example is recorded against what the component is: its description, its signature, its routes. When one
of those changes (`archvow component edit -d / --signature / -r`), what was recorded may no longer hold -
"keep the rows where amount > 0" when the description now says "> 1". archvow cannot tell, so it deletes
nothing: each of those items gets a line `review "<what> changed on <date>"` in the component's vow.

- `archvow show <component>` lists them, the card tells the AI to stop, `archvow next` says the component
  is blocked, and `archvow check` warns (ARCH057; an error with --complete, the release gate).
- Recording an item again (decision make, assumption accept/reject, example add, hazard / invariant /
  not applicable changed or removed and added again, hazard edit) takes its line away.
- When every one still holds as it is, a person runs `archvow component accept <component>`: the lines go,
  and each item is signed again by that person, on that day.
"""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

from archvow import manifest as mf

WHAT = ("description", "signature", "routes")  # what a component is: a change makes its items to review


def what_changed(before: dict, after: dict) -> list[str]:
    """Which of the description, the signature and the routes differ between two states of a component."""
    def signature(comp: dict) -> str:
        symbols = comp.get("symbols") or []
        return str(symbols[0].get("signature") or "") if symbols and symbols[0].get("kind", "function") == "function" else ""

    def routes(comp: dict) -> list:
        return [(s.get("name"), s.get("method"), s.get("path")) for s in comp.get("symbols") or [] if s.get("kind") == "route"]

    changed = []
    if (before.get("description") or "") != (after.get("description") or ""):
        changed.append("description")
    if signature(before) != signature(after):
        changed.append("signature")
    if routes(before) != routes(after):
        changed.append("routes")
    return changed


def _short(item_id: str) -> str:
    return str(item_id).rsplit(".", 1)[-1]


def recorded(data: dict, comp: dict) -> list[tuple[str, dict]]:
    """The items recorded for a component, with their label: decision 1, hazard H1, example pays..."""
    cid = comp["id"]
    found = [(f"decision {n}", d) for n, d in enumerate(comp.get("decisions") or [], 1)
             if d.get("answer") and d.get("origin") != mf.TYPE_ORIGIN]  # a type's answer is the project's, not here
    found += [(f"assumption {n}", a) for n, a in enumerate(comp.get("assumptions") or [], 1)
              if a.get("status") == "accepted"]
    found += [(f"hazard {_short(h['id'])}", h) for h in data.get("hazards") or [] if h.get("component") == cid]
    found += [(f"invariant {_short(i['id'])}", i) for i in data.get("invariants") or [] if i.get("component") == cid]
    found += [(f"not applicable ({d.get('guide_word')})", d) for d in data.get("dismissed") or []
              if d.get("component") == cid]
    found += [(f"example {e.get('name')}", e) for e in comp.get("examples") or []]
    return found


def today() -> str:
    return datetime.now(UTC).date().isoformat()


def mark(data: dict, comp: dict, changed: list[str]) -> list[str]:
    """After a change of the component: every item recorded before gets its review line. The labels."""
    if not changed:
        return []
    day = datetime.now(UTC).date().isoformat()
    words = " and ".join(changed)
    labels = []
    for label, item in recorded(data, comp):
        item["review"] = f"{words} changed on {day}"
        labels.append(label)
    return labels


def pending(data: dict, comp: dict) -> list[tuple[str, str]]:
    """The items of a component still to review: (label, why)."""
    return [(label, item["review"]) for label, item in recorded(data, comp) if item.get("review")]


_FR_ITEMS = {"decision": "décision", "assumption": "hypothèse", "hazard": "hazard", "invariant": "invariant",
             "example": "exemple", "not applicable": "sans objet"}
_FR_WHAT = {"description": "la description", "signature": "la signature", "routes": "les routes"}


def localized(due: list[tuple[str, str]], language: str) -> list[str]:
    """The items to review as the spec card says them: "decision 1 (description changed on 2026-10-30)";
    in French "décision 1 (la description a changé le 2026-10-30)"."""
    if language != "fr":
        return [f"{label} ({why})" for label, why in due]
    out = []
    for label, why in due:
        for en, fr in _FR_ITEMS.items():
            if label.startswith(en):
                label = fr + label[len(en):]
                break
        words, _, day = why.partition(" changed on ")
        what = " et ".join(_FR_WHAT.get(w, "la décision " + w[9:] if w.startswith("decision ") else w)
                           for w in words.split(" and "))
        out.append(f"{label} ({what} {'ont' if ' et ' in what or what == 'les routes' else 'a'} changé le {day})")
    return out


def accept(root: Path, component_id: str) -> list[str]:
    """A person looked at every item to review and each still holds: the lines go, the items are signed again."""
    from archvow import specs

    data = mf.load(root)
    _, comp = specs.find_component(data, component_id)
    due = [(label, item) for label, item in recorded(data, comp) if item.get("review")]
    created = comp.get("origin") == "ai"
    if not due and not created:
        raise specs.SpecError(f"'{component_id}' has nothing to review (archvow show {component_id})")
    signed = specs.stamp(root)
    for _, item in due:
        item.pop("review", None)
        item.update(signed)
    labels = [label for label, _ in due]
    if created:  # created by the AI: a person takes it as the team's own
        labels.insert(0, f"the component (created by {comp.pop('created_by', 'the AI')})")
        comp.pop("origin", None)
        comp["accepted"] = signed
    mf.save(root, data)
    return labels


def message(cid: str, due: list[tuple[str, str]]) -> str:
    """ARCH057's words: what changed, which items, the commands."""
    why = sorted({w for _, w in due})
    first_decision = next((label.split()[1] for label, _ in due if label.startswith("decision ")), None)
    change = (f"archvow decision make {cid} {first_decision} \"...\"" if first_decision
              else f"record it again (archvow show {cid} gives each command)")
    return (f"'{cid}': its {'; '.join(why)}, after {', '.join(label for label, _ in due)} "
            f"{'was' if len(due) == 1 else 'were'} recorded - each may no longer hold -> look at them: "
            f"archvow show {cid}; change one by recording it again ({change}); when every one still holds: "
            f"archvow component accept {cid}")


def run_review(checker) -> None:
    """ARCH057: items recorded before their component changed, not looked at again by a person."""
    for container in checker.manifest.get("containers", []):
        for comp in container.get("components", []):
            due = pending(checker.manifest, comp)
            if due:
                checker.add("ARCH057", message(comp["id"], due),
                            f"{mf.COMPONENTS_REL.as_posix()}/{comp['id']}/{mf.COMPONENT_FILE}", escalate=checker.complete)
