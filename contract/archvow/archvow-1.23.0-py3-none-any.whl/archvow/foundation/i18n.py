"""Translations of the texts archvow writes into a project (specs, status report, guide files, the guide of
each finding).

archvow itself - its commands, options, --help and messages - stays in English. What it generates for a
project follows the project's language (`language` in .archvow/spec.vow, English when absent). The English
text is the key: `tr("fr", "## Must never happen")`. Keywords stay as they are in every language: rule
codes, statuses, severities, guide words, verification methods.

The translations live in locale files, one per language: resources/archvow/locales/<lang>.yaml, with
`texts` (English text -> translation) and `words` (small vocabularies such as the task summaries'). Adding
a language = adding its file; a test checks every language has every text.
"""

from __future__ import annotations

from functools import cache
from pathlib import Path
from typing import Any

import yaml

LOCALES = Path(__file__).resolve().parent.parent / "resources" / "archvow" / "locales"
MISSING: set[tuple[str, str]] = set()  # texts asked in a language that has no translation (tests read it)


@cache
def locale(language: str) -> dict[str, Any]:
    """The locale file of a language ({} for English and for a language without a file)."""
    path = LOCALES / f"{language}.yaml"
    if language == "en" or not path.is_file():
        return {}
    data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    return data if isinstance(data, dict) else {}


def languages() -> tuple[str, ...]:
    """English, then every language that has a locale file."""
    return ("en", *sorted(p.stem for p in LOCALES.glob("*.yaml")))


def texts(language: str) -> dict[str, str]:
    found = locale(language).get("texts") or {}
    return found if isinstance(found, dict) else {}


def words(language: str, group: str) -> dict[str, Any] | None:
    """A vocabulary of the locale file (`words: {group: {...}}`), None when the language has none."""
    found = (locale(language).get("words") or {}).get(group)
    return found if isinstance(found, dict) else None


def tr(language: str | None, text: str, /, **values: object) -> str:
    """`text` in `language` (unchanged when there is no translation), with `values` filled in."""
    language = language or "en"
    translated = text
    if language != "en" and text and locale(language):
        catalogue = texts(language)
        translated = catalogue.get(text, text)
        if text not in catalogue:
            MISSING.add((language, text))
    return translated.format(**values) if values else translated
