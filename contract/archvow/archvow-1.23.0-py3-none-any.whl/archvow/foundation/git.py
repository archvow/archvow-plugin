"""The one way archvow runs git: `git(root, ...)` returns the output or raises GitError, `git_or_none`
returns None instead (no Git, not a repository, a reference that does not exist). Every call is logged at
debug level with its duration (archvow -vv)."""

from __future__ import annotations

import shutil
import subprocess
import time
from pathlib import Path

from archvow.foundation import logs
from archvow.foundation.errors import GitError

log = logs.get("git")


def _run(root: Path, args: tuple[str, ...], stdin: str | None, timeout: float | None) -> subprocess.CompletedProcess[str]:
    start = time.perf_counter()
    try:
        done = subprocess.run(["git", "-C", str(root), *args], capture_output=True, text=True, input=stdin,
                              check=False, encoding="utf-8", errors="replace", timeout=timeout)
    except (OSError, subprocess.SubprocessError) as exc:
        log.debug("git %s: %s", " ".join(args[:2]), type(exc).__name__)
        raise
    ms = round((time.perf_counter() - start) * 1000)
    log.debug("git %s: exit %d (%d ms)", " ".join(args[:2]), done.returncode, ms, extra={"duration_ms": ms})
    return done


def git(root: Path, *args: str, stdin: str | None = None, timeout: float | None = None) -> str:
    """git's output; GitError with git's own message when it fails or is not installed."""
    try:
        done = _run(root, args, stdin, timeout)
    except FileNotFoundError as exc:
        raise GitError("git is not installed") from exc
    except (OSError, subprocess.SubprocessError) as exc:
        raise GitError(f"git {' '.join(args)} failed ({type(exc).__name__})") from exc
    if done.returncode != 0:
        raise GitError(done.stderr.strip() or f"git {' '.join(args)} failed")
    return done.stdout


def git_or_none(root: Path, *args: str, stdin: str | None = None, timeout: float | None = None) -> str | None:
    """git's output, or None when git is missing or the command fails."""
    try:
        done = _run(root, args, stdin, timeout)
    except (OSError, subprocess.SubprocessError):
        return None
    return done.stdout if done.returncode == 0 else None


def available() -> bool:
    """Whether a git command can be found (on the PATH)."""
    return shutil.which("git") is not None


def succeeds(root: Path, *args: str, timeout: float | None = None) -> bool:
    """Whether the git command runs and exits 0 (git missing: False)."""
    try:
        return _run(root, args, None, timeout).returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False
