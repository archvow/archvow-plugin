"""Small text helpers used across archvow: a value as one line, a Markdown table cell, the placeholder
guard, and the words that mean "nothing" in an answer."""

from __future__ import annotations

import re

from archvow.foundation.errors import SpecError

# A placeholder left from an example: "<column>", "<colonne clé>" - never "a < b" or "x <= 0".
PLACEHOLDER_RE = re.compile(r"<[^\W\d_][^<>\n]*[^\W_]>|<[^\W\d_]>")

# Answers that say there is nothing: "none", "no", "aucune", "n/a" - alone, or before a few words
# ("none - no column holds personal data"). Such a decision answers its safety question "not applicable",
# and a run line has no argument for it.
NOTHING_WORDS = {"none", "no", "nothing", "n/a", "na", "-", "aucun", "aucune", "rien", "non", "néant", "neant",
                 "sans objet", "not applicable", "non applicable", "nobody", "personne"}
NOTHING_RE = re.compile(r"^(none|nothing|aucune?|rien|n/a|néant)\b[\s,.:;-]")
DECISION_SUFFIX_RE = re.compile(r"\s*\((decision|décision) \d+\)\s*$", re.IGNORECASE)


def one_line(text: object) -> str:
    """One line, and no `<...>` placeholder copied from an example: the spec says what is meant."""
    line = " ".join(str(text).split())
    found = PLACEHOLDER_RE.search(line)
    if found:
        raise SpecError(f"'{found.group(0)}' is a placeholder from an example: write the real value "
                        f"instead (in: {line})")
    return line


def md_cell(text: object) -> str:
    """A Markdown table cell: one line, a `|` in the text does not start a new column."""
    return " ".join(str(text).split()).replace("|", "\\|")


def says_nothing(text: str | None) -> bool:
    """Whether an answer (or an invariant's words) says there is nothing: none, no, aucune, n/a..."""
    words = DECISION_SUFFIX_RE.sub("", str(text or "")).strip().lower().rstrip(".!")
    if not words:
        return False
    return words in NOTHING_WORDS or (bool(NOTHING_RE.match(words)) and len(words.split()) <= 8)
