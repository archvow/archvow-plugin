"""Every error archvow reports on purpose has one base, ArchvowError: a message, an optional hint (what to
do about it) and the exit code. `archvow.cli.main` handles them in one place: the message in red on
stderr, and with --json also {"error": {...}} on stdout; anything else is a bug and gets a crash report
(archvow.foundation.logs)."""

from __future__ import annotations


class ArchvowError(Exception):
    """An error archvow explains to the person (exit 2 unless the subclass says otherwise)."""

    exit_code = 2

    def __init__(self, message: object = "", hint: str | None = None) -> None:
        super().__init__(message)
        self.hint = hint

    @property
    def kind(self) -> str:
        """The error's name as tools see it (the JSON envelope's `type`), e.g. SpecError."""
        return type(self).__name__


class SpecError(ArchvowError):
    """A spec change is invalid."""


class TemplateError(ArchvowError):
    """A template pack is missing or invalid."""


class ManifestError(ArchvowError):
    """The spec cannot be found or used."""


class VowError(ArchvowError, ValueError):
    """A .vow file archvow cannot read: the message names the file and the line."""


class GitError(ArchvowError):
    """git is unavailable, failed, or the base reference cannot be resolved."""


class ReviewError(ArchvowError):
    """The review could not run (configuration, git, the reviewer's command)."""


class BriefError(ArchvowError, ValueError):
    """A brief cannot be read or does not have the section named."""


class ProposalError(ArchvowError, ValueError):
    """An AI proposal is refused (strict mode, a decision already made, a wrong number)."""


class LockError(ArchvowError):
    """Another archvow command is changing the spec of this project right now."""
