"""The short digests archvow stores in vows: 12 hexadecimal characters of a sha256. They are written in
committed files (template questions, briefs, business examples), so the way each is computed never
changes: a different value would look like a changed question or a changed brief."""

from __future__ import annotations

import hashlib
from collections.abc import Iterable

LENGTH = 12


def short_digest(text: str) -> str:
    """The digest of a text, as stored for template questions (vow `template_question`)."""
    return hashlib.sha256(str(text).encode("utf-8")).hexdigest()[:LENGTH]


def text_digest(text: str) -> str:
    """The digest of a text blind to trailing spaces and to blank lines at the ends (a brief's section)."""
    normal = "\n".join(line.rstrip() for line in text.strip().splitlines())
    return short_digest(normal)


def parts_digest(parts: Iterable[tuple[str, bytes]]) -> str:
    """The digest of named contents in order: each name and content followed by a NUL byte, Windows line
    endings read as LF (a business example: its input/, expected/ and scenario.feature files)."""
    digest = hashlib.sha256()
    for name, content in parts:
        digest.update(name.encode("utf-8") + b"\0")
        digest.update(content.replace(b"\r\n", b"\n") + b"\0")
    return digest.hexdigest()[:LENGTH]
