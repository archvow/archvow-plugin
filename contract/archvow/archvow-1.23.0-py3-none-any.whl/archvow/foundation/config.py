"""Every environment variable archvow reads, in one place. `settings()` reads them each time it is called
(cheap, and a test or a hook may change one between two commands); nothing else in archvow reads
os.environ for its own settings. The variables that tell archvow an AI agent is running come from the
agent profiles (archvow.agent), not from here: they are the agents', not archvow's."""

from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Settings:
    templates: tuple[str, ...]        # ARCHVOW_TEMPLATES: folders of company templates (os.pathsep-separated)
    protected_branches: tuple[str, ...]  # ARCHVOW_PROTECTED_BRANCHES: refused for commits (default main develop)
    history: str                      # ARCHVOW_HISTORY: the file of earlier answers (default in the cache)
    prompt_colours: bool              # ARCHVOW_PROMPT_COLOURS=1: colours in prompts under libedit (macOS)
    review_command: str               # ARCHVOW_REVIEW_COMMAND: the reviewer's command, instead of the template's
    log: str                          # ARCHVOW_LOG=info|debug: the diagnostic log on stderr (like -v / -vv)
    log_file: str                     # ARCHVOW_LOG_FILE: the diagnostic log as JSON lines in this file
    no_color: bool                    # NO_COLOR: no colours, ever
    force_color: bool                 # FORCE_COLOR: colours even when not a terminal
    dumb_terminal: bool               # TERM=dumb: no colours


def settings() -> Settings:
    env = os.environ
    return Settings(
        templates=tuple(p for p in env.get("ARCHVOW_TEMPLATES", "").split(os.pathsep) if p),
        protected_branches=tuple(env.get("ARCHVOW_PROTECTED_BRANCHES", "main develop").split()),
        history=env.get("ARCHVOW_HISTORY", ""),
        prompt_colours=env.get("ARCHVOW_PROMPT_COLOURS") == "1",
        review_command=env.get("ARCHVOW_REVIEW_COMMAND", "").strip(),
        log=env.get("ARCHVOW_LOG", "").strip(),
        log_file=env.get("ARCHVOW_LOG_FILE", "").strip(),
        no_color=bool(env.get("NO_COLOR")),
        force_color=bool(env.get("FORCE_COLOR")),
        dumb_terminal=env.get("TERM") == "dumb",
    )
