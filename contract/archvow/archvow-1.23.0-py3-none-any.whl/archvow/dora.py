"""DORA (EU Digital Operational Resilience Act, banks and insurers): what archvow can prove.

* DORA001 every component has a ticket; the commit-msg hook puts the branch's ticket in each commit.
* DORA002 separation of duties: at least two people can approve guard changes (CODEOWNERS).
* DORA003 third-party register: every package of requirements.txt has its supplier, licence and
  criticality (`archvow dependency add`); a critical one is pinned (==). DORA006: the licence
  differs from the installed package's metadata.
* DORA004 the tests of invariants cannot be skipped, and no CI job may be allowed to fail. That they ran
  and passed is checked for every project with `check --test-report junit.xml` (ARCH046, evidence.py).
* DORA005 operational questions (O1, O2...) are answered - checked with the question sets.
"""

from __future__ import annotations

import ast
import re
from importlib import metadata
from pathlib import Path
from typing import TYPE_CHECKING

from archvow import manifest as mf
from archvow.foundation import logs

log = logs.get("dora")

if TYPE_CHECKING:
    from archvow.check import _Checker

CRITICALITY = ("critical", "important", "minor")
REQUIREMENT_RE = re.compile(r"^\s*([A-Za-z0-9][A-Za-z0-9._-]*)\s*(\[[^\]]*\])?\s*([<>=!~].*?)?\s*(#.*)?$")
MANIFEST = ".archvow/spec.vow"
CI_FILES = (".gitlab-ci.yml", "Jenkinsfile")
ALLOW_FAILURE_RE = re.compile(r"^\s*(allow_failure|continue-on-error)\s*:\s*true\b", re.M)


def normalise(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name).lower()


def requirements(root: Path) -> list[tuple[str, str, int]]:
    """(package, version specifier, line) of requirements.txt."""
    path = root / "requirements.txt"
    if not path.is_file():
        return []
    found = []
    for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip() or line.lstrip().startswith(("#", "-")):
            continue
        match = REQUIREMENT_RE.match(line)
        if match:
            found.append((match.group(1), (match.group(3) or "").strip(), number))
    return found


def add_dependency(root: Path, name: str, supplier: str, licence: str, criticality: str) -> dict:
    """`archvow dependency add`: record a third party in the register (DORA art. 28)."""
    from archvow.specs import SpecError, _required, stamp

    if criticality not in CRITICALITY:
        raise SpecError(f"criticality is one of {', '.join(CRITICALITY)}")
    data = mf.load(root)
    register = data.setdefault("third_parties", [])
    entry = {"name": _required(name, "the package"), "supplier": _required(supplier, "the supplier"),
             "licence": _required(licence, "the licence"), "criticality": criticality, **stamp(root)}
    register[:] = [e for e in register if normalise(e.get("name", "")) != normalise(name)] + [entry]
    register.sort(key=lambda e: normalise(e["name"]))
    mf.save(root, data)
    return entry


def remove_dependency(root: Path, name: str) -> dict:
    from archvow.specs import SpecError

    data = mf.load(root)
    register = data.get("third_parties") or []
    entry = next((e for e in register if normalise(e.get("name", "")) == normalise(name)), None)
    if entry is None:
        raise SpecError(f"'{name}' is not in the register (archvow show --json lists third_parties)")
    data["third_parties"] = [e for e in register if e is not entry]
    mf.save(root, data)
    return entry


def run_dora(checker: _Checker) -> None:
    root, data = checker.root, checker.manifest
    for container in data.get("containers", []):
        template = checker.templates.get(container["id"])
        for comp in container.get("components", []):
            ctype = template.type_of(comp) if template else {}
            if not ctype.get("addable", True):
                continue  # a template's own foundation (spark, config) comes with init, not a ticket
            if not str(comp.get("spec") or "").strip():
                checker.add("DORA001", f"'{comp['id']}' has no ticket -> archvow component edit {comp['id']} -s <ticket>",
                            MANIFEST)
    where, owners = _code_owners(root)
    if where and len(owners) < 2 and not any("/" in o for o in owners):
        checker.add("DORA002", f"only {', '.join(owners) or 'nobody'} can approve guard changes: an author "
                    "would approve their own change -> archvow init <package> --force -a "
                    "architects=\"@first @second\" (or a group @org/team)", where)
    _check_register(checker, data)
    _check_skips(checker)
    for rel in [*CI_FILES, *(p.relative_to(root).as_posix() for p in sorted((root / ".github/workflows").glob("*.y*ml")))]:
        path = root / rel
        if path.is_file():
            text = path.read_text(encoding="utf-8", errors="replace")
            for match in ALLOW_FAILURE_RE.finditer(text):
                line = text[:match.start()].count("\n") + 1
                checker.add("DORA004", f"{match.group(1)}: true - a failing job must stop the merge", rel, line)


def _code_owners(root: Path) -> tuple[str, list[str]]:
    for rel in ("CODEOWNERS", ".github/CODEOWNERS", ".gitlab/CODEOWNERS", "docs/CODEOWNERS"):
        path = root / rel
        if path.is_file():
            owners = set()
            from archvow.docs import OWNERS_BEGIN

            for line in path.read_text(encoding="utf-8").split(OWNERS_BEGIN)[0].splitlines():  # the architects
                if line.strip() and not line.lstrip().startswith(("#", "[")):
                    owners |= {w for w in line.split()[1:] if w.startswith("@") or "@" in w}
            return rel, sorted(owners)
    return "", []


def unregistered(root: Path, data: dict) -> list[str]:
    """With DORA on: the packages of requirements.txt the third-party register does not have yet
    (archvow itself, after init: its supplier and licence are the team's to state)."""
    if "dora" not in (data.get("compliance") or []):
        return []
    register = {normalise(e.get("name", "")) for e in data.get("third_parties") or []}
    return [name for name, _, _ in requirements(root) if normalise(name) not in register]


def _check_register(checker: _Checker, data: dict) -> None:
    register = {normalise(e.get("name", "")): e for e in data.get("third_parties") or []}
    for name, spec, line in requirements(checker.root):
        entry = register.get(normalise(name))
        if entry is None:
            checker.add("DORA003", f"'{name}' is not in the third-party register -> archvow dependency add "
                        f"{name} --supplier \"...\" --licence \"...\" --criticality critical|important|minor",
                        "requirements.txt", line)
            continue
        if entry.get("criticality") == "critical" and not spec.startswith("=="):
            checker.add("DORA003", f"'{name}' is critical: pin its version with == (now: {spec or 'any'})",
                        "requirements.txt", line)
        installed = _installed_licence(name)
        ours, theirs = licence_family(entry.get("licence", "")), licence_family(installed)
        if ours and theirs and ours != theirs:
            checker.add("DORA006", f"'{name}': registered licence {entry.get('licence')}, installed package "
                        f"says {installed}", "requirements.txt", line)


LICENCE_FAMILIES = (("lgpl", ("lgpl", "lesser general public")), ("agpl", ("agpl", "affero")),
                    ("gpl", ("gpl", "general public")), ("mpl", ("mpl", "mozilla")), ("apache", ("apache",)),
                    ("bsd", ("bsd",)), ("mit", ("mit",)), ("psf", ("psf", "python software foundation")),
                    ("isc", ("isc",)), ("unlicense", ("unlicense",)), ("proprietary", ("proprietary",)))


def licence_family(text: str) -> str:
    """mit, apache, bsd, gpl... - what a licence name and a package's metadata both say ('' if unknown)."""
    lowered = text.lower()
    for family, words in LICENCE_FAMILIES:
        if any(re.search(rf"\b{re.escape(w)}\b", lowered) for w in words):
            return family
    return ""


def _installed_licence(name: str) -> str:
    try:
        meta = metadata.metadata(name)
    except metadata.PackageNotFoundError:
        logs.swallowed(log, "_installed_licence: metadata.PackageNotFoundError")
        return ""
    expression = meta.get("License-Expression") or ""
    if expression:
        return expression
    classifiers = [c.split("::")[-1].strip() for c in meta.get_all("Classifier") or [] if c.startswith("License ::")]
    licence = (meta.get("License") or "").strip()
    return classifiers[0] if classifiers else (licence if 0 < len(licence) < 60 else "")


def _check_skips(checker: _Checker) -> None:
    """DORA004: the test of an invariant cannot be skipped or marked as allowed to fail."""
    tests = checker.root / "tests"
    for path in sorted(tests.rglob("*.py")) if tests.is_dir() else []:
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
        except (SyntaxError, UnicodeDecodeError):
            logs.swallowed(log, "_check_skips: SyntaxError, UnicodeDecodeError")
            continue
        rel = path.relative_to(checker.root).as_posix()
        for node in ast.walk(tree):
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            marks = [ast.unparse(d) for d in node.decorator_list]
            if not any(".invariant(" in m or m.startswith("invariant(") for m in marks):
                continue
            skipped = [m for m in marks if re.search(r"\b(skip|skipif|xfail)\b", m)]
            calls = [n for n in ast.walk(node) if isinstance(n, ast.Call)
                     and re.fullmatch(r"(pytest\.)?(skip|xfail|importorskip)", ast.unparse(n.func))]
            if skipped or calls:
                checker.add("DORA004", f"{node.name} tests an invariant and can be skipped "
                            f"({(skipped or [ast.unparse(calls[0].func)])[0]}) - it must always run", rel, node.lineno)


def third_parties_view(data: dict, tr) -> str:
    lang = data.get("language") or "en"
    T = lambda message, **values: tr(lang, message, **values)
    out = ["<!-- Generated by archvow. Do not edit. -->\n\n",
           T("# Third parties - {name}", name=data["system"]["name"]) + "\n\n",
           T("The register of ICT third-party providers this project depends on (DORA art. 28): every "
             "package of requirements.txt, recorded with `archvow dependency add`.") + "\n\n",
           T("| Package | Supplier | Licence | Criticality | Recorded by | On |") + "\n|---|---|---|---|---|---|\n"]
    register = data.get("third_parties") or []
    for e in register:
        out.append(f"| {e.get('name')} | {e.get('supplier')} | {e.get('licence')} | {e.get('criticality')} | "
                   f"{e.get('by', '-')} | {str(e.get('on', '-'))[:10]} |\n")
    if not register:
        out.append(T("| - | - | - | - | - | none yet: archvow dependency add <package> ... |") + "\n")
    return "".join(out)
