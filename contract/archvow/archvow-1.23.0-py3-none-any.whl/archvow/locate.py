"""From a file (and a line) to the component that owns it: `archvow show <file>[:<line>]`.

The question a person asks when a defect points to a file nobody remembers writing. archvow answers it
from what it already keeps:

* which component owns the file - its header's `@component`, else the component whose module or test
  file it is (adopted files included: their module is their path);
* what that component uses, and what uses it (`used_by`: the reverse of `uses`, every component a
  change could break);
* the tests that are the evidence of each decision, rule and invariant (the marks archvow already
  reads for tasks and ARCH045);
* with a line: the public function or class around it, and the tests that call it by name (best
  effort: a call through another name is not found, and the output says so).
"""

from __future__ import annotations

import ast
import re
from pathlib import Path

from archvow import manifest as mf
from archvow.foundation import logs
from archvow.specs import SpecError

log = logs.get("locate")

COMPONENT_TAG = re.compile(r"^\s*@component\s+(\w+)", re.MULTILINE)
WITH_LINE = re.compile(r"^(?P<path>.+?):(?P<line>\d+)$")


def is_path(arg: str | None, root: Path | None = None) -> bool:
    """A file argument (src/x.py, x.py:12, README.md when it exists) - never a component id or an item
    id (clean_orders.INV1)."""
    if not arg:
        return False
    plain = WITH_LINE.sub(r"\g<path>", arg)
    if "/" in plain or "\\" in plain or plain.endswith(".py"):
        return True
    return any(base is not None and (base / plain).is_file() for base in (Path.cwd(), root))


def resolve(root: Path, arg: str) -> tuple[str, int | None]:
    """'src/sales/p1_domain/x.py:12' -> ('src/sales/p1_domain/x.py', 12), relative to the project root.
    The path is read from the current folder first, then from the project root."""
    match = WITH_LINE.match(arg)
    text, line = (match.group("path"), int(match.group("line"))) if match else (arg, None)
    text = text.replace("\\", "/")
    for candidate in (Path.cwd() / text, root / text):
        if candidate.is_file():
            try:
                return candidate.resolve().relative_to(root.resolve()).as_posix(), line
            except ValueError:
                raise SpecError(f"{text}: not inside this project ({root})") from None
    raise SpecError(f"{text}: no such file (give its path from the project root or the current folder)")


def _header_component(path: Path) -> str | None:
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"))
    except (SyntaxError, UnicodeDecodeError, OSError):
        logs.swallowed(log, "_header_component: SyntaxError, UnicodeDecodeError, OSError")
        return None
    match = COMPONENT_TAG.search(ast.get_docstring(tree) or "")
    return match.group(1) if match else None


def owner(root: Path, data: dict, rel: str) -> tuple[str | None, str]:
    """(component id, role) of a file: role is 'code' or 'test'; (None, '') when no component owns it."""
    known = {c["id"] for ct in data.get("containers", []) for c in ct.get("components", [])}
    tagged = _header_component(root / rel) if rel.endswith(".py") else None
    for container in data.get("containers", []):
        for comp in container.get("components", []):
            if mf.source_path(container, comp) == rel:
                return comp["id"], "code"
            if mf.test_path(comp) == rel:
                return comp["id"], "test"
    if tagged in known:
        return tagged, "code"
    return None, ""


def used_by(data: dict, cid: str) -> list[str]:
    """Every component that lists `cid` in its uses: what a change to it may break."""
    return [c["id"] for ct in data.get("containers", []) for c in ct.get("components", [])
            if cid in (c.get("uses") or [])]


def evidence(root: Path, data: dict, comp: dict) -> list[dict]:
    """The marked tests of a component's items: [{item, kind, tests: ['file::name', ...]}], in card order.
    Decisions and rules count in the component's own test file; invariants and examples wherever they
    are marked."""
    from archvow.evidence import mark_values, marked_tests
    from archvow.specs import rules_for

    own_file = mf.test_path(comp)
    tests = marked_tests(root)
    rows = []
    for n, d in enumerate(comp.get("decisions", []) or [], 1):
        if d.get("answer"):
            rows.append({"item": f"decision {n}", "kind": "decision", "key": str(n)})
    rows += [{"item": r["id"], "kind": "rule", "key": r["id"].upper()} for r in rules_for(data, comp)]
    rows += [{"item": i["id"], "kind": "invariant", "key": i["id"].upper()}
             for i in data.get("invariants", []) or [] if i.get("component") == comp["id"]]
    rows += [{"item": f"example {e['name']}", "kind": "example", "key": e["name"].upper()}
             for e in comp.get("examples") or []]
    for row in rows:
        row["tests"] = [f"{t.file}::{t.name}" for t in tests
                        if (row["kind"] in ("invariant", "example") or t.file == own_file)
                        and row["key"] in mark_values(t.marks, row["kind"])]
    return rows


def enclosing(path: Path, line: int) -> dict | None:
    """The top-level function or class around `line`: {name, kind, line, public}."""
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"))
    except (SyntaxError, UnicodeDecodeError, OSError):
        logs.swallowed(log, "enclosing: SyntaxError, UnicodeDecodeError, OSError")
        return None
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            start = min([node.lineno, *(d.lineno for d in node.decorator_list)])
            if start <= line <= (node.end_lineno or node.lineno):
                kind = "class" if isinstance(node, ast.ClassDef) else "function"
                return {"name": node.name, "kind": kind, "line": node.lineno, "public": not node.name.startswith("_")}
    return None


def callers(root: Path, name: str) -> list[str]:
    """Tests that call `name` directly ('file::test'): found by name only."""
    from archvow.evidence import _test_files

    found = []
    for path in _test_files(root):
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
        except (SyntaxError, UnicodeDecodeError):
            logs.swallowed(log, "callers: SyntaxError, UnicodeDecodeError")
            continue
        rel = path.relative_to(root).as_posix()
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith("test"):
                for call in (c for c in ast.walk(node) if isinstance(c, ast.Call)):
                    func = call.func
                    called = func.attr if isinstance(func, ast.Attribute) else getattr(func, "id", "")
                    if called == name:
                        found.append(f"{rel}::{node.name}")
                        break
    return found


def not_in_a_component(rel: str, data: dict) -> str:
    """What to run for a file no component owns."""
    if rel.endswith(".py") and any(rel.startswith(f"{ct['path']}/") for ct in data.get("containers", [])):
        return f"{rel} is not in any component -> archvow component add <type> <name> --file {rel}"
    return f"{rel} is not in any component (archvow checks the Python files of {', '.join(sorted({ct['path'] for ct in data.get('containers', [])}))}/)"
