"""AI review: a second, approved AI reads what was written and reports. It never writes code.

The architects approve reviewers at init (`-a reviewers=codex`), separately from the assistants
that write code (`ai_tools`). A reviewer is told what to do in AGENTS.md ("Review <component>",
"Review the last change") and writes one Markdown report in `reviews/` (local, gitignored):

    # Review
    @reviewer   codex
    @model      gpt-5
    @base       origin/main
    @components clean_sales, compute_revenue
    @date       2026-10-10

    ## Findings
    - HIGH src/pkg/p1_domain/clean_sales.py:18 - decision 3 says ..., the code ...
    - LOW tests/p1_domain/test_clean_input.py - edge case 6 has no test

    ## Questions for the architect
    - none

When reviewers are approved, two rules read these reports (`archvow check`): ARCH041, a review by a tool that is not an
approved reviewer; ARCH042, a self-review - the reviewer is a tool named in the `@assisted`
header of a file it reviewed. Names are declared, not proven: a policy, not a lock.

`archvow review --base REF` runs a review without a person (CI, on every merge request): it
picks an approved reviewer that wrote none of the changed files, runs that tool's own command
line (template `ai_tool_review`, or ARCHVOW_REVIEW_COMMAND), fails if the reviewer changed any
file other than its report, and fails on HIGH findings until a person acknowledges them
(`--acknowledged`, set by CI from the merge-request label review-acknowledged). archvow itself
calls no AI service.
"""

from __future__ import annotations

import ast
import hashlib
import os
import re
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

from archvow import manifest as mf
from archvow.foundation import logs
from archvow.foundation.config import settings
from archvow.foundation.errors import GitError, ReviewError
from archvow.foundation.git import git
from archvow.foundation.paths import REVIEWS_DIR
from archvow.header import TAG_RE

log = logs.get("review")

LAST_CHANGE = "last-change"
SEVERITIES = ("HIGH", "MEDIUM", "LOW")
FINDING_RE = re.compile(r"^\s*[-*]\s*\**(HIGH|MEDIUM|LOW)\b\**\s*:?\s*(.*)$")
PROMPT_VARIABLE = "ARCHVOW_REVIEW_PROMPT"
COMMAND_VARIABLE = "ARCHVOW_REVIEW_COMMAND"


@dataclass
class Report:
    path: str
    tags: dict[str, str]
    findings: list[dict] = field(default_factory=list)

    @property
    def reviewer(self) -> str:
        return self.tags.get("reviewer", "").strip().lower()

    @property
    def components(self) -> list[str]:
        named = [c.strip() for c in self.tags.get("components", "").split(",") if c.strip()]
        stem = Path(self.path).stem
        return named or ([] if stem == LAST_CHANGE else [stem])

    def count(self, severity: str) -> int:
        return sum(1 for f in self.findings if f["severity"] == severity)


def parse_report(path: str, text: str) -> Report:
    """The header tags (`@reviewer codex`) and the findings (`- HIGH <where> - <what>`)."""
    tags: dict[str, str] = {}
    findings: list[dict] = []
    for line in text.splitlines():
        tag = TAG_RE.match(line)
        if tag and tag.group(1) not in tags:
            tags[tag.group(1)] = tag.group(2)
            continue
        finding = FINDING_RE.match(line)
        if finding:
            findings.append({"severity": finding.group(1), "text": finding.group(2).strip()})
    return Report(path, tags, findings)


def reports(root: Path) -> list[Report]:
    folder = root / REVIEWS_DIR
    if not folder.is_dir():
        return []
    return [parse_report(f"{REVIEWS_DIR}/{p.name}", p.read_text(encoding="utf-8", errors="replace"))
            for p in sorted(folder.glob("*.md"))]


def approved_reviewers(manifest: dict) -> list[str]:
    return [t for t in manifest.get("reviewers") or [] if t != "none"]


def _components(manifest: dict) -> dict[str, tuple[dict, dict]]:
    return {c["id"]: (container, c) for container in manifest.get("containers", [])
            for c in container.get("components", [])}


def assisted_by(root: Path, container: dict, component: dict) -> list[str]:
    """The AI tools named in the `@assisted` header of a component's file (`none` left out)."""
    path = root / mf.source_path(container, component)
    try:
        docstring = ast.get_docstring(ast.parse(path.read_text(encoding="utf-8"))) or ""
    except (OSError, SyntaxError, UnicodeDecodeError):
        logs.swallowed(log, "assisted_by: OSError, SyntaxError, UnicodeDecodeError")
        return []
    for line in docstring.splitlines():
        tag = TAG_RE.match(line)
        if tag and tag.group(1) == "assisted":
            return [t.strip().lower() for t in tag.group(2).split(",") if t.strip() and t.strip().lower() != "none"]
    return []


def check_reports(checker) -> None:
    """ARCH041 a review by a tool that is not an approved reviewer; ARCH042 a self-review."""
    manifest, root = checker.manifest, checker.root
    approved = approved_reviewers(manifest)
    if not approved:
        return  # AI review is off: reviews/ is none of archvow's business
    package = manifest["containers"][0].get("package", "<package>") if manifest.get("containers") else "<package>"
    known = _components(manifest)
    for report in reports(root):
        if not report.reviewer:
            checker.add("ARCH041", "review report without @reviewer: the reviewer names itself in the header "
                        "(see AGENTS.md, section Review)", report.path)
            continue
        if report.reviewer not in approved:
            command = ",".join([*approved, report.reviewer])
            checker.add("ARCH041", f"reviewed by '{report.reviewer}', approved reviewers: "
                        f"{', '.join(approved) or 'none'}. An architect approves it: "
                        f"archvow init {package} --force -a reviewers={command}", report.path)
            continue
        for component_id in report.components:
            if component_id not in known:
                continue
            authors = assisted_by(root, *known[component_id])
            if report.reviewer in authors:
                checker.add("ARCH042", f"'{report.reviewer}' reviewed {component_id}, which it wrote "
                            f"(@assisted {', '.join(authors)}): ask another approved reviewer "
                            f"({', '.join(r for r in approved if r not in authors) or 'none left: a person reviews'})",
                            report.path)


# ------------------------------------------------------------------ archvow review --base REF


def _git(root: Path, *args: str) -> str:
    try:
        return git(root, *args)
    except GitError as exc:
        raise ReviewError(str(exc)) from exc


def changed_components(root: Path, manifest: dict, base: str) -> list[str]:
    """Components whose file or test changed since the merge-base of `base` (uncommitted included)."""
    from archvow.baseline import GitError, merge_base

    try:
        commit = merge_base(root, base)  # the same base as check --base, diff and next --base
    except GitError as exc:
        raise ReviewError(f"cannot compare with '{base}': {exc}") from exc
    changed = set(_git(root, "diff", "--name-only", commit).split())
    changed |= set(_git(root, "ls-files", "--others", "--exclude-standard").split())
    return [cid for cid, (container, comp) in _components(manifest).items()
            if mf.source_path(container, comp) in changed or mf.test_path(comp) in changed]


def _working_tree(root: Path) -> dict[str, str]:
    """Every changed or new file (outside reviews/) with a hash of its content."""
    out = _git(root, "status", "--porcelain=v1", "-z", "--untracked-files=all")
    state: dict[str, str] = {}
    entries = out.split("\0")
    index = 0
    while index < len(entries):
        entry = entries[index]
        index += 1
        if len(entry) < 4:
            continue
        status, rel = entry[:2], entry[3:]
        if "R" in status or "C" in status:
            index += 1  # the original path of a rename follows
        if rel.startswith(f"{REVIEWS_DIR}/"):
            continue
        path = root / rel
        state[rel] = hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else "absent"
    return state


def review_command(root: Path, manifest: dict, reviewer: str) -> str:
    override = settings().review_command
    if override:
        return override
    from archvow.templates import TemplateError, load_template

    try:
        data = load_template(mf.template_name(manifest["containers"][0])[0], root).data
    except (TemplateError, KeyError, IndexError):
        logs.swallowed(log, "review_command: TemplateError, KeyError, IndexError")
        data = {}
    command = ((data.get("ai_tool_review") or {}).get(reviewer) or {}).get("command")
    if not command:
        raise ReviewError(f"archvow does not know how to run '{reviewer}' without a person: set "
                          f"{COMMAND_VARIABLE} to its command line (the task is in ${PROMPT_VARIABLE})")
    return " ".join(str(command).split())


def prompt(reviewer: str, base: str, components: list[str], report: str) -> str:
    return (f"Review the last change, as AGENTS.md defines it (section Review). You are the approved "
            f"reviewer '{reviewer}'. Compare with {base}. Components changed: {', '.join(components)}. "
            f"Write your report to {report} and change no other file.")


def run(root: Path, base: str, acknowledged: bool = False, echo=print) -> dict:
    """Review the change since `base` with an approved, independent reviewer. Returns the outcome;
    `outcome["status"]`: nothing | no_reviewer | passed | acknowledged | high | failed."""
    manifest = mf.load(root)
    approved = approved_reviewers(manifest)
    package = manifest["containers"][0].get("package", "<package>")
    if not approved:
        raise ReviewError(f"no AI reviewer is approved for this project. An architect approves one: "
                          f"archvow init {package} --force -a reviewers=<tool>")
    components = changed_components(root, manifest, base)
    outcome: dict = {"base": base, "components": components, "reviewer": None, "report": None,
                     "findings": [], "high": 0, "acknowledged": acknowledged}
    if not components:
        return {**outcome, "status": "nothing", "message": f"no component changed since {base}: nothing to review"}
    known = _components(manifest)
    authors = sorted({t for cid in components for t in assisted_by(root, *known[cid])})
    outcome["authors"] = authors
    candidates = [r for r in approved if r not in authors]
    if not candidates:
        return {**outcome, "status": "no_reviewer",
                "message": f"no independent AI reviewer: the change was written with {', '.join(authors)} and the "
                           f"approved reviewers are {', '.join(approved)} (a tool never reviews its own work). "
                           "A person reviews this change."}
    reviewer = candidates[0]
    command = review_command(root, manifest, reviewer)
    report_rel = f"{REVIEWS_DIR}/{LAST_CHANGE}.md"
    report_path = root / report_rel
    report_path.unlink(missing_ok=True)  # never read a report from an earlier run
    before = _working_tree(root)
    echo(f"Reviewer: {reviewer} - components: {', '.join(components)}")
    echo(f"Running: {command}")
    try:
        result = subprocess.run(command, shell=True, cwd=root, check=False,
                                env={**os.environ, PROMPT_VARIABLE: prompt(reviewer, base, components, report_rel)})
    except OSError as exc:
        raise ReviewError(f"cannot run the reviewer '{reviewer}': {exc}") from exc
    outcome.update(reviewer=reviewer, report=report_rel)
    after = _working_tree(root)
    touched = sorted(rel for rel in set(before) | set(after) if before.get(rel) != after.get(rel))
    if touched:
        return {**outcome, "status": "failed",
                "message": f"the reviewer changed {', '.join(touched)}: a reviewer never changes files other than "
                           f"its report. Undo it (git checkout -- / git clean) and check {reviewer}'s permissions"}
    if result.returncode != 0:
        return {**outcome, "status": "failed",
                "message": f"the reviewer's command failed (exit {result.returncode}): {command}"}
    if not report_path.is_file():
        return {**outcome, "status": "failed", "message": f"the reviewer wrote no report ({report_rel})"}
    report = parse_report(report_rel, report_path.read_text(encoding="utf-8", errors="replace"))
    outcome.update(findings=report.findings, high=report.count("HIGH"))
    if report.reviewer and report.reviewer != reviewer:
        return {**outcome, "status": "failed",
                "message": f"the report says @reviewer {report.reviewer}, the reviewer run was {reviewer}"}
    if not outcome["high"]:
        return {**outcome, "status": "passed", "message": f"no HIGH finding - read {report_rel}"}
    if acknowledged:
        return {**outcome, "status": "acknowledged",
                "message": f"{outcome['high']} HIGH finding(s), acknowledged by a person - see {report_rel}"}
    return {**outcome, "status": "high",
            "message": f"{outcome['high']} HIGH finding(s): a person reads {report_rel}, then fixes the code or "
                       "acknowledges the findings (merge-request label review-acknowledged; "
                       "Jenkins: REVIEW_ACKNOWLEDGED=true)"}
