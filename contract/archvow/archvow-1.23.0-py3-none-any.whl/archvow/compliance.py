"""Compliance checks run after the safety checks: personal data (GDPR), test data (TST),
operational resilience (DORA), the P/O/C question sets and a template's own rules.

Each family is switched on by the project's `rules` answer (GDPR and TST by default,
DORA on request), so `run_compliance` only calls what is on.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from archvow.check import project_rule_sets

if TYPE_CHECKING:
    from archvow.check import _Checker

MANIFEST = ".archvow/spec.vow"


def implemented_components(checker: _Checker) -> set[str]:
    """Components whose every public name is implemented (their code exists)."""
    planned, seen = set(), set()
    for status in checker.report.statuses:
        seen.add(status.component)
        if status.status == "planned":
            planned.add(status.component)
    return seen - planned


def run_compliance(checker: _Checker) -> None:
    from archvow.custom import run_custom

    implemented = implemented_components(checker)
    blocked: set[str] = set()
    run_questions(checker, implemented, blocked)
    if checker.enabled("GDPR001") or checker.enabled("GDPR004"):
        from archvow.privacy import run_privacy

        run_privacy(checker, implemented, blocked)
    if any(checker.enabled(code) for code in ("TST001", "TST002", "TST003")):
        from archvow.testdata import run_testdata

        run_testdata(checker)
    if checker.enabled("DORA001"):
        from archvow.dora import run_dora

        run_dora(checker)
    run_custom(checker)
    for status in checker.report.components:
        if status.component in blocked:
            status.status = "drift"


def run_questions(checker: _Checker, implemented: set[str], blocked: set[str]) -> None:
    """P/O/C questions: open ones count as open questions (`next` blocks); on coded code, an error
    with the question's own rule (GDPR002, GDPR003, GDPR008, DORA005, a company code)."""
    from archvow.privacy import personal_flow
    from archvow.questions import component_questions

    data = checker.manifest
    flows = personal_flow(checker.root, data)
    by_id = {s.component: s for s in checker.report.components}
    for container in data.get("containers", []):
        template = checker.templates.get(container["id"])
        if template is None:
            continue
        for comp in container.get("components", []):
            cid = comp["id"]
            open_questions = [q for q in component_questions(checker.root, data, comp, template, flows)
                              if not q["answer"]]
            if cid in by_id:
                by_id[cid].open_questions += len(open_questions)
            if cid not in implemented:
                continue
            for q in open_questions:
                if q["rule"] in checker.rules:
                    blocked.add(cid)
                    checker.add(q["rule"], f"'{cid}' is implemented but {q['key']} ({q['title']}) is not answered: "
                                f"{q['question']} -> archvow decision make {cid} {q['key']} \"...\"", MANIFEST)


def compliance_views(root: Path, data: dict) -> dict[str, str]:
    """compliance/PERSONAL_DATA.md (GDPR on) and compliance/THIRD_PARTIES.md (DORA on)."""
    from archvow.foundation.i18n import tr
    from archvow.questions import templates_of

    sets = project_rule_sets(list(templates_of(root, data).values()), data)
    views = {}
    if "gdpr" in sets:
        from archvow.privacy import personal_data_view

        views["PERSONAL_DATA.md"] = personal_data_view(root, data, tr)
    if "dora" in sets:
        from archvow.dora import third_parties_view

        views["THIRD_PARTIES.md"] = third_parties_view(data, tr)
    return views

