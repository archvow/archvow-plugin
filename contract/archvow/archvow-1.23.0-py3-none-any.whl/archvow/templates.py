"""Template packs: discovery, inheritance (`extends`) and file overlay.

A template pack is a folder containing `template.yaml` plus an optional `files/`
folder (the project skeleton). Packs are discovered from,
in increasing precedence:

1. built-in packs shipped with archvow,
2. directories listed in the ARCHVOW_TEMPLATES environment variable
   (team catalogs),
3. `<project>/.archvow/templates/` (project-local packs).

Languages: a pack may translate what it generates. `template.<lang>.yaml` overrides the texts
of `template.yaml` (questions asked by each component type, guide words, layer rules...) and
`files-<lang>/` overrides files of `files/`. A project uses one language (manifest `language`,
English when absent); everything not translated falls back to the pack's own text.
"""

from __future__ import annotations

import copy
import keyword
import os
import re
from dataclasses import dataclass, field
from pathlib import Path

import yaml

from archvow import __version__
from archvow.foundation import logs
from archvow.foundation.config import settings
from archvow.foundation.errors import TemplateError
from archvow.foundation.files import write_text
from archvow.manifest import parse_yaml

log = logs.get("templates")

BUILTIN_DIR = Path(__file__).parent / "packs"
PROJECT_TEMPLATES = Path(".archvow/templates")
DEFAULT_LANGUAGE = "en"  # the language of template.yaml and files/, and of projects that name none


def edge_case_text(item: object) -> str:
    """A question of a component type: a string, or {question, suggested}."""
    return str(item["question"]) if isinstance(item, dict) else str(item)


def edge_case_suggestion(item: object) -> str | None:
    """The template's suggested answer to a question, when it gives one."""
    return str(item["suggested"]) if isinstance(item, dict) and item.get("suggested") else None


def edge_case_choices(item: object) -> list[str]:
    """The answers a question offers to start from, when it has no safe default (none pre-selected)."""
    return [str(c) for c in item.get("choices") or []] if isinstance(item, dict) else []


@dataclass
class Template:
    """A fully resolved template (inheritance and language already applied)."""

    name: str
    data: dict
    dirs: list[Path] = field(default_factory=list)  # base pack first, child last
    language: str = DEFAULT_LANGUAGE

    @property
    def version(self) -> str:
        return str(self.data.get("version", "0.0.0"))

    @property
    def ref(self) -> str:
        return f"{self.name}@{self.version}"

    @property
    def layers(self) -> list[dict]:
        return self.data.get("layers", [])

    def rename_layers(self, text: str) -> str:
        """A text of the template's files with the layers' folders the template names (`layer_names`)."""
        return _rename_words(text, _renames(self.data))

    def layer(self, name: str) -> dict | None:
        return next((layer for layer in self.layers if layer["name"] == name), None)

    @property
    def layer_names(self) -> list[str]:
        return [layer["name"] for layer in self.layers]

    @property
    def component_types(self) -> dict:
        return self.data.get("component_types", {})

    def kinds(self, type_name: str) -> list[str]:
        """The kinds a component type offers (`kinds:`, e.g. a reader: files, table, jdbc...), default first."""
        ctype = self.component_types.get(type_name) or {}
        names = list(ctype.get("kinds") or {})
        default = ctype.get("default_kind")
        return [default, *[n for n in names if n != default]] if default in names else names

    def type_of(self, comp: dict) -> dict:
        """A component's type as it applies to it: the type, with its kind's own description,
        symbols, questions, safety questions and hints over it (a reader of kind jdbc...)."""
        ctype = dict(self.component_types.get(comp.get("type")) or {})
        kinds = ctype.pop("kinds", None) or {}
        kind = comp.get("kind") or ctype.get("default_kind")
        ctype.pop("default_kind", None)
        if kind not in kinds:
            return ctype
        own = kinds.get(kind) or {}
        merged = merge(ctype, own)
        if "safety_decisions" in own:  # numbers point to the kind's own questions: never mixed
            merged["safety_decisions"] = dict(own["safety_decisions"] or {})
        return merged

    @property
    def rules(self) -> dict:
        return self.data.get("rules", {})

    def suggested_answers(self, comp: dict) -> dict[str, str]:
        """{question: suggested answer} for a component: its type's questions, or a starting component's."""
        initial = next((c for c in self.data.get("initial_components", []) or [] if c.get("id") == comp.get("id")),
                       None)
        source = initial if initial is not None else self.type_of(comp)
        return {edge_case_text(q): s for q in source.get("edge_cases") or [] if (s := edge_case_suggestion(q))}

    def choices(self, comp: dict) -> dict[str, list[str]]:
        """{question: [answers to start from]} for a component's questions that have no default."""
        initial = next((c for c in self.data.get("initial_components", []) or [] if c.get("id") == comp.get("id")),
                       None)
        source = initial if initial is not None else self.type_of(comp)
        return {edge_case_text(q): c for q in source.get("edge_cases") or [] if (c := edge_case_choices(q))}

    def find(self, rel: str) -> Path:
        """Find a pack file, the most specific (child) pack winning."""
        for directory in reversed(self.dirs):
            candidate = directory / rel
            if candidate.is_file():
                return candidate
        raise TemplateError(f"{self.name}: file '{rel}' not found in pack(s)")

    def skeleton_files(self) -> dict[str, Path]:
        """Relative path -> source path for the project skeleton (child overrides base)."""
        result: dict[str, Path] = {}
        folders = ["files"] if self.language == DEFAULT_LANGUAGE else ["files", f"files-{self.language}"]
        for directory in self.dirs:
            for folder in folders:  # a translated file replaces the original of the same pack
                root = directory / folder
                if not root.is_dir():
                    continue
                for path in sorted(root.rglob("*")):
                    if path.is_file():
                        result[path.relative_to(root).as_posix()] = path
        return result

    def _question_summary(self, question: dict) -> dict:
        """Questions as the IDE wizard needs them: choices resolved, flags explicit."""
        result = dict(question)
        override = (self.data.get("questions_defaults") or {}).get(question.get("id"))
        if override is not None:
            result["default"] = override
        elif question.get("choices_from") == "rule_families" and question.get("default") is None:
            result["default"] = ",".join(self.recommended_families())
        source = question.get("choices_from")
        if source == "rule_families":
            result["choices"] = [*self.selectable_families(), "all", "none"]
        elif source:
            keys = [k for k in (self.data.get(source) or {}) if k != "unlisted"]
            result["choices"] = [*keys, "none"]
        result.setdefault("required", False)
        result.setdefault("multiple", False)
        return result

    COMPLIANCE = ("GDPR", "TST", "DORA")  # the families that also bring registers, questions and views

    def selectable_families(self) -> list[str]:
        """The rule families the `rules` answer chooses from, by name: the code families first (ARCH,
        STYLE, SPARK...), then the compliance ones (GDPR, TST, DORA)."""
        names = [str((v or {}).get("name") or k).upper() for k, v in (self.data.get("rule_families") or {}).items()]
        names = list(dict.fromkeys(names))
        return [n for n in names if n not in self.COMPLIANCE] + [n for n in names if n in self.COMPLIANCE]

    def family_title(self, name: str) -> str:
        return next((str((v or {}).get("title") or "") for k, v in (self.data.get("rule_families") or {}).items()
                     if str((v or {}).get("name") or k).upper() == name), "")

    def recommended_families(self) -> list[str]:
        """The `rules` default: every family but DORA, which is for banks and insurers."""
        return [n for n in self.selectable_families() if n != "DORA"]

    def summary(self) -> dict:
        """JSON-friendly description, used by `catalog --json` (IDE wizard)."""
        return {
            "name": self.name,
            "version": self.version,
            "language": self.data.get("language"),
            "kind": self.data.get("kind"),
            "style": self.data.get("style"),
            "description": self.data.get("description", ""),
            "extends": self.data.get("_extends_chain", []),
            "questions": [self._question_summary(q) for q in self.data.get("questions", [])],
            "layers": [
                {"name": layer["name"], "description": layer.get("description", ""),
                 "may_import": layer.get("may_import", [])}
                for layer in self.layers
            ],
            "component_types": {
                key: {
                    "layer": value.get("layer"),
                    "description": value.get("description", ""),
                    "addable": value.get("addable", True),
                    "name_pattern": value.get("name_pattern"),
                    "name_hint": value.get("name_hint", ""),
                    "module": value.get("module"),
                    "symbols": value.get("symbols", []),
                    "implicit_dependency": bool(value.get("implicit_dependency", False)),
                    "signature_overridable": bool(value.get("signature_overridable", False)),
                    "kinds": self._kinds_summary(key),
                }
                for key, value in self.component_types.items()
            },
            "source": str(self.dirs[-1]) if self.dirs else None,
        }


    def _kinds_summary(self, type_name: str) -> list[dict]:
        """`component add <type> <name> -k <kind>`: each kind with what it is, the default one first (an IDE
        offers them in a list). The default kind's own description, else the type's."""
        ctype = self.component_types.get(type_name) or {}
        declared = ctype.get("kinds") or {}
        default = ctype.get("default_kind")
        return [{"name": kind, "description": str((declared.get(kind) or {}).get("description")
                                                  or (ctype.get("description", "") if kind == default else "")),
                 "default": kind == default}
                for kind in self.kinds(type_name)]


def search_paths(project_root: Path | None) -> list[Path]:
    """Directories containing packs, lowest precedence first."""
    paths = [BUILTIN_DIR]
    paths += [Path(p) for p in settings().templates]
    if project_root is not None:
        paths.append(project_root / PROJECT_TEMPLATES)
    return paths


def discover(project_root: Path | None) -> dict[str, Path]:
    """Pack name -> pack directory (higher precedence overrides)."""
    found: dict[str, Path] = {}
    for base in search_paths(project_root):
        if not base.is_dir():
            continue
        for manifest in sorted(base.glob("*/template.yaml")):
            raw = _read_yaml(manifest)
            found[raw.get("name", manifest.parent.name)] = manifest.parent
    return found


def project_language(project_root: Path | None) -> str:
    """The language of the project in `project_root` (English when it names none, or no project)."""
    if project_root is None:
        return DEFAULT_LANGUAGE
    path = project_root / ".archvow" / "spec.vow"
    try:
        stamp = path.stat().st_mtime_ns
    except OSError:
        logs.swallowed(log, "project_language: OSError")
        return DEFAULT_LANGUAGE
    cached = _LANGUAGE_CACHE.get(path)
    if cached is None or cached[0] != stamp:
        from archvow import vowfile

        try:
            text = path.read_text(encoding="utf-8")
            data = vowfile.loads(text, path.name)[2]
        except (vowfile.VowError, OSError):
            logs.swallowed(log, "project_language: vowfile.VowError, OSError")
            data = {}
        language = data.get("language") if isinstance(data, dict) else None
        cached = (stamp, str(language or DEFAULT_LANGUAGE))
        _LANGUAGE_CACHE[path] = cached
    return cached[1]


_LANGUAGE_CACHE: dict[Path, tuple[int, str]] = {}


def load_template(name: str, project_root: Path | None, _chain: tuple[str, ...] = (),
                  language: str | None = None) -> Template:
    """Load a pack by name, resolve its `extends` chain, in the project's language.

    `language` defaults to the language of the project in `project_root` (English if none).
    """
    if language is None:
        language = project_language(project_root)
    if name in _chain:
        raise TemplateError(f"template inheritance cycle: {' -> '.join((*_chain, name))}")
    packs = discover(project_root)
    if name not in packs:
        available = ", ".join(sorted(packs)) or "none"
        raise TemplateError(f"unknown template '{name}' (available: {available})")
    directory = packs[name]
    raw = _read_yaml(directory / "template.yaml")
    if directory.parent == BUILTIN_DIR:  # archvow's own templates carry archvow's version (one source)
        raw["version"] = __version__
    translated = directory / f"template.{language}.yaml"
    if language != DEFAULT_LANGUAGE and translated.is_file():
        raw = merge(raw, _read_yaml(translated))
    raw.setdefault("name", name)
    parent_name = raw.pop("extends", None)
    if not parent_name:
        raw["_extends_chain"] = []
        return Template(name=name, data=raw if _chain else _apply_layer_names(name, raw), dirs=[directory],
                        language=language)
    parent = load_template(parent_name, project_root, (*_chain, name), language=language)
    merged = merge(parent.data, raw)
    merged["abstract"] = bool(raw.get("abstract", False))  # a base is abstract, what extends it is not
    merged["_extends_chain"] = [parent.name, *parent.data.get("_extends_chain", [])]
    if not _chain:  # the template asked for: its layers get the folders it names, everywhere
        merged = _apply_layer_names(name, merged)
    return Template(name=name, data=merged, dirs=[*parent.dirs, directory], language=language)


def _renames(data: dict) -> dict[str, str]:
    """`layer_names`, the layer -> folder pairs that change something (built-in name -> new name)."""
    return {old: new for old, new in (data.get("layer_names") or {}).items() if old != new}


def _rename_words(value: object, renames: dict[str, str]) -> object:
    """Every layer name in a value (a text, or the strings of a list or mapping) replaced as a whole
    word: p2_io in "p2_io components" or "{{ package }}.p2_io.reader", never inside another name."""
    if not renames:
        return value
    if isinstance(value, str):
        pattern = re.compile(r"(?<![A-Za-z0-9_])(" + "|".join(map(re.escape, renames)) + r")(?![A-Za-z0-9_])")
        return pattern.sub(lambda m: renames[m.group(1)], value)
    if isinstance(value, list):
        return [_rename_words(item, renames) for item in value]
    if isinstance(value, dict):
        return {_rename_words(k, renames): _rename_words(v, renames) for k, v in value.items()}
    return value


LAYER_FOLDER_RE = re.compile(r"^[a-z_][a-z0-9_]*$")


def check_layer_names(template_name: str, layers: list[str], names: dict) -> None:
    """`layer_names` maps existing layers to folders: valid package names, all different."""
    if not isinstance(names, dict):
        raise TemplateError(f"template '{template_name}': layer_names must map a layer to its folder")
    unknown = [old for old in names if old not in layers]
    if unknown:
        raise TemplateError(f"template '{template_name}': layer_names: unknown layer(s) {', '.join(unknown)} "
                            f"(the layers are {', '.join(layers)})")
    bad = [str(new) for new in names.values()
           if not LAYER_FOLDER_RE.match(str(new)) or keyword.iskeyword(str(new))]
    if bad:
        raise TemplateError(f"template '{template_name}': layer_names: {', '.join(bad)} - a folder name is "
                            "a Python package name: lower case, digits and _, not a keyword")
    folders = [names.get(layer, layer) for layer in layers]
    twice = sorted({f for f in folders if folders.count(f) > 1})
    if twice:
        raise TemplateError(f"template '{template_name}': layer_names: {', '.join(twice)} given to two layers")


def _apply_layer_names(template_name: str, data: dict) -> dict:
    names = data.get("layer_names") or {}
    check_layer_names(template_name, [layer["name"] for layer in data.get("layers", [])], names)
    renames = _renames(data)
    if not renames:
        return data
    renamed = {key: (value if key == "layer_names" else _rename_words(value, renames)) for key, value in data.items()}
    renamed["layer_names"] = dict(names)  # kept as written: the built-in name -> its folder (for the files)
    return renamed


def merge(base: dict, child: dict) -> dict:
    """Deep-merge a child template over its parent.

    Dicts merge recursively; `layers` merge by name, `questions` and `initial_components` by id
    (new entries are appended); `allowed_paths`, `executable_files` and `answer_rules` add to the parent's; any other value from the
    child replaces the parent's.
    """
    result = copy.deepcopy(base)
    for key, value in child.items():
        if key in ADDITIVE_LISTS and isinstance(value, list):
            kept = list(result.get(key) or [])
            result[key] = kept + [copy.deepcopy(v) for v in value if v not in kept]
        elif key in NAMED_LISTS and isinstance(value, list):
            result[key] = _merge_layers(result.get(key, []), value, NAMED_LISTS[key])
        elif isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = merge(result[key], value)
        else:
            result[key] = copy.deepcopy(value)
    return result


NAMED_LISTS = {"layers": "name", "questions": "id", "initial_components": "id"}
ADDITIVE_LISTS = {"allowed_paths", "executable_files", "answer_rules"}  # a child adds to the base's list, never loses it


def _merge_layers(base: list[dict], child: list[dict], key: str = "name") -> list[dict]:
    items = [copy.deepcopy(item) for item in base]
    index = {item[key]: i for i, item in enumerate(items)}
    for item in child:
        if item[key] in index:
            items[index[item[key]]] = merge(items[index[item[key]]], item)
        else:
            items.append(copy.deepcopy(item))
    return items


def _read_yaml(path: Path) -> dict:
    try:
        data = parse_yaml(path.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError as exc:
        raise TemplateError(f"{path}: invalid YAML: {exc}") from exc
    if not isinstance(data, dict):
        raise TemplateError(f"{path}: expected a mapping at top level")
    return data


def is_pack_folder(value: str | None) -> bool:
    """`init -t <folder>`: a template given by its folder rather than its name."""
    looks_like_a_path = any(sep in str(value) for sep in ("/", "\\")) or str(value).startswith(".")  # \\: Windows
    return bool(value) and looks_like_a_path and (Path(value) / "template.yaml").is_file()


def use_pack_folder(value: str) -> str:
    """`-t /catalog/acme-pyspark`: make that folder's catalog visible to this process (the packs it
    extends sit next to it) and return the pack's name. A name is returned as it is."""
    if not is_pack_folder(value):
        return value
    folder = Path(value).resolve()
    known = list(settings().templates)
    os.environ["ARCHVOW_TEMPLATES"] = os.pathsep.join([*known, str(folder.parent)])
    return str(_read_yaml(folder / "template.yaml").get("name") or folder.name)


def vendor(project_root: Path, name: str) -> list[Path]:
    """Copy the company packs a project uses into .archvow/templates/, so every clone, the Git
    hook and the CI find them without ARCHVOW_TEMPLATES. The built-in packs ship with
    archvow and are never copied. A pack found outside the project (ARCHVOW_TEMPLATES, or
    the folder given to `init -t`) replaces the project's copy: `init --force` refreshes it."""
    import shutil

    outside = discover(None)
    copied = []
    seen: set[str] = set()
    while name and name in outside and name not in seen:
        seen.add(name)
        source = outside[name]
        if source.parent.resolve() == BUILTIN_DIR.resolve():
            break  # pyspark-pipeline, python-base...: part of archvow
        target = project_root / PROJECT_TEMPLATES / name
        if source.resolve() != target.resolve():
            shutil.rmtree(target, ignore_errors=True)
            shutil.copytree(source, target, ignore=shutil.ignore_patterns(".git", "__pycache__", "*.pyc"))
            copied.append(target)
        name = _read_yaml(source / "template.yaml").get("extends")
    return copied


def scaffold_custom_template(project_root: Path | None, name: str, extends: str,
                             catalog: Path | None = None, *, description: str | None = None,
                             defaults: dict | None = None, allowed_paths: list[str] | None = None,
                             verbatim_folders: list[str] | None = None,
                             layer_names: dict[str, str] | None = None) -> Path:
    """Create a pack that extends an existing one: in a team catalog folder, or in the project.
    What is given (the init answers' company defaults, allowed_paths, verbatim_folders) is written as
    settings; the rest stays as commented examples."""
    base = load_template(extends, project_root)  # fail early if the base does not exist
    if catalog is None and project_root is None:
        raise TemplateError("not in an archvow project: pass --dir <catalog folder> to create a "
                            "company template there")
    directory = (catalog if catalog is not None else project_root / PROJECT_TEMPLATES) / name
    if directory.exists():
        raise TemplateError(f"{directory} already exists")
    text = CUSTOM_TEMPLATE.format(name=name, extends=extends,
                                  description=_flow(description or f"Custom variant of {extends}."))
    if defaults:
        text = text.replace(DEFAULTS_EXAMPLE, "questions_defaults:\n" + "".join(
            f"  {key}: {_flow(value)}\n" for key, value in defaults.items()))
    if allowed_paths:
        text = text.replace(ALLOWED_EXAMPLE, f"allowed_paths: {_flow(allowed_paths)}\n")
    if verbatim_folders:
        text = text.replace(VERBATIM_EXAMPLE, f"verbatim_folders: {_flow(verbatim_folders)}\n")
    current = base.data.get("layer_names") or {}
    folders = {layer["name"]: current.get(layer["name"], layer["name"]) for layer in base.layers}
    if folders:  # every layer with its folder: the base's, unless renamed here
        check_layer_names(name, list(folders), layer_names or {})
        folders |= layer_names or {}
        text = text.replace(LAYERS_EXAMPLE, "layer_names:\n" + "".join(
            f"  {layer}: {folder}\n" for layer, folder in folders.items()))
    (directory / "files").mkdir(parents=True)
    write_text((directory / "template.yaml"), text)
    return directory


def _flow(value: object) -> str:
    """A value as one line of YAML (a list in brackets, a string quoted only when it must be)."""
    return yaml.safe_dump(value, default_flow_style=True, allow_unicode=True, width=10_000).strip() \
        .removesuffix("\n...").strip()


DEFAULTS_EXAMPLE = """\
# questions_defaults:
#   ci: jenkins
#   sonar: "yes"
"""
ALLOWED_EXAMPLE = "# allowed_paths: [devops, tools]\n"
VERBATIM_EXAMPLE = "# verbatim_folders: [templates]\n"
LAYERS_EXAMPLE = "# layer_names: {p1_domain: domain}\n"

CUSTOM_TEMPLATE = """\
# Template '{name}'. Everything not declared here is inherited from '{extends}'.
# Mappings merge key by key, layers merge by name, any other value (a list) replaces the base's,
# except allowed_paths, which adds to the base's.
# Files: put them in ./files/ - rendered with Jinja2 when they end in .j2, copied as they are
# otherwise (or when their folder is in `verbatim_folders`). French versions go in ./files-fr/.
name: {name}
extends: {extends}
version: 0.1.0
description: {description}

# Your defaults for the init answers (a project can still override them with -a).
""" + DEFAULTS_EXAMPLE.replace("{", "{{").replace("}", "}}") + """
# Top folders of Python files that are not components (no ARCH015), added to the base's.
""" + ALLOWED_EXAMPLE + """
# Folders of ./files/ copied exactly as they are, even their .j2 files (another tool renders them).
""" + VERBATIM_EXAMPLE + """
# The folder of each layer (src/<package>/<folder>/, tests/<folder>/): change the right-hand side to
# rename one; archvow uses it everywhere (layers, component types, the files it writes).
""" + LAYERS_EXAMPLE.replace("{", "{{").replace("}", "}}") + """
# Example: add a new component type.
# component_types:
#   stream_reader:
#     layer: p2_io
#     description: Structured Streaming source.
#     module: "{{name}}_stream_reader"
#     name_pattern: "^[a-z][a-z0-9_]*$"
#     symbols:
#       - kind: function
#         name: "read_{{name}}_stream"
#         signature: "(spark: SparkSession, source: str) -> DataFrame"
#     guide_words: [missing, wrong]
#     edge_cases:
#       - "The source is unavailable: fail or wait (e.g. wait 10 min, then fail)?"
#       - question: "A record has no event time: drop it or fail (e.g. drop and count it)?"
#         suggested: "fail with the record's key in the error"   # `decision make <c> <n>` without text takes it

# Example: tune a rule for every project using this template.
# rules:
#   SPK009: {{severity: error, max_chain: 4}}
"""
