"""Question sets beyond a component's own questions: P (personal data), O (operations) and C
(a company's `require_question` rules).

A template declares them as data (`question_sets`); each question names the rule that fails while
it is open on a coded component, so a new set or question needs no code:

    question_sets:
      P:
        title: Personal data
        rule_set: gdpr          # asked only when this family is on (`rules` answer)
        when: personal          # personal | writes | special | always (per question too)
        questions:
          job:
            - {id: purpose, rule: GDPR002, text: "Purpose: why ...?"}

Answers live in the component, keyed by the question id: `answers: {P.purpose: {answer, by, on}}`,
so adding or removing a question never moves another one's answer. People see them numbered
P1, P2... and answer with `archvow decision make <component> P1 "..."`.
"""

from __future__ import annotations

import re
from pathlib import Path

from archvow import manifest as mf
from archvow.check import custom_rules, project_rule_sets, rule_enabled
from archvow.foundation import logs
from archvow.foundation.text import one_line
from archvow.templates import Template, TemplateError, load_template

log = logs.get("questions")

KEY_RE = re.compile(r"^([A-Z])([0-9]+)$")
WHEN = ("always", "personal", "writes", "special")


def templates_of(root: Path, data: dict) -> dict[str, Template]:
    """Container id -> its template (containers whose template cannot load are left out)."""
    found = {}
    for container in data.get("containers", []):
        try:
            found[container["id"]] = load_template(mf.template_name(container)[0], root)
        except TemplateError:
            logs.swallowed(log, "templates_of: TemplateError")
            continue
    return found


def question_sets(template: Template, data: dict) -> dict[str, dict]:
    """The sets switched on for this project: letter -> {title, when, questions: {type: [...]}}."""
    rule_sets = project_rule_sets([template], data)
    sets = {}
    for letter, spec in (template.data.get("question_sets") or {}).items():
        family = spec.get("rule_set")
        if family and family not in rule_sets:
            continue
        sets[str(letter)] = spec
    company: dict[str, list] = {}
    for code, rule in custom_rules([template]).items():
        ask = rule.get("require_question")
        if not ask or not rule_enabled(code, rule_sets) or rule.get("severity") == "off":
            continue
        for ctype in ask.get("types") or []:
            company.setdefault(ctype, []).append({"id": code, "rule": code, "text": ask.get("question", "")})
    if company:
        sets["C"] = {"title": "Company questions", "when": "always", "questions": company}
    return sets


def _applies(when: str, flow: dict) -> bool:
    if when == "personal":
        return bool(flow.get("handles"))
    if when == "writes":
        return bool(flow.get("writes"))
    if when == "special":
        return "special" in (flow.get("handles") or {}).values()
    return True


def component_questions(root: Path, data: dict, comp: dict, template: Template | None = None,
                        flows: dict | None = None) -> list[dict]:
    """The P/O/C questions a component must answer, numbered per set, with their answers."""
    if template is None:
        container = next(c for c in data["containers"] if comp in c.get("components", []))
        template = templates_of(root, data).get(container["id"])
        if template is None:
            return []
    if flows is None:
        from archvow.privacy import personal_flow

        flows = personal_flow(root, data)
    flow = flows.get(comp["id"], {})
    answers = comp.get("answers") or {}
    out = []
    for letter, spec in question_sets(template, data).items():
        number = 0
        for question in (spec.get("questions") or {}).get(comp.get("type"), []) or []:
            if not _applies(question.get("when") or spec.get("when") or "always", flow):
                continue
            number += 1
            stored = answers.get(f"{letter}.{question['id']}") or {}
            out.append({"key": f"{letter}{number}", "set": letter, "title": spec.get("title", letter),
                        "id": question["id"], "rule": question.get("rule", ""), "question": question["text"],
                        "answer": stored.get("answer") or None,
                        **{k: stored[k] for k in ("by", "on") if k in stored}})
    return out


def is_key(text: str) -> bool:
    return bool(KEY_RE.match(str(text).strip().upper()))


def answer(root: Path, component_id: str, key: str, text: str) -> dict:
    """`archvow decision make <component> P1 "..."`: answer a P/O/C question by its number."""
    from archvow.specs import SpecError, find_component, stamp

    data = mf.load(root)
    _, comp = find_component(data, component_id)
    questions = component_questions(root, data, comp)
    wanted = key.strip().upper()
    question = next((q for q in questions if q["key"] == wanted), None)
    if question is None:
        known = ", ".join(q["key"] for q in questions) or "none"
        raise SpecError(f"'{component_id}' has no question {wanted} (it has: {known}; see archvow show "
                        f"{component_id})")
    if not text.strip():
        raise SpecError("an answer is required")
    entry = {"answer": one_line(text), **stamp(root)}
    comp.setdefault("answers", {})[f"{question['set']}.{question['id']}"] = entry
    mf.save(root, data)
    return {**question, **entry}
