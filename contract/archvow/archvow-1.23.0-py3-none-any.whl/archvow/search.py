"""`archvow show <name>`: where a name is in the project, and what archvow finds wrong with it.

The question a person asks when an error names something - a function, a column, a ticket, a business
example - and nobody remembers where it lives. `show` tries what it knows first (a file, an item id, a
component); any other name is searched here, in the places archvow keeps, each hit saying what it is:

* Spec - the vows, with the component and the part of it (symbol, decision 3, example, ticket...). The
  spec cards are generated from the vows: they show the same, and are not searched.
* Code - the package folders: where the name is defined (def, class, constant) and where it is used
  (a call, an import, an attribute, a text such as a column name), with the function around it.
* Tests - the test functions that name it, with their marks; the business examples' folders and files.
* Briefs - the briefs folders, by section.
* Template - a component type or a layer of the project's template.
* Problems - the messages of `archvow check` that name it.

Whole words only (a name inside a longer name is not found); a call through another name, what is
outside the project and the Git history are not searched. Nothing here changes anything.
"""

from __future__ import annotations

import ast
import difflib
import re
from pathlib import Path
from typing import TYPE_CHECKING

from archvow import manifest as mf
from archvow.foundation import logs

log = logs.get("search")

if TYPE_CHECKING:
    from archvow.check import Report

GROUPS = ("spec", "code", "tests", "examples", "briefs", "template", "problems")
TITLES = {"spec": "Spec", "code": "Code", "tests": "Tests", "examples": "Examples", "briefs": "Briefs",
          "template": "Template", "problems": "Problems"}
NOTES = {"spec": "the vow - the spec card shows the same", "problems": "archvow check - the ones naming it"}
SHOW_MAX = 10  # lines per group in the terminal; --json gives them all
SKIP_DIRS = {".git", "venv", ".venv", "env", "build", "dist", "node_modules", "__pycache__", "site-packages",
             ".pytest_cache", ".ruff_cache", ".hypothesis", ".mypy_cache"}
VOW_ITEMS = ("symbol", "decision", "assumption", "example", "hazard", "invariant", "not_applicable", "container",
             "rule", "type_answer", "third_party")


def _word(name: str, ignore_case: bool = False) -> re.Pattern[str]:
    """`name` as a whole word: not inside a longer name (letters, digits, _ and - around it)."""
    return re.compile(rf"(?<![A-Za-z0-9_\-]){re.escape(name)}(?![A-Za-z0-9_\-])", re.IGNORECASE if ignore_case else 0)


def _hit(group: str, file: str, line: int, component: str, part: str, text: str, **more: object) -> dict:
    return {"group": group, "file": file, "line": line, "component": component, "part": part,
            "text": text.strip()[:200], **{k: v for k, v in more.items() if v not in (None, "")}}


def _files(base: Path, suffixes: tuple[str, ...] | None = None) -> list[Path]:
    if not base.is_dir():
        return []
    return [p for p in sorted(base.rglob("*")) if p.is_file() and (suffixes is None or p.suffix in suffixes)
            and not any(part in SKIP_DIRS or part.startswith(".") for part in p.relative_to(base).parts[:-1])]


def _read(path: Path) -> str | None:
    try:
        return path.read_text(encoding="utf-8")
    except (UnicodeDecodeError, OSError):
        logs.swallowed(log, "_read: UnicodeDecodeError, OSError")
        return None


# ------------------------------------------------------------------ the places


def _spec(root: Path, name: str) -> list[dict]:
    """The vows: each line that names it, with its component and the part of the vow it is in."""
    word = _word(name)
    hits = []
    vows = [root / ".archvow" / "spec.vow", *sorted((root / ".archvow" / "components").glob("*/spec.vow"))]
    for path in vows:
        text = _read(path) if path.is_file() else None
        if text is None:
            continue
        rel = path.relative_to(root).as_posix()
        component = path.parent.name if path.parent.name != ".archvow" else "project"
        item = ""  # the item block the line is in: "decision 3", "example FATTRIB-014..."
        group = ""  # a plain key with indented lines under it: columns, init_answers...
        for number, line in enumerate(text.splitlines(), 1):
            if not line.strip() or line.lstrip().startswith("#"):
                continue
            if not line.startswith(" "):
                head = line.split()[0]
                item = " ".join(line.split()[:2]) if head in VOW_ITEMS else ""
                group = head if head not in VOW_ITEMS and len(line.split()) == 1 else ""
                key = head
            else:
                key = line.split()[0]
            if number == 1 or not word.search(line):
                continue
            if item:
                part = item if line.startswith(item) or not line.startswith(" ") else f"{item} {key}"
            elif group and line.startswith(" "):
                part = f"{group} {key}" if key != name else group
            else:
                part = {"spec": "ticket"}.get(key, key)
            hits.append(_hit("spec", rel, number, component, part, line))
    return hits


def _names(tree: ast.AST, name: str) -> tuple[list[tuple[int, str]], list[tuple[int, str]]]:
    """(definitions, uses) of `name` in a Python module: [(line, what)]."""
    defined: list[tuple[int, str]] = []
    used: list[tuple[int, str]] = []
    word = _word(name)
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == name:
            defined.append((node.lineno, f"def {name}(...)"))
        elif isinstance(node, ast.ClassDef) and node.name == name:
            defined.append((node.lineno, f"class {name}"))
        elif isinstance(node, (ast.Assign, ast.AnnAssign)):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            if any(isinstance(t, ast.Name) and t.id == name for t in targets) and node.col_offset == 0:
                defined.append((node.lineno, f"{name} = ..."))
        elif isinstance(node, ast.Name) and node.id == name and isinstance(node.ctx, ast.Load):
            used.append((node.lineno, "used"))
        elif isinstance(node, ast.Attribute) and node.attr == name:
            used.append((node.lineno, "attribute"))
        elif isinstance(node, (ast.Import, ast.ImportFrom)):
            if any((a.asname or a.name).split(".")[-1] == name or a.name == name for a in node.names):
                used.append((node.lineno, "import"))
        elif isinstance(node, ast.Constant) and isinstance(node.value, str) and word.search(node.value):
            first = next((i for i, line in enumerate(node.value.splitlines()) if word.search(line)), 0)
            used.append((min(node.lineno + first, node.end_lineno or node.lineno), "text"))
    return defined, used


def _owner(root: Path, data: dict, rel: str) -> str:
    from archvow.locate import owner

    return owner(root, data, rel)[0] or ""


def _code(root: Path, data: dict, name: str) -> list[dict]:
    """The package folders: where it is defined, where it is used."""
    from archvow.locate import enclosing

    hits = []
    for container in data.get("containers", []):
        for path in _files(root / container["path"], (".py",)):
            text = _read(path)
            if text is None or not _word(name).search(text):
                continue
            rel = path.relative_to(root).as_posix()
            lines = text.splitlines()
            try:
                defined, used = _names(ast.parse(text), name)
            except SyntaxError:
                logs.swallowed(log, "_code: SyntaxError")
                defined, used = [], [(n, "text") for n, line in enumerate(lines, 1) if _word(name).search(line)]
            component = _owner(root, data, rel)
            seen: set[int] = set()
            for number, what in defined:
                seen.add(number)
                hits.append(_hit("code", rel, number, component, "defined", lines[number - 1], what=what))
            for number, what in sorted(set(used)):
                if number in seen:
                    continue
                seen.add(number)
                around = enclosing(path, number)
                where = f"in {around['name']}()" if around and around["name"] != name else ""
                hits.append(_hit("code", rel, number, component, "used", lines[number - 1],
                                 what=" ".join(x for x in (what, where) if x)))
    return hits


def _tests(root: Path, data: dict, name: str) -> list[dict]:
    """The test functions that name it (in their code or their marks), with their marks."""
    from archvow.evidence import _marks, _test_files, describe

    hits = []
    word = _word(name)
    for path in _test_files(root):
        text = _read(path)
        if text is None or not word.search(text):
            continue
        rel = path.relative_to(root).as_posix()
        lines = text.splitlines()
        try:
            tree = ast.parse(text)
        except SyntaxError:
            logs.swallowed(log, "_tests: SyntaxError")
            hits += [_hit("tests", rel, n, _owner(root, data, rel), "text", line)
                     for n, line in enumerate(lines, 1) if word.search(line)]
            continue
        component = _owner(root, data, rel)
        for node in ast.walk(tree):
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) or not node.name.startswith("test"):
                continue
            first = min([node.lineno, *(d.lineno for d in node.decorator_list)])
            body = lines[first - 1:node.end_lineno or node.lineno]
            found = next((first + i for i, line in enumerate(body) if word.search(line)), None)
            if found is None:
                continue
            marks = describe(_marks(node))
            hits.append(_hit("tests", rel, found, component, node.name, lines[found - 1],
                             marks=marks or None))
    return hits


def _examples(root: Path, name: str) -> list[dict]:
    """The business examples' folders and files (actual/ is what a test wrote: not searched)."""
    from archvow.examples import ACTUAL, FOLDER

    hits = []
    base = root / FOLDER
    if not base.is_dir():
        return []
    for folder in sorted(p for p in base.glob("*/*") if p.is_dir()):
        component = folder.parent.name
        rel = folder.relative_to(root).as_posix()
        if folder.name == name:
            hits.append(_hit("examples", rel + "/", 0, component, "example", f"the folder of example {name}"))
        word = _word(name, ignore_case=True)
        for path in _files(folder):
            inside = path.relative_to(folder).as_posix()
            if inside.split("/")[0] == ACTUAL:
                continue
            text = _read(path)
            if text is None:
                continue
            for number, line in enumerate(text.splitlines(), 1):
                if word.search(line):
                    hits.append(_hit("examples", path.relative_to(root).as_posix(), number, component, inside, line,
                                     example=folder.name))
    return hits


def _briefs(root: Path, data: dict, name: str) -> list[dict]:
    """The briefs, line by line, with the section each line is in."""
    from archvow.briefs import HEADING_RE, brief_files, slug

    hits = []
    word = _word(name, ignore_case=True)
    for path in brief_files(root, data):
        text = _read(path)
        if text is None:
            continue
        rel = path.relative_to(root).as_posix()
        section = ""
        for number, line in enumerate(text.splitlines(), 1):
            heading = HEADING_RE.match(line)
            if heading:
                section = slug(heading.group(2))
            if word.search(line):
                hits.append(_hit("briefs", rel, number, "", f"#{section}" if section else rel, line))
    return hits


def _template(root: Path, data: dict, name: str) -> list[dict]:
    """A component type or a layer of the project's template."""
    from archvow.templates import load_template

    hits = []
    for container in data.get("containers", [])[:1]:
        template = load_template(mf.template_name(container)[0], root)
        kinds = [("component type", n) for n in template.component_types] + [("layer", n) for n in template.layer_names]
        for what, value in kinds:
            if value != name:
                continue
            where, line = f"template {template.data.get('name', mf.template_name(container)[0])}", 0
            for folder in reversed(list(getattr(template, "dirs", []) or [])):
                file = Path(folder) / "template.yaml"
                text = _read(file) if file.is_file() else None
                found = next((n for n, row in enumerate((text or "").splitlines(), 1)
                              if re.match(rf"\s*(-\s*name:\s*)?{re.escape(name)}:?\s*$", row)), 0)
                if found:
                    try:
                        where = file.resolve().relative_to(root.resolve()).as_posix()
                    except ValueError:
                        logs.swallowed(log, "_template: ValueError")
                        where = f"archvow/packs/{Path(folder).name}/template.yaml"
                    line = found
                    break
            hits.append(_hit("template", where, line, "", what, f"{what} {name}"))
    return hits


def _problems(report: Report, name: str) -> list[dict]:
    """The findings of `archvow check` whose message names it."""
    word = _word(name)
    return [_hit("problems", v.file, v.line, "", v.code, v.message, severity=v.severity)
            for v in report.violations if word.search(v.message)]


# ------------------------------------------------------------------ what it is, close names


def _summary(data: dict, groups: dict[str, list[dict]], name: str) -> str:
    """What the name is, when the spec or the code says it."""
    for container in data.get("containers", []):
        for comp in container.get("components", []):
            for symbol in comp.get("symbols") or []:
                if symbol.get("name") == name:
                    return f"a {symbol.get('kind', 'function')} of {comp['id']}"
            if any(e.get("name") == name for e in comp.get("examples") or []):
                return f"a business example of {comp['id']}"
            if name in (comp.get("columns") or {}):
                return f"a column of {comp['id']}"
            if comp.get("spec") == name:
                return f"the ticket of {comp['id']}"
    if any(h["part"] == "component type" for h in groups.get("template", [])):
        return "a component type"
    if any(h["part"] == "layer" for h in groups.get("template", [])):
        return "a layer"
    defined = [h for h in groups.get("code", []) if h["part"] == "defined"]
    if defined:
        return f"defined in {defined[0]['component'] or defined[0]['file']}"
    return ""


def known_names(root: Path, data: dict) -> dict[str, str]:
    """Every name archvow knows, and what it is: for the close names of a name found nowhere."""
    names: dict[str, str] = {}
    for container in data.get("containers", []):
        for comp in container.get("components", []):
            names.setdefault(comp["id"], "a component")
            for symbol in comp.get("symbols") or []:
                names.setdefault(str(symbol.get("name")), f"a {symbol.get('kind', 'function')} of {comp['id']}")
            for example in comp.get("examples") or []:
                names.setdefault(str(example.get("name")), f"a business example of {comp['id']}")
            for column in comp.get("columns") or {}:
                names.setdefault(str(column), f"a column of {comp['id']}")
            if comp.get("spec"):
                names.setdefault(str(comp["spec"]), f"the ticket of {comp['id']}")
    for item in [*(data.get("invariants") or []), *(data.get("hazards") or []), *(data.get("project_rules") or [])]:
        if item.get("id"):
            names.setdefault(str(item["id"]), "an item of the spec")
    return names


def search(root: Path, data: dict, name: str, report: Report) -> dict:
    """{name, summary, total, groups: [{group, title, hits}], close: [{name, what}]}."""
    found = {"spec": _spec(root, name), "code": _code(root, data, name), "tests": _tests(root, data, name),
             "examples": _examples(root, name), "briefs": _briefs(root, data, name),
             "template": _template(root, data, name), "problems": _problems(report, name)}
    total = sum(len(v) for v in found.values())
    close: list[dict] = []
    if not total:
        known = known_names(root, data)
        close = [{"name": n, "what": known[n]} for n in difflib.get_close_matches(name, list(known), n=5, cutoff=0.7)]
    return {"name": name, "summary": _summary(data, found, name), "total": total,
            "groups": [{"group": g, "title": TITLES[g], "hits": found[g]} for g in GROUPS if found[g]],
            "close": close}


def print_search(result: dict) -> None:
    """The search as the terminal shows it: the groups in order, at most SHOW_MAX lines each."""
    from archvow import ui

    name = result["name"]
    what = f" ({result['summary']})" if result["summary"] else ""
    print(ui.title(name) + ui.dim(f" - found in {result['total']} place{'' if result['total'] == 1 else 's'}{what}"))
    for group in result["groups"]:
        note = NOTES.get(group["group"])
        print("\n" + ui.title(group["title"]) + (ui.dim(f"  ({note})") if note else ""))
        shown = group["hits"][:SHOW_MAX]

        def part_of(hit: dict) -> str:
            return hit["part"] + (f" ({hit['what']})" if hit.get("what") else "") + (
                f" [{hit['marks']}]" if hit.get("marks") else "")
        width = min(max(len(h["component"] or "-") for h in shown), 24)
        size = min(max(len(part_of(h)) for h in shown), 36)
        for hit in shown:
            where = f"{hit['file']}:{hit['line']}" if hit["line"] else hit["file"]
            if group["group"] == "problems":
                code = ui.red(hit["part"]) if hit.get("severity") == "error" else ui.yellow(hit["part"])
                print(f"  {code}  {hit['text']}  " + ui.dim(where))
                continue
            text = hit["text"] if len(hit["text"]) <= 60 else hit["text"][:59] + "…"
            print(f"  {(hit['component'] or '-'):<{width}}  {part_of(hit):<{size}}  {text:<60}  " + ui.dim(where))
        if len(group["hits"]) > SHOW_MAX:
            print(ui.dim(f"  and {len(group['hits']) - SHOW_MAX} more (archvow show {name} --json)"))
