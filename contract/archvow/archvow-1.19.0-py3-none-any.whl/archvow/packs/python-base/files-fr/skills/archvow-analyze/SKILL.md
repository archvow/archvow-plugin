---
name: archvow-analyze
description: "Proposer les hazards, mises à l'écart et invariants d'un composant (ses questions de sûreté)"
---

À donner : <composant>.

Analyse les risques de ce composant, comme AGENTS.md définit « Analyse les risques de <composant> » : ce que la personne donne (un composant, une fonctionnalité ou un fichier)

Propose les commandes ; n'en lance aucune et n'écris aucun code.
