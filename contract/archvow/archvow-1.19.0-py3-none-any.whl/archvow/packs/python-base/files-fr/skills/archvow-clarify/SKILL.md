---
name: archvow-clarify
description: "Lister ce que la spec d'un composant ne définit pas, sous forme de questions - sans rien décider"
---

À donner : <composant>.

Lance `archvow prompt <composant> --clarify` pour le composant que la personne donne et fais la tâche qu'il affiche : liste ce que la spec de le composant que la personne nomme ne définit pas, sous forme de commandes `archvow question add`. Ne propose aucune réponse et n'écris aucun code.
