"""An answer saved from an AI draft (3.2): `drafted_with <tool>` and `draft edited|unchanged` beside its `by` and `on`.

The answer is the person's - they read the draft and saved it (archvow draft, then --drafted-with). These two keys
only say where it came from, for the reader of show, doc and the merge request's spec changes.
"""

from __future__ import annotations

from typing import Any


def mark(entry: dict[str, Any], tool: str | None, unchanged: bool = False) -> None:
    """Record on a saved answer that it came from an AI draft (or that it no longer does)."""
    entry.pop("drafted_with", None)
    entry.pop("draft", None)
    if tool:
        entry["drafted_with"] = tool
        entry["draft"] = "unchanged" if unchanged else "edited"


def note(entry: dict[str, Any]) -> str:
    """' (AI draft by claude-code, edited)', or '' for an answer a person wrote."""
    if not entry.get("drafted_with"):
        return ""
    return f" (AI draft by {entry['drafted_with']}, {entry.get('draft') or 'edited'})"


def view(entry: dict[str, Any]) -> dict[str, Any]:
    """What the IDEs read: {'drafted': {'tool': ..., 'edited': ...}} or {}."""
    if not entry.get("drafted_with"):
        return {}
    return {"drafted": {"tool": entry["drafted_with"], "edited": entry.get("draft") != "unchanged"}}
