"""`archvow draft <component> <question>`: one of the project's AI assistants drafts an answer; a person saves it.
"""

from __future__ import annotations

import argparse

from archvow import drafts
from archvow.cli.args import COMPONENT_HELP, Builder
from archvow.cli.output import print_result, project_root


def cmd_draft(args: argparse.Namespace) -> int:
    root = project_root(args)
    if args.prompt:
        text = drafts.prompt(root, args.component, args.question)
        print_result(args, {"component": args.component, "question": args.question.upper(), "prompt": text}, text)
        return 0
    found = drafts.run(root, args.component, args.question, args.tool)
    save = (f"archvow hazard add {args.component} {found['question']} <severity> \"...\""
            if found["question"].startswith("S") else f"archvow decision make {args.component} {found['question']} \"...\"")
    print_result(args, found, f"{found['title']}'s draft - read it, change what is wrong, then save it as yours:\n\n"
                              f"{found['draft']}\n\nSave: {save} --drafted-with {found['tool']}")
    return 0


def declare_draft(b: Builder) -> None:
    """`archvow draft`: its parser."""
    p = b.command("draft", cmd_draft, "let one of the project's AI assistants draft an answer; you read it and save it", True,
                  examples="""
        archvow draft orders_schema 2                  # the first AI assistant of the project installed here
        archvow draft orders_schema S1 --with codex    # a safety question, with another of the project's assistants
        archvow draft orders_schema 2 --prompt         # only the prompt, to paste in your AI chat
        """)
    p.add_argument("component", help=COMPONENT_HELP)
    p.add_argument("question", help="the question's number in archvow show: 2, P1, or a safety question S1")
    p.add_argument("--with", dest="tool", metavar="TOOL",
                   help="which of the project's AI assistants (default: the first one installed on this machine)")
    p.add_argument("--prompt", action="store_true", help="print what the AI assistant would read, and run nothing")
