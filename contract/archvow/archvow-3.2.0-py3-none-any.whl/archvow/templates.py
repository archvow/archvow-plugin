"""Templates: resolved by name, their chain (`extends`) merged, their files overlaid.

A template is a folder holding `template.yaml`, its files and its parts (templating/store.py says where they are
found). In a project, the names are those of its copies (.archvow/templates/), and its own additions
(.archvow/template/) apply last; outside one (init, `template check`), the sources.

`extends: [python-base, acme]` merges the bases left to right, a base reached twice counting once; at most one of
them brings layers (the stack), the others are building blocks. One merge rule: mappings merge key by key, lists
add, a list item with an `id` (or a `name`) replaces the base's item of the same id; a template removes something
only by saying so (`remove: [component_types.cli, component_types.model.edge_cases.shape]`).

Languages: `template.<lang>.yaml` overlays the texts of `template.yaml` in place (questions by id, layers by name,
other lists replaced) and `files-<lang>/` overrides files of `files/`. A project uses one language (manifest
`language`, English when absent); everything not translated falls back to the template's own text.
"""

from __future__ import annotations

import copy
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, cast

import yaml

from archvow import agents
from archvow.foundation import logs, once
from archvow.foundation.errors import TemplateError as TemplateError
from archvow.foundation.files import parse_yaml
from archvow.foundation.i18n import DEFAULT_LANGUAGE
from archvow.foundation.paths import PROJECT_REL
from archvow.model import vowfile
from archvow.templating import copies, regimes, store
from archvow.templating.merge import (
    apply_layer_names,
    inherit,
    overlay,
    remove,
    rename_words,
    renames,
    validate,
)
from archvow.templating.regimes import Regime

log = logs.get("templates")



def edge_case_text(item: object) -> str:
    """A question of a component type: {id, question, suggested, choices} (a string in a vow's own list)."""
    return str(item["question"]) if isinstance(item, dict) else str(item)


def edge_case_id(item: object) -> str:
    return str(item.get("id") or "") if isinstance(item, dict) else ""


def open_decision(item: object) -> dict[str, Any]:
    """A component's decision for one of its type's questions, not answered yet."""
    return {**({"id": edge_case_id(item)} if edge_case_id(item) else {}), "question": edge_case_text(item),
            "answer": None}


def edge_case_suggestion(item: object) -> str | None:
    """The template's suggested answer to a question, when it gives one."""
    return str(item["suggested"]) if isinstance(item, dict) and item.get("suggested") else None


def edge_case_choices(item: object) -> list[str]:
    """The answers a question offers to start from, when it has no safe default (none pre-selected)."""
    return [str(c) for c in item.get("choices") or []] if isinstance(item, dict) else []


@dataclass
class Template:
    """A fully resolved template (inheritance and language already applied)."""

    name: str  # as asked: one name, or several joined by ", " (a container's `template: a, b`)
    data: dict[str, Any]
    dirs: list[Path] = field(default_factory=list)  # the chain's folders, bases first, the project's own last
    language: str = DEFAULT_LANGUAGE
    chain: tuple[str, ...] = ()  # the chain's names in merge order (bases first)
    agent_names: tuple[str, ...] = ()  # the agents the chain describes (`ai_tools` offers them)
    regimes: tuple[Regime, ...] = ()  # the privacy regimes the chain holds (`rules` offers them)

    @property
    def version(self) -> str:
        return str(self.data.get("version", "0.0.0"))

    @property
    def ref(self) -> str:
        """How project.vow, `catalog` and `init` name it."""
        return self.name

    @property
    def names(self) -> list[str]:
        return split_names(self.name)

    @property
    def layers(self) -> list[dict[str, Any]]:
        return cast(list[dict[str, Any]], self.data.get("layers", []))

    def rename_layers(self, text: str) -> str:
        """A text of the template's files with the layers' folders the template names (`layer_names`)."""
        return str(rename_words(text, renames(self.data)))

    def layer(self, name: str) -> dict[str, Any] | None:
        return next((layer for layer in self.layers if layer["name"] == name), None)

    @property
    def layer_names(self) -> list[str]:
        return [layer["name"] for layer in self.layers]

    @property
    def component_types(self) -> dict[str, Any]:
        return cast(dict[str, Any], self.data.get("component_types", {}))

    def kinds(self, type_name: str) -> list[str]:
        """The kinds a component type offers (`kinds:`, e.g. a reader: files, table, jdbc...), default first."""
        ctype = self.component_types.get(type_name) or {}
        names = list(ctype.get("kinds") or {})
        default = ctype.get("default_kind")
        return [default, *[n for n in names if n != default]] if isinstance(default, str) and default in names else names

    def type_of(self, comp: dict[str, Any]) -> dict[str, Any]:
        """A component's type as it applies to it: the type, with its kind's own description,
        symbols, questions, safety questions and hints over it (a reader of kind jdbc...)."""
        ctype = dict(self.component_types.get(comp.get("type", "")) or {})
        kinds = ctype.pop("kinds", None) or {}
        kind = comp.get("kind") or ctype.get("default_kind")
        ctype.pop("default_kind", None)
        if kind not in kinds:
            return ctype
        own = kinds.get(kind) or {}
        merged = overlay(ctype, own)
        for key in ("edge_cases", "safety_decisions"):  # a kind's own questions replace the type's: never mixed
            if key in own:
                merged[key] = copy.deepcopy(own[key])
        return merged

    @property
    def rules(self) -> dict[str, Any]:
        return cast(dict[str, Any], self.data.get("rules", {}))

    def rule_set(self, name: str) -> dict[str, Any]:
        """The settings of one of archvow's rule sets the template switches on (`rule_sets: {fastapi: {...}}`)."""
        sets = self.data.get("rule_sets") or {}
        return dict(sets.get(name) or {}) if isinstance(sets, dict) else {}

    def suggested_answers(self, comp: dict[str, Any]) -> dict[str, str]:
        """{question: suggested answer} for a component: its type's questions, or a starting component's."""
        initial = next((c for c in self.data.get("initial_components", []) or [] if c.get("id") == comp.get("id")),
                       None)
        source = initial if initial is not None else self.type_of(comp)
        return {edge_case_text(q): s for q in source.get("edge_cases") or [] if (s := edge_case_suggestion(q))}

    def choices(self, comp: dict[str, Any]) -> dict[str, list[str]]:
        """{question: [answers to start from]} for a component's questions that have no default."""
        initial = next((c for c in self.data.get("initial_components", []) or [] if c.get("id") == comp.get("id")),
                       None)
        source = initial if initial is not None else self.type_of(comp)
        return {edge_case_text(q): c for q in source.get("edge_cases") or [] if (c := edge_case_choices(q))}

    def find(self, rel: str) -> Path:
        """Find a file of the chain, the most specific template winning."""
        for directory in reversed(self.dirs):
            candidate = directory / rel
            if candidate.is_file():
                return candidate
        raise TemplateError(f"{self.name}: file '{rel}' not found in its templates")

    def skeleton_files(self) -> dict[str, Path]:
        """Relative path -> source path for the project skeleton (child overrides base)."""
        result: dict[str, Path] = {}
        folders = ["files"] if self.language == DEFAULT_LANGUAGE else ["files", f"files-{self.language}"]
        for directory in self.dirs:
            for folder in folders:  # a translated file replaces the original of the same template
                root = directory / folder
                if not root.is_dir():
                    continue
                for path in sorted(root.rglob("*")):
                    if path.is_file() and store.kept(path, root):  # what the copy's digest sees (ARCH060)
                        result[path.relative_to(root).as_posix()] = path
        return result

    def _question_summary(self, question: dict[str, Any]) -> dict[str, Any]:
        """Questions as the IDE wizard needs them: choices resolved, flags explicit."""
        result = dict(question)
        override = (self.data.get("questions_defaults") or {}).get(question.get("id"))
        if override is not None:
            result["default"] = override
        elif question.get("choices_from") == "rule_families" and question.get("default") is None:
            result["default"] = ",".join(self.recommended_families())
        source = question.get("choices_from")
        if source == "rule_families":
            result["choices"] = [*self.selectable_families(), "all", "none"]
        elif source == "agents":  # any agent's name; the agents the templates describe are offered
            result["suggestions"] = [*self.agent_names, "none"]
        result.setdefault("required", False)
        result.setdefault("multiple", False)
        return result

    def _families(self) -> list[tuple[str, dict[str, Any]]]:
        """(name, entry) of every rule family, once per name (its regimes' included)."""
        found: dict[str, dict[str, Any]] = {}
        for prefix, entry in (self.data.get("rule_families") or {}).items():
            found.setdefault(str((entry or {}).get("name") or prefix).upper(), entry or {})
        return list(found.items())

    @property
    def COMPLIANCE(self) -> tuple[str, ...]:
        """The families that bring questions, registers or views and are kept as `compliance` in project.vow (TST,
        the regimes: DORA, GDPR...): `compliance: true` in `rule_families`."""
        return tuple(name for name, entry in self._families() if entry.get("compliance"))

    def selectable_families(self) -> list[str]:
        """The rule families the `rules` answer chooses from, by name, in the project doc's reading order: the code families
        (ARCH, STYLE, SPARK...), the regimes (DORA, GDPR, GLBA, US-PRIVACY...), then TST. PRIV is not chosen: it
        is on with any privacy regime."""
        entries = [(name, entry) for name, entry in self._families() if not entry.get("automatic")]
        code = [n for n, e in entries if not e.get("compliance")]
        regimes = [n for n, e in entries if e.get("regime")]
        return code + regimes + [n for n, e in entries if e.get("compliance") and not e.get("regime")]

    def family_title(self, name: str) -> str:
        return next((str((v or {}).get("title") or "") for k, v in (self.data.get("rule_families") or {}).items()
                     if str((v or {}).get("name") or k).upper() == name), "")

    def recommended_families(self) -> list[str]:
        """The `rules` default: every family but those marked `default: false` (DORA, for banks and insurers; the
        US regimes)."""
        entries = dict(self._families())
        return [n for n in self.selectable_families() if entries.get(n, {}).get("default", True)]

    def summary(self) -> dict[str, Any]:
        """JSON-friendly description, used by `catalog --json` (IDE wizard)."""
        return {
            "name": self.name,
            "version": self.version,
            "default": bool(self.data.get("default")),
            "chain": list(self.chain),
            "language": self.data.get("language"),
            "kind": self.data.get("kind"),
            "style": self.data.get("style"),
            "description": self.data.get("description", ""),
            "extends": self.data.get("_extends_chain", []),
            "questions": [self._question_summary(q) for q in self.data.get("questions", [])],
            "layers": [
                {"name": layer["name"], "description": layer.get("description", ""),
                 "may_import": layer.get("may_import", [])}
                for layer in self.layers
            ],
            "component_types": {
                key: {
                    "layer": value.get("layer"),
                    "description": value.get("description", ""),
                    "addable": value.get("addable", True),
                    "name_pattern": value.get("name_pattern"),
                    "name_hint": value.get("name_hint", ""),
                    "module": value.get("module"),
                    "symbols": value.get("symbols", []),
                    "implicit_dependency": bool(value.get("implicit_dependency", False)),
                    "signature_overridable": bool(value.get("signature_overridable", False)),
                    "kinds": self._kinds_summary(key),
                }
                for key, value in self.component_types.items()
            },
            "source": str(self.dirs[-1]) if self.dirs else None,
            "abstract": bool(self.data.get("abstract")),
        }


    def _kinds_summary(self, type_name: str) -> list[dict[str, Any]]:
        """`component add <type> <name> -k <kind>`: each kind with what it is, the default one first (an IDE
        offers them in a list). The default kind's own description, else the type's."""
        ctype = self.component_types.get(type_name) or {}
        declared = ctype.get("kinds") or {}
        default = ctype.get("default_kind")
        return [{"name": kind, "description": str((declared.get(kind) or {}).get("description")
                                                  or (ctype.get("description", "") if kind == default else "")),
                 "default": kind == default}
                for kind in self.kinds(type_name)]


def split_names(ref: str | list[str]) -> list[str]:
    """`fastapi-service`, `fastapi-service, acme-health` or a list: the names, in order."""
    items = ref if isinstance(ref, list) else str(ref).split(",")
    return [str(item).strip() for item in items if str(item).strip()]


def available(project_root: Path | None, extra: tuple[Path, ...] = (), from_sources: bool = False) -> dict[str, Path]:
    """name -> its folder, for every template a name may be resolved to here: in a project, its copies; outside
    one (or `from_sources`, or with `extra`: a template being written or checked), the sources."""
    key = ("templates", str(project_root), extra, from_sources)
    return dict(once.remember(key, lambda: _available(project_root, extra, from_sources)))


def _available(project_root: Path | None, extra: tuple[Path, ...], from_sources: bool) -> dict[str, Path]:
    if not extra and not from_sources and copies.has_copies(project_root):
        return copies.project_copies(project_root)
    given = tuple(store.source_of(folder)[0] for folder in extra)
    return {name: folder for name, (folder, _) in store.find_in(store.default_sources(given)).items()}


discover = available


def project_language(project_root: Path | None) -> str:
    """The language of the project in `project_root` (English when it names none, or no project)."""
    if project_root is None:
        return DEFAULT_LANGUAGE
    path = project_root / PROJECT_REL
    try:
        stamp = path.stat().st_mtime_ns
    except OSError:
        logs.swallowed(log, "project_language: OSError")
        return DEFAULT_LANGUAGE
    cached = _LANGUAGE_CACHE.get(path)
    if cached is None or cached[0] != stamp:
        try:
            text = path.read_text(encoding="utf-8")
            data = vowfile.loads(text, path.name)[2]
        except (vowfile.VowError, OSError):
            logs.swallowed(log, "project_language: vowfile.VowError, OSError")
            data = {}
        language = data.get("language") if isinstance(data, dict) else None
        cached = (stamp, str(language or DEFAULT_LANGUAGE))
        _LANGUAGE_CACHE[path] = cached
    return cached[1]


_LANGUAGE_CACHE: dict[Path, tuple[int, str]] = {}


def load_template(name: str | list[str], project_root: Path | None, language: str | None = None,
                  extra: tuple[Path, ...] = (), from_sources: bool = False) -> Template:
    """A template by name (or a container's list of names), its chain merged, in the project's language.

    `language` defaults to the language of the project in `project_root` (English if none). Built once per
    reading command (foundation/once.py); the template is shared then: never changed by a caller.
    """
    if language is None:
        language = project_language(project_root)
    names = tuple(split_names(name))
    key = ("template", names, str(project_root), language, extra, from_sources)
    return once.remember(key, lambda: _load_template(names, project_root, language, extra, from_sources))


def chain_of(names: list[str] | tuple[str, ...], folders: dict[str, Path], _path: tuple[str, ...] = ()) -> list[str]:
    """The templates to merge for `names`, bases first, each once (a base reached twice counts once)."""
    order: list[str] = []
    for name in names:
        if name in _path:
            raise TemplateError(f"template inheritance cycle: {' -> '.join((*_path, name))}")
        if name not in folders:
            raise TemplateError(f"unknown template '{name}' (available: {', '.join(sorted(folders)) or 'none'})",
                                hint=_unknown_hint(_path))
        for base in chain_of(store.meta(folders[name]).extends, folders, (*_path, name)):
            if base not in order:
                order.append(base)
        if name not in order:
            order.append(name)
    return order


def _unknown_hint(path: tuple[str, ...]) -> str:
    if path:
        return f"{path[-1]} extends it: give the folder that holds it (--from <folder>), or install its package"
    return "archvow catalog lists the templates; a template of your own: -t <its folder>"


def _raw(folder: Path, language: str) -> dict[str, Any]:
    """A template's own data, in a language (its translation overlaid)."""
    return copy.deepcopy(once.remember(("template raw", str(folder), language), lambda: read_raw_texts(folder, language)))


def read_raw_texts(folder: Path, language: str) -> dict[str, Any]:
    raw = store.read_raw(folder) if (folder / store.MANIFEST).is_file() else {}
    translated = folder / f"template.{language}.yaml"
    if language != DEFAULT_LANGUAGE and translated.is_file():
        raw = overlay(raw, _read_yaml(translated))
    return raw


def _load_template(names: tuple[str, ...], project_root: Path | None, language: str, extra: tuple[Path, ...],
                   from_sources: bool) -> Template:
    if not names:
        raise TemplateError("no template named", hint="archvow catalog lists them")
    folders = available(project_root, extra, from_sources)
    order = chain_of(names, folders)
    raws = {name: _raw(folders[name], language) for name in order}
    _one_stack(names, order, folders, raws)
    for name in order:
        store.require_fit(store.meta(folders[name]))
    data: dict[str, Any] = {}
    dirs = [folders[name] for name in order]
    for name in order:
        data = _apply(data, raws[name], name)
    own = None if from_sources or extra else copies.own_folder(project_root)
    if own is not None:  # the project's own additions, last
        data = _apply(data, read_raw_texts(own, language), store.OWN_NAME)
        dirs.append(own)
    first = raws[names[0]]
    for key in ("version", "description", "abstract", "default", "archvow", "languages"):
        data.pop(key, None)
        if key in first:
            data[key] = copy.deepcopy(first[key])
    data["abstract"] = bool(first.get("abstract"))
    data["name"] = ", ".join(names)
    data["_extends_chain"] = [n for n in reversed(order) if n not in names]
    validate(", ".join(names), data)
    data = apply_layer_names(", ".join(names), data)
    found = Template(name=", ".join(names), data=data, dirs=dirs, language=language,
                     chain=(*order, *((store.OWN_NAME,) if own is not None else ())),
                     agent_names=tuple(sorted(agents.profiles(project_root, tuple(dirs)))))
    return _with_regimes(found)


def _one_stack(names: tuple[str, ...], order: list[str], folders: dict[str, Path], raws: dict[str, dict[str, Any]]) -> None:
    """At most one base of an `extends` list (and of a container's list) brings layers: the stack; the others are
    building blocks (rules, agents, regimes, defaults, files, component types)."""
    def stacked(name: str) -> bool:
        return any(raws[n].get("layers") for n in chain_of([name], folders))
    lists = [("the template list", list(names))]
    lists += [(f"template {n}: extends", list(store.meta(folders[n]).extends)) for n in order]
    for where, items in lists:
        stacks = [n for n in items if stacked(n)]
        if len(stacks) > 1:
            raise TemplateError(f"{where}: {', '.join(stacks)} each bring layers - one stack only",
                                hint="the other templates of the list are building blocks: rules, agents, regimes, "
                                "defaults, files and component types, no layers")


def _apply(data: dict[str, Any], raw: dict[str, Any], name: str) -> dict[str, Any]:
    """One template of the chain over what its bases gave: its removals first, then its data."""
    for path in raw.get("remove") or []:
        remove(data, str(path), name)
    return inherit(data, {k: v for k, v in raw.items() if k not in ("extends", "remove")})


def _with_regimes(template: Template) -> Template:
    """The template with the regimes of its chain: each one a compliance rule family (its prefix -> name, title,
    `rule_set`), so the `rules` answer offers it and the check switches its codes."""
    found = tuple(regimes.of_folders(tuple(template.dirs), template.language).values())
    families = dict(template.data.get("rule_families") or {})
    for regime in found:
        families[regime.prefix] = regime.family()
    template.data["rule_families"] = families
    template.regimes = found
    return template


def _read_yaml(path: Path) -> dict[str, Any]:
    try:
        data = parse_yaml(path.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError as exc:
        raise TemplateError(f"{path}: invalid YAML: {exc}") from exc
    if not isinstance(data, dict):
        raise TemplateError(f"{path}: expected a mapping at top level")
    return data


def templates_of(root: Path, data: dict[str, Any]) -> dict[str, Template]:
    """Container id -> its template (containers whose template cannot load are left out)."""
    found = {}
    for container in data.get("containers", []):
        try:
            found[container["id"]] = load_template(template_name(container)[0], root)
        except TemplateError:
            logs.swallowed(log, "templates_of: TemplateError")
            continue
    return found


def template_name(container_data: dict[str, Any]) -> tuple[str, str | None]:
    """A container's template: (its name, or its names joined by ", "; None - the versions are in project.vow's
    `templates`). archvow 2's `archvow/fastapi-service@2.8.0` is read as its name: a 2.x project keeps its words."""
    return ", ".join(name.split("@", 1)[0].rsplit("/", 1)[-1] for name in split_names(container_data["template"])), None
