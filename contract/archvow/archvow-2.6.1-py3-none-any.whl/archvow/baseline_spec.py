"""`check --base`: the guards the spec itself holds, beside the rule settings that baseline.py compares.

Each of these taken away or loosened since the base is ARCH020:

* a project rule (R1, R2...): removed, reworded, or given a scope that leaves out a component it applied to;
* a pack project.vow records: removed, or another version or digest (its rules, regimes, agent profiles and
  templates may say less);
* a column of a component: made less personal, untagged, no longer pseudonymised or removed, or taken out of
  the spec; a decision answered then removed.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from archvow.model.spec import to_accept
from archvow.packs.store import recorded

RANK = {"none": 0, "personal": 1, "special": 2}


Weakened = Callable[..., None]  # weakened(message, file, line=0): a guard made weaker (baseline.compare)

def compare_spec(base: dict[str, Any], now: dict[str, Any], weakened: Weakened, where: str) -> None:
    _project_rules(base, now, weakened, where)
    _packs(base, now, weakened, where)
    _columns(base, now, weakened, where)


def _scope_words(scope: dict[str, Any]) -> str:
    if scope.get("all"):
        return "every component"
    if scope.get("type"):
        return f"type {scope['type']}"
    return ", ".join(str(c) for c in scope.get("components") or []) or "no component"


def _covers(now: dict[str, Any], before: dict[str, Any]) -> bool:
    """Whether scope `now` applies to every component `before` applied to (a type is a type: kept or not)."""
    if now.get("all"):
        return True
    if before.get("components") is not None and now.get("components") is not None:
        return set(before["components"]) <= set(now["components"])
    return now == before


def _project_rules(base: dict[str, Any], now: dict[str, Any], weakened: Weakened, where: str) -> None:
    current = {str(r.get("id")): r for r in now.get("project_rules") or []}
    for rule in [r for r in base.get("project_rules") or [] if not to_accept(r)]:  # an AI's proposal guards nothing yet
        rid, after = str(rule.get("id")), current.get(str(rule.get("id")))
        if after is None:
            weakened(f"project rule {rid} removed ('{rule.get('text')}')", where)
        elif after.get("text") != rule.get("text"):
            weakened(f"project rule {rid} reworded from '{rule.get('text')}' to '{after.get('text')}'", where)
        elif not _covers(after.get("scope") or {}, rule.get("scope") or {}):
            weakened(f"project rule {rid} narrowed from {_scope_words(rule.get('scope') or {})} to "
                     f"{_scope_words(after.get('scope') or {})}", where)


def _packs(base: dict[str, Any], now: dict[str, Any], weakened: Weakened, where: str) -> None:
    after = recorded(now)
    for name, entry in sorted(recorded(base).items()):
        new = after.get(name)
        if new is None:
            weakened(f"pack {name} removed (its rules, regimes and agent profiles no longer apply)", where)
        elif (new.get("version"), new.get("digest")) != (entry.get("version"), entry.get("digest")):
            weakened(f"pack {name} changed from {entry.get('version')} ({entry.get('digest')}) to "
                     f"{new.get('version')} ({new.get('digest')}): its rules and templates may say less", where)


def _columns(base: dict[str, Any], now: dict[str, Any], weakened: Weakened, where: str) -> None:
    """A column made less personal (special -> personal -> none) or taken out of the spec, a tag removed (a
    regime no longer covers it), or a pseudonymisation or removal dropped, weakens the personal-data guards."""

    def components(data: dict[str, Any]) -> dict[str, Any]:
        return {c["id"]: c for ct in data.get("containers", []) or [] for c in ct.get("components", [])}

    old = components(base)
    for cid, comp in components(now).items():
        before = old.get(cid) or {}
        for name, kind in (before.get("columns") or {}).items():
            after = (comp.get("columns") or {}).get(name)
            if after is None and RANK.get(kind, 0):
                weakened(f"column {cid}.{name} taken out of the spec, was {kind}", where)
            elif after is not None and RANK.get(after, 0) < RANK.get(kind, 0):
                weakened(f"column {cid}.{name} classified {after}, was {kind}", where)
        for name, tags in (before.get("column_tags") or {}).items():
            lost = set(tags or []) - set((comp.get("column_tags") or {}).get(name) or [])
            if lost:
                weakened(f"column {cid}.{name} no longer tagged {', '.join(sorted(lost))}", where)
        for key in ("removes", "pseudonymises"):
            dropped = set((before.get("privacy") or {}).get(key) or []) - set((comp.get("privacy") or {}).get(key) or [])
            for name in sorted(dropped):
                weakened(f"{cid} no longer {key} {name}", where)
        now_questions = {d.get("question") for d in comp.get("decisions", []) or []}
        for decision in before.get("decisions", []) or []:  # `archvow question remove <component> <n>`: an answer is gone
            if (decision.get("answer") or "").strip() and decision.get("question") not in now_questions:
                weakened(f"{cid}: decision removed ('{decision.get('question')}' -> {decision.get('answer')})", where)
